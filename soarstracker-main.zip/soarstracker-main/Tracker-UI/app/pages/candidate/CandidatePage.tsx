// src/pages/candidate/CandidatePage.tsx

import React, { useEffect, useState, useCallback, useRef } from "react";
import { DataGrid } from '@mui/x-data-grid';
import { useNavigate, useLocation } from "react-router";
import SearchIcon from '@mui/icons-material/Search';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityIcon from '@mui/icons-material/Visibility';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import Card from "~/components/ui/Card";
import CandidateForm from './Candidateform';
import candidateService from '~/services/candidate/candidate.service';
import type { Candidate, CandidateStatus } from '~/pages/types/types';
import TuneIcon from '@mui/icons-material/Tune';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import StatusBadge from "../student/StatusBadge";
import CandidateDetailsDrawer from './CandidateDetailsDrawer';
import UploadCandidateModal from "./BulkCandidate";
import userService from "~/services/employee/employee.service";
import { HomeIcon } from "~/components/ui/Icons";
import CandidateAssign from "./CandidateAssign";
import {fetchCandidatureStatuses }from "./CandidateUtils";
import CustomTooltip from "~/components/layout/tooltip";
import * as XLSX from 'xlsx';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import clientService from "~/services/client/client.services";

const CandidatePage: React.FC = () => {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState(searchTerm);
  const [statusFilter, setStatusFilter] = useState<string>("Active");
  const location = useLocation();
  const navigate = useNavigate();
  const [candidatureStatusFilter, setCandidatureStatusFilter] = useState<string>(location.state?.candidatureStatus || '');
  const [selectedClientId, setSelectedClientId] = useState<string>(location.state?.clientId || '');
  const [showOptions, setShowOptions] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [candidateToUpdate, setCandidateToUpdate] = useState<Candidate | null>(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalEntries, setTotalEntries] = useState(0);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const debounceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [showFilter, setShowFilter] = useState<string>("");
  const [availableCandidatureStatuses, setAvailableCandidatureStatuses] = useState<string[]>([]);
  const [clientList, setClientList] = useState<{ id: string; clientName: string }[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [genderFilter, setGenderFilter] = useState<string>('All');
  
  const toggleOptions = () => setShowOptions((prev) => !prev);
  const token = localStorage.getItem("userToken");
  const decoded = token ? JSON.parse(atob(token.split('.')[1])) : null;
  const userId = decoded?.userId || '';
  const role = decoded?.roles?.[0] || '';
  const username = decoded?.sub || '';

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowOptions(false);
      }
    };
    setShowFilter(role === 'RECRUITER' ? "Assigned To " + username : "All Candidates");
    if (showOptions) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showOptions, role, username]);

  useEffect(() => {
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }
    debounceTimeoutRef.current = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 500);
    return () => {
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, [searchTerm]);


  const handleDownloadCandidates = async () => {
    try {
      const response = await candidateService.getAll(0, 10000, '', '', '');
      let candidates = response.content || [];
      candidates = candidates.map(({ ...rest }) => rest);
      const worksheet = XLSX.utils.json_to_sheet(candidates);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Candidates');
      XLSX.writeFile(workbook, 'candidates.xlsx');
    } catch (error) {
      alert('Failed to download candidate data.');
    }
  };
  const fetchCandidates = useCallback(async () => {
    if (loading) return;
    setLoading(true);

    try {
      let combinedCandidates: Candidate[] = [];
      let response;
      if (role === 'RECRUITER' && showFilter === "Assigned To " + username) {
        let assignedCandidates: Candidate[] = [];
        let createdCandidates: Candidate[] = [];

        try {
          const recruiterResponse = await userService.getAssignedCandidatesByUserId(userId, currentPage - 1, rowsPerPage, statusFilter, candidatureStatusFilter);
          const recruiterCreatedResponse = await userService.getCreatedCandidatesByUserId(userId, currentPage - 1, rowsPerPage, statusFilter, candidatureStatusFilter);
          assignedCandidates = recruiterResponse?.data?.records || [];
          createdCandidates = recruiterCreatedResponse?.data?.records || [];
        } catch (error: any) {
          showSnackbar(error?.response?.data?.error?.message || "Failed to fetch assigned candidates", "error");
        }

        const candidateMap = new Map<string, Candidate>();
        [...assignedCandidates, ...createdCandidates].forEach((c) => {
          if (c?.id) candidateMap.set(c.id, c);
        });

        combinedCandidates = Array.from(candidateMap.values());
      } else if (showFilter === "All Candidates") {

        response = await candidateService.getAll(
          currentPage - 1,
          rowsPerPage,
          debouncedSearchTerm || "",
          statusFilter || "",
          candidatureStatusFilter || "",
          "createDate",
          "desc",
          selectedClientId,
          genderFilter === 'All' ? '' : genderFilter
        );

        combinedCandidates = (response?.content || []).filter((c: Candidate) => c && c.id);
      }

      setCandidates(combinedCandidates);
      setTotalEntries(response?.totalElements || combinedCandidates.length || 0);

    } catch (error: any) {
      let errorMessage = "Failed to fetch candidates.";
      if (error.response?.status === 401) {
        errorMessage = "Unauthorized: Please log in again.";
      } else if (
        error.response?.status === 404 &&
        error.response?.data?.error?.message === "No candidates found"
      ) {
        setCandidates([]);
        setTotalEntries(0);
      } else if (error.code === "ERR_NETWORK") {
        errorMessage = "Network error: Check your connection or server status.";
        navigate("/")
      } else {
        errorMessage = error?.response?.data?.message || error?.response?.data?.error?.message || "Failed to fetch candidates.";
      }
      showSnackbar(errorMessage, "error");
    } finally {
      setLoading(false);
    }
  }, [
    currentPage,
    rowsPerPage,
    debouncedSearchTerm,
    statusFilter,
    showFilter,
    candidatureStatusFilter,
    role,
    userId,
    username,
    selectedClientId,
   navigate,
    genderFilter,
  ]);

  useEffect(() => {
    fetchCandidates();
  }, [fetchCandidates]);

  useEffect(() => {
    fetchCandidatureStatuses().then(statuses => {
      setAvailableCandidatureStatuses(statuses);
    })
  }, []);

  useEffect(() => {
    const fetchClients = async () => {
      try {
        const response = await clientService.getAll(0, 1000, "", "ACTIVE", "createDate", "desc");
        const clients = response?.content || [];
        setClientList(clients);
      } catch (error) {
        showSnackbar("Failed to fetch clients", "error");
      }
    };

    fetchClients();
  }, []);


  const showSnackbar = (message: string, severity: "success" | "error" = "success") => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  };

  const handleEdit = (candidate: Candidate | null) => {
    setSelectedCandidate(candidate);
    setIsEditMode(!!candidate);
    setShowForm(true);
    setShowOptions(false);
  };

  const handleDeleteClick = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setShowDeleteModal(true);
  };

  const handleViewDetails = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setShowDetailsModal(true);
  };

  const handleStatusClick = (candidate: Candidate) => {
    setCandidateToUpdate(candidate);
    setShowStatusModal(true);
  };

  const confirmStatusChange = async () => {
    if (!candidateToUpdate?.id) return;
    try {
      const payload = { status: "active" as CandidateStatus };
      await candidateService.update(candidateToUpdate.id, payload);
      showSnackbar("Candidate status updated to Active.", "success");
      setStatusFilter("Active");
      fetchCandidates();
    } catch (error: any) {
      const errorResponse = error?.response?.data;
      if (errorResponse?.data) {
        let errorMessage = '';
        if (errorResponse.data.PHONE) {
          errorMessage += errorResponse.data.PHONE + ' ';
        }
        if (errorResponse.data.EMAIL) {
          errorMessage += errorResponse.data.EMAIL;
        }
        showSnackbar(errorMessage.trim() || "Failed to update candidate status.", "error");
      } else {
        showSnackbar("Failed to update candidate status.", "error");
      }
    } finally {
      setShowStatusModal(false);
      setCandidateToUpdate(null);
    }
  };

  const confirmDelete = async () => {
    if (!selectedCandidate?.id) return;
    try {
      await candidateService.delete(String(selectedCandidate.id));
      showSnackbar('Candidate deleted successfully!', "success");
      fetchCandidates();
    } catch (error) {
      showSnackbar('Failed to delete candidate.', "error");
    } finally {
      setShowDeleteModal(false);
      setSelectedCandidate(null);
    }
  };

  return (
    <div className="h-[calc(100vh-100px)]">
      <CustomSnackbar
        open={snackbarOpen}
        message={snackbarMessage}
        severity={snackbarSeverity}
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={3000}
      />

      <div>
        <div className="flex items-center">
          <div className="flex items-center text-sm text-gray-600">
            <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
            <a
              href="/dashboard"
              className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
            >
              Dashboard
            </a>
          </div>
          <span className="mx-2 text-gray-400">/</span>
          <div className="text-sm text-gray-600">
            Candidates
          </div>
        </div>
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            Candidate Management
          </h1>
          <div className="flex items-center gap-3">
            <div className="relative inline-block text-left" ref={dropdownRef}>
              <button
                onClick={toggleOptions}
                className="flex items-center gap-2 font-bold rounded-lg mb-1 px-3.5 py-2 shadow transition cursor-pointer"
                style={{
                  backgroundColor: "#0A2463",
                  color: "white",
                  letterSpacing: "0.5px",
                  fontSize: "1rem",
                }}
              >
                Candidate Register
                <ArrowDropDownIcon sx={{ fontSize: 18 }} />
              </button>
              {showOptions && (
                <div className="absolute right-0 z-20 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg">
                  <button
                    onClick={() => handleEdit(null)}
                    className="block w-full px-4 py-2 text-gray font-semibold hover:bg-gray-100"
                  >
                    New Candidate
                  </button>
                  <button
                    onClick={() => {
                      setShowUploadModal(true);
                      setShowOptions(false);
                    }}
                    className="block w-full px-4 py-2 text-gray font-semibold hover:bg-gray-100 rounded-b-lg"
                  >
                    Upload CSV
                  </button>
                </div>
              )}
            </div>
            {(role === 'COMPANY_ADMIN' || role === 'MANAGER') && (
              <CustomTooltip title="Download Candidates" placement="top">
                <button
                  onClick={handleDownloadCandidates}
                  className="flex items-center gap-2 font-bold rounded-lg mb-1 px-3.5 py-2 shadow transition cursor-pointer"
                  style={{
                    backgroundColor: "#0A2463",
                    color: "white",
                    letterSpacing: "0.5px",
                    fontSize: "1rem",
                  }}
                >
                  <CloudDownloadIcon sx={{ fontSize: 18 }} />
                  Download
                </button>
              </CustomTooltip>
            )}
          </div>
        </div>
      </div>

      <Card className="py-3 mb-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative w-full md:w-96">
            <SearchIcon
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
              sx={{ fontSize: 18 }}
            />
            <input
              type="text"
              placeholder="Search by name, email, phone, job ID, status..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
            />
          </div>
          <div className="ml-auto relative">
            <button
              onClick={() => setShowFilters((prev) => !prev)}
              className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-gray-200 cursor-pointer"
              title="Filter"
            >
              <TuneIcon />
            </button>

            {showFilters && (
              <div className="absolute z-10 right-0 mt-2 w-[260px] bg-white border border-gray-200 rounded-lg shadow-lg p-4 space-y-3">
                {role === 'RECRUITER' && (
                  <div>
                    <label className="block text-xs font-medium mb-1">Candidate View</label>
                    <select
                      value={showFilter}
                      onChange={(e) => {
                        setShowFilter(e.target.value);
                        setCurrentPage(1);
                      }}
                      className="w-full py-2 px-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                    >
                      <option value="All Candidates">All Candidates</option>
                      <option value={"Assigned To " + username}>{"Assigned To " + username}</option>
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium mb-1">Client</label>
                  <select
                    value={selectedClientId}
                    onChange={(e) => {
                      setSelectedClientId(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full py-2 px-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                  >
                    <option value="">All Clients</option>
                    {clientList.map((client) => (
                      <option key={client.id} value={client.id}>
                        {client.clientName}
                      </option>
                    ))}
                  </select>
                </div>

                 <div>
                  <label className="block text-xs font-medium mb-1">Gender</label>
                  <select
                    value={genderFilter}
                    onChange={(e) => {
                      setGenderFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full py-2 px-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                  >
                    <option value="*">All</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>


                <div>
                  <label className="block text-xs font-medium mb-1">Status</label>
                  <select
                    value={statusFilter}
                    onChange={(e) => {
                      setStatusFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full py-2 px-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                  >
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium mb-1">Candidature Status</label>
                  <select
                    value={candidatureStatusFilter}
                    onChange={(e) => {
                      setCandidatureStatusFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full py-2 px-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                  >
                    <option value="All">All</option>
                    {availableCandidatureStatuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}
          </div>

        </div>
      </Card>

      {loading && candidates.length === 0 ? (
        <p className="text-center text-gray-500">Loading candidates...</p>
      ) : (
        <Card className="h-[calc(100vh-245px)] w-full">
          <DataGrid
            rows={candidates.map((cand, index) => ({
              id: cand.id,
              sno: (currentPage - 1) * rowsPerPage + index + 1,
              fullName: `${cand.firstName} ${cand.middleName || ''} ${cand.lastName}`,
              experience: cand.experience,
              skills: cand.skills,
              candidateStatus: cand.candidatureStatus,
              assignTo: cand,
              createdBy: cand.createdBy,
              actions: cand,
            }))}
            columns={[
              { field: 'sno', headerName: '#', width: 80, flex: 0.3 },
              {
                field: 'fullName',
                headerName: 'Full Name',
                flex: 0.8,
                renderCell: (params) => (
                  <CustomTooltip title={'Comments Page'}>
                    <div
                      onClick={() => navigate('/dashboard/comments/', { state: { id: params.id, userId: params.row.assignTo?.userId } })}
                      className="text-blue-600 hover:underline cursor-pointer font-medium w-full h-full flex items-center"
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          navigate('/dashboard/comments', { state: { id: params.id, userId: params.row.assignTo?.userId } });
                        }
                      }}
                    >
                      {params.value}
                    </div>
                  </CustomTooltip>
                ),
              },
              { field: 'experience', headerName: 'Experience', flex: 0.8 },
              { field: 'skills', headerName: 'skills', flex: 1 },
              {
                field: 'candidateStatus',
                headerName: 'Candidate Status',
                flex: 1,
                renderCell: (params) => <StatusBadge CandidateStatus={params.value as CandidateStatus} />,
              },
              {
                field: 'assignTo',
                headerName: 'Assigned To',
                flex: 1,
                sortable: false,
                filterable: false,
                headerAlign: 'left',
                align: 'left',
                renderCell: (params) => (
                  <CandidateAssign
                    candidate={params.value}
                    onAssigned={fetchCandidates}
                    showSnackbar={showSnackbar}
                  />
                ),
              },
              { field: 'createdBy', headerName: 'Created By', flex: 1 },
              {
                field: 'actions',
                headerName: 'Actions',
                flex: 0.8,
                sortable: false,
                filterable: false,
                headerAlign: 'left',
                align: 'center',
                renderCell: (params) => {
                  const candidate = params.row.actions as Candidate;
                  const isInactive = candidate.status?.toLowerCase() === 'inactive';
                  return (
                    <div className="flex items-center gap-3">
                      <CustomTooltip title="View Candidate" placement="top">
                        <div
                          className="p-1 rounded-full hover:bg-blue-100 transition cursor-pointer"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewDetails(candidate);
                          }}
                        >
                          <VisibilityIcon
                            className="text-blue-400 hover:scale-110 transition-transform"
                            sx={{ fontSize: 18 }}
                          />
                        </div>
                      </CustomTooltip>
                      {isInactive && (
                        <CustomTooltip title="Activate Candidate" placement="top">
                          <div
                            className="p-1 rounded-full transition cursor-pointer hover:bg-green-100"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleStatusClick(candidate);
                            }}
                          >
                            <CheckCircleOutlineIcon
                              className="text-green-600 hover:scale-110 transition-transform"
                              sx={{ fontSize: 22 }}
                            />
                          </div>
                        </CustomTooltip>
                      )}
                      {!isInactive && (
                        <>
                          <CustomTooltip title="Edit Candidate" placement="top">
                            <div
                              className="p-1 rounded-full hover:bg-blue-100 transition cursor-pointer"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEdit(candidate);
                              }}
                            >
                              <EditIcon
                                className="text-blue-400 hover:scale-110 transition-transform"
                                sx={{ fontSize: 18 }}
                              />
                            </div>
                          </CustomTooltip>
                          <CustomTooltip title="Delete Candidate" placement="top">
                            <div
                              className="p-1 rounded-full hover:bg-red-100 transition cursor-pointer"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteClick(candidate);
                              }}
                            >
                              <DeleteIcon
                                className="text-red-600 hover:scale-110 transition-transform"
                                sx={{ fontSize: 18 }}
                              />
                            </div>
                          </CustomTooltip>
                        </>
                      )}
                    </div>
                  );
                },
              },
            ]}
            pagination
            paginationMode="server"
            rowCount={totalEntries}
            pageSizeOptions={[5, 10, 20, 50]}
            paginationModel={{ page: currentPage - 1, pageSize: rowsPerPage }}
            onPaginationModelChange={({ page, pageSize }) => {
              setCurrentPage(page + 1);
              setRowsPerPage(pageSize);
            }}
            disableRowSelectionOnClick
            sx={{
              width: '100%',
              '& .MuiDataGrid-columnHeaders': {
                backgroundColor: '#f1f5f9 !important',
              },
              '& .MuiDataGrid-columnHeader': {
                backgroundColor: '#f1f1f1',
              },
              '& .MuiDataGrid-columnHeaderTitle': {
                fontWeight: 'bold',
                textTransform: 'uppercase',
              },
              '& .MuiDataGrid-row:hover': {
                backgroundColor: 'inherit',
              },
              '& .MuiDataGrid-cell[data-field="fullName"]': {
                cursor: 'pointer',
                color: '#2563eb',
              },
              '& .MuiDataGrid-cell[data-field="fullName"]:hover': {
                textDecoration: 'underline',
              },
              '& .MuiDataGrid-cell[data-field="assignTo"]': {
                padding: '4px 8px',
              },
            }}
          />
        </Card>
      )}


      {showForm && (
        <CandidateForm
          open={showForm}
          onClose={() => {
            setShowForm(false);
            setIsEditMode(false);
            setSelectedCandidate(null);
          }}
          onSuccess={() => {
            fetchCandidates();
            setShowForm(false);
            showSnackbar(
              isEditMode ? 'Candidate updated successfully!' : 'Candidate registered successfully!',
              "success"
            );
          }}
          initialData={isEditMode && selectedCandidate ? selectedCandidate : undefined}
        />
      )}

      {showDeleteModal && selectedCandidate && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
            <h2 className="text-lg font-semibold text-center text-black mb-4">Confirm Delete</h2>
            <p className="text-center mb-4">
              Are you sure you want to delete <strong>{selectedCandidate.firstName} {selectedCandidate.lastName}</strong>?
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={confirmDelete}
                className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 cursor-pointer"
              >
                Yes, Delete
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="bg-gray-300 text-gray-700 px-4 py-2 rounded hover:bg-gray-400 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
      {showStatusModal && candidateToUpdate && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
            <h2 className="text-lg font-semibold text-center text-black mb-4">Confirm Activation</h2>
            <p className="text-center mb-4">
              Are you sure you want to activate candidate <strong>{candidateToUpdate.firstName} {candidateToUpdate.lastName}</strong>?
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={confirmStatusChange}
                className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 cursor-pointer"
              >
                Yes, Activate
              </button>
              <button
                onClick={() => {
                  setShowStatusModal(false);
                  setCandidateToUpdate(null);
                }}
                className="bg-gray-300 text-gray-700 px-4 py-2 rounded hover:bg-gray-400 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {showDetailsModal && selectedCandidate && (
        <CandidateDetailsDrawer
          candidate={selectedCandidate}
          open={showDetailsModal}
          onClose={() => setShowDetailsModal(false)}
        />
      )}

      {showUploadModal && (
        <UploadCandidateModal
          onClose={() => setShowUploadModal(false)}
          onUploadSuccess={() => {
            fetchCandidates();
            showSnackbar("Candidates uploaded successfully!", "success");
          }}
        />
      )}
    </div>
  );
};

export default CandidatePage;