package com.soarswell.tracker.model;

import com.soarswell.tracker.persistance.AbstractEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@NoArgsConstructor
@SuperBuilder
@Entity
@Table(name = "recruiter_score",
        indexes = {
                @Index(name = "idx_score_company_user", columnList = "companyId,userId"),
                @Index(name = "idx_score_user", columnList = "userId")
        }
)
public class RecruiterScore extends AbstractEntity {

    @Column(name = "companyId", nullable = false)
    private String companyId;

    @Column(name = "userId", nullable = false)
    private String userId;

    @Column(name = "candidateId", nullable = false)
    private String candidateId;

    @Column(name = "points", nullable = false)
    private Integer points;

    @Column(name = "eventType", nullable = false)
    private String eventType;
} 