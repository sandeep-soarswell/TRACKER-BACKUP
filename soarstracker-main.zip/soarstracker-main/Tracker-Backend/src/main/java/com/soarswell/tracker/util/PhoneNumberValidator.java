package com.soarswell.tracker.util;

import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PhoneNumberValidator implements ConstraintValidator<ValidPhoneNumber, String> {
    private static final Logger logger = LoggerFactory.getLogger(PhoneNumberValidator.class);
    private final PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null || value.isEmpty()) {
            return true;
        }

        try {
            PhoneNumber number = phoneUtil.parse(value, null);
            return phoneUtil.isValidNumberForRegion(number,phoneUtil.getRegionCodeForNumber(number));
        } catch (NumberParseException e) {
            return false;
        }
    }
}
