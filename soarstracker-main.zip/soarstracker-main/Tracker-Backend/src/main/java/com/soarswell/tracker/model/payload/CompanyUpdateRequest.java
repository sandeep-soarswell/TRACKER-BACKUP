package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyUpdateRequest {

    @Schema(description = Constants.COMPANY_ADDRESS_DESC, example = Constants.COMPANY_ADDRESS_EXAMPLE)
    private String companyAddress;

    @Schema(description = Constants.COMPANY_MOBILE_DESC, example = Constants.COMPANY_MOBILE_EXAMPLE)
    @ValidPhoneNumber(message = "{invalid.mobile.number}")
    private String mobileNo;

    @Schema(description = Constants.COMPANY_ALT_MOBILE_DESC, example = Constants.COMPANY_ALT_MOBILE_EXAMPLE)
    @ValidPhoneNumber(message = "{invalid.alternate.mobile.number}")
    private String alternateNo;

    @Schema(description = Constants.CONTACT_EMAIL_DESC, example = Constants.CONTACT_EMAIL_EXAMPLE)
    private String personalMailId;

} 