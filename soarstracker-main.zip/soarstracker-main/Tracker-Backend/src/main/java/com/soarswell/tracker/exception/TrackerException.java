package com.soarswell.tracker.exception;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrackerException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private String errorCode;
    private HttpStatus status;

    public TrackerException(String message, HttpStatus httpStatus) {
        super(message);
        this.status = httpStatus;
    }

    public TrackerException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    public TrackerException(String message, String errorCode, HttpStatus httpStatus) {
        super(message);
        this.errorCode = errorCode;
        this.status = httpStatus;
    }

    public TrackerException(String message, Throwable cause, String errorCode) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    public TrackerException(String message, Throwable cause, String errorCode, HttpStatus httpStatus) {
        super(message, cause);
        this.errorCode = errorCode;
        this.status = httpStatus;
    }

    public TrackerException(String message, Exception cause) {
        super(message, cause);
    }

    public HttpStatus getStatus() {
        return status;
    }

    public HttpStatus getHttpStatus() {
        return status;
    }
}