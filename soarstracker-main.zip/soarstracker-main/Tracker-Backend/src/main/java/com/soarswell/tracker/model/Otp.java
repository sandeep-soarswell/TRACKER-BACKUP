package com.soarswell.tracker.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.time.LocalDateTime;

import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "otp",indexes = {
        @Index(name="idx_otp_email", columnList = "email")
})
public class Otp {
    @Id
    private String email;
    private String otp;
    private LocalDateTime expiryDate;

}