package com.soarswell.tracker.model.payload;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FullAIResponse {
    private String firstName;
    private String middleName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String skills;
    private String experience;
    private String candidateRole;
    private String address;
    private String dateOfBirth;
    private String alternateEmail;
    private String alternatePhoneNumber;
    private String availabilityOfJoining;
    private String noticePeriod;
    private String currentSalary;
    private String expectedSalary;
    private double collegeRating;
    private double companyRating;
    private double experienceRating;
    private double skillsRating;
    private String summary;
}