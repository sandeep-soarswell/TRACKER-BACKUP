import React from 'react';

interface FormContainerProps {
  children: React.ReactNode;
}

const FormContainer: React.FC<FormContainerProps> = ({ children }) => {
  return (
    <div className="bg-white bg-opacity-95 p-8 rounded-2xl shadow-2xl w-full max-w-md text-center transition-height duration-300">
      {children}
    </div>
  );
};

export default FormContainer;
