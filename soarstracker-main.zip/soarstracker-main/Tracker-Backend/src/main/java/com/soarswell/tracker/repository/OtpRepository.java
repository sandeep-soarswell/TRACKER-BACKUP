package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.Otp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
 public interface OtpRepository extends JpaRepository<Otp, String> {
        public Optional<Otp> findByEmail(String email);
        public List<Otp> findTop100ByExpiryDateBefore(LocalDateTime now);
        public void deleteByEmail(String email);
}