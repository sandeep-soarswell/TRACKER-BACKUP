import React from 'react';
import { getStatusColor, getStatusText } from '../../components/util/formatters';
import { type CandidateStatus } from '~/pages/types/types';

interface StatusBadgeProps {
  CandidateStatus?: CandidateStatus;
  className?: string;
  animate?: boolean;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({
  CandidateStatus,
  className = '',
  animate = false
}) => {
  if (!CandidateStatus) return null;

  const statusColor = getStatusColor(CandidateStatus);
  const statusText = getStatusText(CandidateStatus);

  return (
    <div className={`inline-flex items-center ${className}`}>
      <span
        className={`relative flex h-3 w-3 mr-2 ${animate ? 'animate-pulse' : ''}`}
      >
        <span className={`${statusColor} h-3 w-3 rounded-full`}></span>
        <span
          className={`${statusColor} opacity-75 absolute h-3 w-3 rounded-full animate-ping`}
          style={{ animationDuration: '3s' }}
        ></span>
      </span>
      <span className="font-medium">{statusText}</span>
    </div>
  );
};

export default StatusBadge;
