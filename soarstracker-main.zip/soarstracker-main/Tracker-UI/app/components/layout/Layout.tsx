import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router';
import Sidebar from './Sidebar';
import Navbar from './Navbar';
import { Outlet } from 'react-router';
import { isRouteAccessible } from '~/auth/rbac';
import RequireAuth from '../RequireAuth';
import { CircularProgress } from '@mui/material';
function Layout() {
  const [readyToRender, setReadyToRender] = useState(false);
  const [showLoading, setShowLoading] = useState(true);
  const [shouldRedirect, setShouldRedirect] = useState(false);
 
  const navigate = useNavigate();
  const location = useLocation();
 
  useEffect(() => {
    const token = localStorage.getItem('userToken');
 
    if (!token) {
      navigate('/', { replace: true });
      return;
    }
 
    const currentPath = location.pathname;
    const allowed = isRouteAccessible(currentPath);
 
    if (!allowed) {
      setShowLoading(false);
      setShouldRedirect(true);
      return;
    }
 
    setReadyToRender(true);
    setShowLoading(false);
  }, [navigate, location.pathname]);
 
  useEffect(() => {
  }, [shouldRedirect, navigate]);
 
  if (showLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <CircularProgress className="text-gray-500" style={{ fontSize: 48 }} />
      </div>
    );
  }

  if (shouldRedirect) {
    return navigate('/', { replace: true }); 
  }
 
  if (!readyToRender) {
    return null;
  }
 
  return (
    <RequireAuth>
      <div className="flex h-screen bg-gray-50">
        <Sidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <Navbar />
          <main className="flex-1 overflow-y-auto p-4">
            <Outlet />
          </main>
        </div>
      </div>
    </RequireAuth>
  );
}

export default Layout;