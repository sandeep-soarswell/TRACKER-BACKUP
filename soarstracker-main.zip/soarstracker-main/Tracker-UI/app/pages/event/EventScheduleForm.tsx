import React, { useState, useEffect,useMemo } from 'react';
import eventService from '~/services/event/event.service';
import Button from '~/components/ui/Button';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import dayjs from 'dayjs';
import { LocalizationProvider, MultiSectionDigitalClock } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { RequiredLabel } from '~/components/layout/blackFieldStyles';
import getChangedFields from '~/components/util/update-util';

export interface CalendarEvent {
  id?: string;
  title: string;
  date: Date;
  startTime: string;
  endTime: string;
  description?: string;
  [key: string]: any;
}

interface EventScheduleFormProps {
  candidateId: string;
  initialData?: CalendarEvent;
  prefilledData?: { date: string; time: string };
  onSuccess?: (message?: string) => void;
}

const EventScheduleForm: React.FC<EventScheduleFormProps> = ({
  candidateId,
  initialData,
  prefilledData,
  onSuccess
}) => {
  const isEditMode = !!initialData;
  const [eventForm, setEventForm] = useState({
    title: initialData?.title || '',
    date: initialData?.date ? initialData.date.toISOString().split('T')[0] : prefilledData?.date || '',
    startTime: initialData?.startTime || prefilledData?.time || '00:00', // Default to valid time
    endTime: initialData?.endTime || prefilledData?.time || '00:00',     // Default to valid time
    description: initialData?.description || '',
  });
  const [eventErrors, setEventErrors] = useState<{
    title?: string;
    date?: string;
    startTime?: string;
    endTime?: string;
  }>({});
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'error'>('success');
  const [activeTimePicker, setActiveTimePicker] = useState<'start' | 'end' | null>(null);
  const [startTimeValue, setStartTimeValue] = useState(dayjs(`2000-01-01T${eventForm.startTime}`));
  const [endTimeValue, setEndTimeValue] = useState(dayjs(`2000-01-01T${eventForm.endTime}`));
  const [tempStartTimeValue, setTempStartTimeValue] = useState(startTimeValue);
  const [tempEndTimeValue, setTempEndTimeValue] = useState(endTimeValue);
  const [touched, setTouched] = useState({ title: false, date: false, startTime: false, endTime: false });

  const isSubmitDisabled = useMemo(() => {
    const { title, date, startTime, endTime } = eventForm;
    if (!title.trim() || !date || !startTime || !endTime) return true;
    const timeFormatRegex = /^\d{2}:\d{2}$/;
    return !timeFormatRegex.test(startTime) || !timeFormatRegex.test(endTime);
  }, [eventForm]);

  useEffect(() => {
    if (initialData) {
      setEventForm({
        title: initialData.title || '',
        date: initialData.date ? initialData.date.toISOString().split('T')[0] : '',
        startTime: initialData.startTime || '00:00', // Fallback to valid time
        endTime: initialData.endTime || '00:00',     // Fallback to valid time
        description: initialData.description || '',
      });
      setStartTimeValue(dayjs(`2000-01-01T${initialData.startTime || '00:00'}`));
      setEndTimeValue(dayjs(`2000-01-01T${initialData.endTime || '00:00'}`));
      setTempStartTimeValue(dayjs(`2000-01-01T${initialData.startTime || '00:00'}`));
      setTempEndTimeValue(dayjs(`2000-01-01T${initialData.endTime || '00:00'}`));
    } else if (prefilledData) {
      setEventForm(prev => ({
        ...prev,
        date: prefilledData.date,
        startTime: prefilledData.time || '00:00', // Fallback to valid time
        endTime: prefilledData.time || '00:00',   // Fallback to valid time
      }));
      const prefillVal = dayjs(`2000-01-01T${prefilledData.time || '00:00'}`);
      setStartTimeValue(prefillVal);
      setEndTimeValue(prefillVal);
      setTempStartTimeValue(prefillVal);
      setTempEndTimeValue(prefillVal);
    }
  }, [initialData, prefilledData]);

  // Validation Functions
  const isStartTimeInFuture = (dateStr: string, timeStr: string) => {
    if (!dateStr || !timeStr) return true;
    const now = new Date('2025-08-18T08:32:00Z'); // Current time: 02:02 PM IST
    const [year, month, day] = dateStr.split('-').map(Number);
    const [hour, minute] = timeStr.split(':').map(Number);
    const inputDate = new Date(year, month - 1, day, hour, minute);
    return inputDate > now;
  };

  const isEndTimeAfterStartTime = (start: string, end: string) => {
    if (!start || !end) return true;
    const [sh, sm] = start.split(':').map(Number);
    const [eh, em] = end.split(':').map(Number);
    const startMinutes = sh * 60 + sm;
    const endMinutes = eh * 60 + em;
    return endMinutes > startMinutes;
  };

  const validateField = (field: keyof typeof eventForm, value: string) => {
    const errors = { ...eventErrors };
    switch (field) {
      case 'title':
        if (!touched.title && !value.trim()) delete errors.title;
        else if (!value.trim()) errors.title = 'Title is required';
        else if (value.trim().length < 3 && touched.title) errors.title = 'Title must be at least 3 characters';
        else if (value.trim().length > 50) errors.title = 'Title must be at most 50 characters';
        else delete errors.title;
        break;
      case 'date':
        if (!value) errors.date = 'Date is required';
        else {
          const inputDate = new Date(value);
          if (inputDate < new Date('2025-08-18T08:32:00Z')) errors.date = 'Date cannot be in the past';
          else delete errors.date;
        }
        break;
      case 'startTime':
        if (!value) errors.startTime = 'Start time is required';
        else if (!/^\d{2}:\d{2}$/.test(value)) errors.startTime = 'Invalid time format (HH:MM)';
        else {
          const [hour, minute] = value.split(':').map(Number);
          if (hour > 23 || minute > 59) errors.startTime = 'Hour must be 0–23, minute must be 0–59';
          else if (eventForm.date && !isStartTimeInFuture(eventForm.date, value))
            errors.startTime = 'Start time must be in the future';
          else delete errors.startTime;
        }
        break;
      case 'endTime':
        if (!value) errors.endTime = 'End time is required';
        else if (!/^\d{2}:\d{2}$/.test(value)) errors.endTime = 'Invalid time format (HH:MM)';
        else {
          const [hour, minute] = value.split(':').map(Number);
          if (hour > 23 || minute > 59) errors.endTime = 'Hour must be 0–23, minute must be 0–59';
          else if (!isEndTimeAfterStartTime(eventForm.startTime, value))
            errors.endTime = 'End time must be after start time';
          else delete errors.endTime;
        }
        break;
    }
    setEventErrors(errors);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setEventErrors({});

    const errors: any = {};
    if (!eventForm.title.trim()) errors.title = 'Title is required';
    else if (eventForm.title.trim().length < 3) errors.title = 'Title must be at least 3 characters';
    else if (eventForm.title.trim().length > 50) errors.title = 'Title must be at most 50 characters';

    if (!eventForm.date) errors.date = 'Date is required';
    else {
      const inputDate = new Date(eventForm.date);
      if (inputDate < new Date('2025-08-18T08:32:00Z')) errors.date = 'Date cannot be in the past';
    }

    if (!eventForm.startTime) errors.startTime = 'Start time is required';
    else if (!/^\d{2}:\d{2}$/.test(eventForm.startTime)) errors.startTime = 'Invalid time format (HH:MM)';
    else {
      const [hour, minute] = eventForm.startTime.split(':').map(Number);
      if (hour > 23 || minute > 59) errors.startTime = 'Hour must be 0–23, minute must be 0–59';
      else if (eventForm.date && !isStartTimeInFuture(eventForm.date, eventForm.startTime))
        errors.startTime = 'Start time must be in the future';
    }

    if (!eventForm.endTime) errors.endTime = 'End time is required';
    else if (!/^\d{2}:\d{2}$/.test(eventForm.endTime)) errors.endTime = 'Invalid time format (HH:MM)';
    else {
      const [hour, minute] = eventForm.endTime.split(':').map(Number);
      if (hour > 23 || minute > 59) errors.endTime = 'Hour must be 0–23, minute must be 0–59';
      else if (!isEndTimeAfterStartTime(eventForm.startTime, eventForm.endTime))
        errors.endTime = 'End time must be after start time';
    }

    if (Object.keys(errors).length > 0) {
      setEventErrors(errors);
      return;
    }

    const startTime = `${eventForm.startTime}:00`;
    const endTime = `${eventForm.endTime}:00`;

    try {
      let response;
      if (isEditMode && initialData?.id) {
        const changedFields = getChangedFields(initialData, eventForm);
        response = await eventService.update(initialData.id, { ...changedFields, candidateId });
      } else {
        response = await eventService.create({
          title: eventForm.title,
          date: eventForm.date,
          startTime,
          endTime,
          description: eventForm.description,
          candidateId: candidateId || '',
        });
      }

      if (!isEditMode) {
        setEventForm({ title: '', date: '', startTime: '00:00', endTime: '00:00', description: '' });
      }
      setEventErrors({});

      const backendMessage = response?.data?.data || (isEditMode ? 'Event updated successfully' : 'Event created successfully');
      setSnackbarMessage(backendMessage);
      setSnackbarSeverity('success');
      setSnackbarOpen(true);

      if (onSuccess) onSuccess(backendMessage);
    } catch (err: any) {
      const errorData = err?.response?.data;

      if (errorData && errorData.error && typeof errorData.error === 'object') {
        const backendErrors: any = {};

        Object.entries(errorData.error).forEach(([key, value]) => {
          switch (key) {
            case 'date':
              backendErrors.date = value;
              break;
            case 'endTimeAfterStartTime':
              backendErrors.endTime = value;
              break;
            case 'title':
              backendErrors.title = value;
              break;
            case 'startTime':
              backendErrors.startTime = value;
              break;
            case 'endTime':
              backendErrors.endTime = value;
              break;
            default:
              backendErrors.endTime = value;
              break;
          }
        });

        setEventErrors(backendErrors);
        return;
      }

      setSnackbarMessage(err?.message || errorData?.message || (isEditMode ? 'Failed to update event.' : 'Failed to schedule event.'));
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    }
  };

  const handleStartTimeChange = (newValue: dayjs.Dayjs | null) => {
    if (newValue) {
      setTempStartTimeValue(newValue);
    }
  };

  const handleEndTimeChange = (newValue: dayjs.Dayjs | null) => {
    if (newValue) {
      setTempEndTimeValue(newValue);
    }
  };

  const handleCloseTimePicker = (type: 'start' | 'end') => {
    if (type === 'start') {
      const newTime = tempStartTimeValue.format('HH:mm');
      setStartTimeValue(tempStartTimeValue);
      setEventForm(f => ({ ...f, startTime: newTime }));
      validateField('startTime', newTime);
    } else {
      const newTime = tempEndTimeValue.format('HH:mm');
      setEndTimeValue(tempEndTimeValue);
      setEventForm(f => ({ ...f, endTime: newTime }));
      validateField('endTime', newTime);
    }
    setActiveTimePicker(null);
  };

  return (
    <>
      <CustomSnackbar
        open={snackbarOpen}
        message={snackbarMessage}
        severity={snackbarSeverity}
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={3000}
      />

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <RequiredLabel label="Title" />
          </label>
          <input
            type="text"
            className="w-full px-3 py-2 border rounded-md text-sm bg-white border-gray-300"
            value={eventForm.title}
            onChange={(e) => {
              const value = e.target.value;
              setEventForm((f) => ({ ...f, title: value }));
              validateField('title', value);
            }}
            onBlur={(e) => validateField('title', e.target.value)}
            placeholder="Enter event title"
            autoFocus={!eventForm.title}
          />
          {eventErrors.title && <p className="text-red-500 text-sm mt-1">{eventErrors.title}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <RequiredLabel label="Date" />
          </label>
          <input
            type="date"
            className="w-full px-3 py-2 border rounded-md text-sm bg-white border-gray-300"
            value={eventForm.date}
            onChange={(e) => {
              const val = e.target.value;
              const parts = val.split('-');
              if (parts[0] && parts[0].length > 4) parts[0] = parts[0].slice(0, 4);
              const newVal = parts.join('-');
              setEventForm((f) => ({ ...f, date: newVal }));
              setTouched((prev) => ({ ...prev, date: true }));
              validateField('date', newVal);
            }}
            onBlur={(e) => {
              setTouched((prev) => ({ ...prev, date: true }));
              validateField('date', e.target.value);
            }}
          />
          {eventErrors.date && <p className="text-red-500 text-sm mt-1">{eventErrors.date}</p>}
        </div>

        <div className="relative">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <RequiredLabel label="Start Time" />
          </label>
          <div className="flex items-center relative">
            <input
              type="text"
              className="w-full px-3 py-2 border rounded-md text-sm bg-white border-gray-300 pr-8"
              value={eventForm.startTime}
              onChange={(e) => {
                let val = e.target.value.replace(/[^0-9:]/g, '');
                if (/^\d{2}$/.test(val)) val = val + ':';
                if (val.length > 5) val = val.slice(0, 5);
                if (/^\d{3}$/.test(val)) val = val.slice(0, 2) + ':' + val.slice(2);
                setEventForm(f => ({ ...f, startTime: val }));
                if (/^\d{2}:\d{2}$/.test(val) && eventForm.date) {
                  validateField('startTime', val);
                }
              }}
              onBlur={(e) => {
                const val = e.target.value;
                if (/^\d{2}:\d{2}$/.test(val) && eventForm.date) {
                  validateField('startTime', val);
                }
              }}
              placeholder="hh:mm"
              autoComplete="off"
              inputMode="numeric"
              maxLength={5}
            />
            <button
              type="button"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 p-0 bg-transparent flex items-center justify-center"
              tabIndex={-1}
              style={{ height: '100%' }}
              onClick={(e) => {
                e.stopPropagation();
                setActiveTimePicker(activeTimePicker === 'start' ? null : 'start');
              }}
              aria-label="Open start time picker"
            >
              <span style={{ display: 'flex', alignItems: 'center', pointerEvents: 'none', height: '100%' }}>
                <svg width="20" height="20" fill="none" viewBox="0 0 20 20"><path d="M6 8l4 4 4-4" stroke="#888" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </span>
            </button>
          </div>
          {eventErrors.startTime && <p className="text-red-500 text-sm mt-1">{eventErrors.startTime}</p>}
          {activeTimePicker === 'start' && (
            <div className="absolute z-50 mt-2 left-0" onClick={(e) => { e.stopPropagation(); }}>
              <div
                style={{ position: 'fixed', inset: 0, zIndex: 49 }}
                onClick={() => handleCloseTimePicker('start')}
              />
              <div style={{ background: '#fff', borderRadius: 0, boxShadow: '0 2px 8px rgba(0,0,0,0.08)', padding: 0, display: 'inline-block', width: 110, position: 'relative', zIndex: 50 }}>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <MultiSectionDigitalClock
                    value={tempStartTimeValue}
                    onChange={handleStartTimeChange}
                    ampm={false}
                    minutesStep={5}
                    sx={{ width: 110, minWidth: 0, maxWidth: 110, background: '#fff', borderRadius: 0, boxShadow: 'none', padding: 0 }}
                  />
                </LocalizationProvider>
              </div>
            </div>
          )}
        </div>

        <div className="relative">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <RequiredLabel label="End Time" />
          </label>
          <div className="flex items-center relative">
            <input
              type="text"
              className="w-full px-3 py-2 border rounded-md text-sm bg-white border-gray-300 pr-8"
              value={eventForm.endTime}
              onChange={(e) => {
                let val = e.target.value.replace(/[^0-9:]/g, '');
                if (/^\d{2}$/.test(val)) val = val + ':';
                if (val.length > 5) val = val.slice(0, 5);
                if (/^\d{3}$/.test(val)) val = val.slice(0, 2) + ':' + val.slice(2);
                setEventForm(f => ({ ...f, endTime: val }));
                if (/^\d{2}:\d{2}$/.test(val)) {
                  validateField('endTime', val);
                }
              }}
              onBlur={(e) => {
                const val = e.target.value;
                if (/^\d{2}:\d{2}$/.test(val)) {
                  validateField('endTime', val);
                }
              }}
              placeholder="hh:mm"
              autoComplete="off"
              inputMode="numeric"
              maxLength={5}
            />
            <button
              type="button"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 p-0 bg-transparent flex items-center justify-center"
              tabIndex={-1}
              style={{ height: '100%' }}
              onClick={(e) => {
                e.stopPropagation();
                setActiveTimePicker(activeTimePicker === 'end' ? null : 'end');
              }}
              aria-label="Open end time picker"
            >
              <span style={{ display: 'flex', alignItems: 'center', pointerEvents: 'none', height: '100%' }}>
                <svg width="20" height="20" fill="none" viewBox="0 0 20 20"><path d="M6 8l4 4 4-4" stroke="#888" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </span>
            </button>
          </div>
          {eventErrors.endTime && <p className="text-red-500 text-sm mt-1">{eventErrors.endTime}</p>}
          {activeTimePicker === 'end' && (
            <div className="absolute z-50 mt-2 left-0" onClick={(e) => { e.stopPropagation(); }}>
              <div
                style={{ position: 'fixed', inset: 0, zIndex: 49 }}
                onClick={() => handleCloseTimePicker('end')}
              />
              <div style={{ background: '#fff', borderRadius: 0, boxShadow: '0 2px 8px rgba(0,0,0,0.08)', padding: 0, display: 'inline-block', width: 110, position: 'relative', zIndex: 50 }}>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <MultiSectionDigitalClock
                    value={tempEndTimeValue}
                    onChange={handleEndTimeChange}
                    ampm={false}
                    minutesStep={5}
                    sx={{ width: 110, minWidth: 0, maxWidth: 110, background: '#fff', borderRadius: 0, boxShadow: 'none', padding: 0 }}
                  />
                </LocalizationProvider>
              </div>
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description (optional)
          </label>
          <textarea
            className="w-full px-3 py-2 border rounded-md text-sm bg-white border-gray-300 resize-none"
            value={eventForm.description}
            onChange={(e) => setEventForm(f => ({ ...f, description: e.target.value }))}
            placeholder="Event description"
            rows={2}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                const textarea = e.target as HTMLTextAreaElement;
                const start = textarea.selectionStart;
                const end = textarea.selectionEnd;
                const value = eventForm.description;
                const newValue = value.slice(0, start) + ' ' + value.slice(end);
                setEventForm(f => ({ ...f, description: newValue }));
                setTimeout(() => {
                  textarea.selectionStart = textarea.selectionEnd = start + 1;
                }, 0);
              }
            }}
          />
        </div>
        <div className="flex gap-2 justify-end pt-4">
          <Button type="submit" variant="primary">
            {initialData && initialData.id ? 'Update Event' : 'Add Event'}
          </Button>
        </div>
      </form>
    </>
  );
};

export default EventScheduleForm;