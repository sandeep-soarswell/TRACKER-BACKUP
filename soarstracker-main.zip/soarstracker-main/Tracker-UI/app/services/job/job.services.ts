import api from "../api/api.services";
import { type Job } from "~/pages/types/types";
type Listener = (jobs: Job[]) => void;

let listeners: Listener[] = [];
let currentJobs: Job[] = [];


const jobService = {
  getAll: async ({
    page,
    size,
    clientId,
    keyword,
    filter,
  }: {
    page: number;
    size: number;
    clientId?: string | null;
    keyword?: string;
    filter?: string;
  }) => {
    const params: any = {
      page,
      size,
    };

    if (clientId) params.clientId = clientId;
    if (keyword) params.keyword = keyword;
    if (filter) params.filter = filter;

    const response = await api.get("/job/client/jobs", { params });
    return response.data;
  },

  create: async (clientId: string, values: any) => {
    const response = await api.post(`/job/client/${clientId}/job`, values);
    return response.data;
  },

  getById: async (jobId: string) => {
    const response = await api.get(`/job/${jobId}`);
    return response.data;
  },

  delete: async (jobId: string) => {
    const response = await api.delete(`/job/${jobId}`);
    return response.data;
  },
   uploadCSV: async (file: File, clientId: string) => {
     const formData = new FormData();
     formData.append('file', file);
     const response = await api.post(`/job/upload/${clientId}`, formData, {
       headers: {
         'Content-Type': 'multipart/form-data',
       },
     });
    return response.data;
  },


  update: async (jobId: string, values: any) => {
    const response = await api.patch(`/job/${jobId}`, values);
    return response.data;
  },

  getAssignedCandidates: async (jobId: string) => {
    const params = {
      "jobId": jobId
    }
    const response = await api.get(`/job/candidates?${new URLSearchParams(params)}`);
    return response.data;
  },

  getAssignedUsers: async (jobId: string) => {
    const response = await api.get(`/job/users/${jobId}`);
    return response.data;
  },
  getNotifications: async () => {
    const response = await api.get(`/job/notifications`);
    return response.data;
  },
  markJobAsRead: async ( { eventId }: { eventId: string} ) => {
    const params: any = { eventId };
    const response = await api.patch('/job/notifications', null, { params });
    return response.data;
  },
  
  findMatchingCandidates: async (jobId: string) => {
    const response = await api.get(`/job/${jobId}/find-matches`);
    return response.data;
  }
};
export default jobService;

