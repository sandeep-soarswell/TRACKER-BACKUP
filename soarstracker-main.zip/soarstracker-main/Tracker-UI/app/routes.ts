import { type RouteConfig, index, route } from "@react-router/dev/routes";

export default [
  route("/", "./pages/login/Login.tsx"),
  route("forgot-password", "./pages/login/ForgotPassword.tsx"),
  route("reset-password", "./pages/login/ResetPassword.tsx"),
  route("change-password", "./pages/login/ChangePassword.tsx"),

  route("/dashboard", "./components/layout/Layout.tsx", [
     route("", "./pages/dashboard/Dashboard.tsx"),
    route("users", "./pages/employee/EmployeesPage.tsx"),
    route("companies","./pages/company/companiespage.tsx"),
     route("candidates","./pages/candidate/CandidatePage.tsx"),
     route("jobs", "./pages/Jobs/Jobpage.tsx"),
     route("jobs/assign-status", "./pages/Jobs/Jobassign.tsx"),
     route("clients", "./pages/client/ClientList.tsx"),
     route("calendar", "./pages/calendar/CalendarPage.tsx"),
     route("settings", "./pages/settings/Settings.tsx"),
     route("profile", "./pages/profile/Profile.tsx"),
     route("comments", "./pages/candidate/EachCandidate.tsx"),
     route("clientcomments", "./pages/client/EachClient.tsx"),
     route("employee/assignes", "./pages/employee/EmployeeAssignes.tsx"),
     route('employee/candidates', "./pages/employee/EmployeeCandidatesPage.tsx"),
      route("recruiter-leaderboard", "./pages/dashboard/RecruiterLeaderboard.tsx"),
  ]),
    
  route("*", "./pages/NotFound.tsx"), 
] satisfies RouteConfig;

