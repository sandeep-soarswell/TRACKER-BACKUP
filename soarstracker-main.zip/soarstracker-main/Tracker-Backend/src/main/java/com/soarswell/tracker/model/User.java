package com.soarswell.tracker.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.soarswell.tracker.persistance.AbstractEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "user",
        indexes = {
                @Index(name = "idx_user_company_id", columnList = "company_id"),
                @Index(name = "idx_user_status", columnList = "status"),
                @Index(name = "idx_user_role", columnList = "role"),
                @Index(name = "idx_user_company_status", columnList = "company_id, status"),
                @Index(name = "idx_user_company_role_status", columnList = "company_id, role, status"),
                @Index(name = "idx_user_id_company", columnList = "id, company_id")
        })
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class User extends AbstractEntity {

    @Column(name = "email",unique = true)
    private String email;

    @Column(name = "PhoneNumber",unique = true)
    private String phoneNumber;

    @Column(name = "companyId")
    private String companyId;

    @Column(name = "firstName")
    private String firstName;

    @Column(name = "middleName")
    private String middleName;

    @Column(name = "lastName")
    private String lastName;

    @Column(name = "password")
    private String password;

    @Column(name="company_name")
    private String companyName;

    @Column(nullable = false)
    @Builder.Default
    private String status = Status.CREATED.getLongLabel();

    @NotNull(message = "Role is required")
    private String role;

    @ManyToMany(mappedBy = "users", fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<Job> jobs;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonIgnore
    @Builder.Default
    private Set<CandidateUserAssignment> assignments = new HashSet<>();

}