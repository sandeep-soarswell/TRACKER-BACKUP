package com.soarswell.tracker.util;

import java.util.List;

public class Constants {
    public static final String COMPANY_EMAIL_DESC = "Company email address";
    public static final String COMPANY_EMAIL_EXAMPLE = "admin@soarswell.com";
    public static final String PASSWORD_DESC = "User's password";
    public static final String PASSWORD_EXAMPLE = "Passw0rd!";
    public static final String OTP_PATTERN = "^[0-9]{6}$";
    public static final String JWT_ROLES_CLAIM = "roles";
    public static final String ERROR_JWT_GENERATION_FAILED = "error.jwt.generation.failed";
    public static final String ERROR_JWT_EXPIRED = "error.jwt.expired";
    public static final String ERROR_JWT_SIGNATURE = "error.jwt.signature";
    public static final String ERROR_JWT_EXTRACTION = "error.jwt.extraction";
    public static final String ERROR_JWT_ROLES_EXTRACTION = "error.jwt.roles.extraction";
    public static final String ERROR_JWT_VALIDATION = "error.jwt.validation";
    public static final String ERROR_JWT_EXPIRATION = "error.jwt.expiration";
    public static final String ERROR_TOKEN_NULL = "error.token.null";
    public static final String DEFAULT = "default";

    // Application Constants
    public static final String ADMIN = "admin";
    public static final String TRACKER_ADMIN = "sys_admin";
    public static final String COMPANY = "company";
    public static final String COMPANY_ADMIN = "COMPANY_ADMIN";
    public static final String MANAGER = "MANAGER";
    public static final String RECRUITER = "RECRUITER";
    public static final String SUPER_ADMIN_MAIL = "admin@soarswell.com";

    // Common Field Names
    public static final String LOGIN_CREDENTIALS = "loginCredentials";
    public static final String FORGOT_DETAILS = "Forgot password request details";
    public static final String OTP_DETAILS = "OTP validation details";
    public static final String REQUEST_FORGOT = "Request object for forgot password";
    public static final String REQUEST_CHANGE = "Request object for changing password";
    public static final String REQUEST_RESET = "Request object for resetting password";
    public static final String REQUEST_OTP = "Request object for OTP validation";
    public static final String LOG_AUTH_OTP_SENT = "OTP sent to user: {}";

    // API Documentation
    public static final String API_TAG_AUTH = "Login";
    public static final String API_USER_TAG_NAME = "Users";

    // API Operation Descriptions - Authentication
    public static final String API_AUTH_SIGNIN = "login";
    public static final String API_AUTH_CHANGE_PASSWORD = "Change Password";
    public static final String API_AUTH_FORGOT_PASSWORD = "Forgot Password";
    public static final String API_AUTH_VALIDATE_OTP = "OTP";

    // Common API Response Messages
    public static final String API_RESPONSE_OK = "Successful operation";
    public static final String API_RESPONSE_UNAUTHORIZED = "Authentication required";
    public static final String API_RESPONSE_NOT_FOUND = "Resource not found";
    public static final String API_RESPONSE_ERROR = "Internal server error";

    // Mail Constants
    public static final String MAIL_TRANSPORT_PROTOCOL = "mail.transport.protocol";
    public static final String MAIL_SMTP_AUTH = "mail.smtp.auth";
    public static final String MAIL_SMTP_STARTTLS_ENABLE = "mail.smtp.starttls.enable";
    public static final String MAIL_DEBUG = "mail.debug";
    public static final String MAIL_SMTP_SSL_TRUST = "mail.smtp.ssl.trust";
    public static final String SMTP = "smtp";
    public static final String TRUE = "true";

    // Tracker API Constants
    public static final String TRACKER_SECURITY_SCHEME = "Authorization";
    public static final String TRACKER_API_TITLE = "TRACKER REST API";
    public static final String TRACKER_API_DESCRIPTION = "TRACKER REST API";
    public static final String TRACKER_API_VERSION = "v1.0.0";
    public static final String TRACKER_EXTERNAL_DOCS_DESC = "SOARSWELL - Website";
    public static final String TRACKER_EXTERNAL_DOCS_URL = "#";

    // OTP Constants
    public static final String OTP_DESC = "6-digit OTP code";
    public static final String OTP_EXAMPLE = "123456";
    public static final int OTP_EXPIRY_MINUTES = 10;
    public static final String OTP_PURPOSE_LOGIN = "login";
    public static final String OTP_PURPOSE_RESET = "reset";
    public static final String INVALID_CREDENTIALS = "INVALID_CREDENTIALS";
    public static final String USER_NOT_FOUND = "USER_NOT_FOUND";

    // New log message constants
    public static final String LOG_AUTH_LOGIN_ATTEMPT = "Processing authentication request for user: {}";
    public static final String LOG_AUTH_LOGIN_INVALID = "Invalid login attempt for user: {}";
    public static final String LOG_AUTH_USER_NOT_FOUND = "User not found for password change: {}";
    public static final String LOG_AUTH_FORGOT_PASSWORD_ATTEMPT = "Processing forgot password request for email: {}";
    public static final String LOG_AUTH_FORGOT_PASSWORD_USER_NOT_FOUND = "User not found for forgot password: {}";
    public static final String LOG_AUTH_OTP_VALIDATION_ATTEMPT = "Processing OTP validation for email: {}";
    public static final String LOG_AUTH_OTP_NOT_FOUND = "OTP not found for user: {}";
    public static final String LOG_AUTH_OTP_INVALID = "Invalid OTP provided for user: {}";
    public static final String LOG_AUTH_OTP_EXPIRED = "Expired OTP used for user: {}";
    public static final String LOG_AUTH_CHANGE_PASSWORD_ATTEMPT = "Processing password change request for user: {}";
    public static final String LOG_AUTH_CHANGE_PASSWORD_SUCCESS = "Password changed successfully for user: {}";
    public static final String LOG_AUTH_RESET_PASSWORD_ATTEMPT = "Processing password reset request for user: {}";
    public static final String LOG_AUTH_RESET_PASSWORD_SUCCESS = "Password reset successfully for user: {}";

    // Error Response Constants
    public static final String ERROR_RESPONSE_DEFAULT_MESSAGE = "An unexpected error occurred";
    public static final String ERROR_RESPONSE_DEFAULT_DETAIL = "Please contact the system administrator";
    public static final String ERROR_RESPONSE_VALIDATION_MESSAGE = "Validation failed";
    public static final String ERROR_RESPONSE_AUTH_MESSAGE = "Authentication failed";
    public static final String ERROR_RESPONSE_NOT_FOUND_MESSAGE = "Resource not found";
    public static final String ERROR_RESPONSE_FORBIDDEN_MESSAGE = "Access denied";
    public static final String ERROR_RESPONSE_CONFLICT_MESSAGE = "Resource already exists";
    public static final String ERROR_RESPONSE_TIMESTAMP_PATTERN = "yyyy-MM-dd HH:mm:ss";
    public static final String ERROR_COMPANY_ALREADY_EXISTS = "Company with email %s already exists";
    public static final String ERROR_CREATING_COMPANY = "Error creating company: %s";
    public static final String ERROR_FETCHING_COMPANIES = "Error fetching companies: %s";
    public static final String ERROR_UPDATING_COMPANY = "Error updating company: %s";
    // New EMAIL_PATTERN constant

    public static final String EMPLOYEE_NOT_FOUND="EMPLOYEE_NOT_FOUND";
    public static final String OTP_EXPIRED= "OTP_EXPIRED";
    public static final String INVALID_OTP="error.invalid.otp";
    //company
    public static final String COMPANY_NAME_DESC = "Company name";
    public static final String COMPANY_NAME_EXAMPLE = "Acme Corporation";
    public static final String COMPANY_ID = "Company_id";
    public static final String COMPANY_UPDATED = "Company Updated Successfully";
    public static final String COMPANY_STATUS_DESC = "Company status";
    public static final String COMPANY_STATUS_EXAMPLE = "ACTIVE";
    public static final String COMPANY_ADDRESS_DESC = "Company address";
    public static final String COMPANY_ADDRESS_EXAMPLE = "123 Business Street, City, Country";
    public static final String COMPANY_REG_NO_DESC = "Company registration number";
    public static final String COMPANY_REG_NO_EXAMPLE = "REG123456";
    public static final String COMPANY_MOBILE_DESC = "Company mobile number";
    public static final String COMPANY_MOBILE_EXAMPLE = "+1234567890";
    public static final String COMPANY_ALT_MOBILE_DESC = "Company alternate number";
    public static final String COMPANY_ALT_MOBILE_EXAMPLE = "+1234567891";
    public static final String CONTACT_EMAIL_DESC = "Contact person's email";
    public static final String CONTACT_EMAIL_EXAMPLE = "john.doe@email.com";
    public static final String CONTACT_MOBILE_DESC = "Contact person's mobile number";
    public static final String CONTACT_MOBILE_EXAMPLE = "+1234567892";
    public static final String CONTACT_ADDRESS_DESC = "Contact person's address";
    public static final String CONTACT_ADDRESS_EXAMPLE = "456 Personal Street, City, Country";
    public static final String ERROR_PERSONAL_EMAIL = "PERSONAL-EMAIL";

    public static final String VALIDATION_COMPANY_NAME_REQUIRED = "Company name is required field";
    public static final String VALIDATION_COMPANY_EMAIL_REQUIRED = "Company email is required field";
    public static final String VALIDATION_COMPANY_EMAIL_INVALID = "Invalid company email format";
    public static final String VALIDATION_COMPANY_MOBILE_REQUIRED = "Company mobile number is required field";
    public static final String VALIDATION_REGISTRATION_NUMBER = "Company REG.NO contains letters and numbers within 6 to 21 length";
    public static final String COMPANY_NAME_VALIDATION = "Company name should only contain letters,numbers and spaces and within 2 to 100 characters";
    public static final String VALIDATION_CONTACT_EMAIL_REQUIRED = "Contact person's email is required field";
    public static final String VALIDATION_CONTACT_EMAIL_INVALID = "Invalid contact person's email format";

    public static final String LOG_COMPANY_CREATED = "Company Created Successfully with ID: {}";
    public static final String COMPANY_CREATED = "Company Created Successfully!";
    public static final String API_RESPONSE_BAD_REQUEST = "Invalid request";
    public static final String MEDIA_TYPE_JSON = "application/json";

    //USER API CONSTANTS
    public static final String USER_REGISTERED="User Registered Successfully!";
    public static final String USER_UPDATED="User Updated Successfully!";
    public static final String USER_DELETED="User Deleted Successfully!";
    public static final String defaultPassword="Passw0rd!";
    public static final String NO_CHANGES_DETECTED="No new changes found in update request";
    public static final String DEFAULT_PASSWORD="Passw0rd!";
    public static final String USER_ROUTE_PATH = "/user";
    public static final String USER_BY_ID_PATH = "/{userId}";
    public static final String UPDATE_INACTIVE_USER_STATUS_PATH = "/status/{userId}";
    public static final String GET_FREE_USERS_PATH="/free-users";
    public static final String GET_USER_JOBS_PATH="/jobs/";

    //Example Data for the request body
    public static final String FIRST_NAME = "John";
    public static final String MIDDLE_NAME = "Mk";
    public static final String LAST_NAME = "Doe";
    public static final String EMAIL = "johndoe@soarswell.com";
    public static final String PHONE = "7676388731";
    public static final String ROLE = "user";

    // Defining placeholders for annotations
    public static final String FROM_MAIL = "${spring.mail.username}";

    // Email Service impl formatting constants
    public static final String COMPANY_MAIL_IMPL = "{companyName}";
    public static final String EMAIL_MAIL_IMPL = "{email}";
    public static final String PASSWORD_MAIL = "{password}";
    public static final String OTP_MAIL = "{otp}";
    public static final String EXPIRY_MAIL = "{expiry}";
    public static final String NAME_MAIL = "{name}";
    public static final String ENCODING_MAIL = "UTF-8";
    public static final String VALIDATION_ERROR = "Validation error";

    // Validation Values
    public static final long PHONE_MIN = 1000000000L;
    public static final String ROLE_FORMAT="{error.role.validation.mismatch}";
    public static final String PHONE_NULL_MESSAGE = "Phone number is required field";
    public static final String PHONE_MIN_MESSAGE = "Phone number should be at least 10 digits";

    public static final String FIRSTNAME_MESSAGE = "First name must not be blank";
    public static final String FIRSTNAME_FORMAT = "First name must be 3–20 characters.";
    public static final String MIDDLE_NAME_FORMAT = "Middle name must be 3–20 characters.";
    public static final String LASTNAME_MESSAGE = "Last name must not be blank";
    public static final String LASTNAME_FORMAT = "Last name must be 3–20 characters.";
    public static final String INVALID_EMAIL = "Invalid email format";
    public static final String ROLE_NOTNULL_MESSAGE = "Role is required field";

    // Database configuration
    public static final String CREATE_DATABASE_QUERY = "create database if not exists tracker";
    public static final String DATABASE_URL = "database.url";
    public static final String DATABASE_USERNAME = "spring.datasource.username";
    public static final String DATABASE_PASSWORD = "spring.datasource.password";

    // Application data intialization
    public static final String MESSAGE = "message";
    public static final String OTP_SENT_SUCCESS = "OTP sent successfully to your email";
    public static final String USER__NOT_FOUND = "User with id not found";
    public static final String PASSWORD_CHANGE_SUCCESS = "Password Changed Successfully!";
    public static final String CREATED = "created";
    public static final String FIRST_TIME_LOGIN = "first.time.login";
    public static final String VALIDATE_OTP = "validate.otp.success";
    public static final String PASSWORD_RESET_SUCCESS = "Password Reset Successfully";
    public static final String INVALID_OR_EXPIRED_TOKEN = "Invalid token or expired token";
    public static final String LOGOUT_SUCCESS = "Logout successful";
    public static final String INVALID_TOKEN = "error.invalid.token";
    public static final String TOKEN_VALIDATED_SUCCESS = "Token validated successfully";
    public static final String VALIDATE_JWT_TOKEN="Validate JWT Token";
    public static final String TOKEN_VALIDATE_DESCRIPTION="Validates the provided JWT token";
    public static final String LOGOUT="Logout";
    public static final String LOGOUT_DESCRIPTION="Logs out the user and deletes all their sessions.";
    public static final String INVALID__CREDENTIALS = "error.invalid.credentials";
    public static final String ACTIVE = "Active";
    public static final String OTP_ERROR = "error.otp.not.found";
    public static final String TOKEN = "token";
    public static final String INVALID__OR_EXPIRED_TOKEN = "invalid.or.expired.token";
    public static final String JSON_FORMAT = "application/json";
    public static final String AUTH= "Authorization";
    public static final String ANONYMOUSUSER="anonymousUser";
    public static final String SYS_ADMIN_FIRSTNAME = "sysadmin.firstname";
    public static final String SYS_ADMIN_LASTNAME = "sysadmin.lastname";
    public static final String SYS_ADMIN_USERNAME = "sysadmin.username";
    public static final String SYS_ADMIN_PASSWORD = "sysadmin.password";
    public static final String SYS_ADMIN_ROLE = "SYS_ADMIN";
    public static final String EMPLOYEE ="employee" ;
    public static final String USER_INACTIVE="USER.INACTIVE";
    public static final String INACTIVE="INACTIVE";
    public static final String SYSTEM ="system";
    public static final String AUTHORIZATION="Authorization";
    public static final String ROLE_PREFIX = "ROLE_";
    public static final String USER_ROLE_NOT_FOUND = "User role not found";
    public static final String CANDIDATE_ASSIGN_TO_RECRUITER ="Candidate assigning to Recruiter";

    //CANDIDATE API CONSTANTS
    public static final String  CANDIDATE = "Candidate";
    public static final String RESUME="https://www.soarswell.com";
    public static final String RESUME_MESSAGE="Resume is required field.";
    public static final String CANDIDATE_DELETED="Candidate Deleted Successfully!!";
    public static final String CANDIDATE_UPDATED="Candidate Data Updated Sucessfully!";
    public static final String CANDIDATE_CREATED ="Candidate Registered Successfully!";
    public static final String SUCCESS = "SUCCESS";
    public static final String CANDIDATE_RECRUITER="Candidate successfully assigned to Recruiter";
    public static final String CANDIDATE_COMPANY_ADMIN="Candidate successfully assigned to Company Admin";
    public static final String CANDIDATE_MANAGER="Candidate successfully assigned to Manager";
    public static final String CANDIDATE_DEFAULT="Candidate successfully assigned";


    public static final String IMAGE_JPG = "image/jpeg";
    public static final String IMAGE_PNG = "image/png";
    public static final String IMAGE_SVG = "image/svg+xml";
    public static final String PNG = ".png";
    public static final String DIRECTORY = "user.dir";
    public static final String IMAGE = "image";
    public static final String FILE = "file";
    public static final String FILE_PATTERN = "[^a-z0-9]";

    //JOB API CONSTANTS
    public static final String JOB = "Job";
    public static final String JOB_TITLE_REQUIRED ="Job title is required field";
    public static final String SOFTWARE_ENGINEER="Software Engineer";
    public static final String JOB_DESCRIPTION="Develop and maintain software applications.";
    public static final String JOB_LOCATION="Bangalore";
    public static final String JOB_SKILLS="Java, Spring Boot, SQL";
    public static final String JOB_SALARY="80000";
    public static final String JOB_OPENINGS="3";
    public static final String JOB_EXPERIENCE="3-5 years";
    public static final String JOB_DEADLINE="2025-07-01";
    public static final String DESCRIPTION_IS_REQUIRED="Description is required field";
    public static final String LOCATION_IS_REQUIRED="Location is required field";
    public static final String SKILLS_IS_REQUIRED="Skills is required field";
    public static final String SALARY_IS_REQUIRED="Salary is required field";
    public static final String EXPERIENCE_IS_REQUIRED="Experience is required field";
    public static final String OPENINGS_IS_REQUIRED="Openings is required field";
    public static final String DEADLINE_IS_REQUIRED="Deadline is required field";
    public static final String JOB_MANAGEMENT= "Jobs";
    public static final String NO_JOB_FOUND="No job with provided Job id";
    public static final String JOB_READ = "Job notification read successfully";

    //Client Tags
    public static final String CLIENT_TAG="Client";
    public static final String CLIENT_BY_ID = "/client/{clientId}";
    public static final String CLIENT="/clients";
    public static final String CLIENT_UPDATE="/client/{clientId}";
    public static final String AUTH_KEY = "Authorization";
    public static final String NULL = "null";
    public static final String ROLES = "roles";
    public static final String SUB = "sub";
    //Example schema Data for job request
    public static final String GENERAL="general";
    public static final String RESET_PASSWORD="reset_password";
    public static final String FIRST_TIME="first_time";
    public static final String PURPOSE="purpose";
    public static final String ROLE_="ROLE_";
    public static final String BEARER= "Bearer ";
    public static final String INVALID_TOKEN_ENDPOINT="Invalid token for this endpoint";
    public static final String RESET_PASSWORD_ENDPOINT = "/reset-password";
    public static final String CHANGE_PASSWORD_ENDPOINT = "/change-password";
    public static final String PURPOSE_RESET_PASSWORD = "reset_password";
    public static final List<String> RESET_PASSWORD_ALLOWED_ENDPOINTS = List.of(
            RESET_PASSWORD_ENDPOINT,
            CHANGE_PASSWORD_ENDPOINT
    );
    public static final String JOB_STATUS_CLOSED="Job status set to CLOSED";
    public static final String COMMENT = "comment" ;
    public static final String JOB_ASSIGNED="Job assignation success!";
    public static final String CLIENT_UPDATED="Client Details Updated Successfully!";
    public static final String JOB_CREATED ="Job Created Successfully!";
    public static final String JOB_UPDATED ="Job Updated Successfully!";
    public static final String CLIENT_REGISTER ="Client Registered Successfully!";
    public static final String CLIENT_DELETED ="Client Deleted Successfully!";
    public static final String COMPANY_IMAGE_UPDATE ="Company Image Updated Successfully!";
    public static final String SAME_AS_OLD_PASSWORD = "error.same.as.old.password";
    public static final String FILTER_ACTIVE = "ACTIVE";
    public static final String FILTER_INACTIVE = "INACTIVE";
    public static final String ASC = "asc";
    public static final String FILTER_OPEN = "OPEN";
    public static final String FILTER_CLOSED = "CLOSED";
    public static final String USER_STATUS_UPDATED = "User status updated successfully";
    public static final String LOG_AUTH_SEND_OTP_ATTEMPT = "otp sent to user: {}";
    public static final String API_AUTH_RESEND_OTP = "Resend OTP";
    public static final String API_AUTH_RESEND_OTP_DESCRIPTION = "Resend OTP to the user";
    public static final String ERROR = "Error";
    public static final String ERROR_EMAIL="EMAIL";
    public static final String ERROR_PHONE="PHONE";
    public static final String ERROR_COMPANY="COMPANY";
    public static final String ERROR_COMPANY_REGD_NO = "Regd.No";
    public static final String ERROR_COMPANY_NAME = "COMPANY-NAME";
    public static final String ERROR_CLIENT_NAME = "client-name";

    public static final String EVENT ="event" ;
    public static final String EVENT_READ = "Event marked as Read Successfully";
    public static final String EVENT_TAG = "Calendar Events";
    public static final String JOB_UNASSIGNED_FROM_USER = "Job unassigned from user successfully!";
    public static final String JOB_UNASSIGNED_FROM_CANDIDATE = "Job unassigned from candidate successfully!";
    public static final Object CANDIDATE_UNASSIGNED_FROM_USER ="Candidate unassigned from user successfully!";

    public static final String CANDIDATE_JOB = "Candidate-Job";
    public static final String EVENT_ID  = "{eventId}";
    public static final String name = "name";
    public static final String phoneNumber = "phoneNumber";
    public static final String email = "email";
    public static final String candidate = "candidate";
    public static final String jobTitle = "jobTitle";
    public static final String clientName = "clientName";
    public static final String EVENT_CREATION ="Event Created Successfully!";
    public static final String EVENT_UPDATE = "Event Updated Successfully";
    public static final String EVENT_DELETE = "Event Deleted Successfully";
    public static final String CANDIDATE_USER = "candidate-user";

    //Candidate Status Constants
    public static final String FILTER_STAR = "*";
    public static final String FILTER_CREATED = "CREATED";
    public static final String JOB_ID_REQUIRED = "Job ID is required field";
    public static final String FIRST_NAME_MAIL = "{firstName}";
    public static final String LAST_NAME_MAIL = "{lastName}";
    public static final String CANDIDATE_NAME_MAIL = "{candidateName}";

    //Client Comments Constants
    public static final String CLIENT_COMMENT = "Client-Comment";
    public static final String[] DATE_PATTERNS = {
            "yyyy-MM-dd", "dd-MM-yyyy", "MM/dd/yyyy", "dd/MM/yyyy","dd-MMM-yyyy"
    };
    public static final String JOB_ID ="jobId" ;
}