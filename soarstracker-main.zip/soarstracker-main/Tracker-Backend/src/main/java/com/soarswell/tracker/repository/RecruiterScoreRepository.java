package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.RecruiterScore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RecruiterScoreRepository extends JpaRepository<RecruiterScore, String> {

    List<RecruiterScore> findByCompanyIdAndUserId(String companyId, String userId);

    @Query("SELECT COALESCE(SUM(rs.points), 0) FROM RecruiterScore rs WHERE rs.companyId = :companyId AND rs.userId = :userId")
    Integer sumPointsByCompanyAndUser(@Param("companyId") String companyId, @Param("userId") String userId);

    boolean existsByCompanyIdAndUserIdAndCandidateIdAndEventType(String companyId, String userId, String candidateId, String eventType);

    void deleteByCompanyIdAndUserIdAndCandidateIdAndEventType(String companyId, String userId, String candidateId, String eventType);
} 