package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.Candidate;
import com.soarswell.tracker.model.Company;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface CandidateRepository extends JpaRepository<Candidate, String> {

    public Optional<Candidate> findByEmail(String email);

    public boolean existsByCompanyIdAndEmail(String companyId,String email);

    public Page<Candidate> findByCompanyIdAndStatus(String companyId,String status, Pageable pageable);

    public List<Candidate> findByStatus(String Label);
    @Query("SELECT c FROM Candidate c WHERE c.companyId = :companyId " +
            "AND c.status = :status " +
            "AND (" +
            "LOWER(TRIM(REPLACE(CONCAT(c.firstName, ' ', COALESCE(c.middleName, ''), ' ', c.lastName), '  ', ' '))) LIKE LOWER(CONCAT('%', REPLACE(:keyword, '  ', ' '), '%')) OR " +
            "LOWER(c.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.phoneNumber AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.address) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.skills) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.candidateRole) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.alternateEmail) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.alternatePhoneNumber AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.experience) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.noticePeriod) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.currentSalary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "CAST(c.expectedSalary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.candidatureStatus) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(FUNCTION('DATE_FORMAT',c.dateOfBirth, '%Y-%m-%d')) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(FUNCTION('DATE_FORMAT', c.availabilityOfJoining, '%Y-%m-%d')) LIKE LOWER(CONCAT('%', :keyword, '%'))" +
            ")")

    public Page<Candidate> searchAllFieldsByCompanyIdAndStatus(@Param("companyId") String companyId,
                                                        @Param("status") String status,
                                                        @Param("keyword") String keyword,
                                                        Pageable pageable);

    @Query("SELECT c FROM Candidate c WHERE c.companyId = :companyId " +
            "AND c.status = :status " +
            "AND c.candidatureStatus = :candidatureStatus " +
            "AND (" +
            "LOWER(TRIM(REPLACE(CONCAT(c.firstName, ' ', COALESCE(c.middleName, ''), ' ', c.lastName), '  ', ' '))) LIKE LOWER(CONCAT('%', REPLACE(:keyword, '  ', ' '), '%')) OR " +
            "LOWER(c.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.phoneNumber AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.address) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.skills) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.candidateRole) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.alternateEmail) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.alternatePhoneNumber AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.experience) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.noticePeriod) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.currentSalary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "CAST(c.expectedSalary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.candidatureStatus) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(FUNCTION('DATE_FORMAT',c.dateOfBirth, '%Y-%m-%d')) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(FUNCTION('DATE_FORMAT', c.availabilityOfJoining, '%Y-%m-%d')) LIKE LOWER(CONCAT('%', :keyword, '%'))" +
            ")")

    public Page<Candidate> searchAllFieldsByCompanyIdAndStatusAndCandidatureStatus(@Param("companyId") String companyId,
                                                               @Param("status") String status,
                                                               @Param("keyword") String keyword,
                                                               @Param("candidatureStatus") String candidatureStatus,
                                                               Pageable pageable);

    public Page<Candidate> findByCompanyIdAndStatusAndCandidatureStatus(String companyId, String status, String candidatureStatus, Pageable pageable);
    public List<Candidate> findByCompanyIdAndStatus(String companyId,String status);
    public boolean existsByCompanyIdAndPhoneNumber(String companyId,String phoneNumber);
    public boolean existsByCompanyIdAndAlternatePhoneNumber(String compabyId,String alternatePhoneNumber);
    public boolean existsByCompanyIdAndAlternateEmail(String companyId, String alternateEmail);
    public Optional<Candidate> findByCompanyIdAndId(String companyId, String id);
    public List<Candidate> findAllByCompanyId(String companyId);
    public boolean existsByIdAndStatusAndCompanyId(String candidateId, String shortLabel, String companyId);
    public Optional<Candidate> findByCompanyIdAndIdAndStatus(String companyId, String id,String status);

    @Query("SELECT c FROM  Candidate c WHERE c.companyId = :companyId AND c.candidatureStatus = :candidatureStatus AND c IN :candidates")
    public Page<Candidate> candidateForParticularClientStatus(@Param("companyId") String companyId,
            @Param("candidatureStatus") String candidatureStatus,
            @Param("candidates") List<Candidate> candidates,
            Pageable pageable
            );

    @Query("SELECT c FROM  Candidate c WHERE c.companyId = :companyId AND c IN :candidates")
    public Page<Candidate> candidateForParticularClient(@Param("companyId") String companyId,
                                                        @Param("candidates") List<Candidate> candidates,
                                                        Pageable pageable);

    @Query("SELECT c FROM Candidate c WHERE c.companyId = :companyId " +
            "AND c IN :candidates " +
            "AND (" +
            "LOWER(TRIM(REPLACE(CONCAT(c.firstName, ' ', COALESCE(c.middleName, ''), ' ', c.lastName), '  ', ' '))) LIKE LOWER(CONCAT('%', REPLACE(:keyword, '  ', ' '), '%')) OR " +
            "LOWER(c.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.phoneNumber AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.address) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.skills) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.candidateRole) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.alternateEmail) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.alternatePhoneNumber AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.experience) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.noticePeriod) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.currentSalary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "CAST(c.expectedSalary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.candidatureStatus) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(FUNCTION('DATE_FORMAT',c.dateOfBirth, '%Y-%m-%d')) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(FUNCTION('DATE_FORMAT', c.availabilityOfJoining, '%Y-%m-%d')) LIKE LOWER(CONCAT('%', :keyword, '%'))" +
            ")")
    public Page<Candidate> searchCandidateForParticularClient(
            @Param("companyId") String companyId,
            @Param("candidates") List<Candidate> candidates,
            @Param("keyword") String keyword,
            Pageable pageable
    );

    @Query("SELECT c FROM Candidate c WHERE c.companyId = :companyId " +
            "AND c.candidatureStatus = :candidatureStatus " +
            "AND c IN :candidates " +
            "AND (" +
            "LOWER(TRIM(REPLACE(CONCAT(c.firstName, ' ', COALESCE(c.middleName, ''), ' ', c.lastName), '  ', ' '))) LIKE LOWER(CONCAT('%', REPLACE(:keyword, '  ', ' '), '%')) OR " +
            "LOWER(c.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.phoneNumber AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.address) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.skills) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.candidateRole) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.alternateEmail) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.alternatePhoneNumber AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.experience) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.noticePeriod) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.currentSalary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "CAST(c.expectedSalary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(c.candidatureStatus) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(FUNCTION('DATE_FORMAT',c.dateOfBirth, '%Y-%m-%d')) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(FUNCTION('DATE_FORMAT', c.availabilityOfJoining, '%Y-%m-%d')) LIKE LOWER(CONCAT('%', :keyword, '%'))" +
            ")")
    public Page<Candidate> searchCandidateForParticularClientStatus(
            @Param("companyId") String companyId,
            @Param("candidatureStatus") String candidatureStatus,
            @Param("candidates") List<Candidate> candidates,
            @Param("keyword") String keyword,
            Pageable pageable
    );

    public Page<Candidate> findByCompanyIdAndStatusAndGenderIgnoreCase(String companyId,String  status,String gender,Pageable pageable);

    public Page<Candidate>  findByCompanyIdAndStatusAndCandidatureStatusAndGenderIgnoreCase(String companyId, String status,String statusfilter,String gender,Pageable pageable);

    @Query("SELECT c FROM Candidate c WHERE c.companyId = :companyId AND c.candidatureStatus = :candidatureStatus AND c.gender = :gender AND c IN :candidates")
    public Page<Candidate> candidateForParticularClientStatusAndGender(@Param("companyId") String companyId,
                                                              @Param("candidatureStatus") String candidatureStatus,
                                                              @Param("candidates") List<Candidate> candidates,
                                                              @Param("gender" ) String gender,
                                                              Pageable pageable
    );

    @Query("SELECT c FROM Candidate c WHERE c.companyId = :companyId AND c.gender = :gender AND c IN :candidates")
    public Page<Candidate> candidateForParticularClientAndGender(@Param("companyId") String companyId,
                                                        @Param("candidates") List<Candidate> candidates,
                                                        @Param("gender") String gender,
                                                        Pageable pageable);


}