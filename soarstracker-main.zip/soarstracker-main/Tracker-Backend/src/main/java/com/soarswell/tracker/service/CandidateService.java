package com.soarswell.tracker.service;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.model.payload.CandidateRequest;
import com.soarswell.tracker.model.payload.CandidateStatusRequest;
import com.soarswell.tracker.model.payload.CandidateUpdate;
import com.soarswell.tracker.model.payload.FullAIResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.soarswell.tracker.exception.TrackerException;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface CandidateService {

    ResponseEntity<?> register(CandidateRequest candidateRequest, MultipartFile resumeFile, RequestDetails requestDetails) throws TrackerException;

    ResponseEntity<?> getAllCandidates(int page, int size, RequestDetails requestDetails, String sortByField, String order,String keyword,String filter,String gender,String statusfilter,String clientId) throws TrackerException;

    ResponseEntity<?> getCandidateById(String id) throws TrackerException;

    ResponseEntity<?> deleteCandidateById(String id,RequestDetails requestDetails) throws TrackerException;

    ResponseEntity<?> updateCandidate(String id, CandidateUpdate candidateUpdate,RequestDetails requestDetails) throws TrackerException;

    ResponseEntity<?> updateStatus(String id, CandidateStatusRequest candidateStatusRequest,RequestDetails requestDetails);

    ResponseEntity<?>uploadCandidatesFile(MultipartFile file, RequestDetails requestDetails);

    ResponseEntity<?> getJobByCandidateId(String id,RequestDetails requestDetails) throws TrackerException;

    public ResponseEntity<?>  candidateAssignToUser(String recruiterId,String jobId) throws TrackerException;

    public ResponseEntity<?> candidateUnassignFromUser(String candidateId, String jobId) throws TrackerException;
    
    public ResponseEntity<?> candidateReassignUser(String candidateId, String UserId) throws TrackerException;

    public FullAIResponse parseResumeForAutofill(MultipartFile resumeFile);
}