package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.CommentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommentRepository extends JpaRepository<CommentEntity,String> {

    public List<CommentEntity> findByCandidateId(String  candidateId);
}
