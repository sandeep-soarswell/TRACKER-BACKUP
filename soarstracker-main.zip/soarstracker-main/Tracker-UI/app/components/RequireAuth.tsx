import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { jwtDecode } from 'jwt-decode';
import authService from '~/services/login/login.services';

interface RequireAuthProps {
  children: ReactNode;
}

interface DecodedToken {
  sub: string;
  roles: string[];
  userId: string;
  exp: number;
  iat: number;
}

const RequireAuth = ({ children }: RequireAuthProps) => {
  const navigate = useNavigate();
  const location = useLocation();
  const hasRun = useRef(false);
  const tokenCheckInterval = useRef<NodeJS.Timeout | null>(null);
  const initialToken = useRef<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  const logout = (reason: string = 'Session expired') => {
    console.log(`Auto logout: ${reason}`);
    localStorage.removeItem('userToken');
    setIsAuthenticated(false);
    if (tokenCheckInterval.current) {
      clearInterval(tokenCheckInterval.current);
      tokenCheckInterval.current = null;
    }
    navigate('/', { replace: true, state: { message: reason } });
  };

  const isTokenExpired = (token: string): boolean => {
    try {
      const decoded: DecodedToken = jwtDecode(token);
      const currentTime = Math.floor(Date.now() / 1000);
      return decoded.exp < currentTime;
    } catch {
      return true;
    }
  };

  const validateCurrentToken = async (token: string): Promise<boolean> => {
    try {
      if (isTokenExpired(token)) {
        logout('Token expired');
        return false;
      }
      const result = await authService.validateToken(token);
      if (result.message.toLowerCase() !== 'success') {
        logout('Token validation failed');
        return false;
      }
      return true;
    } catch {
      logout('Authentication error');
      return false;
    }
  };

  const checkTokenChanges = () => {
    const currentToken = localStorage.getItem('userToken');
    if (!currentToken && initialToken.current) {
      logout('Token was removed');
      return;
    }
    if (currentToken && initialToken.current && currentToken !== initialToken.current) {
      validateCurrentToken(currentToken).then((isValid) => {
        if (isValid) {
          initialToken.current = currentToken;
        } else {
          logout('Invalid token detected');
        }
      });
      return;
    }
    if (currentToken && isTokenExpired(currentToken)) {
      logout('Token expired');
      return;
    }
  };

  useEffect(() => {
    if (hasRun.current) return;
    hasRun.current = true;

    const checkAuth = async () => {
      const token = localStorage.getItem('userToken');
      if (!token) {
        logout('No authentication token found');
        return;
      }
      initialToken.current = token;
      const isValid = await validateCurrentToken(token);
      if (isValid) {
        setIsAuthenticated(true);
        tokenCheckInterval.current = setInterval(() => {
          checkTokenChanges();
        }, 30000);
        const expirationCheckInterval = setInterval(() => {
          const currentToken = localStorage.getItem('userToken');
          if (currentToken && isTokenExpired(currentToken)) {
            logout('Token expired');
            clearInterval(expirationCheckInterval);
          }
        }, 300000);
        return () => {
          if (tokenCheckInterval.current) {
            clearInterval(tokenCheckInterval.current);
          }
          clearInterval(expirationCheckInterval);
        };
      }
    };

    checkAuth();

    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === 'userToken') {
        const newToken = event.newValue;
        const oldToken = event.oldValue;
        if (!newToken && oldToken) {
          logout('Token was removed from another tab');
          return;
        }
        if (newToken && oldToken && newToken !== oldToken) {
          validateCurrentToken(newToken).then((isValid) => {
            if (isValid) {
              initialToken.current = newToken;
              setIsAuthenticated(true);
            } else {
              logout('Invalid token from another tab');
            }
          });
          return;
        }
        if (newToken && !oldToken) {
          window.location.reload();
        }
      }
    };
    const handleWindowFocus = () => {
      checkTokenChanges();
    };
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        checkTokenChanges();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('focus', handleWindowFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('focus', handleWindowFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (tokenCheckInterval.current) {
        clearInterval(tokenCheckInterval.current);
      }
    };
  }, [navigate, location.pathname]);

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Verifying authentication...</p>
        </div>
      </div>
    );
  }
  return isAuthenticated ? <>{children}</> : null;
};

export default RequireAuth;
