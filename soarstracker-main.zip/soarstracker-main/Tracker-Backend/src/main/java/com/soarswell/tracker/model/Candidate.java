package com.soarswell.tracker.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.soarswell.tracker.persistance.AbstractEntity;
import jakarta.persistence.*;
import jakarta.persistence.Entity;

import java.net.URL;
import java.time.LocalDate;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "candidate", indexes = {
        @Index(name = "idx_candidate_status", columnList = "status"),
        @Index(name= "idx_candidate_role", columnList = "candidateRole"),
        @Index(name="idx_candidate_company_status", columnList = "companyId, status"),
        @Index(name= "idx_candidate_candidate_job_id", columnList = "candidate_job_assign_id"),
        @Index(name= "idx_candidate_candidate_user_id", columnList = "candidate_user_assign_id"),
        @Index(name= "idx_candidate_id_company", columnList = "id, companyId"),
        @Index(name= "idx_candidate_candidature_status", columnList = "candidatureStatus")

})
@Getter
@Setter
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Candidate extends AbstractEntity {

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "middle_name")
    private String middleName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "date_of_birth")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOfBirth;

    @Column(nullable = false)
    private String email;

    @Column(name = "phone_number",columnDefinition = "varchar(15)")
    private String phoneNumber;

    @Column(columnDefinition = "TEXT")
    private String address;

    @Column(columnDefinition = "TEXT")
    private String skills;

    @Column(name = "candidateRole")
    private String candidateRole;

    @Column(name = "alternate_email")
    private String alternateEmail;

    @Column(name = "alternate_phone_number",columnDefinition = "varchar(15)")
    private String alternatePhoneNumber;

    @Column(name = "availability_of_joining")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate availabilityOfJoining;

    private String experience;

    @Column(name = "notice_period")
    private String noticePeriod;

    @Column(name = "current_salary")
    private String currentSalary;

    @Column(name = "expected_salary")
    private String expectedSalary;

    @Column(name = "resume")
    private URL resume;

    @NotNull(message = "Role is required")
    private String status=Status.ACTIVE.getLongLabel();

    @Column(name = "candidatureStatus")
    private String candidatureStatus ;

    private String companyId;

    private String alternateCountryCode;

    private String countryCode;

    private String numberOfOffers;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="candidate_user_assign_id")  // The foreign key for CandidateAssignment
    @JsonIgnore
    private CandidateUserAssignment assignment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "candidate_job_assign_id")  // The foreign key for CandidateJobAssign
    @JsonIgnore
    private CandidateJobAssign jobAssignment;

    private String acceptedPackage;

    private String gender;
    private Double collegeRating;
    private Double companyRating;
    private Double experienceRating;
    private Double skillsRating;

    @Column(columnDefinition = "TEXT")
    private String aiSummary;

}