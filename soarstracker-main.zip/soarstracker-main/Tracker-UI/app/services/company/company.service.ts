import api from '../api/api.services';
import type { CompanyType } from '~/pages/company/companytype';

const companyService = {
  register: async (payload: any) => {
    const response = await api.post('/company', payload);
    return response.data?.data || response.data;
  },

  update: async (companyId: string, payload: any) => {
    const response = await api.patch(`/company/${companyId}`, payload.changedFields);
    return response.data?.data || response.data;
  },

  getAll: async (
    page: number,
    size: number,
    searchTerm: string = "",
    sortByField: string = "createDate",
    desc: string = "desc"
  ) => {
    try {
      const response = await api.get(
        `/company?page=${page}&size=${size}&sortByField=${sortByField}&desc=${desc}${searchTerm ? `&keyword=${encodeURIComponent(searchTerm)}` : ""}`
      );
      const responseData = response.data?.data || {};
      const companies = responseData.data || [];
      const total = responseData.totalEnties || responseData.totalRecords || companies.length;

      return {
        content: companies,
        totalElements: total,
      };
    } catch (error) {
      throw error;
    }
  },

  getById: async (companyId: string) => {
    const response = await api.get(`/company/${companyId}`);
    return response.data?.data || response.data;
  },

  uploadImage: async (companyId: string, formData: FormData) => {
    try {
      formData.append('image', 'true');

      const response = await api.patch(`/company/${companyId}/image`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Accept': 'application/json',
        },
      });
      return response.data?.data || response.data;
    } catch (error) {
      throw error;
    }
  },
  getCompanyImage: async (companyId: string, token: string): Promise<string | null> => {
    try {
      const response = await api.get(`/company/${companyId}/image`, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'files/image/*',
        },
        responseType: 'blob',
      });

      if (response.data && response.data.size > 0) {
        return URL.createObjectURL(response.data);
      }
      return null;
    } catch (error) {
      return null;
    }
  },
};


export default companyService;