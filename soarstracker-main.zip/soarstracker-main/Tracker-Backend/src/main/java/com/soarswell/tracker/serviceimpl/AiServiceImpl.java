package com.soarswell.tracker.serviceimpl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.soarswell.tracker.model.Candidate;
import com.soarswell.tracker.model.Job;
import com.soarswell.tracker.model.payload.AISuitabilityResponse;
import com.soarswell.tracker.model.payload.FullAIResponse;
import com.soarswell.tracker.service.AiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AiServiceImpl implements AiService {

    private final ObjectMapper objectMapper;

    @Value("${openrouter.api.key}")
    private String openRouterApiKey;

    @Override
    public FullAIResponse processResume(String resumeContent) {
        String prompt = createFullAnalysisPrompt(resumeContent);
        try {
            String responseJson = callOpenRouterApi(prompt);
            JsonNode rootNode = objectMapper.readTree(responseJson);
            String aiContent = rootNode.path("choices").path(0).path("message").path("content").asText();

            String cleanedJson = cleanJsonResponse(aiContent);
            log.info("Full AI Analysis Response: {}", cleanedJson);
            return objectMapper.readValue(cleanedJson, FullAIResponse.class);

        } catch (Exception e) {
            log.error("Error performing full AI analysis on resume", e);
            return new FullAIResponse(); // Return an empty object on error
        }
    }

    @Override
    public List<AISuitabilityResponse> getSuitabilityScores(Job job, List<Candidate> candidates) {
        String prompt = createSuitabilityPrompt(job, candidates);
        try {
            String responseJson = callOpenRouterApi(prompt);
            JsonNode rootNode = objectMapper.readTree(responseJson);
            String aiContent = rootNode.path("choices").path(0).path("message").path("content").asText();
            String cleanedJson = cleanJsonResponse(aiContent);
            log.info("AI Suitability Response: {}", cleanedJson);
            return objectMapper.readValue(cleanedJson, new TypeReference<List<AISuitabilityResponse>>() {});

        } catch (Exception e) {
            log.error("Error getting suitability scores from AI", e);
            return Collections.emptyList();
        }
    }

    private String callOpenRouterApi(String promptContent) throws IOException, InterruptedException {
        String requestBody = String.format("""
                {
                  "model": "google/gemini-flash-1.5",
                  "messages": [
                    { "role": "user", "content": "%s" }
                  ]
                }
                """, promptContent.replace("\"", "\\\""));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://openrouter.ai/api/v1/chat/completions"))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + openRouterApiKey)
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            log.error("API call failed with status code {}: {}", response.statusCode(), response.body());
            throw new IOException("API call failed: " + response.body());
        }
        return response.body();
    }

    private String createFullAnalysisPrompt(String resumeContent) {
        return """
        You are a world-class HR data processing tool. Your only task is to extract key details and perform a technical analysis of the provided resume text. Return everything in a single, PURE JSON object.

        PART 1: DATA EXTRACTION
        Extract the following fields. If a field cannot be found, return an empty string "" for it.
        - firstName, middleName, lastName, email, phoneNumber, skills, experience (e.g., "5 Years"), candidateRole, address, dateOfBirth (e.g., "1995-08-21"), alternateEmail, alternatePhoneNumber, availabilityOfJoining, noticePeriod, currentSalary, expectedSalary.

        PART 2: CANDIDATE ANALYSIS
        Provide ratings on a 1-5 scale and a professional summary.
        - collegeRating, companyRating, experienceRating, skillsRating.
        - summary: A concise, 4-5 line professional summary that justifies your ratings.

        CRITICAL INSTRUCTION: Your entire response must be ONLY the valid JSON object specified in the template below. Do not include ```json` markers or any other text.

        JSON TEMPLATE:
        {
          "firstName": "",
          "middleName": "",
          "lastName": "",
          "email": "",
          "phoneNumber": "",
          "skills": "",
          "experience": "",
          "candidateRole": "",
          "address": "",
          "dateOfBirth": "",
          "alternateEmail": "",
          "alternatePhoneNumber": "",
          "availabilityOfJoining": "",
          "noticePeriod": "",
          "currentSalary": "",
          "expectedSalary": "",
          "collegeRating": 0.0,
          "companyRating": 0.0,
          "experienceRating": 0.0,
          "skillsRating": 0.0,
          "summary": ""
        }

        Resume to analyze:
        """ + resumeContent;
    }

    private String createSuitabilityPrompt(Job job, List<Candidate> candidates) {
        String candidatesJson = candidates.stream()
                .map(c -> String.format(
                        "{\"id\": \"%s\", \"experience\": \"%s\", \"skills\": \"%s\", \"aiSummary\": \"%s\"}",
                        c.getId(),
                        escapeJson(c.getExperience()),
                        escapeJson(c.getSkills()),
                        escapeJson(c.getAiSummary())
                ))
                .collect(Collectors.joining(",\n"));

        return String.format("""
        You are an expert AI recruiting assistant. Your task is to compare the following job description against a list of candidates and score their suitability.

        JOB DESCRIPTION:
        Title: %s
        Required Experience: %s
        Required Skills: %s
        Description: %s

        CANDIDATES LIST:
        [
        %s
        ]

        CRITICAL INSTRUCTIONS:
        1. Analyze each candidate's `aiSummary`, `skills`, and `experience` against the job requirements.
        2. Return a JSON array of objects for ONLY the candidates with a suitabilityScore of 60 or higher.
        3. The `suitabilityScore` must be an integer between 60 and 100.
        4. Your entire response must be ONLY the valid JSON array. Do not include ```json` markers or any other text.

        JSON TEMPLATE FOR YOUR RESPONSE:
        [
          { "candidateId": "ID_of_matched_candidate", "suitabilityScore": 85 },
          { "candidateId": "ID_of_another_matched_candidate", "suitabilityScore": 70 }
        ]
        """, escapeJson(job.getTitle()), escapeJson(job.getExperience()), escapeJson(job.getSkills()), escapeJson(job.getDescription()), candidatesJson);
    }

    private String escapeJson(String text) {
        if (text == null) return "";
        return text.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    private String cleanJsonResponse(String response) {
        int firstBracket = response.indexOf('{');
        int firstSquareBracket = response.indexOf('[');
        int start;

        if (firstBracket == -1) {
            start = firstSquareBracket;
        } else if (firstSquareBracket == -1) {
            start = firstBracket;
        } else {
            start = Math.min(firstBracket, firstSquareBracket);
        }

        if (start == -1) {
            return "{}";
        }

        char openingBracket = response.charAt(start);
        char closingBracket = (openingBracket == '{') ? '}' : ']';
        int lastBracket = response.lastIndexOf(closingBracket);

        if (lastBracket != -1 && lastBracket > start) {
            return response.substring(start, lastBracket + 1);
        }

        return "{}";
    }
}