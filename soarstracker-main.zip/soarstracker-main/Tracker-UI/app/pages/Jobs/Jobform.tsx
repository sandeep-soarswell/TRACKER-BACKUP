import React, { useState, useEffect } from 'react';
import Button from '~/components/ui/Button';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import DrawerLayout from '~/components/layout/DrawerLayout';
import type { Job } from '~/pages/types/types';
import jobService from '~/services/job/job.services';
import clientService from '~/services/client/client.services';
import { isValidPhoneNumber } from 'libphonenumber-js';
import { PhoneInput } from "react-international-phone";
import 'react-international-phone/style.css';
import { formatSalaryRangeWithCommas, formatSalaryWithCommas } from '~/components/util/util.services';
import getChangedFields from 'app/components/util/update-util';
import CustomSnackbar from '~/components/ui/Customsnackbar';
interface Client {
  id: string;
  name: string;
}

interface JobFormProps {
  job?: Job;
  open?: boolean;
  onClose: () => void;
  onSuccess: () => void;
  clientId: string | null;
}
const skillsOptions = ["JavaScript", "React", "Node.js", "Java", "Python", "TypeScript"];
const JobForm: React.FC<JobFormProps> = ({ job, onClose, onSuccess, clientId }) => {
  const isEditMode = Boolean(job);
  const [statusError, setStatusError] = useState<string | null>(null);
  const [statusSuccess, setStatusSuccess] = useState<string | null>(null);
  const [selectedClientId, setSelectedClientId] = useState<string | null>(clientId);
  const [clientIdError, setClientIdError] = useState<string | null>(null);
  const [clients, setClients] = useState<Client[]>([]);
  const [backendFieldErrors, setBackendFieldErrors] = useState<{ [key: string]: string }>({});
  const [selectedCurrency, setSelectedCurrency] = useState("₹");
  const validationSchema = Yup.object({
    jobId: Yup.string()
      .required('Job ID is required')
      .min(4, "Job ID must be at least 4 characters"),
    title: Yup.string()
      .required('Job title is required')
      .min(2, "Job title must be at least 2 characters")
      .max(36, "Job title must be at most 36 characters"),
    description: Yup.string()
      .required('Description is required')
      .min(4, "Description must be at least 4 characters")
      .max(500, "Description must be at most 500 characters"),
    location: Yup.string().required('Location is required'),
    skills: Yup.array().min(1, 'Select at least one skill'),
    experience: Yup.string().required('Experience is required'),
    salary: Yup.string()
      .required('Expected salary is required'),
    openings: Yup.number().required('Openings required').min(1, 'Min 1 opening'),
    contactEmail: Yup.string()
      .trim()
      .email('Enter a valid email')
      .matches(/^[a-z][a-z0-9._%+-]*@[a-z0-9.-]+\.[a-z]{2,}$/, 'Invalid email format')
      .required('Please enter email'),
    contactNumber: Yup.string()
      .required('Contact number is required')
      .test('is-valid-phone', 'Invalid phone number for selected country', function (value) {
        if (!value) return false;
        return isValidPhoneNumber(value);
      }),
    contactPerson: Yup.string()
      .trim()
      .min(3, 'Minimum 3 characters')
      .max(20, 'Maximum 20 characters')
      .matches(/^[a-zA-Z\s]+$/, 'Only letters and spaces are allowed')
      .required('Contact person name is required'),
    deadline: Yup.date()
      .required('Deadline is required')
      .min(new Date(), 'Deadline must be a future date')
      .test(
        'year-format',
        'Year must be a 4-digit year',
        value => {
          if (!value) return false;
          const year = new Date(value).getFullYear();
          return year >= 1000 && year <= 9999;
        }
      ),
  });

  const formik = useFormik({
    initialValues: {
      jobId: job?.jobId || '',
      title: job?.title || '',
      description: job?.description || '',
      location: job?.location || '',
      skills: typeof job?.skills === 'string'
        ? (job.skills as string).split(',').map((s: string) => s.trim().toLowerCase())
        : Array.isArray(job?.skills)
          ? job.skills.map((s: string) => s.toLowerCase())
          : [],
      experience: job?.experience || '',
      salary: job?.salary !== undefined ? String(job.salary) : '',
      openings: job?.openings || '',
      contactPerson: job?.contactPersonName || '',
      contactEmail: job?.contactPersonEmail || '',
      contactNumber: job?.contactPersonPhone || '',
      deadline: job?.deadline || '',
    },
    validationSchema,
    onSubmit: async (values) => {
      setClientIdError(null);
      setBackendFieldErrors({});
      try {
        const payload = {
          jobId: values.jobId ? values.jobId.trim() : null,
          title: values.title || null,
          description: values.description || null,
          location: values.location || null,
          skills: values.skills.join(',') || null,
          experience: values.experience || null,
          salary: values.salary || null,
          openings: values.openings || null,
          deadline: values.deadline || null,
          contactPersonName: values.contactPerson || null,
          contactPersonEmail: values.contactEmail || null,
          contactPersonPhone: values.contactNumber || null,
        };
        if (isEditMode && job?.id) {
          const changedFields = getChangedFields(job, payload);
          await jobService.update(String(job.id), changedFields);
          setStatusSuccess("Job updated successfully!");
        } else {
          if (!selectedClientId) {
            setClientIdError("Please select a client.");
            return;
          }
          await jobService.create(selectedClientId, payload);
          setStatusSuccess("Job registered successfully!");
        }

        onSuccess();
        onClose();
      } catch (error: any) {
        const backendError = error?.response?.data?.error;
        if (backendError && typeof backendError === 'object' && !Array.isArray(backendError)) {
          Object.entries(backendError).forEach(([field, message]) => {
                formik.setFieldError(field, message as string);
          });
        }else {
          setStatusError("Something went wrong. Please try again.");
        }
      }
    },
  });


  const fetchClients = async () => {
    try {
      const { content } = await clientService.getAll(0, 1000, "", "ACTIVE", "createDate", "desc");
      setClients(content.map((client: any) => ({
        id: client.id,
        name: client.clientName,
      })));
    } catch (err) {
      console.log('Error fetching clients:', err);
      setClients([]);
    }
  };

  useEffect(() => {
    fetchClients();
  }, []);

  return (
    <>
      <DrawerLayout
        title={isEditMode ? 'Edit Job' : 'Register Job'}
        onClose={onClose}
        footer={
          <Button
            variant="primary"
            type="button"
            onClick={() => formik.handleSubmit()}
            disabled={!(formik.isValid && formik.dirty && !formik.isSubmitting)}
          >
            {isEditMode ? 'Update' : 'Create'}
          </Button>
        }
      >
        <form id="registerform" onSubmit={formik.handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="jobId" className="block text-sm font-medium text-gray-700 mb-1">
                Job ID <span className="text-red-500">*</span>
              </label>
              <input
                id="jobId"
                name="jobId"
                type="text"
                value={formik.values.jobId}
                onChange={e => {
                  formik.handleChange(e);
                  // Clear backend error on change
                  setBackendFieldErrors(prev => ({ ...prev, jobId: '' }));
                }}
                onBlur={formik.handleBlur}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.jobId && (formik.errors.jobId || backendFieldErrors.jobId) ? 'border-red-500' : 'border-gray-300'
                  }`}
              />
              {formik.touched.jobId && formik.errors.jobId && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.jobId}</p>
              )}
              {/* Show backend error below input */}
              {backendFieldErrors.jobId && (
                <p className="text-red-500 text-sm mt-1">{backendFieldErrors.jobId}</p>
              )}
            </div>
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Job Title <span className="text-red-500">*</span>
              </label>
              <input
                id="title"
                name="title"
                type="text"
                value={formik.values.title}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.title && formik.errors.title ? 'border-red-500' : 'border-gray-300'}`}
              />
              {formik.touched.title && formik.errors.title && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.title}</p>
              )}
            </div>
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                Location <span className="text-red-500">*</span>
              </label>
              <input
                id="location"
                name="location"
                type="text"
                value={formik.values.location}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.location && formik.errors.location ? 'border-red-500' : 'border-gray-300'}`}
              />
              {formik.touched.location && formik.errors.location && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.location}</p>
              )}
            </div>
            <div className="flex-1">
              <label htmlFor="deadline" className="block text-sm font-medium text-gray-700 mb-1">
                Deadline <span className="text-red-500">*</span>
              </label>
              <input
                id="deadline"
                name="deadline"
                type="date"
                value={formik.values.deadline}
                onChange={e => {
                  const parts = e.target.value.split('-');
                  if (parts[0] && parts[0].length > 4) {
                    parts[0] = parts[0].slice(0, 4);
                    e.target.value = parts.join('-');
                  }
                  formik.handleChange(e);
                }}
                onBlur={e => {
                  formik.handleBlur(e);
                  const year = e.target.value.split('-')[0];
                  if (year.length !== 4) {
                    formik.setFieldError('deadline', 'Year must be exactly 4 digits');
                  }
                }}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.deadline && formik.errors.deadline ? 'border-red-500' : 'border-gray-300'}`}
              />
              {formik.touched.deadline && formik.errors.deadline && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.deadline}</p>
              )}
            </div>
            <div>
              <label htmlFor="experience" className="block text-sm font-medium text-gray-700 mb-1">
                Experience <span className="text-red-500">*</span>
              </label>
              <input
                id="experience"
                name="experience"
                type="text"
                value={formik.values.experience}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.experience && formik.errors.experience ? 'border-red-500' : 'border-gray-300'}`}
              />
              {formik.touched.experience && formik.errors.experience && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.experience}</p>
              )}
            </div>
            <div>
              <label htmlFor="salary" className='block text-sm font-medium text-gray-700 mb-1'>
                Salary<span className="text-red-500">*</span>
              </label>
              <div className={`flex items-center w-full rounded-md border text-sm bg-white
                    
                  ${formik.touched.salary && formik.errors.salary ? 'border-red-500' : 'border-gray-300'}`}>
                <select
                  className="bg-gray-100 border-r border-gray-300 rounded-l-md p-2 text-sm cursor-pointer focus:outline-none"
                  value={selectedCurrency}
                  onChange={(e)=> setSelectedCurrency(e.target.value)}>
                  <option value="₹">INR (₹)</option>
                  <option value="$">USD ($)</option>
                  <option value="€">EUR (€)</option>
                  <option value="£">GBP (£)</option>
                  <option value="¥">JPY (¥)</option>
                </select>
                <input
                  type="text"
                  name='salary'
                  id="salary"
                  onChange={formik.handleChange}
                  value={formik.values.salary}
                  onBlur={() => {
                    const rawValue = formik.values.salary;

                    if (rawValue.includes("-")) {
                      formik.setFieldValue(
                        "salary",
                        formatSalaryRangeWithCommas(rawValue, selectedCurrency)
                      );
                    } else {
                      formik.setFieldValue(
                        "salary",
                        selectedCurrency.concat(formatSalaryWithCommas(rawValue))
                      );
                    }
                  }}
                  className="w-full px-3 py-2 border-none rounded-r-md"
                />
              </div>
              {formik.touched.salary && formik.errors.salary && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.salary}</p>
              )}
            </div>
            <div>
              <label htmlFor="openings" className="block text-sm font-medium text-gray-700 mb-1">
                Openings <span className="text-red-500">*</span>
              </label>
              <input
                id="openings"
                name="openings"
                type="number"
                value={formik.values.openings}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.openings && formik.errors.openings ? 'border-red-500' : 'border-gray-300'}`}
              />
              {formik.touched.openings && formik.errors.openings && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.openings}</p>
              )}
            </div>
            <div>
              <label htmlFor="contactPerson" className="block text-sm font-medium text-gray-700 mb-1">
                Contact Person <span className="text-red-500">*</span>
              </label>
              <input
                id="contactPerson"
                name='contactPerson'
                type="text"
                value={formik.values.contactPerson}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.contactPerson && formik.errors.contactPerson ? 'border-red-500' : 'border-gray-300'}`}
              />
              {formik.touched.contactPerson && formik.errors.contactPerson && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.contactPerson}</p>
              )}
            </div>
            <div>
              <label htmlFor="contactEmail" className="block text-sm font-medium text-gray-700 mb-1">
                Contact Email <span className="text-red-500">*</span>
              </label>
              <input
                id="contactEmail"
                name='contactEmail'
                type="email"
                value={formik.values.contactEmail}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.contactEmail && formik.errors.contactEmail ? 'border-red-500' : 'border-gray-300'}`}
              />
              {formik.touched.contactEmail && formik.errors.contactEmail && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.contactEmail}</p>
              )}
            </div>
            <div>
              <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
                Contact Number <span className="text-red-500">*</span>
              </label>
              <PhoneInput
                defaultCountry="in"
                disabled={isEditMode}
                countrySelectorStyleProps={{
                  buttonStyle: {
                    height: '40px',
                    border: formik.touched.contactNumber && formik.errors.contactNumber
                      ? '1px solid #ef4444'
                      : '1px solid #d1d5db',
                    borderRadius: '6px 0 0 6px',
                    background: '#fff',
                    padding: '0 8px',
                    cursor: isEditMode ? 'not-allowed' : 'pointer',
                    color: isEditMode ? '#6b7280' : 'inherit',
                  },
                }}
                value={formik.values.contactNumber}
                onChange={(value) => {
                  formik.setFieldValue('contactNumber', value);
                }}
                onBlur={() => formik.setFieldTouched('contactNumber', true)}
                forceDialCode
                inputProps={{
                  disabled: isEditMode,
                  name: 'contactNumber',
                  className: `w-full px-3 py-2 rounded-r-md border text-sm ${isEditMode ? '!bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'} ${formik.touched.contactNumber && formik.errors.contactNumber ? 'border-red-500' : 'border-gray-300'}`,
                  style: { height: '40px' },
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                }}
                inputStyle={{
                  borderRadius: '0 6px 6px 0',
                  borderLeft: 'none',
                }}

              />
              {formik.touched.contactNumber && formik.errors.contactNumber && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.contactNumber}</p>
              )}
            </div>
            <div>
              <label htmlFor="skills" className="block text-sm font-medium text-gray-700 mb-1">
                Skills <span className="text-red-500">*</span>
              </label>
              <input
                id="skillsInput"
                type="text"
                placeholder="Type a skill and press Enter"
                className="w-full px-3 py-2 rounded-md border text-sm bg-white mb-2"
                list="skillsOptions"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    const value = (e.target as HTMLInputElement).value.trim();
                    if (!value) return;
                    const lowerValue = value.toLowerCase();
                    if (!formik.values.skills.map((s) => s.toLowerCase()).includes(lowerValue)) {
                      formik.setFieldValue('skills', [...formik.values.skills, value]);
                      formik.setFieldTouched('skills', true, false);
                    }
                    (e.target as HTMLInputElement).value = '';
                  }
                }}
              />
              <datalist id="skillsOptions">
                {skillsOptions.map((skill) => (
                  <option key={skill} value={skill} />
                ))}
              </datalist>
              <div className="flex flex-wrap gap-2 mt-2">
                {formik.values.skills.map((skill: string, idx: number) => (
                  <span
                    key={skill + idx}
                    className="inline-flex items-center px-3 py-1 bg-gray-600 text-white rounded text-xs max-w-[48%] break-words"
                  >
                    {skill}
                    <button
                      type="button"
                      className="ml-2 text-white hover:text-red-300 cursor-pointer"
                      onClick={() => {
                        const newSkills = formik.values.skills.filter((_, i) => i !== idx);
                        formik.setFieldValue('skills', newSkills);
                        formik.setFieldTouched('skills', true);
                      }}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
              {formik.touched.skills && formik.errors.skills && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.skills}</p>
              )}
            </div>
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Description <span className="text-red-500">*</span>
              </label>
              <input
                id="description"
                name="description"
                type="text"
                value={formik.values.description}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.description && formik.errors.description ? 'border-red-500' : 'border-gray-300'}`}
              />
              {formik.touched.description && formik.errors.description && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.description}</p>
              )}
            </div>
            {!isEditMode &&
              <div>
                <label htmlFor="client" className="block text-sm font-medium text-gray-700 mb-1">
                  Client <span className="text-red-500">*</span>
                </label>
                <select
                  id="client"
                  value={selectedClientId || ""}
                  onChange={(e) => {
                    setSelectedClientId(e.target.value || null);
                    setClientIdError(null);
                  }}
                  className={`w-full px-3 py-2 rounded-md border text-sm bg-white cursor-pointer ${clientIdError ? 'border-red-500' : 'border-gray-300'}`}
                >
                  <option value="">Select a client</option>
                  {clients.map((client) => (
                    <option key={client.id} value={client.id}>
                      {client.name}
                    </option>
                  ))}
                </select>
                {clientIdError && <p className="text-red-500 text-sm mt-1">{clientIdError}</p>}
              </div>
            }
            {isEditMode &&
              <div>
                <label htmlFor="client" className="block text-sm font-medium text-gray-700 mb-1">
                  Client <span className="text-red-500">*</span>
                </label>
                <input
                  id="client"
                  name="client"
                  type="text"
                  value={job?.clientName}
                  readOnly
                  className="w-full px-3 py-2 rounded-md border text-sm bg-gray-100 border-gray-300 cursor-not-allowed"
                />
              </div>
            }
          </div>
        </form>
      </DrawerLayout>
      <CustomSnackbar
        open={Boolean(statusError)}
        message={statusError || ""}
        onClose={() => setStatusError(null)}
        severity="error"
        autoHideDuration={5000}
      />
      <CustomSnackbar
        open={Boolean(statusSuccess)}
        message={statusSuccess || ""}
        onClose={() => setStatusSuccess(null)}
        severity="success"
        autoHideDuration={5000}
      />
    </>
  )
};
export default JobForm;