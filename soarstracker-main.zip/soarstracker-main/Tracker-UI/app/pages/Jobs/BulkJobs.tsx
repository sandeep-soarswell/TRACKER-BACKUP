import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import jobService from '~/services/job/job.services';
import clientService from '~/services/client/client.services';
import Button from '~/components/ui/Button';

interface UploadJobModalProps {
  onClose: () => void;
   open: boolean;
  onUploadSuccess: () => void;
}

const UploadJobModal: React.FC<UploadJobModalProps> = ({
  onClose,
  onUploadSuccess,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [isValidFile, setIsValidFile] = useState(false);
  const [message, setMessage] = useState('');
  const [uploadResponse, setUploadResponse] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [backendErrors, setBackendErrors] = useState<string[]>([]);
  const [clientId, setClientId] = useState<string>('');
  const [failedRecords, setfailedRecordsCount] = useState<number>(0);
  const [clients, setClients] = useState<{ id: string; name: string }[]>([]);

  useEffect(() => {
    const fetchClients = async () => {
      try {
        const { content } = await clientService.getAll(
          0,
          1000,
          "",
          "ACTIVE",
          "createDate",
          "desc"
        );
        setClients(
          content.map((client: any) => ({
            id: client.id,
            name: client.clientName,
          }))
        );
      } catch {
        setClients([]);
      }
    };
    fetchClients();
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];

    setBackendErrors([]);
    setMessage('');
    setUploadResponse(null);

    if (!selectedFile) {
      setFile(null);
      setIsValidFile(false);
      setMessage('No file selected.');
      return;
    }

    const allowedTypes = [
      'text/csv',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ];

    const fileType = selectedFile.type;
    const fileName = selectedFile.name.toLowerCase();

    const isValid =
      allowedTypes.includes(fileType) ||
      fileName.endsWith('.csv') ||
      fileName.endsWith('.xlsx');

    if (!isValid) {
      setFile(null);
      setIsValidFile(false);
      setMessage('Invalid file type. Please upload a .csv or Excel (.xlsx) file.');
      return;
    }

    setFile(selectedFile);
    setIsValidFile(true);
  };

   const handleUpload = async () => {
    if (!file) {
      setMessage('Please select a valid file.');
      return;
    }

    setLoading(true);
    setMessage('');
    setUploadResponse(null);
      const response = await jobService.uploadCSV(file, clientId);
      setUploadResponse(response?.data || {});
      const { successfulRecords = 0, failedRecords = [] } = response?.data || {};

      if (response.message === 'SUCCESS') {
        onUploadSuccess();
        if (failedRecords.length === 0) onClose();
      }
      else {
        setMessage('Unexpected response from server.');
      }
      setfailedRecordsCount(failedRecords.length);
      setLoading(false);
    
  };

const handleDownloadErrors = () => {
    if (!failedRecords) return;
   const worksheetData = uploadResponse.failedRecords.map(
  (
    record: {
      request: { [key: string]: any };
      error: string;
    },
    idx: number
  ) => {
    return {
      ...record.request,
      ErrorMessage: record.error.split('.\n').filter(Boolean).join(' and '),
    };
  }
);

    const worksheet = XLSX.utils.json_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Upload Errors');
    XLSX.writeFile(workbook, 'FailedRecords.xlsx');
  };


  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/60 px-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4 p-0 relative">
        <div
          className="relative w-full"
          style={{
            backgroundColor: '#0A2463',
            borderTopLeftRadius: '0.5rem',
            borderTopRightRadius: '0.5rem',
          }}
        >
          <h2 className="text-xl md:text-2xl font-bold text-white text-center py-4">
            Upload Jobs File
          </h2>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white hover:text-gray-200 text-2xl font-bold focus:outline-none cursor-pointer"
            aria-label="Close"
            style={{ right: 20, top: 16 }}
          >
            ×
          </button>
        </div>
        <div className="px-6 py-4">
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Select Client <span className="text-red-500">*</span>
            </label>
            <select
              value={clientId}
              onChange={e => setClientId(e.target.value)}
              className="w-full px-3 py-2 rounded-md border text-sm bg-white border-gray-300"
            >
              <option value="">Select a client</option>
              {clients.map(client => (
                <option key={client.id} value={client.id}>
                  {client.name}
                </option>
              ))}
            </select>
          </div>

          <input
            type="file"
            accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:bg-blue-100 file:text-blue-500 hover:file:bg-blue-200 cursor-pointer"
          />

          <Button
            onClick={handleUpload}
            disabled={!file || !isValidFile}
            isLoading={loading}
            fullWidth
            className="mt-4"
          >
            Upload
          </Button>
{uploadResponse && (
            <div className="mt-2 text-sm text-center text-gray-700">
              ✅ <b>{uploadResponse.successfulRecords || 0}</b> record(s) uploaded.
              {uploadResponse.failedRecords.length > 0 && (
                <span className="text-red-600 ml-2">
                  ❌ {uploadResponse.failedRecords.length} records failed to upload.
                </span>
              )}
            </div>
          )}

          {!uploadResponse && !message && (<>
            <a
              href="/JobData.xlsx"
              download
              className="block mt-4 text-sm text-blue-700 flex items-center justify-center hover:text-blue-900 cursor-pointer"
            >
              📥 Download Excel/CSV Template
            </a>
            <p className="text-xs text-gray-500 mt-1 text-center">
              Please upload the file in the same format as the template.
            </p>
          </>
          )}
          {message && (
            <div className="mt-3 max-w-2xl mx-auto bg-red-50 border border-red-200 rounded-lg py-1.5 px-2 shadow-md">
              <div className="flex items-start sm:items-center space-x-4">    
                <div className="flex-shrink-0 text-red-500">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                </div>

               <div className="flex-grow">
                  <p className="text-sm text-red-700 mt-1">
                    {message}
                  </p>
                </div>
</div>
            </div>
            )}

          {uploadResponse && uploadResponse.failedRecords.length > 0 && (
            <div className="mt-3 max-w-2xl mx-auto bg-red-50 border border-red-200 rounded-lg py-1.5 px-2 shadow-md">
              <div className="flex items-start sm:items-center space-x-4">
                <div className="flex-shrink-0 text-red-500">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                </div>

               <div className="flex-grow">
                  <p className="text-sm text-red-700 mt-1">
                    Download the file to see the errors, correct them, and upload it again.
                  </p>
                </div>

                <div className="flex-shrink-0 ml-auto">
                  <button
                    onClick={handleDownloadErrors}
                    className="bg-red-600 text-white text-sm font-semibold px-4 py-2 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-all duration-200 ease-in-out"
                  >
                    Download Errors
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
export default UploadJobModal;
