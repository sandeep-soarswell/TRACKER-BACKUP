package com.soarswell.tracker.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.config.SwaggerConfig;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.CandidateRequest;
import com.soarswell.tracker.model.payload.CandidateStatusRequest;
import com.soarswell.tracker.model.payload.CandidateUpdate;
import com.soarswell.tracker.model.payload.FullAIResponse;
import com.soarswell.tracker.service.AiService;
import com.soarswell.tracker.service.CandidateService;
import com.soarswell.tracker.springsecurity.Authorities;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.MessageKeys;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/candidate")
@Tag(name = SwaggerConfig.CANDIDATE_TAG)
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
@ApiResponses(value = {
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "400", description = "The request is malformed or invalid."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "403", description = "The user does not have the necessary privileges to perform the operation."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "500", description = "An internal server error occurred."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "401", description = "Access Denied."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "503", description = "A service is unreachable."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "504", description = "Gateway Timeout Error"),
        @ApiResponse(responseCode = "200"),
        @ApiResponse(responseCode = "202", content = @Content(schema = @Schema(implementation = ResponseObject.class)))
})
public class CandidateController {
    @Autowired
    private CandidateService candidateService;

    @Autowired
    private RequestDetails requestDetails;
    @Autowired
    private ObjectMapper objectMapper;

    @Operation(summary = "${api.registerCandidate.tag}", description = "${api.registerCandidate.description}")
    @PostMapping(consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    @PreAuthorize(Authorities.CANDIDATE_CREATE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> registerCandidate(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}")
            @RequestHeader(Constants.AUTH_KEY) String authToken,
            @Parameter(description = "Candidate details in JSON format", required = true)
            @RequestPart("candidate") String candidateJson,
            @Parameter(description = "Candidate's resume file", required = true)
            @RequestPart("resume") MultipartFile resumeFile) throws TrackerException, IOException {

        CandidateRequest candidateRequest = objectMapper.readValue(candidateJson, CandidateRequest.class);
        return candidateService.register(candidateRequest, resumeFile, requestDetails);
    }

    @Operation(summary = "Parse Resume for Autofill", description = "Upload a resume file to extract candidate details and return them as JSON.")
    @PostMapping(value = "/parse-resume", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> parseResume(@RequestParam("resumeFile") MultipartFile resumeFile) {
        try {
            FullAIResponse extractedDetails = candidateService.parseResumeForAutofill(resumeFile);
            return ResponseEntity.ok(extractedDetails);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to parse resume.");
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @Operation(summary = "${api.getCandidates.tag}", description = "${api.getCandidates.description}")
    @GetMapping
    @PreAuthorize(Authorities.CANDIDATE_LIST)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getAllCandidates(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(value = Constants.AUTH_KEY,required = false) String authToken  ,
            @RequestParam(value="clientId", required = false) String clientId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createDate") String sortByField,
            @RequestParam(value="order", required = false, defaultValue = "desc") String order,
            @RequestParam(value="keyword",required = false) String keyword,
            @RequestParam(defaultValue = "ACTIVE") String filter,
            @RequestParam(defaultValue = "*") String gender,
            @RequestParam(defaultValue = "*") String statusfilter) throws TrackerException {
        return candidateService.getAllCandidates(page, size, requestDetails, sortByField, order,keyword,filter,gender,statusfilter,clientId);
    }

    @Operation(summary = "Update Status", description = "${api.getupdatesByCandidate.description}")
    @PostMapping("/{id}")
    @PreAuthorize(Authorities.CANDIDATE_WRITE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> updateStatus(@PathVariable String id,
                                          @RequestBody CandidateStatusRequest candidateStatusRequest)throws TrackerException{
        return candidateService.updateStatus(id,candidateStatusRequest,requestDetails);
    }

    @Operation(summary = "${api.getCandidate.tag}", description = "${api.getCandidate.description}")
    @GetMapping("/{id}")
    @PreAuthorize(Authorities.CANDIDATE_READ)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getCandidateById(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTH_KEY) String authToken,
            @Parameter(description = "Candidate ID", required = true)
            @PathVariable String id) throws TrackerException {
        return candidateService.getCandidateById(id);
    }

    @Operation(summary = "${api.deleteCandidate.tag}", description = "${api.deleteCandidate.description}")
    @DeleteMapping("/{id}")
    @PreAuthorize(Authorities.CANDIDATE_DELETE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> deleteCandidateById(
            @Parameter(description = "Candidate ID", required = true)
            @PathVariable String id) throws TrackerException {
        return candidateService.deleteCandidateById(id,requestDetails);
    }

    @Operation(summary = "${api.updateCandidate.tag}", description = "${api.updateCandidate.description}")
    @PatchMapping("/{id}")
    @PreAuthorize(Authorities.CANDIDATE_WRITE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> updateCandidate(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTH_KEY) String authToken,
            @Parameter(description = "Candidate ID", required = true)
            @PathVariable String id,
            @Parameter(description = "Updated candidate details", required = true)
            @Valid @RequestBody CandidateUpdate candidateUpdate) throws TrackerException {
        return candidateService.updateCandidate(id, candidateUpdate,requestDetails);
    }

    @Operation(
            summary = "${api.uploadCandidatesFile.tag}",
            description = "${api.uploadCandidatesFile.description}"
    )
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    @PostMapping(value = "/upload", consumes = {"multipart/form-data"})
    @PreAuthorize(Authorities.CANDIDATE_CREATE)
    public ResponseEntity<?> uploadCandidatesFile(
            @Parameter(description = "CSV or Excel file", required = true, content = @Content(mediaType = "multipart/form-data", schema = @Schema(type = "string", format = "binary")))
            @RequestParam("file") MultipartFile file) {
        return candidateService.uploadCandidatesFile(file,requestDetails);
    }

    @Operation(summary = "${api.getJobByCandidateId.tag}", description = "${api.getJobByCandidateId.description}")
    @SecurityRequirement(name=Constants.AUTHORIZATION)
    @GetMapping("job/{candidateId}")
    public ResponseEntity<?> getJobByCandidateId(
            @Parameter(description = "Candidate ID", required = true)
            @PathVariable String candidateId) throws TrackerException {
        return candidateService.getJobByCandidateId(candidateId,requestDetails);
    }

    @Operation(summary = Constants.CANDIDATE, description = Constants.CANDIDATE_ASSIGN_TO_RECRUITER)
    @PostMapping(path = "/assign-candidate-user")
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    @PreAuthorize(Authorities.CANDIDATE_USER_ASSIGN)
    public ResponseEntity<?> candidateToUser(@RequestParam(name="userId") String userId,
                                             @RequestParam(name="candidateId") String candidateId) {
        return candidateService.candidateAssignToUser(userId, candidateId);
    }

    @Operation(summary = MessageKeys.CANDIDATE_USER_UNASSIGN_TAG, description = MessageKeys.CANDIDATE_USER_UNASSIGN_DESCRIPTION)
    @SecurityRequirement(name= Constants.AUTHORIZATION)
    @PreAuthorize(Authorities.CANDIDATE_USER_UNASSIGN)
    @PostMapping("/unassign-candidate-user")
    public ResponseEntity<?> candidateUnassignFromUser(
            @RequestParam(name="candidateId") String candidateId,
            @RequestParam(name="userId") String userId) throws TrackerException {
        return candidateService.candidateUnassignFromUser(candidateId, userId);
    }

    @Operation(summary = MessageKeys.CANDIDATE_USER_REASSIGN_TAG, description = MessageKeys.CANDIDATE_USER_REASSIGN_DESCRIPTION)
    @PostMapping("/reassign-candidate-user")
    @SecurityRequirement(name=Constants.AUTHORIZATION)
    @PreAuthorize(Authorities.CANDIDATE_USER_REASSIGN)
    public ResponseEntity<?> candidateReassignUser(@RequestParam(name="candidateId") String candidateId,@RequestParam(name="userId") String userId){
        return candidateService.candidateReassignUser(candidateId,userId);
    }
}