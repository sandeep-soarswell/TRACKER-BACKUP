package com.soarswell.tracker.common;

import lombok.Getter;

import java.util.List;

@Getter
public class ListResponse<T> {
    private final List<T> records;
    private final long totalRecords;
    private final long requestedPageNumber;
    private final long requestedRecords;

    public ListResponse(List<T> records, long totalRecords,long requestedPageNumber,long requestedRecords) {
        this.records=records;
        this.totalRecords = totalRecords;
        this.requestedPageNumber=requestedPageNumber;
        this.requestedRecords=requestedRecords;
    }
}
