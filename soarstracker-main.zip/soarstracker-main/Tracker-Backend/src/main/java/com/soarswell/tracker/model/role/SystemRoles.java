package com.soarswell.tracker.model.role;


import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.permission.Permissions;
import com.soarswell.tracker.permission.SystemRolePermissions;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public enum SystemRoles {

    SYSTEM_ADMIN("system_admin"                 , "System Admin"            , RoleUsageType.INTERNAL, SystemRolePermissions.SYSTEM_ADMIN_PERMISSIONS),
    COMPANY_ADMIN("company_admin"               , "Company Admin"           , RoleUsageType.EXTERNAL, SystemRolePermissions.COMPANY_ADMIN_PERMISSIONS),
    EMPLOYEE("employee"                         , "Employee"                , RoleUsageType.EXTERNAL, SystemRolePermissions.EMPLOYEE_PERMISSIONS),
    UNDEFINED(""                                , ""                        , null, List.of());

    private final String id;
    private final String name;
    private final RoleUsageType usageType;
    private final Collection<Permissions> permissions;

    SystemRoles(String id, String value, RoleUsageType usageType, Collection<Permissions> permissions) {
        this.id = id;
        this.name = value;
        this.usageType = usageType;
        this.permissions = permissions;
    }

    public String id() {
        return id;
    }

    public String roleName() {
        return name;
    }

    public RoleUsageType usageType() {
        return usageType;
    }

    public Collection<Permissions> permissions() { return permissions; }

    public Collection<String> permissionsLabel() {
        return permissions.stream().map(Permissions::getLabel).toList();
    }


    public static SystemRoles fromIdOrName(final String idOrName) throws TrackerException {
        if(StringUtils.isNotEmpty(idOrName)) {
            for (SystemRoles role : values()) {
                if (idOrName.equalsIgnoreCase(role.name())
                        || idOrName.equalsIgnoreCase(role.id())
                        || idOrName.equalsIgnoreCase(role.roleName())) {
                    return role;
                }
            }
        }
        return UNDEFINED;
    }

    public static Collection<SystemRoles> internalRoles() {
        return Arrays.stream(values())
                .filter(r -> r.usageType() == RoleUsageType.INTERNAL)
                .toList();
    }

    public static Collection<SystemRoles> externalRoles() {
        return Arrays.stream(values())
                .filter(r -> r.usageType() == RoleUsageType.EXTERNAL)
                .toList();
    }
}
