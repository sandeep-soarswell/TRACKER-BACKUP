import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { ChevronLeftIcon, ChevronRightIcon, CalendarMonthIcon, AddIcon, MinusIcon, ClockIcon, HomeIcon } from '~/components/ui/Icons';
import Modal from '~/components/ui/Modal';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import EventScheduleForm from '~/pages/event/EventScheduleForm';
import EventContextMenu from '~/pages/event/EventContextMenu';
import EventDetailsModal from '~/pages/event/EventDetailsModal';
import EventTooltip from './EventTooltip';
import eventService from '~/services/event/event.service';
import type { CalendarEvent } from '~/pages/types/types';

const DAYS_TO_SHOW = 7;
const MAX_EVENTS_BEFORE_COLLAPSE = 5;

interface EventWithPosition extends CalendarEvent {
  column: number;
  totalColumns: number;
}

const Calendar: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const getInitialDate = () => {
    const targetDateStr = location.state?.targetDate;
    if (targetDateStr) {
      const date = new Date(targetDateStr);
      if (!isNaN(date.getTime())) {
        return date;
      }
    }
    return new Date();
  };

  const [showEventModal, setShowEventModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [contextMenuPosition, setContextMenuPosition] = useState({ x: 0, y: 0 });
  const [eventToDelete, setEventToDelete] = useState<CalendarEvent | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [currentWeek, setCurrentWeek] = useState<Date[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(getInitialDate());
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [hoveredEvent, setHoveredEvent] = useState<CalendarEvent | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [prefilledData, setPrefilledData] = useState<{ date: string; time: string } | null>(null);
  const [expandedDates, setExpandedDates] = useState<Set<string>>(new Set());
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'error'>('success');
  const [contextMenuCell, setContextMenuCell] = useState<{ date: Date; hour: number } | null>(null);
  const [viewMode, setViewMode] = useState<'week' | 'month'>('week');

 const getWeekDates = (startDate: Date): Date[] => {
    const dates = [];
    const monday = new Date(startDate);
    monday.setHours(0, 0, 0, 0);
    const dayOfWeek = monday.getDay();
    const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    monday.setDate(monday.getDate() - daysToMonday);
    
    for (let i = 0; i < DAYS_TO_SHOW; i++) {
      const currentDate = new Date(monday);
      currentDate.setDate(monday.getDate() + i);
      dates.push(currentDate);
    }
    return dates;
  };

  const getMonthDates = (date: Date): Date[] => {
    const dates = [];
    const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1);
    const lastDayOfMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    const firstDayOfWeek = firstDayOfMonth.getDay();
    
    const startDate = new Date(firstDayOfMonth);
    startDate.setDate(startDate.getDate() - firstDayOfWeek);
    
    const endDate = new Date(lastDayOfMonth);
    endDate.setDate(endDate.getDate() + (6 - lastDayOfMonth.getDay()));
    
    let currentDate = new Date(startDate);
    while (currentDate <= endDate) {
      dates.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }
    
    return dates;
  };

  const isToday = (date: Date): boolean => {
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  const isDateInCurrentMonth = (date: Date, selectedDate: Date): boolean => {
    return date.getMonth() === selectedDate.getMonth() && date.getFullYear() === selectedDate.getFullYear();
  };

  const isDateExpanded = (date: Date): boolean => {
    return expandedDates.has(date.toDateString());
  };

  const toggleDateExpansion = (date: Date) => {
    const dateStr = date.toDateString();
    const newExpandedDates = new Set(expandedDates);

    if (newExpandedDates.has(dateStr)) {
      newExpandedDates.delete(dateStr);
    } else {
      newExpandedDates.add(dateStr);
    }

    setExpandedDates(newExpandedDates);
  };

  const showSnackbar = (message: string, severity: "success" | "error" = "success") => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  };

  const fetchEvents = async () => {
    try {
      const backendEvents = await eventService.getAll();
      const sidebarBlue = 'bg-[#0A2463]';
      const normalized = backendEvents.map((item: any) => {
        let eventObj = item.event || item;
        let candidate = item.candidate || null;
        const dateObj = new Date(eventObj.date);
        const mainTitle = eventObj.title;
        const tooltip = candidate
          ? {
            name: candidate.name,
            email: candidate.email,
            phoneNumber: candidate.phoneNumber,
            title: eventObj.title,
            startTime: eventObj.startTime?.slice(0, 5),
            endTime: eventObj.endTime?.slice(0, 5),
            jobTitle: candidate.jobTitle || eventObj.jobTitle || '',
            clientName: candidate.clientName || eventObj.clientName || '',
            description: eventObj.description || '',
          }
          : {
            description: eventObj.description || '',
            startTime: eventObj.startTime?.slice(0, 5),
            endTime: eventObj.endTime?.slice(0, 5),
          };
        return {
          id: eventObj.id,
          title: mainTitle,
          startTime: eventObj.startTime?.slice(0, 5),
          endTime: eventObj.endTime?.slice(0, 5),
          date: dateObj,
          color: sidebarBlue,
          candidateId: eventObj.candidateId || '',
          jobId: eventObj.jobId || '',
          remarks: '',
          description: eventObj.description || '',
          type: eventObj.type || 'meeting',
          tooltip,
        };
      });
      setEvents(normalized);
    } catch (error: any) {
      let errorMessage = "Failed to fetch events.";
      if (error.response?.status === 401) {
        errorMessage = "Unauthorized: Please log in again.";
      } else if (
        error.response?.status === 404 &&
        (error.response?.data?.error?.message === "No events found" || error.response?.data?.message)
      ) {
        setEvents([]);
        errorMessage = "No events found.";
      } else if (error.code === "ERR_NETWORK") {
        errorMessage = "Network error: Check your connection or server.";
        navigate("/");
      } else {
        errorMessage = error?.response?.data?.message || error?.response?.data?.error?.message || "Failed to fetch events.";
      }
      setEvents([]);
      showSnackbar(errorMessage, "error");
    }
  };

  useEffect(() => {
    if (viewMode === 'week') {
      const weekDates = getWeekDates(selectedDate).slice(0, DAYS_TO_SHOW);
      setCurrentWeek(weekDates);
    }
    fetchEvents();
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    if (location.state?.targetDate) {
      navigate(location.pathname, { replace: true, state: {} });
    }

    return () => clearInterval(timer);
  }, [selectedDate, location, navigate, viewMode]);

  const navigateWeek = (direction: 'prev' | 'next') => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + (direction === 'next' ? DAYS_TO_SHOW : -DAYS_TO_SHOW));
    setSelectedDate(newDate);
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(selectedDate);
    newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1));
    setSelectedDate(newDate);
  };

  const goToToday = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    setSelectedDate(today);
    setViewMode('week');
  };

  const getEventsForDay = (date: Date) =>
    events.filter((event) => new Date(event.date).toDateString() === date.toDateString());

  const timeToMinutes = (timeStr: string) => {
    if (!timeStr) return 0;
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
  };

  const eventsOverlap = (event1: CalendarEvent, event2: CalendarEvent) => {
    const start1 = timeToMinutes(event1.startTime);
    const end1 = timeToMinutes(event1.endTime);
    const start2 = timeToMinutes(event2.startTime);
    const end2 = timeToMinutes(event2.endTime);
    return start1 < end2 && start2 < end1;
  };

  const getEventsWithColumns = (date: Date): EventWithPosition[] => {
    const dayEvents = getEventsForDay(date);
    const eventsWithColumns: EventWithPosition[] = [];

    if (dayEvents.length === 0) return eventsWithColumns;

    const sortedEvents = dayEvents.sort((a, b) =>
      timeToMinutes(a.startTime) - timeToMinutes(b.startTime)
    );

    const overlappingGroups: CalendarEvent[][] = [];

    for (const event of sortedEvents) {
      let placed = false;
      for (const group of overlappingGroups) {
        const overlapsWithGroup = group.some(groupEvent => eventsOverlap(event, groupEvent));
        if (overlapsWithGroup) {
          group.push(event);
          placed = true;
          break;
        }
      }
      if (!placed) {
        overlappingGroups.push([event]);
      }
    }

    for (const group of overlappingGroups) {
      group.sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));
      const columns: CalendarEvent[][] = [];

      for (const event of group) {
        let columnIndex = 0;
        while (columnIndex < columns.length) {
          const column = columns[columnIndex];
          const hasOverlap = column.some(colEvent => eventsOverlap(event, colEvent));
          if (!hasOverlap) {
            column.push(event);
            break;
          }
          columnIndex++;
        }
        if (columnIndex === columns.length) {
          columns.push([event]);
        }
      }

      const maxColumns = columns.length;
      for (let colIndex = 0; colIndex < columns.length; colIndex++) {
        for (const event of columns[colIndex]) {
          eventsWithColumns.push({
            ...event,
            column: colIndex,
            totalColumns: maxColumns
          });
        }
      }
    }

    return eventsWithColumns;
  };

  const getEventDuration = (event: CalendarEvent) => {
    const startMinutes = timeToMinutes(event.startTime);
    const endMinutes = timeToMinutes(event.endTime);
    return (endMinutes - startMinutes) / 60;
  };

  const getEventPosition = (event: CalendarEvent) => {
    const startMinutes = timeToMinutes(event.startTime);
    const startHour = Math.floor(startMinutes / 60);
    const startMinuteOffset = startMinutes % 60;
    const duration = getEventDuration(event);
    const topOffset = (startMinuteOffset / 60) * 90;
    const height = Math.max(duration * 90 - 4, 30);
    return { topOffset, height, startHour };
  };

  const getContinuingEventHeight = (event: CalendarEvent, hour: number) => {
    const startMinutes = timeToMinutes(event.startTime);
    const endMinutes = timeToMinutes(event.endTime);
    const hourStart = hour * 60;
    const hourEnd = (hour + 1) * 60;

    if (startMinutes <= hourStart && endMinutes >= hourEnd) {
      return 90;
    }

    if (startMinutes <= hourStart && endMinutes < hourEnd) {
      const endMinuteOffset = endMinutes % 60;
      return (endMinuteOffset / 60) * 90;
    }

    return 90;
  };

  const getEventsActiveAtHour = (date: Date, hour: number) => {
    const eventsWithColumns = getEventsWithColumns(date);
    return eventsWithColumns.filter((event) => {
      const startMinutes = timeToMinutes(event.startTime);
      const endMinutes = timeToMinutes(event.endTime);
      const hourStart = hour * 60;
      const hourEnd = (hour + 1) * 60;

      return startMinutes < hourEnd && endMinutes > hourStart;
    });
  };

  const getEventsStartingAtHour = (date: Date, hour: number) => {
    const eventsWithColumns = getEventsWithColumns(date);
    return eventsWithColumns.filter((event) => {
      const startHour = Math.floor(timeToMinutes(event.startTime) / 60);
      return startHour === hour;
    });
  };

  const getEventsContinuingAtHour = (date: Date, hour: number) => {
    const eventsWithColumns = getEventsWithColumns(date);
    return eventsWithColumns.filter((event) => {
      const startMinutes = timeToMinutes(event.startTime);
      const endMinutes = timeToMinutes(event.endTime);
      const startHour = Math.floor(startMinutes / 60);
      const hourStart = hour * 60;
      const hourEnd = (hour + 1) * 60;

      return startHour !== hour && startMinutes < hourEnd && endMinutes > hourStart;
    });
  };

  const getMaxEventsInAnyHour = (date: Date) => {
    let maxEvents = 0;
    for (let hour = 0; hour < 24; hour++) {
      const eventsAtHour = getEventsActiveAtHour(date, hour);
      maxEvents = Math.max(maxEvents, eventsAtHour.length);
    }
    return maxEvents;
  };

  const shouldShowExpandButton = (date: Date, hour: number) => {
    const eventsAtHour = getEventsActiveAtHour(date, hour);
    const maxColumns = Math.max(...eventsAtHour.map(e => e.totalColumns), 0);
    return maxColumns > MAX_EVENTS_BEFORE_COLLAPSE && !isDateExpanded(date);
  };

  const getExpandedColumnWidth = (date: Date) => {
    const maxEvents = getMaxEventsInAnyHour(date);
    const baseWidth = 200;
    const expandedWidth = Math.max(baseWidth, maxEvents * 80);
    return expandedWidth;
  };

  const handleEventHover = (event: CalendarEvent, mouseEvent: React.MouseEvent) => {
    setHoveredEvent(event);
    setMousePosition({ x: mouseEvent.clientX, y: mouseEvent.clientY });
  };

  const handleEventLeave = () => setHoveredEvent(null);

  const handleEventContextMenu = (event: CalendarEvent, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedEvent(event);
    setContextMenuCell(null);
    setContextMenuPosition({ x: e.clientX, y: e.clientY });
    setShowContextMenu(true);
  };

  const handleCellClick = (date: Date, hour: number, e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('.expand-button')) return;
    const dateStr = date.toLocaleDateString('en-CA');
    const startHour = hour;
    const endHour = hour + 1;
    const timeStr = `${startHour.toString().padStart(2, '0')}:00`;
    const endTimeStr = `${endHour.toString().padStart(2, '0')}:00`;
    setPrefilledData({ date: dateStr, time: timeStr });
    setSelectedEvent({
      id: '',
      title: '',
      startTime: timeStr,
      endTime: endTimeStr,
      date: dateStr,
      color: 'bg-[#0A2463]',
      candidateId: '',
      jobId: '',
      remarks: '',
      description: '',
      type: 'meeting',
      tooltip: {},
    } as CalendarEvent);
    setShowEventModal(true);
  };

  const handleMonthCellClick = (date: Date, e: React.MouseEvent) => {
    e.stopPropagation();
    const normalizedDate = new Date(date);
    normalizedDate.setHours(0, 0, 0, 0); // Normalize to start of day
    setSelectedDate(normalizedDate);
    setViewMode('week');
  };

  const handleCellRightClick = (date: Date, hour: number, e: React.MouseEvent) => {
    e.preventDefault();
    const normalizedDate = new Date(date);
    normalizedDate.setHours(0, 0, 0, 0); // Normalize to start of day
    setContextMenuCell({ date: normalizedDate, hour });
    setSelectedEvent(null);
    setContextMenuPosition({ x: e.clientX, y: e.clientY });
    setShowContextMenu(true);
  };

  const handleContextMenuAdd = () => {
    setShowContextMenu(false);
    if (contextMenuCell) {
      const { date, hour } = contextMenuCell;
      const normalizedDate = new Date(date);
      normalizedDate.setHours(0, 0, 0, 0); // Normalize to start of day
      const dateStr = normalizedDate.toLocaleDateString('en-CA')
      const startHour = hour;
      const endHour = hour + 1;
      const timeStr = `${startHour.toString().padStart(2, '0')}:00`;
      const endTimeStr = `${endHour.toString().padStart(2, '0')}:00`;
      setPrefilledData({ date: dateStr, time: timeStr });
      setSelectedEvent({
        id: '',
        title: '',
        startTime: timeStr,
        endTime: endTimeStr,
        date: dateStr,
        color: 'bg-[#0A2463]',
        candidateId: '',
        jobId: '',
        remarks: '',
        description: '',
        type: 'meeting',
        tooltip: {},
      } as CalendarEvent);
      setShowEventModal(true);
    }
  };

  const handleContextMenuView = () => {
    setShowContextMenu(false);
    if (selectedEvent) {
      setShowDetailsModal(true);
    }
  };

  const handleContextMenuUpdate = () => {
    setShowContextMenu(false);
    if (selectedEvent) {
      setShowEventModal(true);
    }
  };

  const handleContextMenuDelete = () => {
    setShowContextMenu(false);
    if (selectedEvent) {
      setEventToDelete(selectedEvent);
      setShowDeleteConfirm(true);
    }
  };

  const handleDeleteConfirm = async () => {
    if (eventToDelete) {
      try {
        const response = await eventService.delete(eventToDelete.id);
        await fetchEvents();
        setShowDeleteConfirm(false);
        setEventToDelete(null);
        setSelectedEvent(null);
        const backendMessage = response?.data?.data;
        setSnackbarMessage(backendMessage);
        setSnackbarSeverity('success');
        setSnackbarOpen(true);
      } catch (e) {
        setShowDeleteConfirm(false);
        setEventToDelete(null);
        setSelectedEvent(null);
        setSnackbarMessage('Failed to delete event');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
      }
    }
  };

  const handleDeleteCancel = () => {
    setShowDeleteConfirm(false);
    setEventToDelete(null);
    setSelectedEvent(null);
  };

  const isEventCompleted = (event: CalendarEvent) => {
    if (!event) return false;
    const eventDate = new Date(event.date);
    const today = new Date();
    const nowMinutes = today.getHours() * 60 + today.getMinutes();
    const [endHour, endMinute] = event.endTime.split(":").map(Number);
    const eventEndMinutes = endHour * 60 + endMinute;

    if (
      eventDate.getFullYear() < today.getFullYear() ||
      (eventDate.getFullYear() === today.getFullYear() && eventDate.getMonth() < today.getMonth()) ||
      (eventDate.getFullYear() === today.getFullYear() && eventDate.getMonth() === today.getMonth() && eventDate.getDate() < today.getDate())
    ) {
      return true;
    }
    if (
      eventDate.getFullYear() === today.getFullYear() &&
      eventDate.getMonth() === today.getMonth() &&
      eventDate.getDate() === today.getDate() &&
      eventEndMinutes < nowMinutes
    ) {
      return true;
    }
    return false;
  };

  const handleModalSuccess = async (backendMessage?: string) => {
    setShowEventModal(false);
    setShowDetailsModal(false);
    setSelectedEvent(null);
    setPrefilledData(null);
    await fetchEvents();
    if (backendMessage) {
      setSnackbarMessage(backendMessage);
      setSnackbarSeverity('success');
      setSnackbarOpen(true);
    }
  };

  const renderEventsInSlot = (dayIndex: number, hour: number) => {
    const date = currentWeek[dayIndex];
    if (!date) return null;

    const eventsStarting = getEventsStartingAtHour(date, hour);
    const eventsContinuing = getEventsContinuingAtHour(date, hour);
    const eventsActive = getEventsActiveAtHour(date, hour);
    const isExpanded = isDateExpanded(date);
    const showExpandBtn = shouldShowExpandButton(date, hour);
    const hasActiveEvents = eventsActive.length > 0;

    if (eventsStarting.length === 0) {
      return (
        <div className="h-full flex items-center justify-center">
          {showExpandBtn && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleDateExpansion(date);
              }}
              className="absolute top-2 right-2 z-20 bg-blue-600 hover:bg-blue-700 text-white text-xs px-2 py-1 rounded-full transition-colors shadow-[0_2px_4px_rgba(0,0,0,0.1)]"
            >
              +{eventsActive.length - MAX_EVENTS_BEFORE_COLLAPSE}
            </button>
          )}

          {eventsContinuing.map((event) => {
            let columnWidth: number;
            let leftOffset: number;

            if (isExpanded) {
              columnWidth = Math.max(100 / event.totalColumns, 15);
              leftOffset = event.column * columnWidth;
            } else {
              const maxDisplayColumns = Math.min(event.totalColumns, MAX_EVENTS_BEFORE_COLLAPSE);
              columnWidth = Math.max(100 / maxDisplayColumns, 10);
              leftOffset = Math.min(event.column, MAX_EVENTS_BEFORE_COLLAPSE - 1) * columnWidth;
            }

            const actualWidth = Math.min(columnWidth - 1, 100 - leftOffset);
            const continuingHeight = getContinuingEventHeight(event, hour);

            return (
              <div
                key={`continuing-${event.id}`}
                className="absolute cursor-pointer hover:bg-black/5 transition-colors z-[5]"
                style={{
                  top: '0px',
                  left: `${leftOffset}%`,
                  height: `${continuingHeight}px`,
                  width: `${actualWidth}%`,
                  minWidth: isExpanded ? '80px' : '40px',
                  maxWidth: '95%',
                }}
                onMouseEnter={(e) => handleEventHover(event, e)}
                onMouseLeave={handleEventLeave}
                onContextMenu={(e) => handleEventContextMenu(event, e)}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedEvent(event);
                  setShowDetailsModal(true);
                }}
              />
            );
          })}

          <button
            onClick={(e) => {
              e.stopPropagation();
              handleCellClick(date, hour, e);
            }}
            className={`opacity-0 hover:opacity-100 transition-opacity text-gray-400 hover:text-gray-600 text-sm flex items-center space-x-1 ${hasActiveEvents ? 'pointer-events-none' : ''}`}
          >
            <AddIcon fontSize="small" />
            <span>Add Event</span>
          </button>
        </div>
      );
    }

    const displayEvents = isExpanded ? eventsStarting : eventsStarting.slice(0, MAX_EVENTS_BEFORE_COLLAPSE);
    const hiddenEventsCount = eventsStarting.length - displayEvents.length;

    return (
      <>
        {(showExpandBtn || isExpanded) && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleDateExpansion(date);
            }}
            className="absolute top-2 right-2 z-20 bg-blue-600 hover:bg-blue-700 text-white text-xs px-2 py-1 rounded-full transition-colors flex items-center space-x-1 shadow-[0_2px_4px_rgba(0,0,0,0.1)]"
          >
            {isExpanded ? (
              <>
                <MinusIcon fontSize="small" />
                <span>Hide</span>
              </>
            ) : (
              <span>+{hiddenEventsCount}</span>
            )}
          </button>
        )}

        {eventsContinuing.map((event) => {
          let columnWidth: number;
          let leftOffset: number;

          if (isExpanded) {
            columnWidth = Math.max(100 / event.totalColumns, 15);
            leftOffset = event.column * columnWidth;
          } else {
            const maxDisplayColumns = Math.min(event.totalColumns, MAX_EVENTS_BEFORE_COLLAPSE);
            columnWidth = Math.max(100 / maxDisplayColumns, 10);
            leftOffset = Math.min(event.column, MAX_EVENTS_BEFORE_COLLAPSE - 1) * columnWidth;
          }

          const actualWidth = Math.min(columnWidth - 1, 100 - leftOffset);
          const continuingHeight = getContinuingEventHeight(event, hour);

          return (
            <div
              key={`continuing-${event.id}`}
              className="absolute cursor-pointer hover:bg-black/5 transition-colors z-[5]"
              style={{
                top: '0px',
                left: `${leftOffset}%`,
                height: `${continuingHeight}px`,
                width: `${actualWidth}%`,
                minWidth: isExpanded ? '80px' : '40px',
                maxWidth: '95%',
              }}
              onMouseEnter={(e) => handleEventHover(event, e)}
              onMouseLeave={handleEventLeave}
              onContextMenu={(e) => handleEventContextMenu(event, e)}
              onClick={(e) => {
                e.stopPropagation();
                setSelectedEvent(event);
                setShowDetailsModal(true);
              }}
            />
          );
        })}

        {displayEvents.map((event) => {
          const { topOffset, height } = getEventPosition(event);
          let columnWidth: number;
          let leftOffset: number;

          if (isExpanded) {
            columnWidth = Math.max(100 / event.totalColumns, 15);
            leftOffset = event.column * columnWidth;
          } else {
            const maxDisplayColumns = Math.min(event.totalColumns, MAX_EVENTS_BEFORE_COLLAPSE);
            columnWidth = Math.max(100 / maxDisplayColumns, 10);
            leftOffset = Math.min(event.column, MAX_EVENTS_BEFORE_COLLAPSE - 1) * columnWidth;
          }

          const actualWidth = Math.min(columnWidth - 1, 100 - leftOffset);
          const estimatedWidthPx = (actualWidth / 100) * (isExpanded ? getExpandedColumnWidth(date) : 200);
          const shouldShowTime = estimatedWidthPx > 80 && height > 40;
          const eventDuration = getEventDuration(event);
          const spansMultipleHours = eventDuration > 1;

          return (
            <div
              key={event.id}
              className={`${event.color} text-white font-medium cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-102 absolute overflow-hidden border border-white/10 z-10 hover:z-[15] ${spansMultipleHours ? 'rounded-t-md rounded-b-md' : 'rounded-md'}`}
              style={{
                top: `${topOffset - (spansMultipleHours ? 1 : 0)}px`,
                left: `${leftOffset}%`,
                height: `${height + (spansMultipleHours ? 2 : 0)}px`,
                width: `${actualWidth}%`,
                minWidth: isExpanded ? '80px' : '40px',
                maxWidth: '95%',
                padding: height > 35 ? '6px' : '4px',
                boxShadow: spansMultipleHours ? '0 0 0 1px rgba(255,255,255,0.1)' : '0 1px 3px rgba(0,0,0,0.1)',
              }}
              onMouseEnter={(e) => handleEventHover(event, e)}
              onMouseLeave={handleEventLeave}
              onContextMenu={(e) => handleEventContextMenu(event, e)}
              onClick={(e) => {
                e.stopPropagation();
                setSelectedEvent(event);
                setShowDetailsModal(true);
              }}
            >
              <div className="flex flex-col h-full justify-center">
                <div
                  className="font-medium leading-tight overflow-hidden"
                  style={{
                    fontSize: height > 50 ? '12px' : '10px',
                    lineHeight: height > 50 ? '1.2' : '1.1',
                  }}
                  title={event.tooltip?.title || event.title}
                >
                  <div className="truncate">
                    {event.tooltip?.title || event.title}
                  </div>
                </div>
                {shouldShowTime && (
                  <div
                    className="text-white/90 mt-1 leading-tight overflow-hidden"
                    style={{
                      fontSize: height > 50 ? '10px' : '9px',
                      lineHeight: '1.1',
                    }}
                  >
                    <div className="truncate">
                      {event.startTime} - {event.endTime}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </>
    );
  };

  const renderMonthView = () => {
    const monthDates = getMonthDates(selectedDate);
    const weeks = [];
    for (let i = 0; i < monthDates.length; i += 7) {
      weeks.push(monthDates.slice(i, i + 7));
    }

    return (
      <div className="grid grid-cols-7 gap-[1px] bg-gray-200 min-h-[600px] w-full min-w-[900px]">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => (
          <div key={index} className="bg-gray-100 text-gray-600 text-xs font-medium text-center py-2">
            {day}
          </div>
        ))}
        {weeks.map((week, weekIndex) => (
          <React.Fragment key={weekIndex}>
            {week.map((date, dayIndex) => {
              const normalizedDate = new Date(date);
              normalizedDate.setHours(0, 0, 0, 0); // Normalize to start of day
              const eventsForDay = getEventsForDay(normalizedDate);
              const isCurrentMonth = isDateInCurrentMonth(normalizedDate, selectedDate);
              return (
                <div
                  key={`${weekIndex}-${dayIndex}`}
                  className={`p-2 bg-white cursor-pointer hover:bg-gray-50 transition-colors border border-gray-200 ${isToday(normalizedDate) ? 'border-2 border-blue-600' : ''} ${isCurrentMonth ? '' : 'bg-gray-50 text-gray-400'}`}
                  style={{ minHeight: '100px', position: 'relative' }}
                  onClick={(e) => handleMonthCellClick(normalizedDate, e)}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setContextMenuCell({ date: normalizedDate, hour: 9 });
                    setSelectedEvent(null);
                    setContextMenuPosition({ x: e.clientX, y: e.clientY });
                    setShowContextMenu(true);
                  }}
                >
                  <div className="text-sm font-medium">{normalizedDate.getDate()}</div>
                  <div className="mt-1 flex flex-col gap-1">
                    {eventsForDay.slice(0, 2).map((event) => (
                      <div
                        key={event.id}
                        className="text-xs text-gray-800 truncate bg-[#0A2463] text-white px-1 py-0.5 rounded"
                        onMouseEnter={(e) => handleEventHover(event, e)}
                        onMouseLeave={handleEventLeave}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedEvent(event);
                          setShowDetailsModal(true);
                        }}
                        title={event.tooltip?.title || event.title}
                      >
                        {event.tooltip?.title || event.title}
                      </div>
                    ))}
                    {eventsForDay.length > 2 && (
                      <div className="text-xs text-gray-500">+{eventsForDay.length - 2} more</div>
                    )}
                  </div>
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>
    );
  };

  const generateGridColumns = () => {
    let columns = '80px ';
    for (const date of currentWeek) {
      if (isDateExpanded(date)) {
        columns += `${getExpandedColumnWidth(date)}px `;
      } else {
        columns += '1fr ';
      }
    }
    return columns.trim();
  };

  return (
    <div className="h-[calc(100vh-100px)] bg-white flex flex-col">
      <div className="flex items-center px-4 py-2">
        <div className="flex items-center text-sm text-gray-600">
          <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
          <a
            href="/dashboard"
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
          >
            Dashboard
          </a>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="text-sm text-gray-600">
          Calendar
        </div>
      </div>

      <div className="bg-white border-b border-gray-200 p-4 relative">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <CalendarMonthIcon fontSize="large" className="text-gray-600" />
              <h1 className="text-xl font-semibold text-gray-900">{viewMode === 'week' ? 'Weekly Calendar' : 'Monthly Calendar'}</h1>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() =>
                   goToToday()}
                className={`px-3 py-1 text-sm font-medium ${isToday(selectedDate) ? 'text-blue-600' : 'text-blue-600 hover:bg-blue-50'} rounded-md transition-colors cursor-pointer`}
              >
                Today
              </button>
              <button
                onClick={() => setViewMode('week')}
                className={`px-3 py-1 text-sm font-medium ${viewMode === 'week' ? 'bg-blue-600 text-white' : 'text-blue-600 hover:bg-blue-50'} rounded-md transition-colors cursor-pointer`}
              >
                Week
              </button>
              <button
                onClick={() => setViewMode('month')}
                className={`px-3 py-1 text-sm font-medium ${viewMode === 'month' ? 'bg-blue-600 text-white' : 'text-blue-600 hover:bg-blue-50'} rounded-md transition-colors cursor-pointer`}
              >
                Month
              </button>
              
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-m text-gray-600">
              <ClockIcon fontSize="small" className="text-gray-600" />
              <span>{currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => viewMode === 'week' ? navigateWeek('prev') : navigateMonth('prev')}
              className="p-2 hover:bg-gray-100 rounded-md cursor-pointer transition-colors"
            >
              <ChevronLeftIcon fontSize="medium" className="text-gray-600" />
            </button>
            <span className="text-lg font-medium text-gray-900 min-w-[200px] text-center">
              {viewMode === 'week'
                ? currentWeek.length > 0 && `${currentWeek[0].toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${currentWeek[DAYS_TO_SHOW - 1].toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`
                : selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
            </span>
            <button
              onClick={() => viewMode === 'week' ? navigateWeek('next') : navigateMonth('next')}
              className="p-2 hover:bg-gray-100 rounded-md cursor-pointer transition-colors"
            >
              <ChevronRightIcon fontSize="medium" className="text-gray-600" />
            </button>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => {
                const normalizedDate = new Date(selectedDate);
                normalizedDate.setHours(0, 0, 0, 0); // Normalize to start of day
                const dateStr =  normalizedDate.toLocaleDateString('en-CA');
                const defaultTime = '09:00'; // Default to 9:00 AM
                const defaultEndTime = '10:00'; // Default to 10:00 AM
                setPrefilledData({ date: dateStr, time: defaultTime });
                setSelectedEvent({
                  id: '',
                  title: '',
                  startTime: defaultTime,
                  endTime: defaultEndTime,
                  date: dateStr,
                  color: 'bg-[#0A2463]',
                  candidateId: '',
                  jobId: '',
                  remarks: '',
                  description: '',
                  type: 'meeting',
                  tooltip: {},
                } as CalendarEvent);
                setShowEventModal(true);
              }}
              className="flex items-center px-5 py-3 bg-[#0A2463] hover:bg-blue-900 text-white cursor-pointer rounded-lg text-base font-semibold transition-colors shadow-md"
              style={{ minWidth: '120px', minHeight: '38px' }}
            >
              <AddIcon fontSize="medium" className="mr-2" /> Add Event
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-auto relative" id="calendar-scrollable-area">
          {viewMode === 'week' ? (
            <div className="grid w-full min-w-[900px] min-h-[1624px] relative" style={{ gridTemplateColumns: generateGridColumns() }}>
              <div className="sticky top-0 left-0 z-[35] bg-gray-50 border-r border-b border-gray-200 shadow-[1px_1px_3px_rgba(0,0,0,0.1)]"></div>
              {currentWeek.map((date, index) => (
                <div
                  key={index}
                  className={`flex flex-col items-center justify-center h-[64px] border-r border-b border-gray-200 bg-gray-50 sticky top-0 z-[30] shadow ${isToday(date) ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'} ${isDateExpanded(date) ? 'relative' : ''}`}
                >
                  <div className="text-xs font-medium text-gray-500 uppercase">
                    {date.toLocaleDateString('en-US', { weekday: 'short' })}
                  </div>
                  <div className={`text-lg font-semibold ${isToday(date) ? 'text-blue-600' : 'text-gray-900'}`}>
                    {date.getDate()}
                  </div>
                  {isDateExpanded(date) && (
                    <div className="absolute top-1 right-1">
                      <span className="text-xs text-blue-600 font-medium">Expanded</span>
                    </div>
                  )}
                </div>
              ))}
              {Array.from({ length: 24 }, (_, hour) => (
                <React.Fragment key={hour}>
                  <div className="flex items-center justify-center h-[90px] border-r border-b border-gray-200 sticky left-0 bg-gray-50 z-[25] top-[64px]">
                    <span className="text-xs text-gray-500 font-medium">{hour}:00</span>
                  </div>
                  {currentWeek.map((date, dayIndex) => {
                    const eventsActive = getEventsActiveAtHour(date, hour);
                    const hasFullSpanEvent = eventsActive.some(event => {
                      const start = timeToMinutes(event.startTime);
                      const end = timeToMinutes(event.endTime);
                      return start <= hour * 60 && end >= (hour + 1) * 60;
                    });
                    return (
                      <div
                        key={dayIndex}
                        className={`flex items-start justify-start border-r border-gray-200 h-[90px] overflow-visible relative z-[1] after:absolute after:bottom-0 after:left-0 after:right-0 after:h-px after:bg-gray-200 after:z-[1] ${isToday(date) ? 'bg-blue-50/30' : ''} ${hasFullSpanEvent ? '!bg-transparent !after:hidden' : ''}`}
                        style={{ position: 'relative' }}
                        onClick={(e) => handleCellClick(date, hour, e)}
                        onContextMenu={(e) => handleCellRightClick(date, hour, e)}
                      >
                        {renderEventsInSlot(dayIndex, hour)}
                      </div>
                    );
                  })}
                </React.Fragment>
              ))}
            </div>
          ) : (
            renderMonthView()
          )}
        </div>
      </div>

      <EventTooltip event={hoveredEvent} position={mousePosition} isVisible={!!hoveredEvent} />

      <EventContextMenu
        isVisible={showContextMenu}
        position={contextMenuPosition}
        onView={handleContextMenuView}
        onUpdate={handleContextMenuUpdate}
        onDelete={handleContextMenuDelete}
        onAdd={handleContextMenuAdd}
        onClose={() => setShowContextMenu(false)}
        showUpdate={selectedEvent ? !isEventCompleted(selectedEvent) : false}
        hasEvent={!!selectedEvent}
      />

      <EventDetailsModal
        event={selectedEvent}
        isOpen={showDetailsModal}
        onClose={() => {
          setShowDetailsModal(false);
          setSelectedEvent(null);
        }}
      />

      <Modal
        open={showEventModal}
        onClose={() => {
          setShowEventModal(false);
          setSelectedEvent(null);
          setPrefilledData(null);
        }}
        title={!selectedEvent || !selectedEvent.id ? 'Add Event' : 'Update Event'}
      >
        <EventScheduleForm
          candidateId={selectedEvent?.candidateId || ''}
          initialData={selectedEvent ? { ...selectedEvent, date: new Date(selectedEvent.date) } : undefined}
          prefilledData={prefilledData ?? undefined}
          onSuccess={handleModalSuccess}
        />
      </Modal>

      <CustomSnackbar
        open={snackbarOpen}
        message={snackbarMessage}
        severity={snackbarSeverity}
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={1000}
      />

      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-white rounded-lg shadow-xl max-w-xs w-full p-0 relative flex flex-col items-center">
            <div
              className="w-full h-10 flex items-center justify-center bg-[#0A2463] rounded-t-lg px-6 py-4"
              style={{ minHeight: '56px' }}
            >
              <h2 className="text-white font-semibold text-lg m-0 w-full text-center">Confirm Delete</h2>
            </div>
            <div className="p-5 w-full flex flex-col items-center">
              <p className="text-gray-700 mb-3 text-center">Are you sure you want to delete this event?</p>
              <div className="flex justify-center space-x-3 w-full">
                <button
                  onClick={handleDeleteConfirm}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 cursor-pointer text-white rounded-md transition-colors min-w-[90px]"
                >
                  Delete
                </button>
                <button
                  onClick={handleDeleteCancel}
                  className="px-4 py-2 bg-gray-200 hover:bg-gray-300 cursor-pointer text-gray-700 rounded-md transition-colors min-w-[90px]"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Calendar;