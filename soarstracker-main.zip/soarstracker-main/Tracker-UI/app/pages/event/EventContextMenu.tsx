import React from 'react';
import { VisibilityIcon, EditIcon, DeleteIcon, AddIcon } from '~/components/ui/Icons';

interface EventContextMenuProps {
  isVisible: boolean;
  position: { x: number; y: number };
  onView: () => void;
  onUpdate: () => void;
  onDelete: () => void;
  onAdd: () => void;
  onClose: () => void;
  showUpdate?: boolean;
  hasEvent?: boolean;
}

const EventContextMenu: React.FC<EventContextMenuProps> = ({
  isVisible,
  position,
  onView, 
  onUpdate,
  onDelete,
  onAdd,
  onClose,
  showUpdate = true,
  hasEvent = false,
}) => {
  if (!isVisible) return null;

  return (
    <>
      <div
        className="fixed inset-0 z-40"
        onClick={onClose}
      />
      <div
        className="fixed z-50 bg-white rounded-lg shadow-xl border border-gray-200 py-2 min-w-[140px]"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
        }}
      >
        {hasEvent ? (
          <>
            <button
              onClick={onView}
              className="w-full flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer transition-colors"
            >
              <VisibilityIcon fontSize="small" className="mr-2" />
              View
            </button>
            {showUpdate && (
              <button
                onClick={onUpdate}
                className="w-full flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer transition-colors"
              >
                <EditIcon fontSize="small" className="mr-2" />
                Update
              </button>
            )}
            <button
              onClick={onDelete}
              className="w-full flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50 cursor-pointer transition-colors"
            >
              <DeleteIcon fontSize="small" className="mr-2" />
              Delete
            </button>
          </>
        ) : (
          <button
            onClick={onAdd}
            className="w-full flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer transition-colors"
          >
            <AddIcon fontSize="small" className="mr-2" />
            Add Event
          </button>
        )}
      </div>
    </>
  );
};

export default EventContextMenu;