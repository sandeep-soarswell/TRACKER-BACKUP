import React from 'react';
import { DescriptionIcon } from '~/components/ui/Icons';


interface AuthHeaderProps {
  subtext: string;
}

const AuthHeader: React.FC<AuthHeaderProps> = ({ subtext }) => (
  <div className="flex flex-col items-center mb-6">
    <DescriptionIcon sx={{ fontSize: 40 }} className="text-[#0A2463] mb-2" />
    <h1 className="text-center text-gray-900 font-bold text-[26px] leading-tight">
      Tracker
    </h1>
    <p className="text-sm text-gray-600 mt-1 text-center">
      {subtext}
    </p>
  </div>
);

export default AuthHeader;
