package com.soarswell.tracker.permission;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Permissions for System Roles.
 *
 */
public interface SystemRolePermissions {

    public Collection<Permissions> SYSTEM_ADMIN_PERMISSIONS = Collections.unmodifiableList(
            List.of(Permissions.COMPANY_CREATE,
                    Permissions.COMPANY_WRITE,
                    Permissions.COMPANY_LIST,
                    Permissions.COMPANY_READ));

    public Collection<Permissions> COMPANY_ADMIN_PERMISSIONS = List.of(
            Permissions.EMPLOYEE_READ,
            Permissions.EMPLOYEE_WRITE,
            Permissions.COMPANY_READ,
            Permissions.COMPANY_WRITE,
            Permissions.PROJECT_READ,
            Permissions.PROJECT_WRITE
    );

    public Collection<Permissions> EMPLOYEE_PERMISSIONS = List.of(
            Permissions.PROJECT_READ
    );

    public Collection<Permissions> DATA_ADMIN_PERMISSIONS = Collections.unmodifiableList(
            List.of());

}
