package com.soarswell.tracker.serviceimpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseBuilder;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.Company;
import com.soarswell.tracker.model.User;
import com.soarswell.tracker.model.Status;
import com.soarswell.tracker.model.payload.CompanyImageUpdate;
import com.soarswell.tracker.model.payload.CompanyRequest;
import com.soarswell.tracker.model.payload.CompanyResponse;
import com.soarswell.tracker.model.payload.CompanyUpdateRequest;
import com.soarswell.tracker.repository.CompanyRepository;
import com.soarswell.tracker.repository.UserRepository;
import com.soarswell.tracker.service.CompanyService;
import com.soarswell.tracker.service.EmailService;
import com.soarswell.tracker.util.*;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class
CompanyServiceImpl implements CompanyService {

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private RequestDetails requestDetails;

    @Value("${file.upload.max-size}")
    private long maxFileSize;

    @Value("${file.upload.path}")
    private String folderPath;

    @Override
    @Transactional
    public ResponseEntity<?> createCompany(CompanyRequest request, RequestDetails requestDetails) {
        try {
            Map<String,String> exceptions = new HashMap<>();
            if (companyRepository.existsByEmailId(request.getEmailId()))  {
                String message = String.format(Constants.ERROR_COMPANY_ALREADY_EXISTS, request.getEmailId());
                exceptions.put(Constants.ERROR_COMPANY,message);
            }
            if(userRepository.existsByEmail(request.getEmailId()))
            {
                String message = ErrorMessageHandler.getMessage(ErrorMessageKey.USER_EMAIL_EXISTS.getStatusCode());
                exceptions.put(Constants.ERROR_EMAIL,message);
            }
            // Check for duplicate registration number
            if (request.getCompanyRegNo() != null && !request.getCompanyRegNo().trim().isEmpty()) {
                if (companyRepository.existsByCompanyRegNo(request.getCompanyRegNo())) {
                    exceptions.put(Constants.ERROR_COMPANY_REGD_NO,ErrorMessageHandler.getMessage(ErrorMessageKey.ERROR_REGISTERATION_NUMBER.getStatusCode()));
                }
            }
            // Check for duplicate mobile number
            if (request.getMobileNo() != null && !request.getMobileNo().trim().isEmpty()) {
                if (companyRepository.existsByMobileNo(request.getMobileNo())) {
                    exceptions.put(Constants.ERROR_PHONE, ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_MOBILE_DUPLICATE.getStatusCode()));
                }
            }
            // Check if mobile and alternate mobile are the same
            if (request.getMobileNo() != null && request.getAlternateNo() != null &&
                    request.getMobileNo().equals(request.getAlternateNo())) {
                exceptions.put(Constants.ERROR_PHONE, ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_MOBILE_ALTERNATE_SAME.getStatusCode()));
            }
            // Check for duplicate company name (case-insensitive)
            if (request.getCompanyName() != null && !request.getCompanyName().trim().isEmpty()) {
                // Fetch all companies and compare names case-insensitively
                boolean nameExists = companyRepository.findAll().stream()
                    .anyMatch(c -> c.getCompanyName() != null && c.getCompanyName().equalsIgnoreCase(request.getCompanyName()));
                if (nameExists) {
                    log.error("Company name already exists: {}", request.getCompanyName());
                    exceptions.put(Constants.ERROR_COMPANY_NAME,"Company name already exists: " + request.getCompanyName());
                }
            }
            if(companyRepository.existsByPersonalMailId(request.getPersonalMailId())){
                exceptions.put(Constants.ERROR_PERSONAL_EMAIL, ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_PERSONAL_EMAIL_DUPLICATE.getStatusCode()));
            }
            if (!exceptions.isEmpty()) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body(ResponseBuilder.builder().build().createErrorResponse(exceptions));
            }
            Company company = objectMapper.convertValue(request, Company.class);
            company.setId(ResourceIdUtils.generateCompanyResourceId(request.getEmailId()));
            company.setStatus(Status.ACTIVE.getLongLabel());
            Date currentDate = new Date(Instant.now().toEpochMilli());
            company.setCreateDate(currentDate);
            company.setCreatedBy(Constants.SYS_ADMIN_ROLE);
            company.setUpdateDate(currentDate);
            company.setUpdatedBy(Constants.SYS_ADMIN_ROLE);
            companyRepository.save(company);
            log.info(Constants.LOG_COMPANY_CREATED, company.getId());
            User adminUser = User.builder()
                    .email(request.getEmailId())
                    .id(ResourceIdUtils.generateUserResourceId(Constants.COMPANY_ADMIN, request.getEmailId()))
                    .firstName(Constants.ADMIN)
                    .lastName(Constants.ADMIN)
                    .phoneNumber(company.getMobileNo())
                    .middleName(Constants.ADMIN)
                    .companyName(request.getCompanyName())
                    .role(Constants.COMPANY_ADMIN)
                    .companyId(company.getId())
                    .createdBy(Constants.SYS_ADMIN_ROLE)
                    .createDate(new Date(Instant.now().toEpochMilli()))
                    .updateDate(new Date(Instant.now().toEpochMilli()))
                    .status(Status.CREATED.getShortLabel())
                    .password(passwordEncoder.encode(Constants.defaultPassword))
                    .build();
            userRepository.save(adminUser);
            try {
                emailService.sendCompanyCreatedEmail(request.getEmailId(), company.getCompanyName(), Constants.DEFAULT_PASSWORD);
            } catch (Exception e) {
                log.warn("Failed to send welcome email: {}", e.getMessage());
            }
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.COMPANY_CREATED), HttpStatus.CREATED);
        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error(Constants.ERROR_CREATING_COMPANY, e.getMessage());
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_SAVE_COMPANY.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<?> getAllCompanies(int page, int size, RequestDetails requestDetails, String sortByField, String order,String keyword) throws TrackerException {
        try {
            if (page < 0 || size <= 0) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_PAGINATION_PARAMS.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            log.info("Fetching all companies");
            Sort.Direction sortDirection = "asc".equalsIgnoreCase(order) ? Sort.Direction.ASC : Sort.Direction.DESC;
            PageRequest pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortByField));
            Page<Company> companyPage;
            if (keyword != null && !keyword.trim().isEmpty()) {
                companyPage = companyRepository.searchAllFieldsByStatusIn(Status.ACTIVE.getLongLabel(), keyword.trim(), pageable);
            } else {
                companyPage = companyRepository.findAllByStatus(Status.ACTIVE.getLongLabel(), pageable);
            }
            List<CompanyResponse> responses = companyPage.stream()
                    .map(company -> objectMapper.convertValue(company, CompanyResponse.class))
                    .collect(Collectors.toList());
            long totalEntries = companyPage.getTotalElements();
            Map<String,Object> res = new HashMap<>();
            res.put("data",responses);
            res.put("totalEnties", totalEntries);
            return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(res));
        } catch (Exception e) {
            log.error(Constants.ERROR_FETCHING_COMPANIES, e.getMessage());
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_COMPANY.getStatusCode()),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<ResponseObject<CompanyResponse>> getCompanyById(String companyId, RequestDetails requestDetails) {
        log.debug("Fetching company with ID: {}", companyId);
        // Move role check logic here
        if (requestDetails.getRoles() != null && requestDetails.getRoles().contains(Constants.COMPANY_ADMIN)) {
            String userCompanyId = AuthTokenUtils.extractCompanyId(requestDetails);
            if (!companyId.equals(userCompanyId)) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_COMPANY_FOUND.getStatusCode()), HttpStatus.NOT_FOUND);
            }
        }
        Company company = companyRepository.findById(companyId)
                .orElseThrow(()-> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));
        log.debug("Retrieved company: {}", company.getCompanyName());
        CompanyResponse response = objectMapper.convertValue(company, CompanyResponse.class);
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(response));
    }

    public ResponseEntity<ResponseObject<String>> updateCompany(String companyId, CompanyUpdateRequest request, RequestDetails requestDetails) {
        log.debug("Updating company with ID: {}", companyId);
        Company existingCompany = companyRepository.findById(companyId)
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_NOT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND));
        // Check for duplicate personal email (excluding current company)
        if (request.getPersonalMailId() != null && !request.getPersonalMailId().trim().isEmpty()) {
            if (!request.getPersonalMailId().equals(existingCompany.getPersonalMailId()) &&
                    companyRepository.existsByPersonalMailId(request.getPersonalMailId())) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_PERSONAL_EMAIL_DUPLICATE.getStatusCode()), HttpStatus.CONFLICT);
            }
        }
        if (request.getMobileNo() != null && !request.getMobileNo().trim().isEmpty()) {
            if (!request.getMobileNo().equals(existingCompany.getMobileNo()) &&
                    companyRepository.existsByMobileNo(request.getMobileNo())) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_MOBILE_DUPLICATE.getStatusCode()), HttpStatus.CONFLICT);
            }
        }
        if (request.getMobileNo() != null && request.getAlternateNo() != null &&
                request.getMobileNo().equals(request.getAlternateNo())) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_MOBILE_ALTERNATE_SAME.getStatusCode()), HttpStatus.CONFLICT);
        }
        try {
            boolean flag = PatchHelper.updateValue(existingCompany, request);
            if (flag) {
                Date currentDate = new Date(Instant.now().toEpochMilli());
                existingCompany.setUpdateDate(currentDate);
                existingCompany.setUpdatedBy(requestDetails.getUserId() != null ? requestDetails.getUserId() : Constants.SYS_ADMIN_ROLE);
                companyRepository.save(existingCompany);
            }
            String response = flag ? Constants.COMPANY_UPDATED : Constants.NO_CHANGES_DETECTED;
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(response), HttpStatus.OK);
        } catch (Exception e) {
            log.error(Constants.ERROR_UPDATING_COMPANY, e.getMessage());
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_SAVE_COMPANY.getStatusCode()),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<ResponseObject<String>> updateCompanyImage(String companyId, CompanyImageUpdate companyImageUpdate, MultipartFile multipartFile, RequestDetails requestDetails) throws TrackerException, IOException {
        List<String> allowedFileTypes = Arrays.asList(Constants.IMAGE_JPG, Constants.IMAGE_PNG, Constants.IMAGE_SVG);
        Company companyEntity = companyRepository.findById(companyId)
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));
        if (multipartFile == null || multipartFile.isEmpty()) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_IMAGE.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        if (multipartFile.getSize() > maxFileSize) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.IMAGE_SIZE_EXCEEDED.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        String contentType = multipartFile.getContentType();
        if (!allowedFileTypes.contains(contentType)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_IMAGE_FORMAT.getStatusCode()), HttpStatus.BAD_REQUEST);
        }

        Path imageDir = Paths.get(System.getProperty(Constants.DIRECTORY)).getParent().resolve(folderPath).resolve(Constants.IMAGE);
        if (!Files.exists(imageDir)) {
            Files.createDirectories(imageDir);
            log.info("Created image directory: {}", imageDir);
        }
        String originalFilename = multipartFile.getOriginalFilename();
        String extension = originalFilename != null ? originalFilename.substring(originalFilename.lastIndexOf(".")) : Constants.PNG;
        String safeCompanyName = companyEntity.getCompanyName().toLowerCase().replaceAll(Constants.FILE_PATTERN, "");
        String newFilename = safeCompanyName + "_" + UUID.randomUUID() + extension;
        Path newFilePath = imageDir.resolve(newFilename);
        try {
            multipartFile.transferTo(newFilePath.toFile());
            log.info("Saved new image file: {}", newFilePath);
        } catch (IOException e) {
            log.error("Failed to save new image file: {}", newFilePath, e);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_IMAGE.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if (companyEntity.getImageFile() != null && !companyEntity.getImageFile().isEmpty()) {
            Path oldFilePath = imageDir.resolve(companyEntity.getImageFile());
            try {
                Files.deleteIfExists(oldFilePath);
                log.info("Deleted old image file: {}", oldFilePath);
            } catch (IOException e) {
                log.error("Failed to delete old image file: {}", oldFilePath, e);
                try {
                    Files.deleteIfExists(newFilePath);
                    log.info("Deleted new image file after failing to delete old file: {}", newFilePath);
                } catch (IOException ex) {
                    log.error("Failed to delete new image file: {}", newFilePath, ex);
                }
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_IMAGE.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        companyEntity.setImageFile(newFilename);
        if (companyImageUpdate != null) {
            objectMapper.updateValue(companyEntity, companyImageUpdate);
        }
        // Set audit fields for update
        Date currentDate = new Date(Instant.now().toEpochMilli());
        companyEntity.setUpdateDate(currentDate);
        companyEntity.setUpdatedBy(requestDetails.getUserId() != null ? requestDetails.getUserId() : Constants.SYS_ADMIN_ROLE);
        companyRepository.save(companyEntity);
        log.info("Updated company image for companyId: {}", companyId);
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(Constants.COMPANY_IMAGE_UPDATE));
    }

    @Override
    public ResponseEntity<?> getCompanyImage(String companyId, HttpServletRequest request, RequestDetails requestDetails) throws TrackerException {
        try {
            Company companyEntity = companyRepository.findById(companyId)
                    .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.COMPANY_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));
            log.info("Company found: {}, imageFile: {}", companyEntity.getCompanyName(), companyEntity.getImageFile());
            if (companyEntity.getImageFile() == null || companyEntity.getImageFile().isEmpty()) {
                log.error("No image file associated with company ID {}", companyId);
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_IMAGE.getStatusCode()), HttpStatus.NOT_FOUND);
            }
            Path imageDir = Paths.get(System.getProperty(Constants.DIRECTORY)).getParent().resolve(folderPath).resolve(Constants.IMAGE);
            if (!Files.exists(imageDir)) {
                Files.createDirectories(imageDir);
                log.info("Created image directory: {}", imageDir);
            }
            Path filePath = imageDir.resolve(companyEntity.getImageFile());
            log.info("Constructed file path: {}", filePath);
            if (!Files.exists(filePath)) {
                log.error("Image file does not exist at path: {}", filePath);
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.IMAGE_FILE_NOT_EXISTS.getStatusCode()), HttpStatus.NOT_FOUND);
            }
            Resource resource = new FileSystemResource(filePath.toFile());
            String contentType = Files.probeContentType(filePath);
            if (contentType == null) {
                log.warn("Could not determine content type for file: {}, defaulting to octet-stream", filePath);
                contentType = MediaType.APPLICATION_OCTET_STREAM_VALUE;
            }
            log.info("Serving image with content type: {}", contentType);

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + companyEntity.getImageFile() + "\"")
                    .body(resource);
        }catch(TrackerException e){
            throw e;
        } catch(IOException e) {
            log.error("IOException while reading image file for company {}: {}", companyId, e.getMessage(), e);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_IMAGE.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch(Exception ex) {
            log.error("Unexpected exception while retrieving company image {}: {}", companyId, ex.getMessage(), ex);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_IMAGE.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
