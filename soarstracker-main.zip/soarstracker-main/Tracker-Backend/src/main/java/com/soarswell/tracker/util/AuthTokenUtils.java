package com.soarswell.tracker.util;

import com.soarswell.tracker.auth.JWTService;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.exception.TrackerException;
import io.jsonwebtoken.Claims;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;

public class AuthTokenUtils {
    private static final Logger logger = LoggerFactory.getLogger(AuthTokenUtils.class);

    public static String extractCompanyId(RequestDetails requestDetails) throws TrackerException {
        String token = cleanToken(requestDetails.getAuthToken());

        try {
            Claims claims = JWTService.validateToken(token);
            String companyId = claims.get(Constants.COMPANY_ID, String.class);
            logger.info(companyId);
            if (!StringUtils.hasText(companyId)) {
                throw new TrackerException("Company ID not found in token", HttpStatus.UNAUTHORIZED);
            }
            return companyId;
        } catch (Exception e) {
            throw new TrackerException("Invalid or expired token", e, "INVALID_TOKEN", HttpStatus.UNAUTHORIZED);
        }
    }

    public static String extractEmail(RequestDetails requestDetails) throws TrackerException {
        String token = cleanToken(requestDetails.getAuthToken());

        try {
            Claims claims = JWTService.validateToken(token);
            return claims.getSubject();
        } catch (Exception e) {
            throw new TrackerException("Invalid or expired token", e, "INVALID_TOKEN", HttpStatus.UNAUTHORIZED);
        }
    }

    private static String cleanToken(String rawToken) {
        if (!StringUtils.hasText(rawToken)) {
            throw new TrackerException("Authorization token is missing", HttpStatus.UNAUTHORIZED);
        }
        return rawToken.startsWith("Bearer ") ? rawToken.substring(7) : rawToken;
    }
}