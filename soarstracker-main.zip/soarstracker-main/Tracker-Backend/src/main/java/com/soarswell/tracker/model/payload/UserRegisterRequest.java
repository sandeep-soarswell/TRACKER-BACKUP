package com.soarswell.tracker.model.payload;

import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.RegExConstants;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import io.swagger.v3.oas.annotations.media.Schema;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserRegisterRequest {

    @Schema(example = Constants.FIRST_NAME)
    @NotBlank(message = Constants.FIRSTNAME_MESSAGE)
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = Constants.FIRSTNAME_FORMAT)
    @Size(min = 3, max = 20, message = "{user.firstname.size}")
    private String firstName;

    @Schema(example = Constants.MIDDLE_NAME)
    @Size(max = 20, message = "{user.middleName.size}")
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = Constants.MIDDLE_NAME_FORMAT)
    private String middleName;

    @Schema(example = Constants.LAST_NAME)
    @NotBlank(message = Constants.LASTNAME_MESSAGE)
    @Size(min = 3, max = 20, message = "{user.lastname.size}")
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = Constants.LASTNAME_FORMAT)
    private String lastName;

    @Schema(example = Constants.EMAIL)
    @NotBlank(message = Constants.ADMIN)
    @Email(message = Constants.INVALID_EMAIL)
    private String email;

    @Schema(example = Constants.PHONE)
    @NotNull(message = Constants.PHONE_NULL_MESSAGE)
    @ValidPhoneNumber(message = "{invalid.mobile.number}")
    String phoneNumber;


    @Schema(example = Constants.ROLE)
    @NotNull(message = Constants.ROLE_NOTNULL_MESSAGE)
    @Pattern(regexp = RegExConstants.ROLE_VALIDATION_PATTERN,message="{role.invalid.format}")
    private String role;
}