package com.soarswell.tracker.serviceimpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseBuilder;
import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.*;
import com.soarswell.tracker.model.payload.ClientCommentRequest;
import com.soarswell.tracker.model.payload.CommentRequest;
import com.soarswell.tracker.repository.CandidateRepository;
import com.soarswell.tracker.repository.ClientCommentRepository;
import com.soarswell.tracker.repository.ClientRepository;
import com.soarswell.tracker.repository.CommentRepository;
import com.soarswell.tracker.service.CommentService;
import com.soarswell.tracker.service.CompanyService;
import com.soarswell.tracker.util.AuthTokenUtils;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.ResourceIdUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.soarswell.tracker.exception.ErrorMessageKey.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommentServiceImpl implements CommentService {

    @Autowired
    private  CommentRepository commentRepository;
    private final CandidateRepository candidateRepository;
    private final ObjectMapper objectMapper;

    @Autowired
    private ClientRepository clientRepository;
    
    @Autowired
    private ClientCommentRepository clientCommentRepository;
    
    @Autowired
    private CompanyService companyService;

    @Override
    public ResponseEntity<?> addComment(String candidateId, CommentRequest commentRequest, RequestDetails requestDetails) throws TrackerException {
        try {
            if (candidateId == null || candidateId.trim().isEmpty()) {
                log.error("Candidate ID is null or empty in comment request");
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(CANDIDATE_ID_NULL_OR_EMPTY.getStatusCode()),
                        HttpStatus.BAD_REQUEST
                );
            }
            Optional<Candidate> candidateOpt = candidateRepository.findById(candidateId);
            if (candidateOpt.isEmpty()) {
                log.error("Candidate not found for ID: {}", candidateId);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(CANDIDATE_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                );
            }

            if(candidateOpt.get().getJobAssignment()==null){
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NO_JOB_ASSIGNMENT.getStatusCode()),
                        HttpStatus.BAD_REQUEST
                );
            }
            if(candidateOpt.get().getAssignment()==null){
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_USER_ASSIGNED_CANDIDATE.getStatusCode()),HttpStatus.BAD_REQUEST);
            }
            CommentEntity comment = CommentEntity.builder()
                    .id(ResourceIdUtils.generateCommentResourceId(new Date(Instant.now().toEpochMilli())))
                    .content(commentRequest.getContent())
                    .createDate(new Date(Instant.now().toEpochMilli()))
                    .createdBy(requestDetails.getUserId())
                    .candidateId(candidateId)
                    .build();

            commentRepository.save(comment);
            return new ResponseEntity<>(
                    ResponseBuilder.builder().build().createSuccessResponse(Constants.SUCCESS),
                    HttpStatus.CREATED
            );

        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Unable to add comment: {}", e.getMessage(), e);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(UNABLE_SAVE_COMMENT.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    @Override
    public ResponseEntity<?> getCommentsByCandidate(String candidateId) throws TrackerException {
        try {
            if (candidateId == null || candidateId.trim().isEmpty()) {
                log.error("Candidate ID is null or empty while fetching comments");
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(CANDIDATE_ID_NULL_OR_EMPTY.getStatusCode()),
                        HttpStatus.BAD_REQUEST
                );
            }
            List<CommentEntity> commentList = commentRepository.findByCandidateId(candidateId);
            log.info("Fetched {} comments for candidate ID: {}", commentList.size(), candidateId);
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(commentList), HttpStatus.OK);
        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Unable to fetch comments for candidate {}: {}", candidateId, e.getMessage(), e);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(UNABLE_GET_COMMENT.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    @Override
    public ResponseEntity<?> addSystemComment(String candidateId, String content, RequestDetails requestDetails) throws TrackerException {
        CommentEntity commentEntity = CommentEntity.builder()
                .id(ResourceIdUtils.generateCommentResourceId(new Date(Instant.now().toEpochMilli())))
                .candidateId(candidateId)
                .content(content)
                .createdBy(requestDetails.getUserId())
                .createDate(new Date(Instant.now().toEpochMilli()))
                .build();
        commentRepository.save(commentEntity);
        return ResponseEntity.status(HttpStatus.CREATED).body(Constants.SUCCESS);
    }

    @Override
    public ResponseEntity<?> addClientComment(String clientId, ClientCommentRequest clientCommentRequest, RequestDetails requestDetails) throws TrackerException{
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        try {
            if (clientId == null || clientId.trim().isEmpty()) {
                log.error("Client ID is null or Empty :{}", clientId);
                throw new TrackerException(ErrorMessageHandler.getMessage(CLIENT_ID_NULL_OR_EMPTY.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            if (clientRepository.findByCompanyIdAndIdAndStatus(companyId, clientId, Status.ACTIVE.getLongLabel()).isEmpty()) {
                throw new TrackerException(ErrorMessageHandler.getMessage(NO_CLIENT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND);
            }
            ClientCommentEntity clientComment = ClientCommentEntity.builder()
                    .id(ResourceIdUtils.generateClientCommentResourceId(companyId, clientId, new Date(Instant.now().toEpochMilli())))
                    .createdBy(requestDetails.getUserId())
                    .createDate(new Date(Instant.now().toEpochMilli()))
                    .clientId(clientId)
                    .companyId(companyId)
                    .content(clientCommentRequest.getContent())
                    .build();
            clientCommentRepository.save(clientComment);
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.SUCCESS), HttpStatus.CREATED);
        }catch (TrackerException e){
            throw e;
        } catch (Exception e) {
            log.error("Unable to add comment for client {}: {}", clientId, e.getMessage(), e);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_SAVE_COMMENT.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<?> getClientComments(String clientId, RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        try {
            if (clientId == null || clientId.trim().isEmpty()) {
                log.error("Client ID is null or Empty :{}", clientId);
                throw new TrackerException(ErrorMessageHandler.getMessage(CLIENT_ID_NULL_OR_EMPTY.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            if (clientRepository.findByCompanyIdAndId(companyId, clientId).isEmpty()) {
                throw new TrackerException(ErrorMessageHandler.getMessage(NO_CLIENT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND);
            }
            List<ClientCommentEntity> clientComment = clientCommentRepository.findByCompanyIdAndClientId(companyId, clientId).stream().toList();
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(clientComment), HttpStatus.OK);
        }
        catch(TrackerException e){
            throw  e;
        }
        catch (Exception e){
            log.error("Unable to fetch comments for client {}: {}", clientId, e.getMessage(), e);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_COMMENT.getStatusCode()),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @Override
    public void clientComments(String clientId, String content, RequestDetails requestDetails) throws TrackerException{
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        try {
            if (clientId == null || clientId.trim().isEmpty()) {
                log.error("Client ID is null or Empty :{}", clientId);
                throw new TrackerException(ErrorMessageHandler.getMessage(CLIENT_ID_NULL_OR_EMPTY.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            if (clientRepository.findByCompanyIdAndId(companyId, clientId).isEmpty()) {
                throw new TrackerException(ErrorMessageHandler.getMessage(NO_CLIENT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND);
            }
            ClientCommentEntity clientComment = ClientCommentEntity.builder()
                    .id(ResourceIdUtils.generateClientCommentResourceId(companyId, clientId, new Date(Instant.now().toEpochMilli())))
                    .createdBy(requestDetails.getUserId())
                    .createDate(new Date(Instant.now().toEpochMilli()))
                    .clientId(clientId)
                    .companyId(companyId)
                    .content(content)
                    .build();
            clientCommentRepository.save(clientComment);
        }catch(TrackerException e){
            throw e;
        } catch(Exception e){
            log.error("Unable to add comment to client {}:{}", clientId, e.getMessage());
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_SAVE_COMMENT.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}