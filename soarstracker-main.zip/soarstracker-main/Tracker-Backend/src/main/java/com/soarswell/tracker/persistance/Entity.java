package com.soarswell.tracker.persistance;

public interface Entity {

}
