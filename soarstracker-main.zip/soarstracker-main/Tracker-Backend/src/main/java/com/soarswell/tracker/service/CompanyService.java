package com.soarswell.tracker.service;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.CompanyImageUpdate;
import com.soarswell.tracker.model.payload.CompanyRequest;
import com.soarswell.tracker.model.payload.CompanyResponse;
import com.soarswell.tracker.model.payload.CompanyUpdateRequest;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
@Service
public interface CompanyService {
    @Transactional
    ResponseEntity<?> createCompany(CompanyRequest request, RequestDetails requestDetails);

    ResponseEntity<?> getAllCompanies(int page, int size, RequestDetails requestDetails, String sortByField, String order, String keyword) throws TrackerException;

    ResponseEntity<ResponseObject<CompanyResponse>> getCompanyById(String companyId, RequestDetails requestDetails);

    @Transactional
    ResponseEntity<ResponseObject<String>> updateCompany(String companyId, CompanyUpdateRequest request, RequestDetails requestDetails);

    ResponseEntity<ResponseObject<String>> updateCompanyImage(String companyId, CompanyImageUpdate companyImageUpdate, MultipartFile multipartFile, RequestDetails requestDetails) throws TrackerException, IOException;

    ResponseEntity<?> getCompanyImage(String companyId, HttpServletRequest request, RequestDetails requestDetails)  throws TrackerException;
}
