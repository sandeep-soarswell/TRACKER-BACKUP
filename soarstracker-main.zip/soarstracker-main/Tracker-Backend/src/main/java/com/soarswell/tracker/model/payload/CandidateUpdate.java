package com.soarswell.tracker.model.payload;

import com.soarswell.tracker.util.RegExConstants;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import io.swagger.v3.oas.annotations.media.Schema;
import com.soarswell.tracker.util.Constants;

import java.net.URL;
import java.time.LocalDate;

@Getter
@Setter
public class CandidateUpdate {

    @Schema(example = Constants.FIRST_NAME)
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = Constants.FIRSTNAME_FORMAT)
    @Size(min = 3, max = 20, message = "{candidate.firstname.size}")
    private String firstName;

    @Schema(example = Constants.MIDDLE_NAME)
    @Size(max = 20, message = "{candidate.middleName.size}")
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = Constants.MIDDLE_NAME_FORMAT)
    private String middleName;

    @Schema(example = Constants.LAST_NAME)
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = Constants.LASTNAME_FORMAT)
    @Size(min = 3, max = 20, message = "{candidate.lastname.size}")
    private String lastName;

    private LocalDate dateOfBirth;

    @Schema(example = Constants.CONTACT_ADDRESS_EXAMPLE)
    @Size(max = 500, message = "{address.size}")
    private String address;

    @Schema(example = Constants.JOB_SKILLS)
    @Size(max = 500, message = "{skills.size}")
    private String skills;

    @Schema(example = "Software Engineer")
    @Pattern(regexp = RegExConstants.CANDIDATE_ROLE,message = "{invalid.candidate.role.format}")
    @Size(max = 500, message = "{candidate.role.size}")
    private String candidateRole;

    @Schema(example = Constants.EMAIL)
    @Email(message = "{invalid.email.format}")
    private String alternateEmail;

    @Schema(example = Constants.PHONE)
    @ValidPhoneNumber(message = "{invalid.alternate.mobile.number}")
    private String alternatePhoneNumber;

    @Schema( example = "2025-07-01" )
    @Future(message = "Availability date must be in the future")
    private LocalDate availabilityOfJoining;

    @Schema(example = "4.5 Years")
    @Size(max = 100, message = "{experience.size}")
    private String experience;

    @Schema( example = "30 Days")
    @Size(max = 100, message = "{noticePeriod.size}")
    private String noticePeriod;

    @Schema(example = "9,00,000")
    private String currentSalary;

    @Schema(example = "11,20,000")
    private String  expectedSalary;

    @Schema(example=Constants.RESUME)
    private URL resume;

    @Schema(example = "active")
    @Pattern(regexp = RegExConstants.STATUS_PATTERN, message = "{status.pattern.message}")
    private String status;

    @Schema(example = "1, 2, 3 or more")
    private String numberOfOffers;

    @Schema(example = "Male or Female")
    private String gender;
}