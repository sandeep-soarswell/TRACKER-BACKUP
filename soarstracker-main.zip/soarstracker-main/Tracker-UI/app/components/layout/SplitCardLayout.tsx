import React from 'react';
interface SplitCardLayoutProps {
  children: React.ReactNode;
}

const SplitCardLayout: React.FC<SplitCardLayoutProps> = ({ children }) => {
  return (
    <div className="flex min-h-screen">
      <div
        className="w-full flex justify-center items-center bg-cover bg-no-repeat bg-center"
        style={{ backgroundBlendMode: 'overlay' }}
      >
        {children}
      </div>
    </div>
  );
};

export default SplitCardLayout;
