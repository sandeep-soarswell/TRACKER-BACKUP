import { AddIcon, SearchIcon, DeleteIcon, VisibilityIcon, EditIcon, HomeIcon } from '~/components/ui/Icons';
import React, { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router";
import TuneIcon from '@mui/icons-material/Tune';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import { DataGrid, type GridRenderCellParams, useGridApiRef } from '@mui/x-data-grid';
import Card from "~/components/ui/Card";
import userService from "~/services/employee/employee.service";
import type { Employee as EmployeeType } from "~/pages/types/types";
import EmployeeDetailsDrawer from "./EmployeesDetailsDrawer";
import EmployeeForm from "./RegisterEmployeeForm";
import CustomSnackbar from '~/components/ui/Customsnackbar';
import CustomTooltip from '~/components/layout/tooltip';

const formatRole = (role: string | string[] | null): string => {
  if (!role) return "N/A";
  if (Array.isArray(role)) {
    return role
      .map((r) =>
        r
          .split("_")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
          .join(" ")
      )
      .join(", ");
  }
  return role
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
};

const formatStatus = (status: string | null): string => {
  if (!status) return "N/A";
  return status.charAt(0).toUpperCase() + status.slice(1).toLowerCase();
};

const EmployeesPage: React.FC = () => {
  const [employees, setEmployees] = useState<EmployeeType[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [roleFilter, setRoleFilter] = useState<string>("");
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [viewMode, setViewMode] = useState<"view" | "edit" | "create" | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState<EmployeeType | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [employeeToUpdate, setEmployeeToUpdate] = useState<EmployeeType | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const navigate = useNavigate();
  const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 10 });
  const apiRef = useGridApiRef();

  const fetchEmployees = async () => {
    setSearchError(null);
    setLoading(true);
    try {
      const response = await userService.getAll(
        0,
        1000,
        roleFilter || "*",
        searchTerm,
        statusFilter || "*",
        "createDate",
        "desc"
      );
      const employeeData = response?.data?.records || [];
      if (Array.isArray(employeeData)) {
        const validEmployees = employeeData.filter((employee: EmployeeType) => employee && employee.id);
        setEmployees(validEmployees);
      } else {
        setEmployees([]);
        showSnackbar("Unexpected data format from server.", "error");
      }
    } catch (error: any) {
      let errorMessage = "Failed to fetch employees.";
      if (error.response?.status === 404) {
        errorMessage = error.response?.data?.error?.message || error.response?.data?.message || "Users not found";
        setSearchError(errorMessage);
      }
      showSnackbar(errorMessage, "error");
      setEmployees([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, [searchTerm, statusFilter, roleFilter]);

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
  };

  const handleFilterChange = (setter: React.Dispatch<React.SetStateAction<string>>, value: string) => {
    setter(value);
  };

  const showSnackbar = (message: string, severity: "success" | "error" = "success") => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  };

  const handleViewDetails = (employee: EmployeeType) => {
    setSelectedEmployee(employee);
    setViewMode("view");
    setIsDrawerOpen(true);
  };

  const handleStatusClick = (employee: EmployeeType) => {
    if (employee.status?.toLowerCase() === 'inactive') {
      setEmployeeToUpdate(employee);
      setShowStatusModal(true);
    }
  };

  const confirmStatusChange = async () => {
    if (!employeeToUpdate?.id) return;
    try {
      await userService.updateStatus(employeeToUpdate.id, "Active");
      showSnackbar("Employee status updated to Active.", "success");
      fetchEmployees();
    } catch (error) {
      showSnackbar("Failed to update employee status.", "error");
    } finally {
      setShowStatusModal(false);
      setEmployeeToUpdate(null);
    }
  };

  const handleEdit = (employee: EmployeeType | null) => {
    setSelectedEmployee(employee);
    setViewMode(employee ? "edit" : "create");
    setIsDrawerOpen(true);
  };

  const handleDelete = (employee: EmployeeType) => {
    setSelectedEmployee(employee);
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    if (!selectedEmployee?.id) return;
    try {
      await userService.delete(selectedEmployee.id);
      showSnackbar("Employee deleted successfully!", "success");
      fetchEmployees();
    } catch (error: any) {
      showSnackbar("Failed to delete employee.", "error");
    } finally {
      setShowDeleteModal(false);
      setSelectedEmployee(null);
    }
  };

  const closeDrawer = () => {
    setIsDrawerOpen(false);
    setSelectedEmployee(null);
    setViewMode(null);
  };

  const rows = useMemo(() => {
    return employees.map((emp) => ({
      ...emp,
      fullName: `${emp.firstName || ''} ${emp.middleName || ''} ${emp.lastName || ''}`.trim(),
      role: formatRole(emp.role),
      status: formatStatus(emp.status),
      actions: {
        emp,
        isDeleteDisabled: Array.isArray(emp.role) ? emp.role.includes("COMPANY_ADMIN") : emp.role === "COMPANY_ADMIN" || emp.status?.toLowerCase() === "inactive",
        isInactive: emp.status?.toLowerCase() === "inactive"
      }
    }));
  }, [employees]);

  return (
    <div className="h-[calc(100vh-100px)]">
      <CustomSnackbar
        open={snackbarOpen}
        message={snackbarMessage}
        severity={snackbarSeverity}
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={3000}
      />
      <div className="flex items-center">
        <div className="flex items-center text-sm text-gray-600">
          <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
          <a
            href="/dashboard"
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
            onClick={(e) => { e.preventDefault(); navigate('/dashboard'); }}
          >
            Dashboard
          </a>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="text-sm text-gray-600">Employees</div>
      </div>
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center">
          Employee Management
        </h1>
        <button
          onClick={() => handleEdit(null)}
          className="flex items-center gap-2 font-bold rounded-lg mb-1 px-3.5 py-2 shadow transition"
          style={{
            backgroundColor: "#0A2463",
            color: "white",
            letterSpacing: "0.5px",
            fontSize: "1rem",
            cursor: "pointer",
          }}
        >
          <AddIcon sx={{ fontSize: 18 }} />
          New Employee
        </button>
      </div>
      <Card className="py-3 mb-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative w-full md:w-96">
            <SearchIcon
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
              sx={{ fontSize: 18 }}
            />
            <input
              type="text"
              placeholder="Search by name, email, phone..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
              value={searchTerm}
              onChange={handleSearchChange}
            />
          </div>
          <div className="ml-auto relative">
            <button
              onClick={() => setShowFilters((prev) => !prev)}
              className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-gray-200 cursor-pointer"
              title="Filter"
            >
              <TuneIcon />
            </button>
            {showFilters && (
              <div className="absolute z-10 right-0 mt-2 w-[260px] bg-white border border-gray-200 rounded-lg shadow-lg p-4 space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Status</label>
                  <select
                    value={statusFilter}
                    onChange={(e) => handleFilterChange(setStatusFilter, e.target.value)}
                    className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  >
                    <option value="">All Statuses</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Created">Created</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Role</label>
                  <select
                    value={roleFilter}
                    onChange={(e) => handleFilterChange(setRoleFilter, e.target.value)}
                    className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  >
                    <option value="">All Roles</option>
                    <option value="COMPANY_ADMIN">{formatRole("COMPANY_ADMIN")}</option>
                    <option value="MANAGER">{formatRole("MANAGER")}</option>
                    <option value="RECRUITER">{formatRole("RECRUITER")}</option>
                  </select>
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>
      {loading ? (
        <p className="text-center text-gray-500">Loading employees...</p>
      ) : (
        <Card className="h-[calc(100vh-245px)] w-full">
          <DataGrid
            apiRef={apiRef}
            rows={rows}
            getRowId={(row) => row.id as string | number} // Type assertion to ensure non-undefined GridRowId
            columns={[
              {
                field: 'sno',
                headerName: '#',
                flex: 0.3,
                renderCell: (params: GridRenderCellParams) => {
                  const totalRowsBeforePage = paginationModel.page * paginationModel.pageSize;
                  const rowIndex = apiRef.current?.getRowIndexRelativeToVisibleRows(params.id) ?? 0; // Handle null with fallback
                  return <span>{totalRowsBeforePage + rowIndex + 1}</span>;
                }
              },
              {
                field: 'fullName',
                headerName: 'Name',
                flex: 1.2,
                renderCell: (params: GridRenderCellParams) => (
                  <CustomTooltip title={'Employee Details'}>
                    <div
                      onClick={() => navigate('/dashboard/employee/assignes', { state: { id: params.row.id } })}
                      className="text-blue-600 hover:underline cursor-pointer font-medium w-full h-full flex items-center"
                      role="button"
                      tabIndex={0}
                    >
                      {params.value}
                    </div>
                  </CustomTooltip>
                ),
              },
              { field: 'email', headerName: 'Email', flex: 1.5 },
              { field: 'phoneNumber', headerName: 'Mobile Number', flex: 0.8 },
              { field: 'role', headerName: 'Role', flex: 1 },
              {
                field: 'actions',
                headerName: 'Actions',
                flex: 0.8,
                sortable: false,
                filterable: false,
                renderCell: (params: GridRenderCellParams) => {
                  const { emp, isDeleteDisabled, isInactive } = params.row.actions;
                  const deleteTooltip = isDeleteDisabled ? (Array.isArray(emp.role) && emp.role.includes("COMPANY_ADMIN") ? "Unable to delete a company admin" : "Unable to delete an inactive employee") : "Delete Employee";
                  return (
                    <div className="flex items-center gap-3">
                      <CustomTooltip title="View Employee" placement="top">
                        <div
                          className="p-1 transition cursor-pointer"
                          onClick={(e) => { e.stopPropagation(); handleViewDetails(emp); }}
                        >
                          <VisibilityIcon className="text-blue-400 hover:scale-110 transition-transform" sx={{ fontSize: 18 }} />
                        </div>
                      </CustomTooltip>
                      {isInactive && (
                        <CustomTooltip title="Activate Employee" placement="top">
                          <div
                            className="p-1 transition cursor-pointer"
                            onClick={(e) => { e.stopPropagation(); handleStatusClick(emp); }}
                          >
                            <CheckCircleOutlineIcon className="text-green-600 hover:scale-110 transition-transform" sx={{ fontSize: 22 }} />
                          </div>
                        </CustomTooltip>
                      )}
                      {!isInactive && (
                        <>
                          <CustomTooltip title="Edit Employee" placement="top">
                            <div
                              className="p-1 transition cursor-pointer"
                              onClick={(e) => { e.stopPropagation(); handleEdit(emp); }}
                            >
                              <EditIcon className="text-blue-400 hover:scale-110 transition-transform" sx={{ fontSize: 18 }} />
                            </div>
                          </CustomTooltip>
                          <CustomTooltip title={deleteTooltip} placement="top">
                            <div
                              className={`p-1 transition ${isDeleteDisabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}
                              onClick={(e) => {
                                if (!isDeleteDisabled) {
                                  e.stopPropagation();
                                  handleDelete(emp);
                                }
                              }}
                            >
                              <DeleteIcon className="text-red-600 hover:scale-110 transition-transform" sx={{ fontSize: 18 }} />
                            </div>
                          </CustomTooltip>
                        </>
                      )}
                    </div>
                  );
                },
              },
            ]}
            pagination
            paginationMode="client"
            pageSizeOptions={[5, 10, 20, 50]}
            paginationModel={paginationModel}
            onPaginationModelChange={setPaginationModel}
            rowCount={rows.length}
            disableRowSelectionOnClick
            sx={{
              width: '100%',
              '& .MuiDataGrid-columnHeaders': { backgroundColor: '#f1f5f9 !important' },
              '& .MuiDataGrid-columnHeader': { backgroundColor: '#f1f1f1' },
              '& .MuiDataGrid-columnHeaderTitle': { fontWeight: 'bold', textTransform: 'uppercase' },
              '& .MuiDataGrid-row:hover': { backgroundColor: 'inherit' },
              '& .MuiDataGrid-main': { padding: 0 },
              '& .MuiDataGrid-footerContainer': { justifyContent: 'flex-end' },
            }}
          />
        </Card>
      )}
      {isDrawerOpen && viewMode === "view" && selectedEmployee && (
        <EmployeeDetailsDrawer open={isDrawerOpen} onClose={closeDrawer} employee={selectedEmployee} />
      )}
      {isDrawerOpen && (viewMode === "edit" || viewMode === "create") && (
        <EmployeeForm
          employee={selectedEmployee ?? undefined}
          onClose={closeDrawer}
          onSuccess={() => {
            fetchEmployees();
            closeDrawer();
            showSnackbar(
              viewMode === "edit" ? "Employee updated successfully!" : "Employee registered successfully!",
              "success"
            );
          }}
        />
      )}
      {showDeleteModal && selectedEmployee && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
            <h2 className="text-lg font-semibold text-center text-black mb-4">Confirm Delete</h2>
            <p className="text-center mb-4">
              Are you sure you want to delete <strong>{selectedEmployee.firstName} {selectedEmployee.lastName}</strong>?
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={confirmDelete}
                className="bg-red-600 text-white px-5 py-3 rounded hover:bg-red-700 cursor-pointer"
              >
                Yes, Delete
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="bg-gray-300 text-gray-700 px-5 py-3 rounded hover:bg-gray-400 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
      {showStatusModal && employeeToUpdate && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
            <h2 className="text-lg font-semibold text-center text-black mb-4">Confirm Status Change</h2>
            <p className="text-center mb-4">
              Are you sure you want to change the status of <strong>{employeeToUpdate.firstName} {employeeToUpdate.lastName}</strong> to Active?
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={confirmStatusChange}
                className="bg-green-600 text-white px-5 py-3 rounded hover:bg-green-700 cursor-pointer"
              >
                Yes, Activate
              </button>
              <button
                onClick={() => {
                  setShowStatusModal(false);
                  setEmployeeToUpdate(null);
                }}
                className="bg-gray-300 text-gray-700 px-5 py-3 rounded hover:bg-gray-400 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeesPage;