import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { MailIcon, LockIcon, VisibilityIcon, VisibilityOffIcon } from '~/components/ui/Icons';
import AuthHeader from '~/components/layout/AuthHeader';
import SplitCardLayout from '~/components/layout/SplitCardLayout';
import authService from '~/services/login/login.services';
import { jwtDecode } from 'jwt-decode';
import  equalsIgnoreCase  from '~/components/util/util.services';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import CustomOtpInput from '~/components/layout/customotp';

const Login: React.FC = () => {
  const [step, setStep] = useState<'login' | 'otp' | 'changePassword'>('login');
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [otp, setOtp] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [alertSeverity, setAlertSeverity] = useState<'success' | 'error' | 'info'>('info');
  const [alertMessage, setAlertMessage] = useState('');
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [touched, setTouched] = useState({ email: false, password: false });
  const [resendTimer, setResendTimer] = useState(30);
  const [isResendDisabled, setIsResendDisabled] = useState(true);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [otpError, setOtpError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('userToken');
    if (token) navigate('/dashboard');

    if (step === 'otp') {
      const storedEmail = localStorage.getItem('userEmail') || '';
      setEmail(storedEmail);
    }
  }, [navigate, step]);

  const startResendCountdown = () => {
    setIsResendDisabled(true);
    setResendTimer(30);

    const timer = setInterval(() => {
      setResendTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsResendDisabled(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };


  useEffect(() => {
    let timer: NodeJS.Timeout;

    if (step === 'otp') {
      if (step === 'otp') {
        startResendCountdown();
      }
    }
  }, [step]);


  useEffect(() => {
    const email = formData.email;
    if (!email) {
      setEmailError('');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setEmailError('Invalid email format');
    } else {
      setEmailError('');
    }
  }, [formData.email]);


  useEffect(() => {
    const pwd = formData.password.trim();

    if (!pwd) {

    } else {
      setPasswordError('');
    }
  }, [formData.password]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'email' ? value.trim().toLowerCase() : value,
    }));
  };

  const togglePasswordVisibility = () => setShowPassword(prev => !prev);
  const handleSnackbarClose = () => setOpenSnackbar(false);

  const handleLoginSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    setEmailError('');
    setPasswordError('');

    if (!formData.email.trim()) {
      setEmailError('Email is required');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setEmailError('Invalid email format');
    }
    if (!formData.password.trim()) {
      setPasswordError('Password is required');
    }
    if (!formData.email.trim() || !formData.password.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      return;
    }
    try {
      const response = await authService.login(formData.email, formData.password);
      const message = response?.message ?? '';

      if (equalsIgnoreCase(message, 'Success')) {
        localStorage.setItem('userEmail', formData.email);

        const tempToken = response.data?.token;
        if (tempToken) {
          const decoded: any = jwtDecode(tempToken);
          const purpose = decoded?.purpose;

          if (purpose === 'general') {
            localStorage.setItem('userToken', tempToken);
            navigate('/dashboard');
          } else {
            localStorage.setItem('tempToken', tempToken);
            setStep('otp');
            setOtp('');
          }
        } else {
          setStep('otp');
          setAlertSeverity('success');

          setAlertMessage(response?.data?.message || 'Otp has been sent to your email. Please verify to proceed.');

          setOpenSnackbar(true);
        }

      } else {
        throw new Error(response?.message ?? 'Login failed');
      }
    } catch (error: any) {
      const backendError = error?.response?.data?.error;
      let backendMessage = error?.message;
      let showSnackbarMsg = true;
      if (typeof backendError === 'string') {
        backendMessage = backendError;
      } else if (typeof backendError === 'object' && backendError !== null) {
        if (backendError.password) {
          setPasswordError(backendError.password);
          showSnackbarMsg = false;
        }
        if (!backendError.password) {
          backendMessage = Object.values(backendError)[0];
        }
      }
      if (showSnackbarMsg && backendMessage) {
        setAlertSeverity('error');
        setAlertMessage(backendMessage || 'Login failed');
        setOpenSnackbar(true);
      }
    }
  };
  const handleOtpSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!otp.trim()) {
      setOtpError('OTP is required');
      return;
    }
    if (!/^\d{6}$/.test(otp)) {
      setOtpError('OTP must be exactly 6 digits');
      return;
    }
    setOtpError('');

    const storedEmail = localStorage.getItem('userEmail');
    if (!storedEmail) {
      setAlertSeverity('error');
      setAlertMessage('Email not found. Please login again.');
      setOpenSnackbar(true);
      setStep('login');
      return;
    }

    try {
      const response = await authService.validateOtp(storedEmail, otp);
      const tempToken = response.data?.token;
      if (!tempToken) throw new Error('No token received');
      localStorage.setItem('tempToken', tempToken);

      const decoded: any = jwtDecode(tempToken);
      const purpose = decoded?.purpose;

      switch (purpose) {
        case 'first_time':
        case 'reset_password':
          setStep('changePassword');
          setAlertSeverity('info');
          setAlertMessage('Please set your new password.');
          break;
        case 'general':
          localStorage.removeItem('tempToken');
          localStorage.setItem('userToken', tempToken);
          setTimeout(() => {
            navigate('/dashboard');
          }, 500);
          break;
        default:
          throw new Error('Unexpected OTP purpose');
      }

      setAlertSeverity('success');
      setAlertMessage(response?.data?.message || 'OTP verified successfully.' );
      setOpenSnackbar(true);
    } catch (error: any) {
      const backendMsg = error?.response?.data?.error?.message || error?.response?.data?.message || error?.message;
      setAlertSeverity('error');
      setAlertMessage(backendMsg || 'Invalid OTP');
      setOpenSnackbar(true);
    }
  };
  const handleChangePassword = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (newPassword.trim() === '') {
      setAlertSeverity('error');
      setAlertMessage('New password cannot be empty');
      setOpenSnackbar(true);
      return;
    }



    try {
      const resetData = await authService.changePassword(newPassword);
      console.log('Password change response:', resetData);
      if (
        resetData?.message?.toLowerCase() === 'success' ||
        resetData?.message?.toLowerCase() === 'password changed successfully'
      ) {
        localStorage.removeItem('tempToken');
        setAlertSeverity('success');
        setAlertMessage(resetData?.data?.message);
        setOpenSnackbar(true);
        setStep('login');
      } else {
        throw new Error(resetData?.data?.message || 'Password reset failed.');
      }
    } catch (error: any) {
      setAlertSeverity('error');
      setAlertMessage(error?.response?.data?.error?.message || error?.message || 'Failed to change password');
      setOpenSnackbar(true);
    }

  };

  const passwordChecks = [
    { label: 'At least one uppercase letter', isValid: /[A-Z]/.test(newPassword) },
    { label: 'At least one lowercase letter', isValid: /[a-z]/.test(newPassword) },
    { label: 'At least one digit', isValid: /[0-9]/.test(newPassword) },
    { label: 'At least one special character (!@#$%^&*)', isValid: /[!@#$%^&*]/.test(newPassword) },
    { label: 'Minimum 8 characters', isValid: newPassword.length >= 6 },
  ];
  const isPasswordValid = passwordChecks.every(check => check.isValid);

  const handleResendOtp = async () => {
    try {
      const response = await authService.resendOtp(email);
      setOtp('');
      setOtpError('');
      setAlertSeverity('success');
      setAlertMessage(response.data?.message || 'OTP resent successfully.');
      setOpenSnackbar(true);
      startResendCountdown();
    } catch (error: any) {
      const backendMsg = error?.response?.data?.error?.message || error?.response?.data?.message || error?.message;
      setAlertSeverity('error');
      setAlertMessage(backendMsg || 'Failed to resend OTP.');
      setOpenSnackbar(true);
    }
  };

  return (
    <SplitCardLayout>
      {step === 'login' ? (
        <form
          onSubmit={handleLoginSubmit}
          className="bg-white p-10 rounded-xl shadow-2xl w-full max-w-[400px] flex flex-col items-center"
          autoComplete="on"
        >
          <AuthHeader subtext="Sign in to your account to continue" />

          <div className="relative mb-1 w-full">
            <label htmlFor="email" className="block mb-1 text-sm text-gray-700">Email address</label>
            <span className="absolute left-3 top-[31px] text-gray-500"><MailIcon sx={{ fontSize: 18 }} /></span>
            <input
              id="email"
              type="email"
              name="email"
              placeholder="you@example.com"
              value={formData.email}
              onChange={handleChange}
              onBlur={() => {
                setTouched(prev => ({ ...prev, email: true }));
                if (!formData.email.trim()) {
                  setEmailError('Email is required');
                }
              }}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 bg-[#fafafa] text-[15px] focus:outline-none focus:ring-2 focus:ring-[#3E92CC]"
              autoComplete="email"
            />
            {emailError && (
              <p className="text-red-600 text-sm mt-1 ml-1" role="alert">
                {emailError}
              </p>
            )}
          </div>

          <div className="relative mb-5 mt-4 w-full">
            <label htmlFor="password" className="block mb-1 text-sm text-gray-700">Password</label>
            <span className="absolute left-3 top-[31px] text-gray-500"><LockIcon sx={{ fontSize: 18 }} /></span>
            <input
              id="password"
              type={showPassword ? 'text' : 'password'}
              name="password"
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleChange}
              onBlur={() => {
                setTouched(prev => ({ ...prev, password: true }));
                if (!formData.password.trim()) {
                  setPasswordError('Password is required');
                }
              }}
              className="w-full pl-10 pr-10 py-2 rounded-lg border border-gray-300 bg-[#fafafa] text-[15px] focus:outline-none focus:ring-2 focus:ring-[#3E92CC]"
              autoComplete="current-password"
            />
            {passwordError && (
              <p className="text-red-600 text-sm mt-1 ml-1" role="alert">
                {passwordError}
              </p>
            )}
            <span
              onClick={togglePasswordVisibility}
              className="absolute right-3 top-[31px] text-gray-500 cursor-pointer"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') togglePasswordVisibility();
              }}
            >
              {showPassword ? (
                <VisibilityOffIcon sx={{ fontSize: 18 }} />
              ) : (
                <VisibilityIcon sx={{ fontSize: 18 }} />
              )}
            </span>
          </div>

          <button
            type="submit"
            className="w-full py-3 text-white border-none rounded-md cursor-pointer text-[16px] font-semibold shadow-md transition-all duration-300 bg-[#0A2463] hover:bg-[#081c4e] focus:ring-2 focus:ring-[#0A2463]"
          >
            Sign In
          </button>

          <div className="flex justify-end w-full mb-5">
            <Link to="forgot-password" className="text-blue-500 text-sm hover:underline py-5 font-bold">
              Forgot password?
            </Link>
          </div>
        </form>
      ) : step === 'otp' ? (
        <form
          onSubmit={handleOtpSubmit}
          className="bg-white p-10 rounded-xl shadow-2xl w-full max-w-[400px] flex flex-col items-center"
          autoComplete="off"
        >
          <AuthHeader subtext="Enter the OTP sent to your email" />
          <div className="mb-5 mt-4 w-full">
            <p className="block mb-8 text-sm text-gray-700">Enter the OTP sent to {formData.email}</p>
            <CustomOtpInput
              value={otp}
              onChange={(val: string) => {
                setOtp(val);
                if (otpError && val.trim()) setOtpError('');
              }}
              length={6}
              autoFocus
            />

            {otpError && <p className="text-red-600 text-xs mt-1">{otpError}</p>}
          </div>
          <button
            type="submit"
            className={`w-full py-3 text-white border-none rounded-md cursor-pointer text-[16px] font-semibold shadow-md transition-all duration-300 bg-[#0A2463] hover:bg-[#081c4e] focus:ring-2 focus:ring-[#0A2463] }`}
          >
            Verify OTP
          </button>

          <div className="flex justify-between w-full mb-5">
            <button
              type="button"
              onClick={handleResendOtp}
              disabled={isResendDisabled}
              className={`text-sm font-bold py-5 cursor-pointer ${isResendDisabled ? 'text-gray-400' : 'text-blue-500 hover:underline'
                }`}
            >
              {isResendDisabled ? `Resend OTP in ${resendTimer}s` : 'Resend OTP'}
            </button>

          </div>
        </form>
      ) : step === 'changePassword' ? (
        <form
          onSubmit={handleChangePassword}
          className="bg-white p-10 rounded-xl shadow-2xl w-full max-w-[400px] flex flex-col items-center"
          autoComplete="off"
        >

          <AuthHeader subtext="Enter your new password" />

          <div className="mb-4 w-full text-left text-sm text-gray-600">
            <label htmlFor="email" className="font-medium text-gray-800 block mb-1">Email address</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                <MailIcon sx={{ fontSize: 18 }} />
              </span>
              <input
                id="email"
                type="email"
                value={email}
                readOnly
                className="w-full pl-10 py-2 rounded-lg border border-gray-300 bg-[#f0f0f0] text-gray-700  text-[16px] cursor-not-allowed"
              />
            </div>
          </div>
          <div className="mb-5 w-full relative">
            <label htmlFor="newPassword" className="block mb-1 text-sm text-gray-700">New Password</label>
            <div className="relative">
              <span className="absolute left-3 top-5 transform -translate-y-1/2 text-gray-500">
                <LockIcon sx={{ fontSize: 18 }} />
              </span>
              <input
                id="newPassword"
                type={showNewPassword ? "text" : "password"}
                name="newPassword"
                placeholder="Enter your new password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full pl-10 pr-10 py-2 rounded-lg border border-gray-300 bg-[#fafafa] text-[16px] focus:outline-none focus:ring-2 focus:ring-[#3E92CC]"
                minLength={6}
              />

              {showNewPassword ? (
                <VisibilityOffIcon
                  className="absolute right-3 top-5 transform -translate-y-1/2 text-gray-500 cursor-pointer"
                  onClick={() => setShowNewPassword(false)}
                  sx={{ fontSize: 20 }}
                />
              ) : (
                <VisibilityIcon
                  className="absolute right-3 top-5 transform -translate-y-1/2 text-gray-500 cursor-pointer"
                  onClick={() => setShowNewPassword(true)}
                  sx={{ fontSize: 20 }}
                />
              )}
            </div>
          </div>
          <ul className="text-xs text-left text-black mb-4 w-full pl-5 list-disc space-y-1">
            {passwordChecks
              .filter(({ isValid }) => !isValid)
              .map(({ label }) => (
                <li key={label}>{label}</li>
              ))}
          </ul>

          <button
            type="submit"
            disabled={!isPasswordValid}
            className={`w-full py-3 text-white rounded-md text-[16px] font-semibold shadow-md transition-all duration-300 cursor-pointer bg-[#0A2463] hover:bg-[#081c4e] }`}
          >
            Change Password
          </button>
        </form>
      ) : null
      }
      <CustomSnackbar
        open={openSnackbar}
        message={alertMessage}
        severity={alertSeverity}
        onClose={handleSnackbarClose}
      />
    </SplitCardLayout>
  );
};

export default Login;

