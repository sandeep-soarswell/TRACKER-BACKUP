package com.soarswell.tracker.serviceimpl;

import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.service.EmailService;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.MessageKeys;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpStatus;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private MessageSource messageSource;

    @Value(Constants.FROM_MAIL)
    private String fromEmail;

    public void sendWelcomeEmail(String toEmail, String firstName, String password) {
        try {
            String subject = messageSource.getMessage(MessageKeys.MAIL_SUBJECT_REGISTRATION, null,
                    LocaleContextHolder.getLocale());
            String template = messageSource.getMessage(MessageKeys.MAIL_TEMPLATE_REGISTRATION, null,
                    LocaleContextHolder.getLocale());

            String content = template
                    .replace(Constants.NAME_MAIL, firstName)
                    .replace(Constants.EMAIL_MAIL_IMPL, toEmail)
                    .replace(Constants.PASSWORD_MAIL, password);

            CompletableFuture.runAsync(() -> sendEmail(toEmail, subject, content));
        } catch (Exception e) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(MessageKeys.ERROR_EMAIL_SEND_FAILED),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void sendUserDetailsUpdatedEmail(String toEmail, String firstName) {
        try {
            String subject = messageSource.getMessage(MessageKeys.MAIL_SUBJECT_USER_UPDATED, null,
                    LocaleContextHolder.getLocale());
            String template = messageSource.getMessage(MessageKeys.MAIL_TEMPLATE_USER_UPDATED, null,
                    LocaleContextHolder.getLocale());

            String content = template
                    .replace(Constants.NAME_MAIL, firstName)
                    .replace(Constants.EMAIL_MAIL_IMPL, toEmail);

            CompletableFuture.runAsync(() -> sendEmail(toEmail, subject, content));
        } catch (Exception e) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(MessageKeys.ERROR_EMAIL_SEND_FAILED),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void sendOtpEmail(String toEmail, String otp, String expiry, String subjectKey) {
        try {
            String subject = messageSource.getMessage(subjectKey, null, Locale.getDefault());
            String template = messageSource.getMessage(MessageKeys.MAIL_TEMPLATE_OTP, null, Locale.getDefault());

            String formattedText = template
                    .replace(Constants.OTP_MAIL, otp)
                    .replace(Constants.EXPIRY_MAIL, expiry);

            CompletableFuture.runAsync(() -> sendEmail(toEmail, subject, formattedText));
        } catch (Exception e) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(MessageKeys.ERROR_EMAIL_SEND_FAILED),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void sendCompanyCreatedEmail(String toEmail, String companyName, String password) {
        try {
            String subject = messageSource.getMessage(MessageKeys.MAIL_SUBJECT_REGISTRATION, null,
                    LocaleContextHolder.getLocale());
            String template = messageSource.getMessage(MessageKeys.MAIL_TEMPLATE_COMPANY_CREATED, null,
                    LocaleContextHolder.getLocale());

            String content = template
                    .replace(Constants.COMPANY_MAIL_IMPL, companyName)
                    .replace(Constants.EMAIL_MAIL_IMPL, toEmail)
                    .replace(Constants.PASSWORD_MAIL, password);

            CompletableFuture.runAsync(() -> sendEmail(toEmail, subject, content));
        } catch (Exception e) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(MessageKeys.ERROR_EMAIL_SEND_FAILED),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void sendPasswordChangedEmail(String toEmail) {
        try {
            String subject = messageSource.getMessage(MessageKeys.MAIL_SUBJECT_PASSWORD_CHANGED, null,
                    LocaleContextHolder.getLocale());
            String template = messageSource.getMessage(MessageKeys.MAIL_TEMPLATE_PASSWORD_CHANGED, null,
                    LocaleContextHolder.getLocale());

            CompletableFuture.runAsync(() -> sendEmail(toEmail, subject, template));
        } catch (Exception e) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(MessageKeys.ERROR_EMAIL_SEND_FAILED),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void sendEventReminderEmail(String toEmail, String eventName, String eventDate, String eventTime, String eventDescription) {
        try {
            Locale locale = LocaleContextHolder.getLocale();
            String subjectTemplate = messageSource.getMessage("mail.subject.event.reminder", null, locale);
            String template = messageSource.getMessage("mail.template.event.reminder", null, locale);
            String subject = subjectTemplate.replace("{eventName}", eventName);
            String content = template
                    .replace("{eventName}", eventName)
                    .replace("{eventDate}", eventDate)
                    .replace("{eventTime}", eventTime)
                    .replace("{eventDescription}", eventDescription != null ? eventDescription : "");

            CompletableFuture.runAsync(() -> sendEmail(toEmail, subject, content));
        } catch (Exception e) {
            log.error("Error preparing event reminder email for {}: {}", toEmail, e.getMessage());
        }
    }

    public void sendJobDeadlineEmail(String toEmail, String jobTitle, String deadline) {
        try {
            Locale locale = LocaleContextHolder.getLocale();
            String subjectTemplate = messageSource.getMessage("mail.subject.job.deadline", null, locale);
            String template = messageSource.getMessage("mail.template.job.deadline", null, locale);
            String subject = subjectTemplate.replace("{jobTitle}", jobTitle);
            String content = template
                    .replace("{jobTitle}", jobTitle)
                    .replace("{deadline}", deadline);

            CompletableFuture.runAsync(() -> sendEmail(toEmail, subject, content));
        } catch (Exception e) {
            log.error("Error preparing job deadline email for {}: {}", toEmail, e.getMessage());
        }
    }

    public void sendEmail(String toEmail, String subject, String content) {
        try {
            if (subject == null || subject.trim().isEmpty()) {
                subject = messageSource.getMessage(MessageKeys.MAIL_SUBJECT_DEFAULT, null, LocaleContextHolder.getLocale());
            }

            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, Constants.ENCODING_MAIL);

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject(subject);
            helper.setText(content, true);
            mailSender.send(message);
        } catch (Exception e) {
            log.error("Failed to send email to {}: {}", toEmail, e.getMessage(), e);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(MessageKeys.ERROR_EMAIL_SEND_FAILED),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void senduserAssigedtocanduidateEmail(String toEmail, String firstName, String lastName, String candidateName) {
        try {
            String subject = messageSource.getMessage(MessageKeys.MAIL_SUBJECT_USER_ASSIGNED_TO_CANDIDATE, null,
                    LocaleContextHolder.getLocale());
            String template = messageSource.getMessage(MessageKeys.MAIL_TEMPLATE_USER_ASSIGNED_TO_CANDIDATE, null,
                    LocaleContextHolder.getLocale());

            String content = template
                    .replace(Constants.FIRST_NAME_MAIL, firstName != null ? firstName : "")
                    .replace(Constants.LAST_NAME_MAIL, lastName != null ? lastName : "")
                    .replace(Constants.CANDIDATE_NAME_MAIL, candidateName != null ? candidateName : "");

            CompletableFuture.runAsync(() -> sendEmail(toEmail, subject, content));

        } catch (Exception e) {
            log.error("Failed to prepare user assigned to candidate email for {}: {}", toEmail, e.getMessage(), e);
        }
    }
}