package com.soarswell.tracker.service;

import org.springframework.http.ResponseEntity;

public interface ScoringService {

    void addScore(String userId, String candidateId, int points, String eventType);

    ResponseEntity<?> getUserScoreSummary(String userId);
    
    ResponseEntity<?> getUserScoreDetails(String userId);
    
    ResponseEntity<?> clearUserScores(String userId);

    void removeScore(String userId, String candidateId, String eventType);
} 