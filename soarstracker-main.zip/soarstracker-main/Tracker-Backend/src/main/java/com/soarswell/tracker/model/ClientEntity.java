package com.soarswell.tracker.model;

import com.soarswell.tracker.persistance.AbstractEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Entity
@Table(name = "client" ,indexes = {
        @Index(name= "idx_client_company_id", columnList = "companyId,id"),
        @Index(name = "idx_company_email", columnList = "companyId, email"),
        @Index(name = "idx_company_client_name", columnList = "companyId, clientName"),
        @Index(name = "idx_company_contact_number", columnList = "companyId, contactPersonNumber"),
        @Index(name = "idx_company_status", columnList = "companyId, status")
})
public class ClientEntity extends AbstractEntity{

    @Column(name = "email", nullable = false)
    private String email;
    private String clientName;
    private String contactPersonName;
    @Column(nullable = false)
    private String status;
    private String website;
    private String address;
    @Column(name = "contact_person_number",columnDefinition = "varchar(15)", nullable = false)
    private String contactPersonNumber;
    private String companyId;
    private String country;
    private String state;
    private String zipCode;
    private Integer coolingPeriod;

}