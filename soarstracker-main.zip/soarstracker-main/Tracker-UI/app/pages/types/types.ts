export type Candidate = {
  acceptedPackage: string | null;
  createdBy: any;
  id: string;
  fullName: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  userId: string ;
  userName: string | null;
  dateOfBirth: string;
  gender: string;
  email: string;
  phoneNumber: string; 
  address: string;
  skills: string;
  languagesKnown: string;
  alternateEmail: string;
  alternatePhoneNumber: string;
  availabilityOfJoining: string;
  experience: string;
  noticePeriod: string; 
  currentSalary: string;
  expectedSalary: string;
  recruiterId: number;
  candidateRole: string;
  resume: string;
  status: String; 
  candidatureStatus: CandidateStatus; 
  createdAt?: string;
  updatedAt?: string;
  clientName: string;
  jobId: string;
  jobTitle: string;
  offersInHand?: boolean;
  numberOfOffers?: string;
  aiSummary?: string;
  companyRating?: string;
  collegeRating?: string;
  experienceRating?: string;
  skillsRating?: string;
};
export interface FormValues {
   id: string;
   firstName: string;
   middleName: string;
   lastName: string;
   dateOfBirth: string;
   gender: string;
   email: string;
   phoneNumber: string;
   alternateEmail: string;
   alternatePhoneNumber: string;
   address: string;
   skills: string[];
   experience: string;
   noticePeriod: string;
   currentSalary: string;
   expectedSalary: string;
   availabilityOfJoining: string;
   resume: string;
   candidateRole: string;
   status:string;
   offersInHand: boolean;
   numberOfOffers: string;
 }
  export type CandidateStatus = string; 

  export type Client = {
  data: any;
  id: string;
  clientName: string;
  email: string;
  contactPersonNumber: string;
  contactPersonName: string;
  website: string;
  address: string;
  status: string;
  country: string;
  state: string;
  zipCode: string;
  coolingPeriod: string;
}

export type Comment = {
  id: string;
  candidateId: string;
  text: string;
  createdBy: string;
  content: string;
  createDate: string;
}
export type CommentFormData = {
  text: string;
}

export type CompanyType = {
  id: string;
  companyName: string;
  emailId: string;
  companyAddress: string;
  companyRegNo: string;
  mobileNo?: string;
  alternateNo?: string;
  status: string;
  personalMailId?: string;
  imageFile?: string | null;
};

export type Employee = {
  id?: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  email: string;
  countryCode: string;
  phoneNumber: string;
  role: string | string[];
  status: 'ACTIVE' | 'INACTIVE';
}

export type Job = {
  id?: number | string;
  clientName: string;
  jobId: string;
  title: string;
  description: string;
  location: string;
  skills: string[];
  experience: string;
  salary: string;
  openings: number;
  contactPersonName: string;
  contactPersonEmail: string;
  contactPersonPhone: string;
  status: string;
  deadline: string;
  candidates_required: number;
  recruiters_assigned: string[];
  clientId?: string;
  createdBy: any;
}

export type CalendarEvent = {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  date: string;
  color: string;
  candidateId: string;
  jobId: string;
  remarks: string;
  description: string;
  type: 'interview' | 'meeting' | 'call' | 'review';
  tooltip?: {
    name?: string;
    email?: string;
    phoneNumber?: string;
    title?: string;
    startTime?: string;
    endTime?: string;
    jobTitle?: string;
    clientName?: string;
    description?: string;
  };
}

export interface TimeSlot {
  hour: number;
  events: CalendarEvent[];
}