package com.soarswell.tracker.util;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.ocr.TesseractOCRConfig;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;

public class DocumentParserUtil {

    public static String parseTextFromUrlWithOcr(URL url) throws IOException, TikaException, SAXException {
        if (url == null) {
            return "";
        }
        try (InputStream stream = url.openStream()) {
            return parseTextFromStreamWithOcr(stream);
        }
    }


    public static String parseTextFromFileWithOcr(Path filePath) throws IOException, TikaException, SAXException {
        if (filePath == null || !Files.exists(filePath)) {
            return "";
        }
        try (InputStream stream = Files.newInputStream(filePath)) {
            return parseTextFromStreamWithOcr(stream);
        }
    }

    private static String parseTextFromStreamWithOcr(InputStream stream) throws IOException, TikaException, SAXException {
        TesseractOCRConfig config = new TesseractOCRConfig();
        AutoDetectParser parser = new AutoDetectParser();
        BodyContentHandler handler = new BodyContentHandler(-1);
        ParseContext context = new ParseContext();
        context.set(TesseractOCRConfig.class, config);
        context.set(AutoDetectParser.class, parser);
        Metadata metadata = new Metadata();

        parser.parse(stream, handler, metadata, context);
        return handler.toString();
    }
}