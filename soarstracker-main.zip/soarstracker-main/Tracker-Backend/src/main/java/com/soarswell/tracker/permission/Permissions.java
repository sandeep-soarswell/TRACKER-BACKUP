package com.soarswell.tracker.permission;
import lombok.Getter;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Getter
public enum Permissions {


    SYSTEM_ADMINISTRATOR		            ("SystemAdministrator"                      , "System Administrator"),
    DATA_ADMINISTRATOR		                ("DateAdministrator"                        , "Data Administrator"),

    DASHBOARD                               ("Dashboard"                                , "Dashboard"),

    EMPLOYEE_WRITE                          ("EmployeeWrite"                            , "Employee-Write"),
    EMPLOYEE_READ                           ("EmployeeRead"                             , "Employee-Read"),
    COMPANY_WRITE                           ("CompanyWrite"                             , "Company-Write"),
    COMPANY_READ                            ("CompanyRead"                              , "Company-Read"),
    COMPANY_CREATE                           ("CompanyCreate"                              , "Company-Create"),
    COMPANY_LIST                           ("CompanyList"                              , "Company-List"),
    PROJECT_WRITE                           ("ProjectWrite"                             , "Project-Write"),
    PROJECT_READ                            ("ProjectRead"                              , "Project-Read"),
    ROLES_WRITE                             ("RolesWrite"                               , "Roles-Write"),
    ROLES_READ                              ("RolesRead"                                , "Roles-Read"),
    ASSIGN_ROLES                            ("AssignRoles"                              , "Assign Roles");

    private final String label;

    private final String shortLabel;

    private Permissions(String label, String shortLabel) {
        this.label = label;
        this.shortLabel = shortLabel;
    }

    public static Permissions parse(String value) {
        for (Permissions val : values()) {
            if (val.getLabel().equalsIgnoreCase(value)) {
                return val;
            }
        }
        return null;
    }

    public static Collection<Permissions> internalPermissions() {
        return Collections.unmodifiableList(List.of(SYSTEM_ADMINISTRATOR, DATA_ADMINISTRATOR));
    }

    public static Collection<Permissions> externalPermissions() {
        return Arrays.stream(values()).filter(p -> !internalPermissions().contains(p)).toList();
    }

}
