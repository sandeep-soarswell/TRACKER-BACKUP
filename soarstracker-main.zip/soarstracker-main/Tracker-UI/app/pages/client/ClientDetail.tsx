import DrawerLayout from "~/components/layout/DrawerLayout";

const ClientDetailsDrawer = ({ onClose, client }: { onClose: () => void; client: any; }) => {
  if (!client) return null;
  const fields = [
    { label: "Client Name", value: client.clientName },
    { label: "Email", value: client.email },
    { label: "Website", value: client.website },
    { label: "Contact Name", value: client.contactPersonName },
    {
      label: "Contact Number",
      value: `${client?.countryCode ?? ''} ${client?.contactPersonNumber ?? ''}`.trim()
    },
    { label: "Address", value: client.address },
    { label: "Country", value: client.country },
    { label: "State", value: client.state },
    { label: "Zip Code", value: client.zipCode },
  ];

  return (
    <DrawerLayout
      onClose={onClose}
      title="Client Details"
    >
      <form className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4">
        {fields.map(({ label, value }) => (
          <div key={label}>
            <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
            <input
              type="text"
              value={typeof value === 'string' || typeof value === 'number' ? String(value) : '—'}
              readOnly
              className="w-full px-3 py-2 rounded-md text-sm !bg-gray-100 cursor-not-allowed focus:outline-none border-0"
              style={{ boxShadow: 'none' }}
            />
          </div>
        ))}
      </form>
    </DrawerLayout>
  );
};

export default ClientDetailsDrawer;
