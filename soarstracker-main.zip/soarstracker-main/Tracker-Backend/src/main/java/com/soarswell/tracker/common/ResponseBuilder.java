package com.soarswell.tracker.common;

import lombok.Builder;
import lombok.NoArgsConstructor;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.soarswell.tracker.util.Constants;

import java.util.Map;
import java.util.stream.Collectors;

@Builder
@NoArgsConstructor
public class ResponseBuilder {
    public <T> ResponseObject<T> createSuccessResponse(T data) {
        return ResponseObject.<T>builder()
                .path(ServletUriComponentsBuilder.fromCurrentRequest().toUriString())
                .message(Constants.SUCCESS)
                .data(data)
                .build();
    }

    public <T> ResponseObject<T> createFailureResponse(ResponseErrorObject error) {
        return ResponseObject.<T>builder()
                .path(ServletUriComponentsBuilder.fromCurrentRequest().toUriString())
                .error(error.getMessage())
                .build();
    }

    public <T> ResponseObject<T> createFailureResponse(Exception e) {
        ResponseErrorObject error = ResponseErrorObject.builder()
                .error(e)
                .build();
        return ResponseObject.<T>builder()
                .path(ServletUriComponentsBuilder.fromCurrentRequest().toUriString())
                .message(e.getMessage())
                .error(error.getMessage())
                .build();
    }

    public <T> ResponseObject<T> createErrorResponse(T exceptions) {
        return ResponseObject.<T>builder()
                .path(ServletUriComponentsBuilder.fromCurrentRequest().toUriString())
                .message(Constants.ERROR)
                .error(exceptions)
                .build();
    }
}