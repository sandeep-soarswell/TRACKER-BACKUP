package com.soarswell.tracker.springsecurity;

public interface Authorities {

    String IS_AUTHENTICATED = "isAuthenticated()";

    String COMPANY_LIST = "hasRole('SYS_ADMIN') or hasRole('COMPANY_ADMIN')";
    String COMPANY_CREATE = "hasRole('SYS_ADMIN')";
    String COMPANY_WRITE = "hasRole('SYS_ADMIN') or hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";
    String COMPANY_READ = "hasRole('SYS_ADMIN') or hasRole('COMPANY_ADMIN')";

    String USER_WRITE = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') or hasRole('SYS_ADMIN')";
    String USER_READ = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";
    String USER_CREATE = "hasRole('COMPANY_ADMIN') or hasRole('Manager')";
    String USER_LIST = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";
    String USER_DELETE = "hasRole('COMPANY_ADMIN') or hasRole('MANAGER')";
    String FREE_RECRUITERS= "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";
    String USER_JOBS = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";
    String USER_SCORE = "hasRole('COMPANY_ADMIN') or hasRole('Manager')";
    String CLIENT_WRITE = "hasRole('COMPANY_ADMIN') or hasRole('MANAGER') or hasRole('RECRUITER')";
    String CLIENT_READ = "hasRole('COMPANY_ADMIN') or hasRole('MANAGER') or hasRole('RECRUITER')";
    String CLIENT_CREATE = "hasRole('COMPANY_ADMIN') or hasRole('MANAGER') or hasRole('RECRUITER')";
    String CLIENT_LIST = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";
    String CLIENT_DELETE = "hasRole('COMPANY_ADMIN') or hasRole('MANAGER') or hasRole('RECRUITER')";

    String CANDIDATE_CREATE = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String CANDIDATE_LIST = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String CANDIDATE_USER_ASSIGN = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String CANDIDATE_USER_UNASSIGN = "hasRole('COMPANY_ADMIN') or hasRole('MANAGER') ";
    String CANDIDATE_READ = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String CANDIDATE_WRITE = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String CANDIDATE_DELETE = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String USER_CANDIDATES = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";

    String JOB_CREATE = "hasRole('COMPANY_ADMIN')or hasRole('MANAGER')";
    String JOB_LIST = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String JOB_READ = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String JOB_WRITE = "hasRole('COMPANY_ADMIN') or hasRole('MANAGER') ";
    String JOB_DELETE = "hasRole('COMPANY_ADMIN')  or hasRole('MANAGER') ";
    String JOB_CANDIDATE_ASSIGN = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String JOB_USER_ASSIGN= "hasRole('COMPANY_ADMIN') or hasRole('MANAGER') or hasRole('RECRUITER')";
    String JOB_CANDIDATE_UNASSIGN="hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER') ";
    String JOB_USER_UNASSIGN = "hasRole('COMPANY_ADMIN') or hasRole('MANAGER')";
    String USERS_LIST_BYJOBID = "hasRole('COMPANY_ADMIN')  or hasRole('MANAGER') or hasRole('RECRUITER')";
    String JOB_UPLOAD_LIST = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";

    String COMMENTS_CREATE = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";
    String COMMENTS_LIST = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";

    String EVENTS_CREATE = "hasRole('COMPANY_ADMIN') or hasRole('RECRUITER') or hasRole('MANAGER')";
    String CANDIDATE_USER_REASSIGN = "hasRole('COMPANY_ADMIN') or hasRole('MANAGER')";

}