package com.soarswell.tracker.service;

import com.soarswell.tracker.model.payload.*;
import org.springframework.http.ResponseEntity;

public interface AuthService {
    public ResponseEntity<?> authenticate(LoginRequest request);

    public ResponseEntity<?> changePassword(String username, ChangePasswordRequest request);

    public ResponseEntity<?> forgotPassword(ForgotPasswordRequest request);

    public ResponseEntity<?> validateOtp(ValidateOtpRequest request);

    public ResponseEntity<?> resetPassword(ResetPasswordRequest request);

    public ResponseEntity<?> validateToken(String token);

    public ResponseEntity<?> reSendOtp(String username);

    public ResponseEntity<?> logout(String username);
}
