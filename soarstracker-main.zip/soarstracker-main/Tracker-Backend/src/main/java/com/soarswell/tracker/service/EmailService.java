package com.soarswell.tracker.service;

public interface EmailService {

    void sendWelcomeEmail(String toEmail, String firstName, String password);

    void sendUserDetailsUpdatedEmail(String toEmail, String firstName);

    void sendOtpEmail(String toEmail, String otp, String expiry, String subjectKey);

    void sendCompanyCreatedEmail(String toEmail, String companyName, String password);

    void sendPasswordChangedEmail(String toEmail);

    void sendEmail(String toEmail, String subject, String content);
    void sendEventReminderEmail(String toEmail, String eventName, String eventDate, String eventTime, String eventDescription);
    
    void senduserAssigedtocanduidateEmail(String toEmail, String firstName, String lastName, String candidateName);

    void sendJobDeadlineEmail(String toEmail, String jobTitle, String deadline);
}

