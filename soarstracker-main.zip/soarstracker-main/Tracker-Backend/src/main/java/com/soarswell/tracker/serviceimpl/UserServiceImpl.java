package com.soarswell.tracker.serviceimpl;

import com.soarswell.tracker.model.*;
import com.soarswell.tracker.repository.*;
import com.soarswell.tracker.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.model.payload.UserResponse;
import com.soarswell.tracker.model.payload.UserRegisterRequest;
import com.soarswell.tracker.model.payload.UserUpdateRequest;
import com.soarswell.tracker.common.ListResponse;
import com.soarswell.tracker.service.EmailService;
import com.soarswell.tracker.service.UserService;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.common.ResponseBuilder;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.model.payload.JobResponse;
import com.soarswell.tracker.model.payload.CandidateResponse;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.ErrorMessageHandler;

import java.time.Instant;
import java.util.*;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private RequestDetails requestDetails;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private EmailService emailService;
    @Autowired
    private JobRepository jobRepository;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private ClientRepository clientRepository;
    @Autowired
    private CandidateAssignmentRepository candidateAssignmentRepository;
    @Autowired
    private CandidateRepository candidateRepository;

    private List<String> statuses;

    private String getCompanyId() {
        return AuthTokenUtils.extractCompanyId(requestDetails);
    }

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Override
    @Transactional
    public ResponseEntity<?> register(UserRegisterRequest userRegisterRequest) {
        String companyId=getCompanyId();
        Map<String,String> exceptions = new HashMap<>();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        if (userRepository.existsByEmail(userRegisterRequest.getEmail())) {
            exceptions.put(Constants.ERROR_EMAIL,ErrorMessageHandler.getMessage(ErrorMessageKey.USER_EMAIL_EXISTS.getStatusCode()));
        }

        if (userRepository.existsByPhoneNumber(userRegisterRequest.getPhoneNumber())) {
            exceptions.put(Constants.ERROR_PHONE,ErrorMessageHandler.getMessage(ErrorMessageKey.USER_PHONE_EXISTS.getStatusCode()));
        }
        if (!exceptions.isEmpty()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResponseBuilder.builder().build().createErrorResponse(exceptions));
        }
        String companyName=companyRepository.findById(companyId).map(Company::getCompanyName)
                .orElseThrow(()->new TrackerException(ErrorMessageHandler.getMessage(
                        ErrorMessageKey.UNABLE_GET_COMPANY.getStatusCode()),
                        HttpStatus.NOT_FOUND));
        User user=objectMapper.convertValue(userRegisterRequest,User.class);
        user.setId(ResourceIdUtils.generateUserResourceId(user.getRole(), user.getEmail()));
        user.setStatus(Status.CREATED.getLongLabel());
        user.setCompanyName(companyName);
        user.setCompanyId(companyId);
        user.setPassword(passwordEncoder.encode(Constants.DEFAULT_PASSWORD));
        user.setCreateDate(new Date(Instant.now().toEpochMilli()));
        user.setCreatedBy(requestDetails.getUserId());
        userRepository.save(user);
        emailService.sendWelcomeEmail(user.getEmail(), user.getFirstName(), Constants.DEFAULT_PASSWORD);
        ResponseObject<String> response = ResponseBuilder.builder().build()
                .createSuccessResponse(Constants.USER_REGISTERED);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<?> getUsers(int page, int size, String sortByField, String order, String keyword, String role, String filter) throws TrackerException {
        String companyId=getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        if (page < 0 || size <= 0) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_PAGINATION_PARAMS.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        Sort.Direction sortDirection = "asc".equalsIgnoreCase(order) ? Sort.Direction.ASC : Sort.Direction.DESC;
        PageRequest pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortByField));
        if (filter != null && !filter.trim().isEmpty()) {
            if (!Constants.FILTER_STAR.equalsIgnoreCase(filter) && !Constants.FILTER_ACTIVE.equalsIgnoreCase(filter) && !Constants.FILTER_INACTIVE.equalsIgnoreCase(filter) && !Constants.FILTER_CREATED.equalsIgnoreCase(filter)) {
                logger.error("Invalid filter value: {}", filter);
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_FILTER_VALUE.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            if (Constants.FILTER_INACTIVE.equalsIgnoreCase(filter)) {
                statuses = List.of(Status.INACTIVE.getLongLabel());
            }else if(Constants.FILTER_CREATED.equalsIgnoreCase(filter)){
                statuses = List.of(Status.CREATED.getLongLabel());
            } else if(Constants.FILTER_ACTIVE.equalsIgnoreCase(filter)){
                statuses = List.of(Status.ACTIVE.getLongLabel());
            }else {
                statuses= List.of(Status.ACTIVE.getLongLabel(), Status.CREATED.getLongLabel());
            }
        }

        Page<User> userPage;
        boolean hasKeyword = keyword != null && !keyword.trim().isEmpty();

        if (role.equals("*")) {
            userPage = hasKeyword
                    ? userRepository.searchAllFieldsByCompanyIdAndStatusIn(companyId, statuses, keyword.trim(), pageable)
                    : userRepository.findByCompanyIdAndStatusIn(companyId, statuses, pageable);
        } else {
            userPage = hasKeyword
                    ? userRepository.searchAllFieldsByCompanyIdAndRoleAndStatusIn(companyId, role, statuses, keyword.trim(), pageable)
                    : userRepository.findByCompanyIdAndRoleAndStatusIn(companyId, role, statuses, pageable);
        }
        long totalEntries = userPage.getTotalElements();
        List<UserResponse> users = userPage.getContent().stream()
                .map(user -> objectMapper.convertValue(user, UserResponse.class))
                .toList();
        ResponseObject<ListResponse<UserResponse>> response = ResponseBuilder.builder().build()
                .createSuccessResponse(new ListResponse<UserResponse>(users,totalEntries,page+1,size));
        return ResponseEntity.ok(response);
    }

    @Override
    public ResponseEntity<?> getUserById(String id) throws TrackerException {
        String companyId=getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        statuses= List.of(Status.ACTIVE.getLongLabel(), Status.CREATED.getLongLabel());
        logger.info("finding user with id {} and companyID{}",id,companyId);
        User user = userRepository.findByIdAndCompanyIdAndStatusIn(id, companyId,statuses)
                .filter(u -> u.getStatus().equalsIgnoreCase(Status.ACTIVE.getLongLabel())
                                    || u.getStatus().equalsIgnoreCase(Status.CREATED.getLongLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));
        ResponseObject<UserResponse> response = ResponseBuilder.builder().build().createSuccessResponse(
                objectMapper.convertValue(user,UserResponse.class)
        );
        return ResponseEntity.ok(response);

    }

    @Override
    @Transactional
    public ResponseEntity<?> deleteUser(String id) throws TrackerException {
        String companyId=getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        statuses= List.of(Status.ACTIVE.getLongLabel(), Status.CREATED.getLongLabel());
        User user = userRepository.findByIdAndCompanyIdAndStatusIn(id, companyId,statuses)
                .filter(u -> u.getStatus().equalsIgnoreCase(Status.ACTIVE.getLongLabel())
                                || u.getStatus().equalsIgnoreCase(Status.CREATED.getLongLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));
        user.setStatus(Status.INACTIVE.getLongLabel());
        userRepository.save(user);
        ResponseObject<String> response = ResponseBuilder.builder().build()
                .createSuccessResponse(Constants.USER_DELETED);
        return ResponseEntity.ok(response);
    }

    @Override
    @Transactional
    public ResponseEntity<?> updateUser(String id, UserUpdateRequest updatedUser) {
        String companyId=getCompanyId();
        boolean check=!companyRepository.existsById(companyId) && !requestDetails.getRoles().getFirst().equalsIgnoreCase(Roles.SUPER_ADMIN.getShortLabel());
        if (check) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        statuses= List.of(Status.ACTIVE.getLongLabel(), Status.CREATED.getLongLabel());
        User existingUser = userRepository.findByIdAndStatusIn(id,statuses)
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));

        boolean flag= PatchHelper.updateValue(existingUser,updatedUser);

        if(flag) {
            existingUser.setUpdateDate(new Date(Instant.now().toEpochMilli()));
            existingUser.setUpdatedBy(requestDetails.getUserId());
            userRepository.save(existingUser);
            emailService.sendUserDetailsUpdatedEmail(existingUser.getEmail(), existingUser.getFirstName());
            ResponseObject<String> response = ResponseBuilder.builder().build()
                    .createSuccessResponse(Constants.USER_UPDATED);
            return ResponseEntity.ok(response);
        }
        ResponseObject<String> response = ResponseBuilder.builder().build()
                .createSuccessResponse(Constants.NO_CHANGES_DETECTED);
        return ResponseEntity.ok(response);
    }

    @Override
    public ResponseEntity<?> updateInactiveUserStatus(String userId, String status) throws TrackerException {
        String companyId=getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        statuses= List.of(Status.INACTIVE.getLongLabel());
        User existingUser = userRepository.findByIdAndCompanyIdAndStatusIn(userId, companyId,statuses)
                .filter(u -> u.getStatus().equalsIgnoreCase(Status.INACTIVE.getLongLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));

            existingUser.setStatus(status);
            existingUser.setUpdateDate(new Date(Instant.now().toEpochMilli()));
            existingUser.setUpdatedBy(requestDetails.getUserId());
            userRepository.save(existingUser);
            ResponseObject<String> response = ResponseBuilder.builder().build()
                    .createSuccessResponse(Constants.USER_STATUS_UPDATED);
            return ResponseEntity.ok(response);

    }

    @Override
    public ResponseEntity<?> getUserJobs(String userId,String clientId, int page, int size) throws TrackerException {
        String companyId=getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        User user = userRepository.findByIdAndCompanyId(userId, companyId)
                .filter(u -> u.getStatus().equalsIgnoreCase(Status.ACTIVE.getLongLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));

        List<JobResponse> jobs = user.getJobs()
                .stream()
                .distinct()
                .filter(j -> clientId == null || clientId.trim().isEmpty() || j.getClientId().equals(clientId))
                .map(j->{
                    JobResponse jobResponse= objectMapper.convertValue(j, JobResponse.class);
                    jobResponse.setClientName(clientRepository.findById(j.getClientId()).map(ClientEntity::getClientName).orElse("Unknown Client"));
                    return jobResponse;
                })
                .toList();

        if(jobs.isEmpty()){
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_JOBS_FOUND_FOR_USER.getStatusCode()),HttpStatus.NOT_FOUND);
        }

        int total = jobs.size();
        int fromIndex = Math.min((page) * size, total);
        int toIndex = Math.min(fromIndex + size, total);

        ListResponse<JobResponse> paginatedJobs = new ListResponse<>(jobs.subList(fromIndex, toIndex), total, page+1, size);
        ResponseObject<ListResponse<JobResponse>> response = ResponseBuilder.builder().build().createSuccessResponse(paginatedJobs);
        return ResponseEntity.ok(response);

    }

    @Override
    public ResponseEntity<?> getFreeUsers(int page, int size, String jobId,String role) throws TrackerException {
        String companyId=getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        // Pagination validation
        if (page < 0 || size <= 0) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_PAGINATION_PARAMS.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        Job job = jobRepository.findById(jobId)
                .filter(j->j.getStatus().equalsIgnoreCase(Status.OPEN.getShortLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND));
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Order.desc("createDate")));
        List<UserResponse> userPage;
        if (role.equals("*")) {
            userPage = userRepository.findByStatusAndCompanyId(Status.ACTIVE.getLongLabel(), companyId,pageable).stream()
                    .filter(user->user.getJobs().isEmpty() || !(user.getJobs().contains(job)))
                    .map(user->objectMapper.convertValue(user,UserResponse.class))
                    .toList();
        }
        else {
            userPage = userRepository.findByRoleAndStatusAndCompanyId(role,Status.ACTIVE.getLongLabel(), companyId, pageable).stream()
                    .filter(user->user.getJobs().isEmpty() || !(user.getJobs().contains(job)))
                    .map(user->objectMapper.convertValue(user,UserResponse.class))
                    .toList();
        }

        ListResponse<UserResponse> paginatedUsers=new ListResponse<>(userPage,userPage.size(), page+1, size);
        ResponseObject<ListResponse<UserResponse>> response = ResponseBuilder.builder().build()
                .createSuccessResponse(paginatedUsers);
        return ResponseEntity.ok(response);
    }

    @Override
    public ResponseEntity<?> getUserAssignedCandidates(String userId, int page, int size,String filter,String statusFilter)  throws TrackerException {
        String companyId = getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        // Pagination validation
        if (page < 0 || size <= 0) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_PAGINATION_PARAMS.getStatusCode()), HttpStatus.FORBIDDEN);
        }
        User user = userRepository.findByIdAndCompanyId(userId, companyId)
                .filter(u -> !u.getStatus().equalsIgnoreCase(Status.INACTIVE.getShortLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));

        List<Candidate>candidateResponses=user.getAssignments().stream()
                                                    .filter(assignment -> assignment.getId()!=null && assignment.getUser()!=null && assignment.getCandidate()!=null)
                                                    .map(CandidateUserAssignment::getCandidate)
                                                    .toList();
        List<CandidateResponse> filteredCandidateResponses=candidateResponses.stream()
                .filter(candidate->filter==null
                                                    ||filter.trim().isEmpty()
                                                    ||candidate.getStatus().equalsIgnoreCase(filter))

                .filter(candidateResponse ->statusFilter==null
                                                            || statusFilter.trim().isEmpty()
                                                            || statusFilter.equals("*")
                                                            || candidateResponse.getCandidatureStatus().equalsIgnoreCase(statusFilter))
                .map(candidateResponse-> {
                    if (candidateResponse.getJobAssignment() != null || candidateResponse.getAssignment() != null) {
                        CandidateResponse candidate = objectMapper.convertValue(candidateResponse, CandidateResponse.class);
                        if (candidateResponse.getJobAssignment() != null) {
                            String clientName = clientRepository.findById(candidateResponse.getJobAssignment().getJob().getClientId())
                                    .map(ClientEntity::getClientName)
                                    .orElse("Unknown Client");
                            candidate.setJobTitle(candidateResponse.getJobAssignment().getJob().getTitle());
                            candidate.setClientName(clientName);
                            candidate.setJobId(candidateResponse.getJobAssignment().getJob().getJobId());
                        }
                        if (candidateResponse.getAssignment() != null) {
                            candidate.setUserId(candidateResponse.getAssignment().getUser().getId());
                            String fullName = CandidateUtils.safeJoin(candidateResponse.getAssignment().getUser().getFirstName(),
                                    candidateResponse.getAssignment().getUser().getMiddleName(),
                                    candidateResponse.getAssignment().getUser().getLastName());
                            candidate.setUserName(fullName);
                        }
                        return candidate;
                    }
                    return objectMapper.convertValue(candidateResponse, CandidateResponse.class);
                })
                .toList();

        int total = filteredCandidateResponses.size();
        int fromIndex = Math.min((page) * size, total);
        int toIndex = Math.min(fromIndex + size, total);
        ListResponse<CandidateResponse> paginatedCandidates = new ListResponse<>(filteredCandidateResponses.subList(fromIndex, toIndex), total, page+1, size);

        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(paginatedCandidates));

    }

    @Override
    public ResponseEntity<?> getUserCreatedCandidates(String userId, int page, int size,String filter,String statusFilter) throws TrackerException {
        String companyId = getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),
                    HttpStatus.FORBIDDEN);
        }
        // Pagination validation
        if (page < 0 || size <= 0) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_PAGINATION_PARAMS.getStatusCode()), HttpStatus.FORBIDDEN);
        }
        User user = userRepository.findByIdAndCompanyId(userId, companyId)
                .filter(u -> !u.getStatus().equalsIgnoreCase(Status.INACTIVE.getShortLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));

        String currentUserMail=requestDetails.getUserId();
        List<CandidateResponse>currentLoggedInUserCreatedRecords=candidateRepository.findAllByCompanyId(companyId)
                .stream()
                .filter(candidate -> Objects.nonNull(candidate.getCreatedBy()))
                .filter(candidate -> candidate.getStatus().equalsIgnoreCase(Status.ACTIVE.getShortLabel())
                        && candidate.getCreatedBy().equals(currentUserMail)
                        && candidate.getAssignment()==null)
                .map(candidateResponse->{
                    if(candidateResponse.getJobAssignment()!=null){
                        CandidateResponse candidate = objectMapper.convertValue(candidateResponse,CandidateResponse.class);
                        if( candidateResponse.getJobAssignment() != null) {
                            String  clientName= clientRepository.findById(candidateResponse.getJobAssignment().getJob().getClientId())
                                    .map(ClientEntity::getClientName)
                                    .orElse("Unknown Client");
                            candidate.setJobTitle(candidateResponse.getJobAssignment().getJob().getTitle());
                            candidate.setClientName(clientName);
                            candidate.setJobId(candidateResponse.getJobAssignment().getJob().getJobId());
                        }
                        if( candidateResponse.getAssignment() != null) {
                            candidate.setUserId(candidateResponse.getAssignment().getUser().getId());
                            String fullName= CandidateUtils.safeJoin(candidateResponse.getAssignment().getUser().getFirstName(),
                                    candidateResponse.getAssignment().getUser().getMiddleName(),
                                    candidateResponse.getAssignment().getUser().getLastName());
                            candidate.setUserName(fullName);
                        }
                        return candidate;
                    }
                    return objectMapper.convertValue(candidateResponse, CandidateResponse.class);

                })
                .toList();

        int total = currentLoggedInUserCreatedRecords.size();
        int fromIndex = Math.min((page) * size, total);
        int toIndex = Math.min(fromIndex + size, total);
        ListResponse<CandidateResponse> paginatedCandidates = new ListResponse<>(currentLoggedInUserCreatedRecords.subList(fromIndex, toIndex), total, page+1, size);

        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(paginatedCandidates));

    }
}