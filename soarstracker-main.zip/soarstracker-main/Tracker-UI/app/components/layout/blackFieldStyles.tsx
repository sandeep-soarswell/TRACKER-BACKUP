import React from 'react';

import type { SxProps } from '@mui/system';

export const blackFieldStyles: SxProps = {
  '& .MuiInputLabel-root': {
    color: 'black',

  },
  '& .MuiInputLabel-root.Mui-focused': {
    color: 'black',
  },
  '& .MuiInputLabel-root.Mui-error': {
    color: 'black',
  },
  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderColor: 'black',
    },
    '&:hover fieldset': {
      borderColor: 'black',
    },
    '&.Mui-focused fieldset': {
      borderColor: 'black',
    },
    '&.Mui-error fieldset': {
      borderColor: 'black',
    },
    '& input': {
      color: 'black',
    },
  },
  '& .MuiOutlinedInput-input': {
    color: 'black',
  },
};

export const RequiredLabel: React.FC<{ label: string }> = ({ label }) => (
  <span style={{ color: 'black' }}>
    {label} <span style={{ color: 'red' }}>*</span>
  </span>
);

