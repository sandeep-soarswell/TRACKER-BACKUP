package com.soarswell.tracker.config;

import com.soarswell.tracker.util.Constants;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.utils.SpringDocUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.MultipartFile;

@Configuration
public class SwaggerConfig {

    public static final String COMMENT_TAG = "Comments" ;
    public static final String CANDIDATE_TAG = "Candidates";
    public static final String CANDIDATE_JOB_TAG = "Candidate Jobs";
    public static final String ASSIGNMENT_TAG = "Assignments";

    static{
        SpringDocUtils.getConfig().addFileType(MultipartFile.class);
    }

    @Bean
    public OpenAPI trackerOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title(Constants.TRACKER_API_TITLE)
                        .description(Constants.TRACKER_API_DESCRIPTION)
                        .version(Constants.TRACKER_API_VERSION))
                .components(new Components()
                        .addSecuritySchemes(Constants.TRACKER_SECURITY_SCHEME,
                                new SecurityScheme()
                                        .type(SecurityScheme.Type.HTTP)
                                        .scheme("Bearer")
                                        .bearerFormat("JWT")))
                .externalDocs(new ExternalDocumentation()
                        .description(Constants.TRACKER_EXTERNAL_DOCS_DESC)
                        .url(Constants.TRACKER_EXTERNAL_DOCS_URL));
    }
}