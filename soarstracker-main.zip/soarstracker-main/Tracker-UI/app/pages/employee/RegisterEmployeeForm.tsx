import React, { useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import DrawerLayout from '~/components/layout/DrawerLayout';
import Button from '~/components/ui/Button';
import userService from '~/services/employee/employee.service';
import type { Employee } from '~/pages/types/types';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import { isValidPhoneNumber } from 'libphonenumber-js';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import getChangedFields from '~/components/util/update-util';
import { jwtDecode } from 'jwt-decode';

interface EmployeeFormProps {
  employee?: Employee;
  onClose: () => void;
  onSuccess: (message?: string) => void;
}

interface FormValues {
  firstName: string;
  middleName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  role: string;
  status?: 'Active' | 'Inactive';
}
const nameSchema = Yup.string()
  .trim()
  .min(3, 'Name must be at least 3 characters')
  .max(50, 'Name must be at most 50 characters')
  .required('Name is required')
  .matches(/^([A-Za-z]+(\s[A-Za-z]+)*)?$/, 'Letters only');

const validationSchema = Yup.object({
  firstName: nameSchema,
  middleName: nameSchema.notRequired(),
  lastName: nameSchema,
  email: Yup.string()
    .trim()
    .required('Email is required')
    .email('Enter a valid email')
    .matches(
      /^[a-z][a-z0-9._%+-]*@[a-z0-9.-]+\.[a-z]{2,}$/,
      'Email must be lowercase and start with a letter (e.g., john@example.com)'
    ),
  phoneNumber: Yup.string()
    .required('Phone number is required')
    .test('is-valid-phone', 'Invalid phone number for selected country', function (value) {
      if (!value) return false;
      return isValidPhoneNumber(value);
    }),
  role: Yup.string()
    .required('Role is required')
    .oneOf(['COMPANY_ADMIN', 'MANAGER', 'RECRUITER'], 'Invalid role'),
});

const EmployeeForm: React.FC<EmployeeFormProps> = ({ employee, onClose, onSuccess }) => {
  const isEditMode = Boolean(employee?.id);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");

  const token = localStorage.getItem('userToken');
  const decodedToken = jwtDecode<any>(token || '');
  const userRole = decodedToken?.roles[0] || '';

  const isCompanyAdmin = userRole === 'COMPANY_ADMIN', isCompanyAdminEdit = employee?.role === 'COMPANY_ADMIN';

  const showSnackbar = (message: string ) => {
    setSnackbarMessage(message);
    setSnackbarSeverity("success");
    setSnackbarOpen(true);
  };

  const formik = useFormik<FormValues>({
    initialValues: {
      firstName: employee?.firstName || '',
      middleName: employee?.middleName || '',
      lastName: employee?.lastName || '',
      email: employee?.email || '',
      phoneNumber: employee?.phoneNumber || '',
      role: Array.isArray(employee?.role) ? employee?.role[0] || '' : employee?.role || '',
      status: employee?.status === 'INACTIVE' ? 'Inactive' : 'Active',
    },
    validationSchema,
    validateOnChange: true,
    validateOnBlur: true,
    onSubmit: async (values) => {
      try {
        const payload: any = {
          firstName: values.firstName?values.firstName.trim():null,
          middleName: values.middleName?values.middleName?.trim():null,
          lastName: values.lastName?values.lastName.trim():null,
          email: values.email?values.email.trim():null,
          phoneNumber: values.phoneNumber?values.phoneNumber.trim():null,
          role: values.role?values.role.trim():null,
          status: values.status?values.status.trim():null,
        };
        if (isEditMode) {
          payload.id = employee?.id;
        }
        const finalData = Object.fromEntries(
          Object.entries(payload).filter(([_, value]) => value !== undefined)
        );
        let response;
        if (isEditMode && employee?.id) {
          const changedFields=getChangedFields(employee,finalData)
          response = await userService.update(employee.id, changedFields);
        } else {
          response = await userService.register(finalData);
        }
        let successMessage = response?.data;
        if (successMessage === "User Registered Successfully!") {
          successMessage = "Employee Registered Successfully!";
        } else if (successMessage === "User Updated Successfully!") {
          successMessage = "Employee Updated Successfully!";
        } else if (!successMessage) {
          successMessage = isEditMode ? "Employee updated successfully!" : "Employee registered successfully!";
        }
        showSnackbar(successMessage);
        onSuccess(successMessage);
      } catch (error: any) {
        const errorResponse = error?.response?.data;
        let hasFieldError = false;

        if (errorResponse?.error) {
          const errorMap: { [key: string]: string } = {
            PHONE: 'phoneNumber',
            EMAIL: 'email',
            FIRSTNAME: 'firstName',
            MIDDLENAME: 'middleName',
            LASTNAME: 'lastName',
            ROLE: 'role',
          };

          Object.keys(errorResponse.error).forEach((backendKey) => {
            const formField = errorMap[backendKey.toUpperCase()];
            if (formField) {
              formik.setFieldError(formField, errorResponse.error[backendKey]);
              hasFieldError = true;
            }
          });
        }

        if (!hasFieldError) {
          showSnackbar(errorResponse?.message || error?.message || 'An unexpected error occurred');
        }
      } finally {
        formik.setSubmitting(false);
      }
    },
  });

  return (
    <>
      <CustomSnackbar
      open={snackbarOpen}
      message={snackbarMessage}
      severity={snackbarSeverity}
      onClose={() => setSnackbarOpen(false)}
      autoHideDuration={4000}
    />
      <DrawerLayout
        title={isEditMode ? 'Edit Employee' : 'Register Employee'}
        onClose={onClose}
        footer={
          <Button
            variant="primary"
            type="button"
            onClick={() => formik.handleSubmit()}
            disabled={!(formik.isValid && formik.dirty && !formik.isSubmitting)}
          >
            {isEditMode ? 'Update' : 'Create'}
          </Button>
        }
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4">
          <div>
            <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
              First Name <span className="text-red-500">*</span>
            </label>
            <input
              id="firstName"
              name="firstName"
              type="text"
              value={formik.values.firstName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.firstName && formik.errors.firstName ? 'border-red-500' : 'border-gray-300'
                }`}
              style={{ height: '40px' }}
            />
            {formik.touched.firstName && formik.errors.firstName && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.firstName}</p>
            )}
          </div>
          <div>
            <label htmlFor="middleName" className="block text-sm font-medium text-gray-700 mb-1">
              Middle Name
            </label>
            <input
              id="middleName"
              name="middleName"
              type="text"
              value={formik.values.middleName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.middleName && formik.errors.middleName ? 'border-red-500' : 'border-gray-300'
                }`}
              style={{ height: '40px' }}
            />
            {formik.touched.middleName && formik.errors.middleName && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.middleName}</p>
            )}
          </div>
          <div>
            <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
              Last Name <span className="text-red-500">*</span>
            </label>
            <input
              id="lastName"
              name="lastName"
              type="text"
              value={formik.values.lastName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.lastName && formik.errors.lastName ? 'border-red-500' : 'border-gray-300'
                }`}
              style={{ height: '40px' }}
            />
            {formik.touched.lastName && formik.errors.lastName && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.lastName}</p>
            )}
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
              Email <span className="text-red-500">*</span>
            </label>
            <input
              id="email"
              name="email"
              type="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled={isEditMode}
              className={`w-full px-3 py-2 rounded-md border text-sm ${isEditMode ? '!bg-gray-200 text-gray-600 cursor-not-allowed' : 'bg-white'
                } ${formik.touched.email && formik.errors.email ? 'border-red-500' : 'border-gray-300'}`}
              style={{ height: '40px' }}
            />
            {formik.touched.email && formik.errors.email && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.email}</p>
            )}
          </div>
          <div>
            <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
              Mobile Number <span className="text-red-500">*</span>
            </label>
            <PhoneInput
              defaultCountry="in"
              value={formik.values.phoneNumber}
              onChange={(value) => {
                formik.setFieldValue('phoneNumber', value);
              }}
              onBlur={() => formik.setFieldTouched('phoneNumber', true)}
              forceDialCode
              inputProps={{
                id: 'phoneNumber',
                name: 'phoneNumber',
                className: `w-full px-3 py-2 rounded-r-md border text-sm bg-white ${formik.touched.phoneNumber && formik.errors.phoneNumber
                  ? 'border-red-500'
                  : 'border-gray-300'
                  }`,
                style: { height: '40px' },
              }}
              style={{
                display: 'flex',
                alignItems: 'center',
              }}
              countrySelectorStyleProps={{
                buttonStyle: {
                  height: '40px',
                  border: formik.touched.phoneNumber && formik.errors.phoneNumber
                    ? '1px solid #ef4444'
                    : '1px solid #d1d5db',
                  borderRadius: '6px 0 0 6px',
                  background: '#fff',
                  padding: '0 8px',
                },
              }}
              inputStyle={{
                borderRadius: '0 6px 6px 0',
                borderLeft: 'none',
              }}
            />
            {formik.touched.phoneNumber && formik.errors.phoneNumber && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.phoneNumber}</p>
            )}
          </div>
          <div>
            <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">
              Role <span className="text-red-500">*</span>
            </label>
            <select
              id="role"
              name="role"
              value={formik.values.role}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled={!isCompanyAdmin|| isCompanyAdminEdit}
              className={`w-full px-3 py-2 rounded-md border text-sm ${!isCompanyAdmin|| isCompanyAdminEdit ? '!bg-gray-200 text-gray-600 cursor-not-allowed' : 'bg-white'
                } ${formik.touched.role && formik.errors.role ? 'border-red-500' : 'border-gray-300'}`}
              style={{ height: '40px' }}
            >
              <option value="">Select role</option>
              <option value="COMPANY_ADMIN">Company Admin</option>
              <option value="MANAGER">Manager</option>
              <option value="RECRUITER">Recruiter</option>
            </select>
            {formik.touched.role && formik.errors.role && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.role}</p>
            )}
          </div>
        </div>
      </DrawerLayout>

    </>
  );
};

export default EmployeeForm;