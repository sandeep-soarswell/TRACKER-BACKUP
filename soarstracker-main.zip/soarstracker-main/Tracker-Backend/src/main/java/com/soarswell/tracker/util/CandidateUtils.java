package com.soarswell.tracker.util;

import com.soarswell.tracker.model.payload.CandidateRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.stream.Collectors;

@Slf4j
public class CandidateUtils {

    public static CandidateRequest mapRowToCandidateRequest(String[] row) {
        CandidateRequest candidateRequest = new CandidateRequest();
        candidateRequest.setFirstName(getStringValue(row,0));
        candidateRequest.setMiddleName(getStringValue(row,1));
        candidateRequest.setLastName(getStringValue(row,2));
        candidateRequest.setDateOfBirth(safeMapDate(getStringValue(row,3)));
        candidateRequest.setEmail(getStringValue(row,4));
        candidateRequest.setPhoneNumber(getStringValue(row,5));
        candidateRequest.setAddress(getStringValue(row,6));
        candidateRequest.setSkills(getStringValue(row,7));
        candidateRequest.setCandidateRole(getStringValue(row,8));
        candidateRequest.setAlternateEmail(getStringValue(row,9));
        candidateRequest.setAlternatePhoneNumber(getStringValue(row,10));
        candidateRequest.setAvailabilityOfJoining(safeMapDate(getStringValue(row,11)));
        candidateRequest.setExperience(getStringValue(row,12));
        candidateRequest.setNoticePeriod(getStringValue(row,13));
        candidateRequest.setCurrentSalary(getStringValue(row,14));
        candidateRequest.setExpectedSalary(getStringValue(row,15));
        candidateRequest.setNumberOfOffers(getStringValue(row,16));
        candidateRequest.setGender(getStringValue(row,17));
        return candidateRequest;
    }

    public static CandidateRequest mapRowToCandidateRequest(Row row) {
        CandidateRequest candidateRequest = new CandidateRequest();
        candidateRequest.setFirstName(getCellStringValue(row.getCell(0)));
        candidateRequest.setMiddleName(getCellStringValue(row.getCell(1)));
        candidateRequest.setLastName(getCellStringValue(row.getCell(2)));
        candidateRequest.setDateOfBirth(safeMapDate(row.getCell(3).toString()));
        candidateRequest.setEmail(getCellStringValue(row.getCell(4)));
        candidateRequest.setPhoneNumber(getCellStringValue(row.getCell(5)));
        candidateRequest.setAddress(getCellStringValue(row.getCell(6)));
        candidateRequest.setSkills(getCellStringValue(row.getCell(7)));
        candidateRequest.setCandidateRole(getCellStringValue(row.getCell(8)));
        candidateRequest.setAlternateEmail(getCellStringValue(row.getCell(9)));
        candidateRequest.setAlternatePhoneNumber(getCellStringValue(row.getCell(10)));
        candidateRequest.setAvailabilityOfJoining(safeMapDate(row.getCell(11).toString()));
        candidateRequest.setExperience(getCellStringValue(row.getCell(12)));
        candidateRequest.setNoticePeriod(getCellStringValue(row.getCell(13)));
        candidateRequest.setCurrentSalary(getCellStringValue(row.getCell(14)));
        candidateRequest.setExpectedSalary(getCellStringValue(row.getCell(15)));
        candidateRequest.setNumberOfOffers(getCellStringValue(row.getCell(16)));
        candidateRequest.setGender(getCellStringValue(row.getCell(17)));
        return candidateRequest;
    }

    private static LocalDate safeMapDate( String fetchedDate) {
        try {
            Date date = DateUtils.parseDate(fetchedDate,Locale.ENGLISH, Constants.DATE_PATTERNS);
            return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        } catch (Exception e) {
           log.error("invalid-date{}",fetchedDate);
        }
        return null;
    }

    private static URL safeParseURL(String value) {
        try {
            return value == null ? null : new URL(value.trim());
        } catch (Exception e) {
            return null;
        }
    }

    public static String getStringValue(String[] row, int index) {
        return index < row.length && row[index] != null && !row[index].trim().isEmpty() ? row[index].trim() : null;
    }

    public static String getCellStringValue(Cell cell) {
        if (cell == null) return null;
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                double val = cell.getNumericCellValue();
                long longVal = (long) val;
                if (val == longVal) {
                    return String.valueOf(longVal);
                } else {
                    return String.valueOf(val);
                }
            default:
                return null;
        }
    }

    public static String safeJoin(String... parts) {
        return Arrays.stream(parts)
                .filter(part -> part != null && !part.isBlank())
                .collect(Collectors.joining(" "));
    }

}
