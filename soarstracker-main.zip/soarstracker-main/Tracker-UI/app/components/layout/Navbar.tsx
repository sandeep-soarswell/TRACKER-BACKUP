import React, { useState, useEffect, useRef } from 'react';
import { jwtDecode } from 'jwt-decode';
import { Link, useNavigate } from 'react-router';
import companyService from '~/services/company/company.service';
import eventService from '~/services/event/event.service';
import jobService from '~/services/job/job.services';
import {
  AccountCircleIcon,
  ExpandMoreIcon,
  VerifiedUserIcon,
  ManageAccountsIcon,
  BusinessCenterIcon,
  AdminPanelSettingsIcon,
  LogoutIcon,
  SettingsIcon,
  LockResetIcon,
  NotificationsNoneIcon,
} from '~/components/ui/Icons';
import DoneAllOutlinedIcon from '@mui/icons-material/DoneAllOutlined';
import authService from '~/services/login/login.services';
import ProfileDrawer from '~/pages/profile/Profiledrawyer';
import { Tooltip } from '@mui/material';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';

interface Notification {
  deadline: string;
  id: string;
  title: string;
  startTime: string;
  read: boolean;
}

const Navbar: React.FC = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [userName, setUserName] = useState<string>('');
  const [userRole, setUserRole] = useState<string>('');
  const [companyLogo, setCompanyLogo] = useState<string | null>(null);
  const [loadingLogo, setLoadingLogo] = useState(true);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [openProfileDrawer, setOpenProfileDrawer] = useState(false);
  const navigate = useNavigate();
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'error'>('success');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [markEventAsRead, setMarkEventAsRead] = useState(false);
  const [notificationDropdownOpen, setNotificationDropdownOpen] = useState(false);
  const [hasNewNotification, setHasNewNotification] = useState(false);
  const notificationDropdownRef = useRef<HTMLDivElement>(null);
  const allowedRolesForNotification = ['COMPANY_ADMIN', 'MANAGER', 'RECRUITER'];
  const [jobDeadlineNotifications, setJobDeadlineNotifications] = useState<Notification[]>([]);
  const [markJobAsRead, setMarkJobAsRead] = useState(false);
  const [userEmail, setUserEmail] = useState<string>('');

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('userToken');
      if (token) {
        try {
          const decoded: any = jwtDecode(token);
          const user = decoded.sub.split('@')[0];
          const role = Array.isArray(decoded.roles) ? decoded.roles[0] : 'user';
          setUserName(user.split(new RegExp('[0-9]'))[0]);
          setUserRole(role);
        } catch (err) {
          console.error("Failed to decode token", err);
        }
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchLogo = async () => {
      if (allowedRolesForNotification.includes(userRole)) {
        const token = localStorage.getItem('userToken');
        const decoded: any = token ? jwtDecode(token) : {};
        setUserEmail(decoded.sub || '');
        const companyId = decoded.companyId || decoded.Company_id || localStorage.getItem('companyId');
        if (companyId && token) {
          setLoadingLogo(true);
          try {
            const imageUrl = await companyService.getCompanyImage(companyId, token);
            setCompanyLogo(imageUrl);
          } catch (err) {
            setCompanyLogo(null);
          } finally {
            setLoadingLogo(false);
          }
        } else {
          setCompanyLogo(null);
          setLoadingLogo(false);
        }
      }
    };
    if (userRole) fetchLogo();
  }, [userRole]);

  useEffect(() => {
    const fetchNotifications = async () => {
      if (allowedRolesForNotification.includes(userRole)) {
        try {
          const newNotifications = (await eventService.getNotifications()) || [];
          const jobDeadlineNotifs = (await jobService.getNotifications?.()) || [];
          let flag = newNotifications.some((notification: { read: boolean; }) => !notification.read) ||
            jobDeadlineNotifs.some((notification: { read: boolean; }) => !notification.read);

          if (flag) {
            setHasNewNotification(true)
          }
          setNotifications(newNotifications);
          setJobDeadlineNotifications(jobDeadlineNotifs);

        } catch (error) {
          setNotifications([]);
          setJobDeadlineNotifications([]);
        }
      }
    };

    if (userRole) {
      fetchNotifications();
      const intervalId = setInterval(fetchNotifications, 60000);
      return () => clearInterval(intervalId);
    }
  }, [userRole, markEventAsRead, markJobAsRead]);


  const handleClickOutside = (event: MouseEvent) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) setDropdownOpen(false);
    if (notificationDropdownRef.current && !notificationDropdownRef.current.contains(event.target as Node)) setNotificationDropdownOpen(false);
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = async () => {
    const res = await authService.logout();
    setSnackbarMessage(res?.data?.message || 'Logged out successfully');
    setSnackbarSeverity("success");
    setSnackbarOpen(true);
    setTimeout(() => navigate('/'), 200);
  };

  const handleNotificationClick = () => {
    setNotificationDropdownOpen(!notificationDropdownOpen);
    setHasNewNotification(false);
  };

  const getRoleInfo = (role: string) => {
    switch (role.toLowerCase()) {
      case 'sys_admin': return { icon: <AdminPanelSettingsIcon sx={{ fontSize: 14, color: '#3B82F6', marginRight: 1 }} />, label: 'Super Admin' };
      case 'company_admin': return { icon: <VerifiedUserIcon sx={{ fontSize: 14, color: '#3B82F6', marginRight: 1 }} />, label: 'Company Admin' };
      case 'manager': return { icon: <BusinessCenterIcon sx={{ fontSize: 14, color: '#2563EB', marginRight: 1 }} />, label: 'Manager' };
      case 'recruiter': return { icon: <ManageAccountsIcon sx={{ fontSize: 14, color: '#2563EB', marginRight: 1 }} />, label: 'Recruiter' };
      case 'user': return { icon: <ManageAccountsIcon sx={{ fontSize: 14, color: '#6B7280', marginRight: 1 }} />, label: 'User' };
      default: return { icon: <ManageAccountsIcon sx={{ fontSize: 14, color: '#6B7280', marginRight: 1 }} />, label: role };
    }
  };

  const handleMarkAsRead = async (Notification: Notification) => {
    
      await eventService.markEventAsRead({ eventId: Notification.id });
      setNotifications(prev =>
        prev.map(notif =>
          notif.id === Notification.id ? { ...notif, read: true } : notif
        )
      );
      setMarkEventAsRead(true);
      setHasNewNotification(false);
  };
  const handleMarkJobAsRead = async (Notification: Notification) => {
      await jobService.markJobAsRead({ eventId: Notification.id });
      setNotifications(prev =>
        prev.map(notif =>
          notif.id === Notification.id ? { ...notif, read: true } : notif
        )
      );
      setMarkJobAsRead(true);
      setHasNewNotification(false);
  };

  return (
    <>
      <header className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 w-60 h-10">
            {allowedRolesForNotification.includes(userRole) && (
              loadingLogo ? (<div className="w-24 h-10 bg-gray-200 animate-pulse rounded" />) :
                companyLogo ? (<img src={companyLogo} alt="Company Logo" className="h-16 w-auto object-contain" style={{ maxHeight: '40px', maxWidth: '200px' }} onError={() => setCompanyLogo(null)} />) :
                  (<div className="w-24 h-10 bg-gray-300 flex items-center justify-center rounded text-gray-500 text-sm font-semibold"> No Logo </div>)
            )}
          </div>
          <div className="flex items-center space-x-4">
            {allowedRolesForNotification.includes(userRole) && (
              <div className="relative" ref={notificationDropdownRef}>
                <Tooltip title="Notifications" placement="bottom">
                  <button onClick={handleNotificationClick} className="relative p-2 rounded-full hover:bg-gray-100 transition-colors cursor-pointer focus:outline-none" >
                    <NotificationsNoneIcon sx={{ color: '#4B5563' }} />
                    {hasNewNotification && (<span className="absolute top-2 right-2 block h-2 w-2 rounded-full bg-red-500" />)}
                  </button>
                </Tooltip>
                {notificationDropdownOpen && (
                  <div className="absolute right-0 mt-2 mr-2 w-72 bg-white rounded-md shadow-lg z-50 border border-gray-200">
                    <div className="py-1 max-h-80 overflow-y-auto ml-3">
                      {/* Event Notifications */}
                      {notifications && notifications.length > 0 ? (
                        notifications.map((notif, index) => (
                          <div
                            key={index}
                            className="px-2 py-2 hover:bg-gray-100 cursor-pointer flex justify-between items-start"
                            title={notif.title}
                          >
                            <div className="flex-1 flex items-center gap-2">
                              {/* Calendar icon for event notifications */}
                              <CalendarMonthIcon fontSize="small" className="text-blue-500" />
                              <div>
                                <p
                                  className={`text-sm font-semibold truncate ${notif.read ? 'text-gray-500' : 'text-blue-600'
                                    }`}
                                >
                                  {notif.title}
                                </p>
                                <p className="text-xs text-gray-400">Starts at: {notif.startTime}</p>
                              </div>
                            </div>
                            {!notif.read && (
                              <Tooltip title="Mark as Read" placement="bottom">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleMarkAsRead(notif);
                                  }}
                                  className={`ml-2 text-xs cursor-pointer ${notif.read
                                    ? 'text-gray-400 cursor-not-allowed'
                                    : 'text-blue-500 hover:underline'
                                    }`}
                                >
                                  <DoneAllOutlinedIcon fontSize="small" />
                                </button>
                              </Tooltip>
                            )}
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-gray-500 text-center py-4">No upcoming event reminders.</p>
                      )}

                      {/* Job Deadline Notifications */}
                      {jobDeadlineNotifications && jobDeadlineNotifications.length > 0 && (
                        <>
                          {jobDeadlineNotifications.map((notif, index) => (
                            <div
                              key={`jobdeadline-${index}`}
                              className="px-2 py-2 hover:bg-gray-100 cursor-pointer flex justify-between items-start"
                              title={notif.title}
                            >
                              <div className="flex-1 flex items-center gap-2">
                                {/* Job icon for job deadline notifications */}
                                <BusinessCenterIcon fontSize="small" className="text-blue-500" />
                                <div>
                                  <p
                                    className={`text-sm font-semibold truncate ${notif.read ? 'text-gray-400 cursor-not-allowed'
                                      : 'text-green-500 hover:underline'
                                      }`}
                                  >
                                    {notif.title}
                                  </p>
                                  <p className="text-xs text-gray-400">Deadline: {notif.deadline}</p>
                                </div>
                              </div>
                              {!notif.read && (
                                <Tooltip title="Mark as Read" placement="bottom">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleMarkJobAsRead(notif);
                                    }}
                                    className={`ml-2 text-xs cursor-pointer ${notif.read
                                      ? 'text-gray-400 cursor-not-allowed'
                                      : 'text-blue-500 hover:underline'
                                      }`}
                                  >
                                    <DoneAllOutlinedIcon fontSize="small" />
                                  </button>
                                </Tooltip>
                              )}
                            </div>
                          ))}
                        </>
                      )}

                      {/* No notifications */}
                      {(!notifications.length && !jobDeadlineNotifications.length) && (
                        <p className="text-sm text-gray-500 text-center py-4">No upcoming notifications.</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
            <div className="relative" ref={dropdownRef}>
              <button className="flex items-center space-x-2 focus:outline-none cursor-pointer" onClick={() => setDropdownOpen(!dropdownOpen)} >
                <img src={`https://api.dicebear.com/9.x/shapes/svg?seed=${userEmail}`} alt="Profile" className="w-8 h-8 rounded-full" />
                <div className="hidden md:block text-left">
                  <p className="text-sm font-medium text-gray-700">{userName}</p>
                  <div className="flex items-center text-xs text-gray-500">
                    {getRoleInfo(userRole).icon}
                    <span className="capitalize">{getRoleInfo(userRole).label}</span>
                  </div>
                </div>
                <ExpandMoreIcon sx={{ fontSize: 16, color: '#4B5563' }} />
              </button>
              {dropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                  <button onClick={() => setOpenProfileDrawer(true)} className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left cursor-pointer" >
                    <AccountCircleIcon fontSize="small" /> Profile
                  </button>
                  <Link to="/dashboard/settings" className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    <SettingsIcon fontSize="small" /> Settings
                  </Link>
                  <Link to="/change-password" className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    <LockResetIcon fontSize="small" /> Reset Password
                  </Link>
                  <button onClick={handleLogout} className="w-full text-left flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer" >
                    <LogoutIcon fontSize="small" /> Sign out
                  </button>
                </div>
              )}
              <ProfileDrawer open={openProfileDrawer} setOpen={setOpenProfileDrawer} />
            </div>
          </div>
        </div>
      </header>
      <CustomSnackbar
        open={snackbarOpen}
        message={snackbarMessage}
        severity={snackbarSeverity}
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={4000}
      />
    </>
  );
};

export default Navbar;