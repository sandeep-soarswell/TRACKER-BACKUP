package com.soarswell.tracker.model.role;

public enum RoleUsageType {

    INTERNAL,
    EXTERNAL;
}