package com.soarswell.tracker.model.payload;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidateLoginRequest {
    @NotBlank
    private String token;
}