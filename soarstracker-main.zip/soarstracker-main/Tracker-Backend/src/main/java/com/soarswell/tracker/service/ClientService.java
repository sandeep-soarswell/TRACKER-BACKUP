package com.soarswell.tracker.service;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.ClientRequest;
import org.springframework.http.ResponseEntity;
import com.soarswell.tracker.model.payload.ClientUpdateRequest;

public interface ClientService {
    ResponseEntity<?> registerClients(ClientRequest clientRequest,RequestDetails requestDetails);
    ResponseEntity<?> deleteClientById(String clientId,RequestDetails requestDetails) throws TrackerException;
    ResponseEntity<?> getClients(int page,int size, RequestDetails requestDetails,String sortByField,String order,String keyword,String filter) throws TrackerException;
    ResponseEntity<?> getClientsById(String clientId,  RequestDetails requestDetails) throws TrackerException;
    ResponseEntity<?> updateClientById(String clientId, ClientUpdateRequest request,  RequestDetails requestDetails) throws TrackerException;

}
