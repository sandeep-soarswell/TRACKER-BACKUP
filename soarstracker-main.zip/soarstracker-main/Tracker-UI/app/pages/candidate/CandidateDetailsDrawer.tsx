import React from "react";
import type { Candidate } from "~/pages/types/types";
import dayjs from "dayjs";
import DrawerLayout from "~/components/layout/DrawerLayout";

const CandidateDetailsDrawer = ({
  candidate,
  open,
  onClose,
}: {
  candidate: Candidate | null;
  open: boolean;
  onClose: () => void;
}) => {
  if (!candidate || !open) return null;

  const formatValue = (value: any): string => {
    if (value === null || value === undefined) return "—";
    if (typeof value === 'boolean') return value ? "Yes" : "No";
    if (Array.isArray(value)) return value.length > 0 ? value.join(', ') : "—";
    const stringValue = String(value).trim();
    return stringValue || "—";
  };

  const fields = [
    {
      label: "Name",
      value: `${candidate.firstName ?? ""} ${candidate.middleName ?? ""} ${candidate.lastName ?? ""}`.trim() || "—",
    },
    {
      label: "Date of Birth",
      value: candidate.dateOfBirth ? dayjs(candidate.dateOfBirth).format("YYYY-MM-DD") : "—",
    },
    { label: "Gender", value: candidate.gender || "—" },
    { label: "Email", value: formatValue(candidate.email) },
    { label: "Alternate Email", value: formatValue(candidate.alternateEmail) },
    {
      label: "Phone Number",
      value: `${candidate.phoneNumber ?? ""}`.trim(),
    },
    {
      label: "Alternate Phone Number",
      value: candidate.alternatePhoneNumber ? String(candidate.alternatePhoneNumber).trim() : "—",
    }, { label: "Address", value: formatValue(candidate.address) },
    { label: "Current Salary", value: formatValue(candidate.currentSalary) },
    { label: "Expected Salary", value: formatValue(candidate.expectedSalary) },
    {
      label: "Availability of Joining", value: candidate.availabilityOfJoining
        ? dayjs(candidate.availabilityOfJoining).format("YYYY-MM-DD")
        : "—",
    },
    { label: "Candidate Role", value: formatValue(candidate.candidateRole) },
    { label: "Skills", value: formatValue(candidate.skills) },
    { label: "Experience", value: formatValue(candidate.experience) },
    { label: "Notice Period", value: formatValue(candidate.noticePeriod) },
    { label: "Offers in Hand", value: candidate.numberOfOffers ? "Yes" : "No" },
    { label: "Number of Offers", value: candidate.numberOfOffers ? candidate.numberOfOffers : "—" },
    { label: "Status", value: candidate.status },
    { label: "Resume", value: formatValue(candidate.resume) },
    {
      label: "College Rating",
      value: candidate.collegeRating ? `${formatValue(candidate.collegeRating)} / 5` : "N/A"
    },
    { label: "Company Rating", value: candidate.companyRating ? `${formatValue(candidate.companyRating)} / 5` : "N/A" },
    { label: "Experience Rating", value: candidate.experienceRating ? `${formatValue(candidate.experienceRating)} / 5` : "N/A" },
    { label: "Skills Rating", value: candidate.skillsRating ? `${formatValue(candidate.skillsRating)} / 5` : "N/A" },
    { label: "Status", value: formatValue(candidate.status) },
    { label: "AI Summary", value: candidate.aiSummary ? formatValue(candidate.aiSummary) : "N/A" },
  ];

  return (
    <DrawerLayout title="Candidate Details" onClose={onClose}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4">

        {fields.map(({ label, value }) => (
          <div
            key={label}
            className={
              label === "AI Summary"
                ? "md:col-span-2" // full width on medium+ screens
                : ""
            }
          >
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {label}
            </label>
            <textarea
              value={
                typeof value === "string" || typeof value === "number"
                  ? String(value)
                  : "—————"
              }
              readOnly
              className="w-full px-3 py-2 rounded-md text-sm text-justify !bg-gray-100 cursor-not-allowed focus:outline-none border-0 resize-none"
              style={{ boxShadow: "none", overflow: "hidden" }}
              rows={1}
              ref={(el) => {
                if (el) {
                  el.style.height = "auto";
                  el.style.height = el.scrollHeight + "px";
                }
              }}
            />
          </div>
        ))}

      </div>
    </DrawerLayout>
  );
};

export default CandidateDetailsDrawer;