package com.soarswell.tracker.model;

import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;

@AllArgsConstructor
@Getter
public enum ResourceStatus {

    PENDING("pending"),
    ACTIVE("active"),
    REJECT("reject"),
    CRO_REVIEW("cro_review"),
    REGISTERED("registered"),
    INACTIVE("inactive");

    private final String value;

    public String value() {
        return this.value;
    }

    public static ResourceStatus fromValue(String value) throws com.soarswell.tracker.exception.TrackerException {
        if (StringUtils.isBlank(value))
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_RESOURCE_TYPE.name()),
                    HttpStatus.BAD_REQUEST);

        for (ResourceStatus type : values()) {
            if (type.name().equalsIgnoreCase(value) || type.value().equalsIgnoreCase(value)) {
                return type;
            }
        }
        throw new TrackerException(
                String.format(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_RESOURCE_TYPE.name()), value),
                HttpStatus.BAD_REQUEST);
    }
}