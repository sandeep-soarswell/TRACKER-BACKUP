import api from "../api/api.services";

const authService = {
  login: async (username: string, password: string) => {
    const response = await api.post('/user/login', { username, password });
    return response.data;
  },

  forgotPassword: async (email: string) => {
    const response = await api.post('/forgot-password', { email });
    return response.data;
  },


  validateOtp: async (email: string, otp: string) => {
    const response = await api.post('/validate-otp', { email, otp });
    return response.data;
  },

  resendOtp: async (username: string) => {
    const response = await api.post('/resend-otp', null, { params: { username } });
    return response.data;
  },

  validateToken: async (token: string) => {
    const response = await api.post('/token/validate', { token });
    return response.data;
  },
  changePassword: async (newPassword: string) => {
    const tempToken = localStorage.getItem("tempToken") || localStorage.getItem("userToken");
    if (!tempToken)
      throw new Error('No token found')
    const response = await api.post('/change-password', { newPassword },
      {
        headers:
        {
          Authorization: `Bearer ${tempToken}`
        }
      }
    );
    return response.data;
  },

  logout: async () => {
    const token = localStorage.getItem('userToken');
    const response = await api.post('/user/logout', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    localStorage.clear();
    return response.data;
  }

}

export default authService;
