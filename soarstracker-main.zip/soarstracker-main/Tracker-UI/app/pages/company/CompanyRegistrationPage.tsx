import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import isEqual from 'lodash.isequal';
import DrawerLayout from '~/components/layout/DrawerLayout';
import companyService from '~/services/company/company.service';
import type { CompanyType } from '~/pages/types/types';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import Button from '~/components/ui/Button';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import parsePhoneNumberFromString, { isValidPhoneNumber } from 'libphonenumber-js';
import getChangedFields from '~/components/util/update-util';
import { getCountryCallingCodeLength, getCountryForCallingCode } from '~/components/util/phone-utils';
import api from '~/services/api/api.services';

interface CompanyFormProps {
  company?: CompanyType;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

const validationSchema = Yup.object({
  companyName: Yup.string()
    .trim()
    .min(2, 'Company name must be at least 2 characters')
    .max(50, 'Company name must be 50 characters or less')
    .required('Company name is required')
    .test('companyName-companyRegNo-different', 'Company name and registration number cannot be the same', function (value) {
      const { companyRegNo } = this.parent;
      return !value || !companyRegNo || value.trim().toLowerCase() !== companyRegNo.trim().toLowerCase();
    }),
  emailId: Yup.string()
    .trim()
    .email('Invalid company email format')
    .required('Company email is required')
    .matches(
      /^[a-z][a-z0-9._%+-]*@[a-z0-9.-]+\.[a-z]{2,}$/,
      'Email must be lowercase and start with a letter (e.g., john@example.com)'
    ),
  companyAddress: Yup.string()
    .trim()
    .min(5, 'Address must be at least 5 characters')
    .required('Company address is required'),
  companyRegNo: Yup.string()
    .trim()
    .min(6, 'Registration must be at least 6 characters')
    .required('Company Reg No is required')
    .test('companyRegNo-companyName-different', 'Registration number and company name cannot be the same', function (value) {
      const { companyName } = this.parent;
      return !value || !companyName || value.trim().toLowerCase() !== companyName.trim().toLowerCase();
    }),
  mobileNo: Yup.string()
    .trim()
     .test('valid-phone-required', 'Phone Number required', (value) => {
    const trimmed = value?.trim() || '';
    return trimmed.length>4;
    })
    .test('is-valid-phone', 'Invalid phone number format', (value) => {
      if (!value) return true;
      return isValidPhoneNumber(value);
    }),

  alternatePhoneNumber: Yup.string()
    .trim()
    .nullable()
    .test('is-valid-phone-or-digits', 'Invalid phone number format', function(value){
      if (!value) return true;
      if (getCountryCallingCodeLength(this.parent.mobileNo) >= value.length) return true;
      return isValidPhoneNumber(value);
    })
    .test('different-from-primary-phone', 'Must be different from primary phone', function (value) {
      if (!value) return true;
      if (getCountryCallingCodeLength(this.parent.mobileNo) >= value.length) return true;
      return value !== this.parent.mobileNo;
    }),
  personalMailId: Yup.string()
    .trim()
    .email("Invalid contact person's email format")
    .required("Contact person's email is required")
    .test('personal-email-company-email-different', 'Personal email must be different from company email', function (value) {
      const emailId  = this.parent.emailId;
       return value !== emailId
    }),
});

const CompanyForm: React.FC<CompanyFormProps> = ({ company, onClose, onSuccess }) => {
  const isEditMode = Boolean(company);
  const [openSnackbar, setOpenSnackbar] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [snackbarSeverity, setSnackbarSeverity] = React.useState<'success' | 'error'>('success');
  const showSnackbar = (message: string, severity: 'success' | 'error' = 'success') => {
    setAlertMessage(message);
    setSnackbarSeverity(severity);
    setOpenSnackbar(true);
  };

  type CompanyFormValues = {
    id: string;
    companyName: string;
    emailId: string;
    companyAddress: string;
    companyRegNo: string;
    mobileNo: string;
    alternatePhoneNumber: string | null;
    personalMailId: string;
    status: string;
  };

  const normalizePhoneNumber = (phone: string | null) => {
    if (!phone) return '';
    return phone.replace(/[\s-]/g, '');
  };

  const isButtonEnabled = () => {
    if (formik.isSubmitting) return false;

    if (!isEditMode) {
      return formik.isValid;
    }

    const fields: (keyof CompanyFormValues)[] = [
      'companyName',
      'emailId',
      'companyAddress',
      'companyRegNo',
      'mobileNo',
      'personalMailId',
      'alternatePhoneNumber',
    ];

    return formik.isValid && fields.some((field) => {
      const currentValue = field === 'alternatePhoneNumber' || field === 'mobileNo'
        ? normalizePhoneNumber(formik.values[field])
        : formik.values[field] ?? '';
      const initialValue = field === 'alternatePhoneNumber' || field === 'mobileNo'
        ? normalizePhoneNumber(formik.initialValues[field])
        : formik.initialValues[field] ?? '';
      return !isEqual(currentValue, initialValue);
    });
  };

  const initialValues = React.useMemo(() => {
    return {
      companyId: company?.id || '',
      companyName: company?.companyName || '',
      emailId: company?.emailId || '',
      companyAddress: company?.companyAddress || '',
      companyRegNo: company?.companyRegNo || '',
      mobileNo: company?.mobileNo || '',
      alternatePhoneNumber: company?.alternateNo || null,
      personalMailId: company?.personalMailId || '',
      status: company?.status || 'active',
    };
  }, [company]);

  const formik = useFormik({
    initialValues: {
      id: initialValues.companyId,
      companyName: initialValues.companyName,
      emailId: initialValues.emailId,
      companyAddress: initialValues.companyAddress,
      companyRegNo: initialValues.companyRegNo,
      mobileNo: initialValues.mobileNo,
      alternatePhoneNumber: initialValues.alternatePhoneNumber,
      personalMailId: initialValues.personalMailId,
      status: initialValues.status,

    },
    enableReinitialize: true,
    validationSchema,
    validateOnMount: true,
    onSubmit: async (values) => {
      try {
        const payload = {
          id: values.id ? values.id.trim() : null,
          companyName: values.companyName.trim(),
          emailId: values.emailId.trim(),
          companyAddress: values.companyAddress.trim(),
          companyRegNo: values.companyRegNo.trim(),
          personalMailId: values.personalMailId.trim(),
          mobileNo: values.mobileNo.trim(),
          alternateNo:
            values.alternatePhoneNumber && isValidPhoneNumber(values.alternatePhoneNumber) && values.alternatePhoneNumber.length > getCountryCallingCodeLength(values.mobileNo)
              ? values.alternatePhoneNumber.trim()
              : null,
          status: values.status,
        };
        let apiMessage = '';
        if (isEditMode && company?.id) {
          const changedFields = getChangedFields(company, payload);
          const updateresponse = await companyService.update(company.id, { changedFields });
          console.log('Update response:', updateresponse);
          apiMessage = updateresponse || 'Company updated successfully';
        } else {
          const regresponse = await companyService.register(payload);
          apiMessage = regresponse || 'Company registered successfully';
        }
        console.log(apiMessage);
        showSnackbar(apiMessage, 'success');
        onSuccess(apiMessage);
      } catch (error: any) {
        const errorMsg =
          error?.response?.data?.error?.message ||
          error?.message ||
          'An unexpected error occurred';
        const errorData = error?.response?.data?.error;
        let hasFieldError = false;
        const backendToFieldMap: Record<string, string> = {
          'company-name': 'companyName',
          EMAIL: 'personalMailId',
          'Regd.No': 'companyRegNo',
          COMPANY: 'emailId',
          PHONE: 'mobileNo',
        };
        if (typeof errorData === 'object' && errorData !== null) {
          Object.entries(errorData).forEach(([backendKey, message]) => {
            const field = backendToFieldMap[backendKey];
            if (field && formik.values.hasOwnProperty(field)) {
              formik.setFieldError(field, String(message));
              hasFieldError = true;
            }
          });
        }
        const lower = errorMsg.toLowerCase();
        if (!hasFieldError) {
          if (lower.includes('company name')) {
            formik.setFieldError('companyName', 'Company name already exists');
            hasFieldError = true;
          }
          if (lower.includes('email') && lower.includes('company')) {
            formik.setFieldError('emailId', 'This company email already exists');
            hasFieldError = true;
          }
          if (lower.includes('email') && lower.includes('personal')) {
            formik.setFieldError('personalMailId', 'This personal email is already used');
            hasFieldError = true;
          }
          if (lower.includes('reg') || lower.includes('registration')) {
            formik.setFieldError('companyRegNo', 'This registration number already exists');
            hasFieldError = true;
          }
          if (lower.includes('mobile') || lower.includes('phone')) {
            formik.setFieldError('mobileNo', 'This company mobile number already exists');
            hasFieldError = true;
          }
        }
        setTimeout(() => {
          const firstErrorField = Object.keys(formik.errors)[0];
          if (firstErrorField) {
            const el = document.querySelector(`[name="${firstErrorField}"]`) as HTMLElement;
            el?.focus();
          }
        }, 0);
        if (!hasFieldError) {
          setAlertMessage(errorMsg);
          setSnackbarSeverity('error');
          setOpenSnackbar(true);
        }
      } finally {
        formik.setSubmitting(false);
      }
    },
  });

  return (
    <>
      <CustomSnackbar
        open={openSnackbar}
        message={alertMessage}
        onClose={() => setOpenSnackbar(false)}
        severity={snackbarSeverity}
        autoHideDuration={5000}
      />
      <DrawerLayout
        title={isEditMode ? 'Edit Company' : 'Register Company'}
        onClose={onClose}
        footer={
          <Button
            variant="primary"
            type="button"
            onClick={() => formik.handleSubmit()}
            disabled={!isButtonEnabled()}
          >
            {isEditMode ? 'Update' : 'Create'}
          </Button>
        }
      >
        <form id="registerform" onSubmit={formik.handleSubmit} className="space-y-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="companyName" className="block text-sm font-medium text-gray-700 mb-1">
              Company Name <span className="text-red-500">*</span>
            </label>
            <input
              id="companyName"
              name="companyName"
              type="text"
              value={formik.values.companyName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled={isEditMode}
              className={`w-full px-3 py-2 rounded-md border text-sm ${isEditMode ? '!bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'} ${formik.touched.companyName && formik.errors.companyName ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.companyName && formik.errors.companyName && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.companyName}</p>
            )}
          </div>
          <div>
            <label htmlFor="emailId" className="block text-sm font-medium text-gray-700 mb-1">
              Company Email <span className="text-red-500">*</span>
            </label>
            <input
              id="emailId"
              name="emailId"
              type="email"
              value={formik.values.emailId}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled={isEditMode}
              className={`w-full px-3 py-2 rounded-md border text-sm ${isEditMode ? '!bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'} ${formik.touched.emailId && formik.errors.emailId ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.emailId && formik.errors.emailId && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.emailId}</p>
            )}
          </div>
          <div>
            <label htmlFor="companyAddress" className="block text-sm font-medium text-gray-700 mb-1">
              Company Address <span className="text-red-500">*</span>
            </label>
            <input
              id="companyAddress"
              name="companyAddress"
              type="text"
              value={formik.values.companyAddress}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.companyAddress && formik.errors.companyAddress ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.companyAddress && formik.errors.companyAddress && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.companyAddress}</p>
            )}
          </div>
          <div>
            <label htmlFor="companyRegNo" className="block text-sm font-medium text-gray-700 mb-1">
              Company Reg No <span className="text-red-500">*</span>
            </label>
            <input
              id="companyRegNo"
              name="companyRegNo"
              type="text"
              value={formik.values.companyRegNo}
              onChange={(e) => {
                const value = e.target.value;
                const alphanumericRegex = /^[a-zA-Z0-9]*$/;
                if (value === '' || (alphanumericRegex.test(value) && value.length <= 21)) {
                  formik.setFieldValue('companyRegNo', value);
                }
              }}
              onBlur={formik.handleBlur}
              maxLength={21}
              disabled={isEditMode}
              className={`w-full px-3 py-2 rounded-md border text-sm ${isEditMode ? '!bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'} ${formik.touched.companyRegNo && formik.errors.companyRegNo ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.companyRegNo && formik.errors.companyRegNo && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.companyRegNo}</p>
            )}
          </div>
          <div>
            <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
              Mobile Number <span className="text-red-500">*</span>
            </label>
            <PhoneInput
              defaultCountry="in"
              disabled={isEditMode}
              countrySelectorStyleProps={{
                buttonStyle: {
                  height: '40px',
                  border: formik.touched.mobileNo && formik.errors.mobileNo
                    ? '1px solid #ef4444'
                    : '1px solid #d1d5db',
                  borderRadius: '6px 0 0 6px',
                  background: '#fff',
                  padding: '0 8px',
                  cursor: isEditMode ? 'not-allowed' : 'pointer',
                  color: isEditMode ? '#6b7280' : 'inherit',
                },
              }}
              value={formik.values.mobileNo}
              onChange={(value) => {
                formik.setFieldValue('mobileNo', value);
              }}
              onBlur={() => formik.setFieldTouched('mobileNo', true)}
              forceDialCode
              inputProps={{
                disabled: isEditMode,
                name: 'phoneNumber',
                className: `w-full px-3 py-2 rounded-r-md border text-sm ${isEditMode ? '!bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'} ${formik.touched.mobileNo && formik.errors.mobileNo ? 'border-red-500' : 'border-gray-300'}`,
                style: { height: '40px' },
              }}
              style={{
                display: 'flex',
                alignItems: 'center',
              }}
              inputStyle={{
                borderRadius: '0 6px 6px 0',
                borderLeft: 'none',
              }}
            />
            {formik.touched.mobileNo && formik.errors.mobileNo && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.mobileNo}</p>
            )}
          </div>
          <div>
            <label htmlFor="alternatePhoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
              Alternate PhoneNumber
            </label>
            <PhoneInput
              defaultCountry={getCountryForCallingCode(String(parsePhoneNumberFromString(formik.values.mobileNo)?.countryCallingCode))|| 'in'}
              value={String(formik.values.alternatePhoneNumber)}
              onChange={(value) => {
                formik.setFieldValue('alternatePhoneNumber', value);
                formik.setFieldTouched('alternatePhoneNumber', true, false); // Ensure dirty state
              }}
              onBlur={() => formik.setFieldTouched('alternatePhoneNumber', true)}
              forceDialCode
              inputProps={{
                id: 'alternatePhoneNumber',
                name: 'alternatePhoneNumber',
                className: `w-full px-3 py-2 rounded-r-md border text-sm bg-white ${formik.touched.alternatePhoneNumber && formik.errors.alternatePhoneNumber
                  ? 'border-red-500'
                  : 'border-gray-300'
                  }`,
                style: { height: '40px' },
              }}
              style={{
                display: 'flex',
                alignItems: 'center',
              }}
              countrySelectorStyleProps={{
                buttonStyle: {
                  height: '40px',
                  border: formik.touched.alternatePhoneNumber && formik.errors.alternatePhoneNumber
                    ? '1px solid #ef4444'
                    : '1px solid #d1d5db',
                  borderRadius: '6px 0 0 6px',
                  background: '#fff',
                  padding: '0 8px',
                },
              }}
              inputStyle={{
                borderRadius: '0 6px 6px 0',
                borderLeft: 'none',
              }}
            />
            {formik.touched.alternatePhoneNumber && formik.errors.alternatePhoneNumber && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.alternatePhoneNumber}</p>
            )}
          </div>
          <div>
            <label htmlFor="personalMailId" className="block text-sm font-medium text-gray-700 mb-1">
              Personal Email <span className="text-red-500">*</span>
            </label>
            <input
              id="personalMailId"
              name="personalMailId"
              type="email"
              value={formik.values.personalMailId}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.personalMailId && formik.errors.personalMailId ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.personalMailId && formik.errors.personalMailId && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.personalMailId}</p>
            )}
          </div>
        </form>
      </DrawerLayout>
    </>
  );
};

export default CompanyForm;