package com.soarswell.tracker.exception;

public enum ErrorMessageKey {

    INVALID_TOKEN("invalid.token"),
    INVALID_RESOURCE_TYPE("invalid.resource"),
    UNABLE_SAVE_COMPANY("unable.save.company"),
    UNABLE_GET_COMPANY("unable.get.company"),
    CLIENT_ID_NULL_OR_EMPTY("client.id.null.or.empty"),
    UNABLE_SAVE_CLIENT_DETAILS("unable.save.client.details"),
    SYSTEM_ROLE_NOT_AVAILABLE("system.role.not.available"),
    ALREADY_ASSIGNED_TO_SAME_USER("candidate.already.assigned.same.user"),

    EMAIL_EXISTS("Candidate.with.this.email.already.exists"),
    CANDIDATE_NOT_FOUND("Candidate.not.found"),
    CANDIDATE_NOT_FOUND_WITH_ID("Candidate.not.found.with.id"),
    CANDIDATE_ID_NULL_OR_EMPTY("Candidate.ID.is.null.or.empty"),
    UNABLE_TO_CREATE_CANDIDATE("Unable.to.create.candidate"),
    UNABLE_GET_CANDIDATE("Unable.to.get.candidate"),
    CANDIDATE_ID_REQUIRED_UPDATE("Candidate.ID.is.required.for.update"),
    UNABLE_SAVE_CANDIDATE("Unable.to.save.candidate"),
    UNABLE_DELETE_CANDIDATE("Unable.Delete.Candidate"),
    SAVE_FAILED("save.failed"),

//    User related keys
    ACCESS_DENIED("error.access.denied"),
    USER_EMAIL_EXISTS("error.user.with.this.email.already.exists"),
    ENTITY_INVALID("entity.invalid"),

//    Job related keys
    JOB_TITLE_REQUIRED("Job.title.is.required"),
    UNABLE_TO_CREATE_JOB("Unable.to.create.job"),
    JOB_NOT_FOUND("Job.not.found"),
    JOB_ALREADY_CLOSED("Job.already.closed"),
    NO_USERS_ASSIGNED_JOB ("No.users.assigned.job"),
    ALREADY_ASSIGNED("already.assigned.candidate"),
    NO_CANDIDATES_ASSIGNED("No.candidates.assigned"),
    NO_JOBS_FOUND_FOR_USER("error.no.jobs.found.user"),

//    Pagination keys
    INVALID_PAGINATION_PARAMS("invalid.pagination"),
    ERROR_INIT_DATABASE("Error initializing database"),
    INTERNAL_SERVER_ERROR("Internal.Server.Error"),
    NO_CLIENT_FOUND("Client.not.found"),
    UNABLE_GET_CLIENT_DETAILS("unable.get.client.details"),
    UNABLE_DELETE_CLIENT_DETAILS("unable.delete.client.details"),
    ERROR_REGISTERATION_NUMBER("error.registration.number"),

    UNABLE_TO_RETRIEVE_JOBS("unable.to.retrieve.jobs"),
    UNABLE_SAVE_COMMENT("unable.save.comment"),
    UNABLE_GET_COMMENT("unable.get.comment"),
    USER_NOT_FOUND("error.no.user.found"),
    COMPANY_NOT_FOUND("error.company.not.found"),
    UNABLE_TO_UPDATE_JOB("unable.to.update.job"),
    NO_COMPANY_FOUND("no.company.found"),
    NO_USERS_FOUND_WITH_PROVIDED_COMPANY_ID("error.no.users.found"),
    INVALID_FILTER_VALUE("error.invalid.filter.value"),
    INVALID_SORTBYFIELD("invalid.sortbyfield"),
    SUPPORTED_FILES("supported.files"),
    UNABLE_TO_PROCESS_FILE("unable.to.process.file"),
    UNABLE_TO_UPLOAD_CANDIDATE("unable.to.upload.candidate"),
    UNABLE_GET_CANDIDATES("Unable.to.get.candidates"),
    JOB_NOT_FOUND_FOR_CANDIDATE("job.not.found.for.candidate"),
    NO_ACCESS_TO_ASSIGN_TO_JOB("no.access.to.assign.to.job"),
    USER_PHONE_EXISTS("error.user.with.this.phone.already.exists"),
    CANDIDATES_NOT_FOUND("no.candidates.not.found.for.required.skillSet"),
    USER_NOT_AUTHENTICATED("error.user.not.authenticated"),
    USER_NOT_ASSIGNED_TO_JOB("error.user.not.assigned.to.job"),
    CANDIDATE_NOT_ASSIGNED_TO_JOB("error.candidate.not.assigned.to.job"),
    USER_HAS_NO_CANDIDATE_ASSIGNMENTS("error.user.has.no.candidate.assignments"),
    COOLING_PERIOD_NOT_OVER ("error.cooling.period.not.completed"),
    INVALID_ASSIGNMENT("error.invalid.assignment"),
    ERROR_JWT_REFRESH_FAILED ("error.jwt.refresh.failed"),

    COMPANY_MOBILE_DUPLICATE("error.company.mobile.duplicate"),
    COMPANY_PERSONAL_EMAIL_DUPLICATE("error.company.personal.email.duplicate"),
    COMPANY_MOBILE_ALTERNATE_SAME("error.company.mobile.alternate.same"),
    EVENT_NOT_FOUND("error.event.not.found"),
    INVALID_EVENT_DATE("invalid.event.date"),
    INVALID_EVENT_TIME("invalid.event.time"),
    CANDIDATE_NOT_ASSIGNED_TO_USER("error.candidate.not.assigned.to.user"),
    CANDIDATE_NO_JOB_ASSIGNMENT("error.candidate.no.job.assignment"),

    //Candidate to Job Assignment Keys
    ALTERNATE_EMAIL_CANNOT_BE_SAME("alternate.email.cannot.be.same"),
    ALTERNATE_PHONE_CANNOT_BE_SAME("alternate.phone.cannot.be.same"),
    ALREADY_CANDIDATE_DELETED("candidate.already.deleted"),
    CANDIDATE_ALREADY_HIRED("candidate.already.hired"),
    UNASSIGN_FAILED("unable.to.unassign.candidate"),
    CANDIDATE_ALREADY_ASSIGNED("candidate.already.assigned"),
    JOB_ID_ALREADY_EXISTS("error.job.id.already.exists"),
    NO_USER_ASSIGNED_CANDIDATE("error.user.not.assigned.to.candidate"),
    IMAGE_SIZE_EXCEEDED("error.image.size.exceeded"),
    UNABLE_GET_IMAGE("error.unable.to.get.image"),
    INVALID_IMAGE_FORMAT("error.invalid.image.format"),
    IMAGE_FILE_NOT_EXISTS("error.image.file.not.exists"),
    OTP_EXPIRED("error.otp.expired"),
    PARSING_RESUME("error.resume.parsing"),
    RESUME_PROCESS("error.resume.processing");

    private final String key;

    ErrorMessageKey(String keyVal) {
        key = keyVal;
    }

    public String getStatusCode() {
        return key;
    }

    @Override
    public String toString() {
        return key;
    }
}
