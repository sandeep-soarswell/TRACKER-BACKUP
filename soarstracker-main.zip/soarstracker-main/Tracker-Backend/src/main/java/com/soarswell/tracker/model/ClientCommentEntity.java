package com.soarswell.tracker.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.soarswell.tracker.persistance.AbstractEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Setter
@Getter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "client_comments", indexes = {
        @Index(name = "idx_client_id", columnList = "clientId")})
public class ClientCommentEntity extends AbstractEntity {

    private String clientId;
    private String companyId;
    @Column(columnDefinition = "TEXT", nullable = false)
    private String content;
}
