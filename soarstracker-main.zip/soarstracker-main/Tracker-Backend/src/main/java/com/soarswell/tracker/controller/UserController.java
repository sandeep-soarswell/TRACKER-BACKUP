package com.soarswell.tracker.controller;

import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.UserRegisterRequest;
import com.soarswell.tracker.model.payload.UserUpdateRequest;
import com.soarswell.tracker.service.UserService;
import com.soarswell.tracker.common.ResponseObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.soarswell.tracker.springsecurity.Authorities;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.MessageKeys;
import com.soarswell.tracker.util.RegExConstants;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import com.soarswell.tracker.service.ScoringService;

@RestController
@RequestMapping(Constants.USER_ROUTE_PATH)
@Tag(name = Constants.API_USER_TAG_NAME)

@ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = Constants.API_RESPONSE_OK, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "400", description = Constants.VALIDATION_ERROR, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "401", description = Constants.API_RESPONSE_UNAUTHORIZED, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "404", description = Constants.API_RESPONSE_NOT_FOUND, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "409", description = Constants.API_RESPONSE_NOT_FOUND, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "500", description = Constants.API_RESPONSE_ERROR, content = @Content(schema = @Schema(implementation = ResponseObject.class)))
})

public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private ScoringService scoringService;

    @Operation(summary = MessageKeys.USER_REGISTRATION_TAG_NAME, description = MessageKeys.USER_REGISTRATION_DESCRIPTION)
    @PostMapping
    @PreAuthorize(Authorities.USER_CREATE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> registerUser(@Valid @RequestBody UserRegisterRequest userDto) {
        return userService.register(userDto);
    }

    @GetMapping
    @PreAuthorize(Authorities.USER_LIST)
    @Operation(summary = MessageKeys.USER_GET_ALL_TAG_NAME, description = MessageKeys.USER_GET_ALL_DESCRIPTION)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getAllUsers(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(value = Constants.AUTH_KEY,required = false) String authToken  ,
            @RequestParam(defaultValue = "0",required=false) int page,
            @RequestParam(defaultValue = "10",required = false) int size,
            @RequestParam(defaultValue = "createDate",required = false) String sortByField,
            @RequestParam(value = "desc/asc", required = false) String order,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue="*") String filter,
            @RequestParam(defaultValue="*",required = false)
            @Pattern(regexp = RegExConstants.ROLE_VALIDATION_PATTERN,message=Constants.ROLE_FORMAT) String role) throws TrackerException {
        return userService.getUsers(page, size, sortByField, order, keyword,role,filter);
    }

    @Operation(summary = MessageKeys.USER_GET_BY_ID_TAG_NAME, description = MessageKeys.USER_GET_BY_ID_DESCRIPTION)
    @GetMapping(Constants.USER_BY_ID_PATH)
    @PreAuthorize(Authorities.USER_READ)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getUserById(@PathVariable String userId) {
        return userService.getUserById(userId);
    }

    @Operation(summary = MessageKeys.USER_DELETE_TAG_NAME, description = MessageKeys.USER_DELETE_DESCRIPTION)
    @DeleteMapping(Constants.USER_BY_ID_PATH)
    @PreAuthorize(Authorities.USER_DELETE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> deleteUser(@PathVariable String userId) {
        return userService.deleteUser(userId);
    }

    @Operation(summary = MessageKeys.USER_UPDATE_TAG_NAME, description = MessageKeys.USER_UPDATE_DESCRIPTION)
    @PatchMapping(Constants.USER_BY_ID_PATH)
    @PreAuthorize(Authorities.USER_WRITE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> updateUser(
            @PathVariable String userId,
            @Valid @RequestBody UserUpdateRequest userDto) {
        return userService.updateUser(userId, userDto);
    }

    @Operation(summary = MessageKeys.GET_FREE_USERS_TAG_NAME, description = MessageKeys.GET_FREE_USERS_DESCRIPTION)
    @GetMapping(Constants.GET_FREE_USERS_PATH)
    @PreAuthorize(Authorities.FREE_RECRUITERS)
    @SecurityRequirement(name = Constants.AUTHORIZATION)

    public ResponseEntity<?> getFreeRecruiters( @RequestParam(defaultValue = "0") int page,
                                                @RequestParam(defaultValue = "10") int size,
                                                @RequestParam(defaultValue = "*")
                                                @Pattern(regexp = RegExConstants.ROLE_VALIDATION_PATTERN,message=Constants.ROLE_FORMAT)String role,
                                                @RequestParam(required = true)String jobId){
        return userService.getFreeUsers(page,size,jobId,role);
    }

    @Operation(summary = MessageKeys.GET_USER_JOBS_TAG_NAME, description = MessageKeys.GET_USER_JOBS_DESCRIPTION)
    @GetMapping(Constants.GET_USER_JOBS_PATH)
    @PreAuthorize(Authorities.USER_JOBS)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getUserJobs( @RequestParam(defaultValue = "0") int page,
                                          @RequestParam(defaultValue = "10") int size,
                                          @RequestParam String userId,
                                          @RequestParam(required = false) String clientId){
        return userService.getUserJobs(userId,clientId,page,size);

    }
    @Operation(summary = MessageKeys.UPDATE_INACTIVE_USER_STATUS_TAG_NAME, description = MessageKeys.UPDATE_INACTIVE_USER_STATUS_DESCRIPTION)
    @PatchMapping(Constants.UPDATE_INACTIVE_USER_STATUS_PATH)
    @PreAuthorize(Authorities.USER_WRITE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> updateInactiveUserStatus(
            @PathVariable String userId,
            @Pattern(regexp = RegExConstants.STATUS_VALIDATION_PATTERN, message = "{status.invalid.format}")
            @RequestParam(required = true) String status){
        return userService.updateInactiveUserStatus(userId, status);
    }

    @Operation(summary = MessageKeys.GET_USER_ASSIGNED_CANDIDATES_TAG_NAME, description = MessageKeys.GET_USER_ASSIGNED_CANDIDATES_DESCRIPTION)
    @GetMapping("/assigned-candidates/")
    @PreAuthorize(Authorities.USER_CANDIDATES)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getUserAssignedCandidates(
            @RequestParam String userId,
            @RequestParam(defaultValue = "0",required = false) int page,
            @RequestParam(defaultValue = "10",required = false) int size,
            @RequestParam(defaultValue = "ACTIVE",required = false) String filter,
            @RequestParam(defaultValue = "*" ,required = false)String statusFilter
    ){
        return userService.getUserAssignedCandidates(userId, page, size,filter,statusFilter);
    }

    @Operation(summary = MessageKeys.GET_USER_CREATED_CANDIDATES_TAG_NAME, description = MessageKeys.GET_USER_CREATED_CANDIDATES_DESCRIPTION)
    @GetMapping("/created-candidates/")
    @PreAuthorize(Authorities.USER_CANDIDATES)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getUserCreatedCandidates(
            @RequestParam String userId,
            @RequestParam(defaultValue = "0",required = false) int page,
            @RequestParam(defaultValue = "10",required = false) int size,
            @RequestParam(defaultValue = "ACTIVE",required = false) String filter,
            @RequestParam(defaultValue = "*" ,required = false)String statusFilter
    ) {
        return userService.getUserCreatedCandidates(userId, page, size, filter, statusFilter);
    }

    @Operation(summary = MessageKeys.GET_SCORE, description = MessageKeys.GET_SCORE_DESC)
    @GetMapping("/score")
    @PreAuthorize(Authorities.USER_SCORE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getRecruiterScore(@RequestParam String userId) {
        return scoringService.getUserScoreSummary(userId);
    }

    @Operation(summary = MessageKeys.GET_SCORE_DETAILS, description = MessageKeys.GET_SCORE_DETAILS_DESC)
    @GetMapping("/score/details")
    @PreAuthorize(Authorities.USER_SCORE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getRecruiterScoreDetails(@RequestParam String userId) {
        return scoringService.getUserScoreDetails(userId);
    }

    @Operation(summary = MessageKeys.CLEAR_SCORE, description = MessageKeys.CLEAR_SCORE_DESC)
    @DeleteMapping("/score/clear")
    @PreAuthorize(Authorities.USER_SCORE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> clearRecruiterScores(@RequestParam String userId) {
        return scoringService.clearUserScores(userId);
    }
}