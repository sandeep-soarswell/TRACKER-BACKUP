package com.soarswell.tracker.util;

import java.util.HashMap;
import java.util.Map;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ApiResponses {

    public static Map<String, String> success(String message) {
        Map<String, String> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", message);
        return response;
    }

    // Success messages
    public static final String CREATED = "Resource created successfully";

    // Error messages
    public static final String BAD_REQUEST = "Invalid request";
    public static final String EMAIL_EXISTS = "Email already used";

    // Validation messages
    public static final String NO_COMPANY_FOUND="No company found with provided id";
    public static final String ALREADY_ASSIGNED ="Already this job assigned to this user";
    public static final String CLIENT_NAME_EXISTS = "Client name already exists";
    public static final String CONTACT_PERSON_NUMBER="Contact person number already exists";
    public static final String ALREADY_ASSIGNED_TO_CANDIDATE ="Already candidate assigned to the job ";

}