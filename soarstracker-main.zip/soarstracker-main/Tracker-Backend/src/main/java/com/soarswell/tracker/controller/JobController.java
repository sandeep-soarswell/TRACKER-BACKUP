package com.soarswell.tracker.controller;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.JobRequest;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.model.payload.JobUpdateRequest;
import com.soarswell.tracker.service.JobService;
import com.soarswell.tracker.springsecurity.Authorities;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.MessageKeys;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import com.soarswell.tracker.model.payload.MatchedCandidateResponse;
import com.soarswell.tracker.common.ResponseBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/job")
@Tag(name = Constants.JOB_MANAGEMENT)
@RequiredArgsConstructor
@ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = Constants.API_RESPONSE_OK, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "400", description = Constants.VALIDATION_ERROR, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "401", description = Constants.API_RESPONSE_UNAUTHORIZED, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "404", description = Constants.API_RESPONSE_NOT_FOUND, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "500", description = Constants.API_RESPONSE_ERROR, content = @Content(schema = @Schema(implementation = ResponseObject.class)))
})
public class JobController {

    private final JobService jobService;

    @Autowired
    private RequestDetails requestDetails;

    @Operation(summary = MessageKeys.JOB_CREATION_TAG_NAME, description = MessageKeys.JOB_CREATION_DESCRIPTION)
    @PostMapping("/client/{clientId}/job")
    @PreAuthorize(Authorities.JOB_CREATE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> createJob(@Valid @RequestBody JobRequest jobRequest, @PathVariable String clientId) {
        return jobService.createJob(jobRequest, clientId,requestDetails);
    }

    @Operation(summary = "${api.getJobsByClientId}", description = "${api.fetches.jobs.associated.with.clientId}")
    @GetMapping("/client/jobs")
    @PreAuthorize(Authorities.JOB_LIST)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getJobsByClientId(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(value = Constants.AUTH_KEY,required = false) String authToken,
            @RequestParam(required = false) String clientId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createDate") String sortByField,
            @RequestParam(value="desc/asc",required = false) String order,
            @RequestParam(value = "keyword", required = false) String keyword,
            @RequestParam(defaultValue = "OPEN") String filter) throws TrackerException {
        return jobService.getJobsByClientId(clientId,page, size, sortByField, order, keyword, filter);
    }

    @Operation(summary = MessageKeys.JOB_DELETE_TAG_NAME, description = MessageKeys.JOB_DELETE_DESCRIPTION)
    @DeleteMapping("/{jobId}")
    @PreAuthorize(Authorities.JOB_DELETE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> deleteJob(@PathVariable String jobId) {
        return jobService.deleteJob(jobId);
    }

    @Operation(summary = MessageKeys.JOB_UPDATE, description = MessageKeys.JOB_UPDATE_DESC)
    @PatchMapping("/{jobId}")
    @PreAuthorize(Authorities.JOB_WRITE)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> updateJob(@RequestBody @Valid JobUpdateRequest jobUpdateRequest, @PathVariable String jobId) {
        return jobService.updateJob(jobId, jobUpdateRequest,requestDetails);
    }

    @Operation(summary=MessageKeys.JOB_GET_BY_ID,description = MessageKeys.JOB_GET_BY_ID_DESCRIPTION)
    @GetMapping(path="/{jobId}")
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    @PreAuthorize(Authorities.JOB_READ)
    public ResponseEntity<?> getById(@PathVariable String jobId){
        return jobService.getJob(jobId);
    }

    @Operation(summary = "${api.getUsersByJobId}", description = "${api.fetches.users.associated.with.JobId}")
    @GetMapping("/users/{jobId}")
    @PreAuthorize(Authorities.USERS_LIST_BYJOBID)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getUsersByJobId(
            @PathVariable String jobId) {
        return jobService.getUsersByJobId(jobId);
    }

    @Operation(summary = "${api.getCandidatesByJobId.tag}", description = "${api.getCandidatesByJobId.description}")
    @GetMapping("/candidates")
    @PreAuthorize(Authorities.JOB_LIST)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getCandidatesByJob(
            @RequestParam(name="jobId") String jobId){
        return jobService.getCandidatesByJobId(jobId);
    }

    @Operation(summary = "${api.getCandidatesByJobSkills.tag}", description = "${api.getCandidatesByJobSkills.description}")
    @GetMapping("skills/candidates")
    @PreAuthorize(Authorities.USERS_LIST_BYJOBID)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getCandidatesByJobIdWithSkills(
            @RequestParam(name="jobId") String jobId) {
        return jobService.getCandidatesByJobIdWithSkills(jobId,requestDetails);
    }

    @Operation(summary =MessageKeys.JOB_ASSIGN_USER_TAG , description = MessageKeys.JOB_ASSIGN_USER_DESCRIPTION)
    @PostMapping(path = "/assign-user-job")
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    @PreAuthorize(Authorities.JOB_USER_ASSIGN)
    public ResponseEntity<?> assignJob(@RequestParam(name="userId") String userId,
                                       @RequestParam(name="jobId") String jobId) {
        return jobService.JobAssignToUser(userId, jobId);
    }

    @Operation(summary = MessageKeys.ASSIGN_JOB_CANDIDATE_TAG_NAME, description = MessageKeys.ASSIGN_JOB_CANDIDATE_DESCRIPTION)
    @PostMapping("/assign-candidate-job")
    @PreAuthorize(Authorities.JOB_CANDIDATE_ASSIGN)
    @SecurityRequirement(name =Constants.AUTHORIZATION)
    public ResponseEntity<?> assignJobToCandidate(
            @RequestParam(name="jobId") String jobId,
            @RequestParam(name="candidateId") String candidateId) {
        return jobService.JobAssignToCandidate(candidateId,jobId,requestDetails);
    }

    @Operation(summary = MessageKeys.JOB_UNASSIGN_CANDIDATE_TAG, description = MessageKeys.JOB_UNASSIGN_CANDIDATE_DESCRIPTION)
    @PostMapping("/unassign-candidate-job")
    @SecurityRequirement(name=Constants.AUTHORIZATION)
    @PreAuthorize(Authorities.JOB_CANDIDATE_UNASSIGN)
    public ResponseEntity<?> jobUnassignFromCandidate(
            @RequestParam(name="jobId") String jobId,
            @RequestParam(name="candidateId") String candidateId) {
        return jobService.JobUnassignFromCandidate(candidateId, jobId);
    }

    @Operation(summary = MessageKeys.JOB_UNASSIGN_USER_TAG, description = MessageKeys.JOB_UNASSIGN_USER_DESCRIPTION)
    @PostMapping("/unassign-user-job")
    @SecurityRequirement(name=Constants.AUTHORIZATION)
    @PreAuthorize(Authorities.JOB_USER_UNASSIGN)
    public ResponseEntity<?> jobUnassignFromUser(
            @RequestParam(name="jobId") String jobId,
            @RequestParam(name="userId") String userId) {
        return jobService.JobUnassignFromUser(userId, jobId);
    }
    @GetMapping("/notifications")
    @PreAuthorize(Authorities.IS_AUTHENTICATED)
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)}, summary = "Get upcoming job deadline notifications", description = "Retrieves notifications for jobs with deadline of today.")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved job deadline notifications")
    public ResponseEntity<?> getUpcomingJobDeadlineNotifications(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTH_KEY) String authToken) {
        return jobService.getUpcomingJobDeadlineNotifications(requestDetails);
    }

    @PatchMapping("/notifications")
    @PreAuthorize("isAuthenticated()")
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)}, summary = "Mark notification as Read")
    public ResponseEntity<?> markAsRead(
            @RequestParam(name="eventId") String jobId) {
        return jobService.markNotificationAsRead(jobId,requestDetails);
    }
    @Operation(summary = MessageKeys.UPLOAD_BULK_JOBS, description = MessageKeys.UPLOAD_BULK_JOBS_DESC)
    @PostMapping(value = "/upload/{clientId}", consumes = {"multipart/form-data"})
    @PreAuthorize(Authorities.JOB_UPLOAD_LIST)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> uploadjobs(
            @Parameter(description = MessageKeys.FILE_NAME_FORMATE, required = true, content = @Content(mediaType = "multipart/form-data", schema = @Schema(type = "string", format = "binary")))
            @RequestParam("file") MultipartFile file,
            @PathVariable String clientId) {
        return jobService.uploadjobs(file, requestDetails, clientId);
    }

    @Operation(summary = "Find Matching Candidates for a Job", description = "Uses AI to analyze and rank all candidates based on their suitability for a specific job.")
    @GetMapping("/{jobId}/find-matches")
    @PreAuthorize(Authorities.JOB_READ)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> findMatchingCandidates(@PathVariable String jobId) {
        List<MatchedCandidateResponse> matches = jobService.findMatchingCandidates(jobId);
        if (matches.isEmpty()) {
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse("No suitable candidates found."), HttpStatus.OK);
        }
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(matches), HttpStatus.OK);
    }
}