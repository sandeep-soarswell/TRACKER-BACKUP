package com.soarswell.tracker.common;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResponseErrorObject {

    public String getMessage() {
        return "Error: " + (error != null ? error.toString() : "Unknown error");
    }

    private Object error;
    private String message;
}