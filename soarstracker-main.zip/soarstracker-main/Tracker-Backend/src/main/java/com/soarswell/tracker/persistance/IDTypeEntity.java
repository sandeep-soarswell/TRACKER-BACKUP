package com.soarswell.tracker.persistance;
public interface IDTypeEntity extends IDEntity {

}
