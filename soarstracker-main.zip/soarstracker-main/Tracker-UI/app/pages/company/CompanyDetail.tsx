import React, { useEffect, useState } from "react";
import type { CompanyType } from "~/pages/types/types";
import DrawerLayout from "~/components/layout/DrawerLayout";
import companyService from "~/services/company/company.service";

const CompanyDetailsDrawer = ({ open, onClose, company }: { open: boolean; onClose: () => void; company: CompanyType | null; }) => {
  const [companyImageUrl, setCompanyImageUrl] = useState<string | null>(null);

  useEffect(() => {
    const loadCompanyImage = async () => {
      const hasImage = company?.imageFile &&
        company.imageFile !== 'false' &&
        company.imageFile !== 'null' &&
        company.imageFile !== '' &&
        company?.id;

      if (hasImage && company?.id) {
        try {
          const token = localStorage.getItem('userToken');
          if (token) {
            const imageUrl = await companyService.getCompanyImage(company.id, token);
            setCompanyImageUrl(imageUrl);
          }
        } catch (error) {
          setCompanyImageUrl(null);
        }
      } else {
        setCompanyImageUrl(null);
      }
    };

    if (open && company) {
      loadCompanyImage();
    } else {
      setCompanyImageUrl(null);
    }
  }, [open, company]);

  if (!open || !company) return null;

  const fields = [
    { label: "Company Name", value: company.companyName },
    { label: "Company Email", value: company.emailId },
    { label: "Company Address", value: company.companyAddress },
    { label: "Company Registration Number", value: company.companyRegNo },
    { label: "Company Mobile Number", value: `${company.mobileNo && company.mobileNo !== '-' ? company.mobileNo : '—'}`.trim() },
    { label: "Alternate Number", value: `${company.alternateNo && company.alternateNo !== '-' ? company.alternateNo : '—'}`.trim() },
    { label: "Status", value: company.status },
    { label: "Personal Email", value: company.personalMailId },
  ];

  return (
    <DrawerLayout title="Company Details" onClose={onClose}>
      <div className="space-y-6">
        {companyImageUrl && (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Company Logo</label>
            <div className="w-full h-48 border border-gray-300 rounded-lg overflow-hidden">
              <img
                src={companyImageUrl}
                alt="Company logo"
                className="w-full h-full object-contain bg-gray-50"
              />
            </div>
          </div>
        )}
        <form className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4">
          {fields.map(({ label, value }) => (
            <div key={label}>
              <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
              <input
                type="text"
                value={typeof value === 'string' || typeof value === 'number' ? String(value) : '—'}
                readOnly
                className="w-full px-3 py-2 rounded-md text-sm !bg-gray-100 cursor-not-allowed focus:outline-none border-0"
                style={{ boxShadow: 'none' }}
              />
            </div>
          ))}
        </form>
      </div>
    </DrawerLayout>
  );
};

export default CompanyDetailsDrawer;