import React, { useEffect, useState, useMemo } from 'react';
import { StatCard } from './StatCard';
import jobService from '~/services/job/job.services';
import candidateService from '~/services/candidate/candidate.service';
import eventService from '~/services/event/event.service';
import clientService from '~/services/client/client.services';
import userService from '~/services/employee/employee.service';
import Card from '~/components/ui/Card';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import { Link, useNavigate } from 'react-router';
import { jwtDecode } from 'jwt-decode';
import { BusinessCenter, People, EventAvailable, HowToReg, Timeline } from '@mui/icons-material';

interface Candidate {
  id: string;
  createdBy?: string;
  candidatureStatus?: 'Created' | 'Pending' | 'Interviewing' | 'Hired' | 'Rejected' | 'Job Assigned' | string;
}

interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  tooltip?: { name: string };
  startDateTime?: Date;
}

interface Job {
  id: string;
  title: string;
  clientId: string;
  clientName: string;
  status: 'OPEN' | 'CLOSED';
  openings: number;
}

interface Client {
  id: string;
  clientName: string;
  status: 'ACTIVE' | 'INACTIVE';
}

interface DecodedToken {
  userId?: string;
  roles?: string[];
  sub?: string;
  oid?: string;
  id?: string;
  email?: string;
}

const RecruiterDashboard: React.FC = () => {
  const [totalOpenJobs, setTotalOpenJobs] = useState<number>(0);
  const [totalCandidates, setTotalCandidates] = useState<number>(0);
  const [interviewingCandidates, setInterviewingCandidates] = useState<number>(0);
  const [hiredCandidates, setHiredCandidates] = useState<number>(0);
  const [upcomingEvents, setUpcomingEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [pieChartLoading, setPieChartLoading] = useState<boolean>(true);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'error'>('success');
  const [ChartComponent, setChartComponent] = useState<React.ComponentType<any> | null>(null);
  const [totalJobs, setTotalJobs] = useState<number>(0);
  const [clientNameToId, setClientNameToId] = useState<{ [name: string]: string }>({});
  const [jobsPerClient, setJobsPerClient] = useState<{ [client: string]: number }>({});
  const [jobsStatusByClient, setJobsStatusByClient] = useState<{ [client: string]: { open: number; closed: number } }>({});
  const [candidatesByStatusData, setCandidatesByStatusData] = useState<{ name: string; data: number[] }>({ name: 'Candidates', data: [] });
  const [candidatesByStatusLabels, setCandidatesByStatusLabels] = useState<string[]>([]);
  const [donutHoverInfo, setDonutHoverInfo] = useState<{ label: string; value: string } | null>(null);
  const [openingsPerClient, setOpeningsPerClient] = useState<{ [client: string]: number }>({});
  const navigate = useNavigate();

  const customPalette = ["#8bbcebff", "#a8f050ff", "#eb98e8ff", "#f3c769ff", "#4472C4", '#66CDAA', "#9E480E"];

  const showSnackbar = (message: string, severity: 'success' | 'error' = 'success') => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  };

  useEffect(() => {
    const loadChart = async () => {
      try {
        const { default: ReactApexChart } = await import('react-apexcharts');
        setChartComponent(() => ReactApexChart);
      } catch (error) {
      }
    };
    loadChart();
  }, []);

  useEffect(() => {
    const userToken = localStorage.getItem('userToken');
    if (!userToken) {
      showSnackbar('No user token found. Please log in.', 'error');
      navigate('/login');
      return;
    }

    let decoded: DecodedToken;
    try {
      decoded = jwtDecode(userToken);
    } catch (error) {
      showSnackbar('Failed to decode user token.', 'error');
      navigate('/login');
      return;
    }

    const userId = decoded?.userId || '';
    const role = decoded?.roles?.[0] || '';
    const username = decoded?.sub || '';

    const fetchOpenJobs = async () => {
      try {
        let totalOpenJobsCount = 0;

        const response = await userService.getJobsByUserId(userId, '');
        if (Array.isArray(response?.data?.records)) {
          const openJobs = response.data.records.filter((job: Job) => job.status === 'OPEN');
          totalOpenJobsCount = openJobs.length;
        }

        setTotalOpenJobs(totalOpenJobsCount);
      } catch (error) {
        showSnackbar('Failed to fetch open jobs for this user.', 'error');
      }
    };


    const fetchRecruiterCandidates = async (): Promise<Candidate[]> => {
      if (role === 'RECRUITER') {
        let assignedCandidates: Candidate[] = [];
        let createdCandidates: Candidate[] = [];

        try {
          const decoded: any = jwtDecode(userToken);
          const userId = decoded?.userId
          const assignedResponse = await userService.getAssignedCandidatesByUserId({ userId, page: 0, size: 2000, filter: 'All', statusFilter: 'All' });
          if (Array.isArray(assignedResponse?.data?.records)) {
            assignedCandidates = assignedResponse.data.records.filter((c: Candidate) => c && c.id)||[];
          }
        } catch (error) {
        }

        try {
          const allResponse = await userService.getCreatedCandidatesByUserId({ userId, page: 0, size: 2000, filter: 'All', statusFilter: 'All' });
          if (Array.isArray(allResponse?.content)) {
            createdCandidates = allResponse.data.records.filter((c: Candidate) => c && c.id)|| []
          }
        } catch (error) {
        }

        const candidateMap = new Map<string, Candidate>();
        [...assignedCandidates, ...createdCandidates].forEach((c) => {
          if (c?.id) candidateMap.set(c.id, c);
        });

        return Array.from(candidateMap.values());
      } else {
        const response = await candidateService.getAll(0, 2000, '', 'ALL');
        return response?.content || [];
      }
    };

    const processCandidateStats = (candidates: Candidate[]) => {
      setTotalCandidates(candidates.length);
      const interviewing = candidates.filter(c => c.candidatureStatus?.toLowerCase() === 'interviewing').length;
      setInterviewingCandidates(interviewing);
      const hired = candidates.filter(c => c.candidatureStatus?.toLowerCase() === 'hired').length;
      setHiredCandidates(hired);

      const candidatureStatuses: string[] = ['Created', 'Pending', 'Interviewing', 'Hired', 'Rejected'];
      const statusCounts = candidatureStatuses.map(status =>
        candidates.filter(c => c.candidatureStatus?.toLowerCase() === status.toLowerCase()).length
      );
      const statusLabels = candidatureStatuses.map(s => s.replace('_', ' '));
      setCandidatesByStatusData({ name: 'Candidates', data: statusCounts });
      setCandidatesByStatusLabels(statusLabels);
    };

    const fetchUpcomingEvents = async () => {
      const allEventsData = await eventService.getAll();
      const now = new Date();

      const normalizedEvents = allEventsData.map((item: any) => {
        if (item.event && item.candidate) {
          return { ...item.event, tooltip: { name: item.candidate.name } };
        }
        return item;
      });

      const upcoming = normalizedEvents
        .map((event: any) => ({
          ...event,
          startDateTime: new Date(`${event.date}T${event.startTime}`),
        }))
        .filter((event: any) => event.startDateTime instanceof Date && !isNaN(event.startDateTime.getTime()) && event.startDateTime >= now)
        .sort((a: any, b: any) => a.startDateTime.getTime() - b.startDateTime.getTime())
        .slice(0, 3);

      setUpcomingEvents(upcoming);
    };

    const fetchClients = async (): Promise<Client[]> => {
      const activeRes = await clientService.getAll(0, 1000, '', 'ACTIVE', 'createDate', 'desc');
      const inactiveRes = await clientService.getAll(0, 1000, '', 'INACTIVE', 'createDate', 'desc');
      const clientsList: Client[] = [...(activeRes.content || []), ...(inactiveRes.content || [])];
      const nameToIdMap: { [name: string]: string } = {};
      clientsList.forEach((c) => {
        if (c.id && c.clientName) nameToIdMap[c.clientName] = c.id;
      });
      setClientNameToId(nameToIdMap);
      return clientsList;
    };

    const fetchJobs = async (clientsList: Client[]) => {
      try {
        let allJobs: Job[] = [];

        const res = await userService.getJobsByUserId(userId, '');
        if (Array.isArray(res?.data?.records)) {
          allJobs = res.data.records.filter((j: Job) => j && j.id);
        }

        setTotalJobs(allJobs.length);

        const jobsPerClientMap: { [clientName: string]: number } = {};
        const openingsPerClientMap: { [clientName: string]: number } = {};
        const jobsStatusByClientMap: { [clientName: string]: { open: number; closed: number } } = {};

        allJobs.forEach((job) => {
          const finalName =
            clientsList.find((c) => c.id === job.clientId)?.clientName ||
            job.clientName ||
            'Unknown';

          jobsPerClientMap[finalName] = (jobsPerClientMap[finalName] || 0) + 1;
          openingsPerClientMap[finalName] =
            (openingsPerClientMap[finalName] || 0) + (job.openings || 0);

          if (!jobsStatusByClientMap[finalName]) {
            jobsStatusByClientMap[finalName] = { open: 0, closed: 0 };
          }

          if (job.status.toLowerCase() === 'open') {
            jobsStatusByClientMap[finalName].open++;
          } else {
            jobsStatusByClientMap[finalName].closed++;
          }
        });

        setJobsPerClient(jobsPerClientMap);
        setOpeningsPerClient(openingsPerClientMap);
        setJobsStatusByClient(jobsStatusByClientMap);
      } catch (error) {
        console.error('Failed to fetch user-specific jobs', error);
        showSnackbar('Failed to fetch jobs for this user.', 'error');
      }
    };

    const fetchAllData = async () => {
      setLoading(true);
      setPieChartLoading(true);
      try {
        const [clientsList, allRecruiterCandidates] = await Promise.all([
          fetchClients(),
          fetchRecruiterCandidates()
        ]);

        processCandidateStats(allRecruiterCandidates);

        await Promise.all([
          fetchOpenJobs(),
          fetchUpcomingEvents(),
          fetchJobs(clientsList),
        ]);
      } catch (error) {
        showSnackbar('Failed to fetch dashboard data.', 'error');
      } finally {
        setLoading(false);
        setPieChartLoading(false);
      }
    };

    fetchAllData();
  }, [navigate]);

  const handleJobsPerClientClick = (client: string) => {
    const clientId = clientNameToId[client];
    if (clientId) {
      navigate('/dashboard/jobs', { state: { clientId } });
    } else {
      navigate('/dashboard/jobs');
    }
  };

  const handleEventClick = (event: CalendarEvent) => {
    if (event.startDateTime) {
      navigate('/dashboard/calendar', { state: { targetDate: event.startDateTime.toISOString() } });
    }
  };

  const TOP_N = 6;
  const chartData = useMemo(() => {
    const clientNames = Object.keys(jobsStatusByClient)
      .filter(name => jobsStatusByClient[name]?.open > 0)
      .sort((a, b) => jobsStatusByClient[b].open - jobsStatusByClient[a].open);
    const topClientNames = clientNames.slice(0, TOP_N);
    const jobCounts = topClientNames.map(name => jobsStatusByClient[name].open);
    // Optionally group the rest as 'Others'
    const otherCount = clientNames.slice(TOP_N).reduce((sum, name) => sum + jobsStatusByClient[name].open, 0);
    let labels = [...topClientNames];
    let series = [...jobCounts];
    if (otherCount > 0) {
      labels.push('Others');
      series.push(otherCount);
    }
    return { labels, series };
  }, [jobsStatusByClient]);

  const donutChartOptions = useMemo(() => ({
    chart: {
      type: 'donut',
      events: {
        dataPointMouseEnter: (event: MouseEvent, chartContext: any, config: { dataPointIndex: number }) => {
          const clientName = chartData.labels[config.dataPointIndex];
          const total = jobsStatusByClient[clientName]?.open || 0;
          if (clientName) {
            setDonutHoverInfo({ label: clientName, value: `${total}` });
          }
        },
        mouseLeave: () => setDonutHoverInfo(null),
        dataPointSelection: (event: MouseEvent, chartContext: any, config: { dataPointIndex: number }) => {
          const client = chartData.labels[config.dataPointIndex];
          handleJobsPerClientClick(client);
        },
      },
    },
    plotOptions: {
      pie: {
        donut: {
          size: '65%',
          labels: {
            show: true,
            total: {
              show: true,
              showAlways: true,
              label: donutHoverInfo ? donutHoverInfo.label : 'Open Jobs',
              fontSize: donutHoverInfo ? '16px' : '22px',
              fontWeight: donutHoverInfo ? 400 : 600,
              color: '#374151',
              formatter: () => donutHoverInfo ? donutHoverInfo.value : `${chartData.series.reduce((a, b) => a + b, 0)}`,
            }
          }
        }
      }
    },
    tooltip: {
      custom: function ({ seriesIndex, w }: any) {
        const clientName = w.globals.labels[seriesIndex];
        const openJobs = jobsStatusByClient[clientName]?.open || 0;
        return `<div class="p-2 bg-gray-800 text-white rounded-lg shadow-xl border border-gray-700">
                  <div class="font-bold text-base mb-1">${clientName}</div>
                  <div class="flex items-center"><span class="w-2 h-2 rounded-full bg-green-400 mr-2"></span>Open: ${openJobs}</div>
                </div>`;
      }
    },
    dataLabels: {
      enabled: true,
      formatter: (val: number) => `${val.toFixed(0)}%`,
      style: { colors: ['#fff'], fontWeight: 'bold' },
      dropShadow: { enabled: true, top: 1, left: 1, blur: 1, color: '#000', opacity: 0.45 }
    },
    legend: {
      show: true,
      position: 'bottom',
      horizontalAlign: 'center',
      offsetY: 5,
      fontSize: '14px',
      fontWeight: 500,
      markers: {
        width: 12,
        height: 12,
        radius: 6
      },
      itemMargin: {
        horizontal: 8,
        vertical: 4
      }
    },
    colors: customPalette,
    labels: chartData.labels,
  }), [chartData, donutHoverInfo, jobsStatusByClient, customPalette]);

  return (
    <div className="space-y-6">
      <CustomSnackbar open={snackbarOpen} message={snackbarMessage} severity={snackbarSeverity} onClose={() => setSnackbarOpen(false)} autoHideDuration={3000} />

      <div className="bg-white rounded-xl p-8 border border-blue-200/20">
        <h1 className="text-3xl font-bold mb-2 text-gray-900">Recruiter Dashboard</h1>
        <p className="text-gray-700 text-lg">Quick overview of your recruiting activities</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Open Jobs" icon={BusinessCenter} color="blue" value={totalOpenJobs} onClick={() => navigate('/dashboard/jobs')} />
        <StatCard title="Total Candidates" icon={People} color="blue" value={totalCandidates} onClick={() => navigate('/dashboard/candidates')} />
        <StatCard title="Candidates Interviewing" icon={EventAvailable} color="blue" value={interviewingCandidates} onClick={() => navigate('/dashboard/candidates', { state: { candidatureStatus: 'Interviewing' } })} />
        <StatCard title="Hired Candidates" icon={HowToReg} color="blue" value={hiredCandidates} onClick={() => navigate('/dashboard/candidates', { state: { candidatureStatus: 'Hired' } })} />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      

        <Card className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Jobs by Client</h3>
          {pieChartLoading ? (
            <p className="text-gray-500">Loading...</p>
          ) : ChartComponent && Object.keys(chartData.labels).length > 0 ? (
            <ChartComponent
              options={donutChartOptions}
              series={chartData.series}
              type="donut"
              height={350}
            />
          ) : (
            <p className="text-gray-500">No job data available.</p>
          )}
        </Card>
         
         <Card className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Total Job Openings by Client</h3>
          {loading ? (
            <p className="text-gray-500">Loading...</p>
          ) : ChartComponent && Object.keys(openingsPerClient).length > 0 ? (
            <ChartComponent
              options={{
                chart: {
                  type: 'bar',
                  height: 350,
                  toolbar: { show: false },
                  selection: { enabled: false },
                  events: {
                    dataPointSelection: (event: MouseEvent, chartContext: any, config: { dataPointIndex: number }) => {
                      const client = Object.keys(openingsPerClient)[config.dataPointIndex];
                      handleJobsPerClientClick(client);
                    }
                  }
                },
                colors: customPalette,
                plotOptions: { bar: { horizontal: false, columnWidth: '25%', endingShape: 'rounded' } },
                dataLabels: { enabled: false },
                stroke: { show: true, width: 2, colors: ['transparent'] },
                xaxis: {
                  categories: Object.keys(openingsPerClient),
                  title: { text: 'Client' },
                  labels: {
                    rotate: 0,
                    rotateAlways: false,
                    style: { fontSize: '12px' },
                    formatter: (value: string) => value.length > 10 ? `${value.substring(0, 10)}...` : value
                  }
                },
                yaxis: { title: { text: 'Number of Job Openings' } },
                fill: { opacity: 1 },
                tooltip: { y: { formatter: (val: number) => `${val} openings` } },
              }}
              series={[{ name: 'Job Openings', data: Object.values(openingsPerClient) }]}
              type="bar"
              height={350}
            />
          ) : (
            <p className="text-gray-500">No job openings data available.</p>
          )}
        </Card>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
           <Card className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Overall Candidates by Status</h3>
          {loading ? (
            <p className="text-gray-500">Loading...</p>
          ) : ChartComponent && candidatesByStatusData.data.some(d => d > 0) ? (
            <ChartComponent
              options={{
                chart: { type: 'bar', height: 350, toolbar: { show: false }, selection: { enabled: false } },
                colors: customPalette,
                plotOptions: { bar: { horizontal: false, columnWidth: '25%', endingShape: 'rounded' } },
                dataLabels: { enabled: false },
                stroke: { show: true, width: 2, colors: ['transparent'] },
                xaxis: { categories: candidatesByStatusLabels },
                yaxis: { title: { text: 'Number of Candidates' } },
                fill: { opacity: 1 },
                tooltip: { y: { formatter: (val: number) => `${val} candidates` } },
              }}
              series={[candidatesByStatusData]} type="bar" height={350}
            />
          ) : (
            <p className="text-gray-500">No overall candidate status data available.</p>
          )}
        </Card>
       

        <Card className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Events</h3>
          {loading ? (
            <p className="text-gray-500">Loading...</p>
          ) : upcomingEvents.length > 0 ? (
            <ul className="space-y-3" role="list" aria-label="Upcoming events">
              {upcomingEvents.map((event) => (
                <li
                  key={event.id}
                  className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-200"
                  onClick={() => handleEventClick(event)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === 'Enter' && handleEventClick(event)}
                >
                  <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center bg-[#0A2463] text-white rounded-full">
                    <Timeline className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{event.title}</p>
                    <p className="text-sm text-gray-600">
                      {event.startDateTime?.toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })} at {event.startTime} - {event.endTime}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No upcoming events scheduled.</p>
          )}
          <Link to="/dashboard/calendar" className="block mt-4 text-blue-600 hover:underline">
            View All Calendar Events
          </Link>
        </Card>
      </div>
    </div>
  );
};

export default RecruiterDashboard;