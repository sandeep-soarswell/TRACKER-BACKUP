import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import DrawerLayout from '~/components/layout/DrawerLayout';
import clientService from '~/services/client/client.services';
import type { Client } from '~/pages/types/types';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import Button from '~/components/ui/Button';
import Select from 'react-select';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import { isValidPhoneNumber } from 'libphonenumber-js';
import getChangedFields from '~/components/util/update-util';

const validationSchema = Yup.object({
  clientName: Yup.string()
    .trim()
    .min(3, 'Minimum 3 characters')
    .max(50, 'Maximum 50 characters')
    .required('Please enter client name'),
  email: Yup.string()
    .trim()
    .email('Enter a valid email')
    .matches(/^[a-z][a-z0-9._%+-]*@[a-z0-9.-]+\.[a-z]{2,}$/, 'Invalid email format')
    .required('Please enter email'),
  contactPersonNumber: Yup.string()
    .required('Phone number is required')
    .test('is-valid-phone', 'Invalid phone number for selected country', function (value) {
      if (!value) return false;
      return isValidPhoneNumber(value);
    }),
  contactPersonName: Yup.string()
    .trim()
    .min(3, 'Minimum 3 characters')
    .max(25, 'Maximum 25 characters')
    .required('Contact person name is required'),
  website: Yup.string()
    .trim()
    .url('Must be a valid URL')
    .required('Website is required'),
  address: Yup.string()
    .trim()
    .min(5, 'Minimum 5 characters')
    .max(100, 'Maximum 100 characters')
    .required('Address is required'),
  country: Yup.string()
    .trim()
    .required('Country is required'),
  state: Yup.string().trim().notRequired(),
  status: Yup.string().oneOf(['active', 'inactive']).notRequired(),
  zipCode: Yup.string()
    .trim()
    .min(5, 'Zip code must be at least 5 characters')
    .max(10, 'Zip code must be at most 10 characters')
    .notRequired(),
  coolingPeriod: Yup.number().optional()
    .min(0, 'Cooling period must be positive(in days)')
    .max(365, 'Cooling period must be at most 365 days')
    .required('Cooling period is required'),

});

const countryStateMap = {
  India: [
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
    "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
    "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
    "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim",
    "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand",
    "West Bengal", "Delhi", "Puducherry", "Other"
  ],
  USA: [
    "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado",
    "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho",
    "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana",
    "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota",
    "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada",
    "New Hampshire", "New Jersey", "New Mexico", "New York",
    "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
    "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota",
    "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
    "West Virginia", "Wisconsin", "Wyoming", "Other"
  ],
  UK: ["England", "Scotland", "Wales", "Northern Ireland", "Other"],
  Australia: [
    "New South Wales", "Queensland", "South Australia", "Tasmania",
    "Victoria", "Western Australia", "Australian Capital Territory",
    "Northern Territory", "Other"
  ],
  Germany: [
    "Baden-Württemberg", "Bavaria", "Berlin", "Brandenburg", "Bremen",
    "Hamburg", "Hesse", "Lower Saxony", "Mecklenburg-Vorpommern",
    "North Rhine-Westphalia", "Rhineland-Palatinate", "Saarland",
    "Saxony", "Saxony-Anhalt", "Schleswig-Holstein", "Thuringia", "Other"
  ],
  China: [
    "Anhui", "Beijing", "Chongqing", "Fujian", "Gansu", "Guangdong",
    "Guangxi", "Guizhou", "Hainan", "Hebei", "Heilongjiang", "Henan",
    "Hong Kong", "Hubei", "Hunan", "Inner Mongolia", "Jiangsu",
    "Jiangxi", "Jilin", "Liaoning", "Macau", "Ningxia", "Qinghai",
    "Shaanxi", "Shandong", "Shanghai", "Shanxi", "Sichuan", "Tianjin",
    "Tibet", "Xinjiang", "Yunnan", "Zhejiang", "Other"
  ],
  Japan: [
    "Aichi", "Akita", "Aomori", "Chiba", "Ehime", "Fukui", "Fukuoka",
    "Fukushima", "Gifu", "Gunma", "Hiroshima", "Hokkaido", "Hyogo",
    "Ibaraki", "Ishikawa", "Iwate", "Kagawa", "Kagoshima", "Kanagawa",
    "Kochi", "Kumamoto", "Kyoto", "Mie", "Miyagi", "Miyazaki", "Nagano",
    "Nagasaki", "Nara", "Niigata", "Oita", "Okayama", "Okinawa", "Osaka",
    "Saga", "Saitama", "Shiga", "Shimane", "Shizuoka", "Tochigi",
    "Tokushima", "Tokyo", "Tottori", "Toyama", "Wakayama", "Yamagata",
    "Yamaguchi", "Yamanashi", "Other"
  ],
};

interface ClientFormProps {
  client?: Client;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

const ClientRegistration: React.FC<ClientFormProps> = ({ client, onClose, onSuccess }) => {
  const [openSnackbar, setOpenSnackbar] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [snackbarSeverity, setSnackbarSeverity] = React.useState<'success' | 'error'>('success');
  const isEditMode = Boolean(client);

  const editableFieldsInEditMode = new Set([
    'contactPersonNumber',
    'contactPersonName',
    'address',
    'website',
    'country',
    'state',
    'zipCode',
    'coolingPeriod',
  ]);

  const formik = useFormik({
    initialValues: {
      clientName: client?.clientName || '',
      email: client?.email || '',
      contactPersonNumber: client?.contactPersonNumber ? String(client.contactPersonNumber).replace(/\D/g, '') : '',
      contactPersonName: client?.contactPersonName || '',
      website: client?.website || '',
      address: client?.address || '',
      country: client?.country || '',
      state: client?.state || '',
      zipCode: client?.zipCode || '',
      status: client?.status?.toLowerCase() || 'active',
      coolingPeriod: client?.coolingPeriod || '',
    },

    validationSchema,
    onSubmit: async (values) => {
      try {
        const payload = {
          ...values,
          clientName: values.clientName.trim() || null,
          email: values.email.trim() || null,
          address: values.address.trim() || null,
          contactPersonName: values.contactPersonName.trim() || null,
          website: values.website.trim() || null,
          country: values.country.trim() || null,
          state: values.state.trim() || null,
          zipCode: values.zipCode.trim() || null,
          coolingPeriod: values.coolingPeriod !== '' ? Number(values.coolingPeriod) : 0,
          status: values.status === 'Inactive' ? 'Active' : values.status,
        };

        let apiMessage = '';
        if (isEditMode && client?.id) {
          const changedPayload = getChangedFields(client, payload);
          const updatedResponse = await clientService.update(String(client.id), changedPayload);
          apiMessage = updatedResponse?.data || 'Client updated successfully';
          console.log(apiMessage);
          setAlertMessage(apiMessage);
          setSnackbarSeverity('success');
        } else {
          const createdResponse = await clientService.create(payload);
          apiMessage = createdResponse?.data || 'Client created successfully';
          setAlertMessage(apiMessage);
          setSnackbarSeverity('success');
        }
        onSuccess(apiMessage);
      } catch (error: any) {
        formik.setSubmitting(false);
        const backendErrors = error?.response?.data?.error || {};
        let hasFieldError = false;

        if (backendErrors && backendErrors.EMAIL) {
          formik.setFieldError('email', backendErrors.EMAIL as string);
          hasFieldError = true;
        }

        if (backendErrors && backendErrors.PHONE) {
          formik.setFieldError('contactPersonNumber', backendErrors.PHONE as string);
          hasFieldError = true;
        }

        if (backendErrors && backendErrors["client-name"]) {
          formik.setFieldError('clientName', backendErrors["client-name"] as string);
          hasFieldError = true;
        }

        Object.entries(backendErrors).forEach(([field, message]) => {
          if (field !== "message") {
            formik.setFieldError(field, message as string);
            hasFieldError = true;
          }
        });

        if (!hasFieldError) {
          const backendMsg = error?.response?.data?.message || error?.message || 'Unknown error';
          setAlertMessage(backendMsg);
          setSnackbarSeverity('error');
          setOpenSnackbar(true);
          formik.setStatus({ error: backendMsg });
        }

        setTimeout(() => {
          const firstErrorField = Object.keys(formik.errors)[0];
          if (firstErrorField) {
            const el = document.querySelector(`[name="${firstErrorField}"]`) as HTMLElement;
            el?.focus();
          }
        }, 0);
      }
    },
  });

  const hasEditableChanges = () => {
    if (!isEditMode) return formik.dirty;

    return Array.from(editableFieldsInEditMode).some((field) => {
      const fieldName = field as keyof typeof formik.values;
      const initialValue = formik.initialValues[fieldName];
      const currentValue = formik.values[fieldName];
      if (field === 'contactPersonNumber') {
        const initPhone = (initialValue as string)?.replace(/\D/g, '') ?? '';
        const currPhone = (currentValue as string)?.replace(/\D/g, '') ?? '';
        return initPhone !== currPhone;
      }

      const normalizedInitial = typeof initialValue === 'string' ? initialValue.trim() : initialValue ?? '';
      const normalizedCurrent = typeof currentValue === 'string' ? currentValue.trim() : currentValue ?? '';

      return normalizedInitial !== normalizedCurrent;
    });
  };

  Array.from(editableFieldsInEditMode).forEach((field) => {
    const i = formik.initialValues[field as keyof typeof formik.values];
    const v = formik.values[field as keyof typeof formik.values];
  });


  return (
    <>
      <CustomSnackbar
        open={openSnackbar}
        message={alertMessage}
        onClose={() => setOpenSnackbar(false)}
        severity={snackbarSeverity}
        autoHideDuration={5000}
      />
      <DrawerLayout
        title={isEditMode ? 'Edit Client' : 'Register Client'}
        onClose={onClose}
        footer={
          <Button
            variant="primary"
            type="button"
            onClick={() => formik.handleSubmit()}
            disabled={
              !formik.isValid ||
              formik.isSubmitting ||
              (isEditMode && !hasEditableChanges())
            }
          >
            {isEditMode ? 'Update' : 'Create'}
          </Button>
        }
      >
        <form id="registerform" onSubmit={formik.handleSubmit} className="space-y-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="clientName" className="block text-sm font-medium text-gray-700 mb-1">
              Client Name <span className="text-red-500">*</span>
            </label>
            <input
              id="clientName"
              name="clientName"
              type="text"
              value={formik.values.clientName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled={isEditMode}
              className={`w-full px-3 py-2 rounded-md border text-sm ${isEditMode ? '!bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'} ${formik.touched.clientName && formik.errors.clientName ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.clientName && formik.errors.clientName && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.clientName}</p>
            )}
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
              Email <span className="text-red-500">*</span>
            </label>
            <input
              id="email"
              name="email"
              type="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled={isEditMode}
              className={`w-full px-3 py-2 rounded-md border text-sm ${isEditMode ? '!bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'} ${formik.touched.email && formik.errors.email ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.email && formik.errors.email && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.email}</p>
            )}
          </div>
          <div>
            <label htmlFor="contactPersonNumber" className="block text-sm font-medium text-gray-700 mb-1">
              Mobile Number <span className="text-red-500">*</span>
            </label>
            <PhoneInput
              defaultCountry="in"
              value={formik.values.contactPersonNumber}
              onChange={(value) => {
                formik.setFieldValue('contactPersonNumber', value);
              }}
              onBlur={() => formik.setFieldTouched('contactPersonNumber', true)}
              forceDialCode
              inputProps={{
                id: 'contactPersonNumber',
                name: 'contactPersonNumber',
                className: `w-full px-3 py-2 rounded-r-md border text-sm bg-white ${formik.touched.contactPersonNumber && formik.errors.contactPersonNumber
                  ? 'border-red-500'
                  : 'border-gray-300'
                  }`,
                style: { height: '40px' },
              }}
              style={{
                display: 'flex',
                alignItems: 'center',
              }}
              countrySelectorStyleProps={{
                buttonStyle: {
                  height: '40px',
                  border: formik.touched.contactPersonNumber && formik.errors.contactPersonNumber
                    ? '1px solid #ef4444'
                    : '1px solid #d1d5db',
                  borderRadius: '6px 0 0 6px',
                  background: '#fff',
                  padding: '0 8px',
                },
              }}
              inputStyle={{
                borderRadius: '0 6px 6px 0',
                borderLeft: 'none',
              }}
            />
            {formik.touched.contactPersonNumber && formik.errors.contactPersonNumber && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.contactPersonNumber}</p>
            )}
          </div>
          <div>
            <label htmlFor="contactPersonName" className="block text-sm font-medium text-gray-700 mb-1">
              Contact Person <span className="text-red-500">*</span>
            </label>
            <input
              id="contactPersonName"
              name="contactPersonName"
              type="text"
              value={formik.values.contactPersonName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.contactPersonName && formik.errors.contactPersonName ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.contactPersonName && formik.errors.contactPersonName && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.contactPersonName}</p>
            )}
          </div>
          <div>
            <label htmlFor="website" className="block text-sm font-medium text-gray-700 mb-1">
              Website <span className="text-red-500">*</span>
            </label>
            <input
              id="website"
              name="website"
              type="text"
              value={formik.values.website}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.website && formik.errors.website ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.website && formik.errors.website && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.website}</p>
            )}
          </div>
          <div>
            <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
              Address <span className="text-red-500">*</span>
            </label>
            <input
              id="address"
              name="address"
              type="text"
              value={formik.values.address}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.address && formik.errors.address ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.address && formik.errors.address && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.address}</p>
            )}
          </div>
          <div>
            <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-1">
              Country <span className="text-red-500">*</span>
            </label>
            <select
              id="country"
              name="country"
              value={formik.values.country}
              onChange={(e) => {
                formik.handleChange(e);
                formik.setFieldValue('state', '');
              }}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.country && formik.errors.country ? 'border-red-500' : 'border-gray-300'
                }`}
            >
              <option value="">Select country</option>
              {Object.keys(countryStateMap).map((country) => (
                <option key={country} value={country}>
                  {country}
                </option>
              ))}
            </select>
            {formik.touched.country && formik.errors.country && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.country}</p>
            )}
          </div>
          <div>
            <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">
              State
            </label>
            <Select
              inputId="state"
              name="state"
              isDisabled={!formik.values.country}
              value={
                formik.values.state
                  ? { value: formik.values.state, label: formik.values.state }
                  : null
              }
              onChange={(option) => formik.setFieldValue('state', option ? option.value : '')}
              onBlur={formik.handleBlur}
              options={(countryStateMap[formik.values.country as keyof typeof countryStateMap] || []).map(
                (state) => ({ value: state, label: state })
              )}
              placeholder="Select state"
              menuPlacement="top"
              maxMenuHeight={150}
              styles={{
                menu: (provided) => ({
                  ...provided,
                  zIndex: 9999,
                }),
                menuList: (provided) => ({
                  ...provided,
                  maxHeight: '150px',
                  overflowY: 'auto',
                }),
                container: (provided) => ({
                  ...provided,
                  width: '100%',
                }),
              }}
            />
            {formik.touched.state && formik.errors.state && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.state}</p>
            )}
          </div>
          <div>
            <label htmlFor="zipCode" className="block text-sm font-medium text-gray-700 mb-1">
              Zip Code
            </label>
            <input
              id="zipCode"
              name="zipCode"
              type="text"
              value={formik.values.zipCode}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.zipCode && formik.errors.zipCode ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.zipCode && formik.errors.zipCode && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.zipCode}</p>
            )}
          </div>
          <div>
            <label htmlFor="coolingPeriod" className="block text-sm font-medium text-gray-700 mb-1">
              Cooling Period (days)<span className="text-red-500">*</span>
            </label>
            <input
              id="coolingPeriod"
              name="coolingPeriod"
              type="number"
              min="0"
              value={formik.values.coolingPeriod}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.coolingPeriod && formik.errors.coolingPeriod ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.coolingPeriod && formik.errors.coolingPeriod && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.coolingPeriod}</p>
            )}
          </div>
        </form>
      </DrawerLayout>
    </>
  );
};

export default ClientRegistration;