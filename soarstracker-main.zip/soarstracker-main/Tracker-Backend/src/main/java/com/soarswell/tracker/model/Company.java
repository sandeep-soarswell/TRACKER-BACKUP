package com.soarswell.tracker.model;

import com.soarswell.tracker.persistance.AbstractEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "company",indexes = {
        @Index(name= "idx_company_name", columnList = "company_name"),
        @Index(name= "idx_company_status", columnList = "status"),
})
public class Company extends AbstractEntity {

    @Column(name = "company_name", nullable = false)
    private String companyName;
    @Column(name = "status", nullable = false)
    private String status;
    @Column(name = "email_id", nullable = false, unique = true)
    private String emailId;
    @Column(name = "company_address")
    private String companyAddress;
    @Column(name = "company_reg_no", unique = true)
    private String companyRegNo;
    @Column(name = "mobile_no", nullable = false,unique = true)
    private String mobileNo;
    @Column(name = "alternate_no")
    private String alternateNo;
    @Column(name = "personal_mail_id", nullable = false,unique = true)
    private String personalMailId;
    @Column(name = "imageFile")
    private  String imageFile;
}