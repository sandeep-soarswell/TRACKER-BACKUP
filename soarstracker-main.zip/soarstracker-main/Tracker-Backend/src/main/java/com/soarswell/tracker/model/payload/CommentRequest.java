package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

public class CommentRequest {

    @NotBlank(message = "{comment.not.null}")
    @Size(min = 3, message = "{comment.min.length}")
    @Size(max = 500, message = "{comment.max.length}")
    @Schema(example="GOOD")
    private String content;

}
