package com.soarswell.tracker.config;

import com.soarswell.tracker.util.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@Configuration
public class EmailConfig {

    @Value("${spring.mail.host}")
    private String host;

    @Value("${spring.mail.port}")
    private int port;

    @Value("${spring.mail.username}")
    private String username;

    @Value("${spring.mail.password}")
    private String password;

    @Bean
    public JavaMailSender javaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(host);
        mailSender.setPort(port);
        mailSender.setUsername(username);
        mailSender.setPassword(password);

        Properties props = mailSender.getJavaMailProperties();
        props.put(Constants.MAIL_TRANSPORT_PROTOCOL, Constants.SMTP);
        props.put(Constants.MAIL_SMTP_AUTH, Constants.TRUE);
        props.put(Constants.MAIL_SMTP_STARTTLS_ENABLE, Constants.TRUE);
        props.put(Constants.MAIL_DEBUG, Constants.TRUE);
        props.put(Constants.MAIL_SMTP_SSL_TRUST, host);

        return mailSender;
    }
}