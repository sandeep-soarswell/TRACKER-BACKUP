import { Fragment, useEffect, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import ProfilePage from './Profile';
import { useLocation } from 'react-router';

interface ProfileDrawerProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

const ProfileDrawer: React.FC<ProfileDrawerProps> = ({ open, setOpen }) => {
  const location = useLocation();

  useEffect(() => {
    setOpen(false);
  }, [location, setOpen]);

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={handleClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-in-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in-out duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-hidden">
          <div className="absolute inset-0 overflow-hidden">
            <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
              <Transition.Child
                as={Fragment}
                enter="transform transition ease-in-out duration-300 sm:duration-300"
                enterFrom="translate-x-full"
                enterTo="translate-x-0"
                leave="transform transition ease-in-out duration-300 sm:duration-200"
                leaveFrom="translate-x-0"
                leaveTo="translate-x-full"
              >
                <Dialog.Panel className="pointer-events-auto w-screen max-w-2xl">
                  <div className="flex h-full flex-col overflow-y-scroll bg-white shadow-xl">
                    <div className="sticky top-0 px-4 sm:px-6 py-4.5 border-b border-gray-200 flex justify-between bg-[#0A2463] items-center z-10">
                      <Dialog.Title className="text-lg font-medium text-white">Profile</Dialog.Title>

                      <button
                        onClick={handleClose}
                        className="text-white hover:text-gray-200 text-2xl font-bold focus:outline-none cursor-pointer"
                        aria-label="Close"
                      >
                        ×
                      </button>
                    </div>
                    <div className="relative flex-1 px-4 sm:px-6 py-4">
                      <ProfilePage onClose={handleClose}/>
                    </div>
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
};

export default ProfileDrawer;