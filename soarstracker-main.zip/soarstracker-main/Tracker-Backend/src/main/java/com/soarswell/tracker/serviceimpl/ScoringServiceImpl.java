package com.soarswell.tracker.serviceimpl;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.model.RecruiterScore;
import com.soarswell.tracker.model.Candidate;
import com.soarswell.tracker.repository.RecruiterScoreRepository;
import com.soarswell.tracker.repository.CandidateRepository;
import com.soarswell.tracker.service.ScoringService;
import com.soarswell.tracker.util.AuthTokenUtils;
import com.soarswell.tracker.common.ResponseBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

@Service
public class ScoringServiceImpl implements ScoringService {

    @Autowired
    private RecruiterScoreRepository recruiterScoreRepository;

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private RequestDetails requestDetails;

    private String normalize(String value) {
        return value == null ? null : value.trim();
    }

    private String stdEvent(String eventType) {
        String e = Optional.ofNullable(eventType).map(String::trim).orElse("").toUpperCase(Locale.ROOT);
        if ("INTERVIEW".equals(e)) {
            return "INTERVIEWING";
        }
        return e;
    }

    private String buildFullName(String firstName, String middleName, String lastName) {
        StringBuilder fullName = new StringBuilder();
        
        if (firstName != null && !firstName.trim().isEmpty()) {
            fullName.append(firstName.trim());
        }
        
        if (middleName != null && !middleName.trim().isEmpty()) {
            if (fullName.length() > 0) fullName.append(" ");
            fullName.append(middleName.trim());
        }
        
        if (lastName != null && !lastName.trim().isEmpty()) {
            if (fullName.length() > 0) fullName.append(" ");
            fullName.append(lastName.trim());
        }
        
        return fullName.length() > 0 ? fullName.toString() : "Unknown";
    }

    private int pointsForEvent(String stdEventType) {
        return switch (stdEventType) {
            case "ASSIGNED" -> 10;
            case "INTERVIEWING" -> 15;
            case "HIRED" -> 30;
            default -> 0;
        };
    }

    @Override
    public void addScore(String userId, String candidateId, int ignoredPoints, String eventType) {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        String stdEvent = stdEvent(eventType);
        
        // Check if this event already exists for this candidate and user
        boolean exists = recruiterScoreRepository.existsByCompanyIdAndUserIdAndCandidateIdAndEventType(
                companyId, userId, candidateId, stdEvent);
        
        if (exists) {
            // If event already exists, don't add duplicate score
            return;
        }
        
        int points = pointsForEvent(stdEvent);
        if (points <= 0) {
            return;
        }
        
        RecruiterScore entry = RecruiterScore.builder()
                .id(UUID.randomUUID().toString())
                .companyId(normalize(companyId))
                .userId(normalize(userId))
                .candidateId(normalize(candidateId))
                .points(points)
                .eventType(stdEvent)
                .createDate(new Date(Instant.now().toEpochMilli()))
                .createdBy(requestDetails.getUserId())
                .build();
        recruiterScoreRepository.save(entry);
    }

    @Override
    public void removeScore(String userId, String candidateId, String eventType) {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        String stdEvent = stdEvent(eventType);
        recruiterScoreRepository.deleteByCompanyIdAndUserIdAndCandidateIdAndEventType(companyId, userId, candidateId, stdEvent);
    }

    @Override
    public ResponseEntity<?> getUserScoreSummary(String userId) {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        List<RecruiterScore> scores = recruiterScoreRepository.findByCompanyIdAndUserId(companyId, userId);

        int totalPoints = scores.stream()
                .mapToInt(s -> Optional.ofNullable(s.getPoints()).orElse(0))
                .sum();

        long distinctCandidates = scores.stream()
                .map(RecruiterScore::getCandidateId)
                .map(this::normalize)
                .filter(Objects::nonNull)
                .distinct()
                .count();
        
        int entries = scores.size();
        double averageOverEntries = distinctCandidates == 0 ? 0.0 : ((double) totalPoints) / distinctCandidates;

        Set<String> hiredCandidateIds = new HashSet<>();
        for (RecruiterScore s : scores) {
            String evt = normalize(s.getEventType());
            String cid = normalize(s.getCandidateId());
            if (cid != null && "HIRED".equalsIgnoreCase(evt)) {
                hiredCandidateIds.add(cid);
            }
        }
        int hiredCandidates = hiredCandidateIds.size();
        double hiredPercentage = distinctCandidates == 0 ? 0.0 : ((double) hiredCandidates * 100.0) / distinctCandidates;

        Map<String, Object> scoreBreakdown = new HashMap<>();
        scoreBreakdown.put("assigned", scores.stream()
                .filter(s -> "ASSIGNED".equalsIgnoreCase(s.getEventType()))
                .mapToInt(s -> Optional.ofNullable(s.getPoints()).orElse(0))
                .sum());
        scoreBreakdown.put("interviewing", scores.stream()
                .filter(s -> "INTERVIEWING".equalsIgnoreCase(s.getEventType()))
                .mapToInt(s -> Optional.ofNullable(s.getPoints()).orElse(0))
                .sum());
        scoreBreakdown.put("hired", scores.stream()
                .filter(s -> "HIRED".equalsIgnoreCase(s.getEventType()))
                .mapToInt(s -> Optional.ofNullable(s.getPoints()).orElse(0))
                .sum());

        Map<String, Object> res = new HashMap<>();
        res.put("userId", userId);
        res.put("totalPoints", totalPoints);
        res.put("entries", entries);
        res.put("distinctCandidates", distinctCandidates);
        res.put("averagePoints", averageOverEntries);
        res.put("hiredCandidates", hiredCandidates);
        res.put("hiredPercentage", hiredPercentage);
        res.put("scoreBreakdown", scoreBreakdown);

        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(res), HttpStatus.OK);
    }
    public ResponseEntity<?> getUserScoreDetails(String userId) {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        List<RecruiterScore> scores = recruiterScoreRepository.findByCompanyIdAndUserId(companyId, userId);
        
        Map<String, Object> details = new HashMap<>();
        details.put("userId", userId);
        details.put("totalScores", scores.size());
        
        // Group scores by candidate with candidate details
        Map<String, Map<String, Object>> candidatesWithDetails = new HashMap<>();
        for (RecruiterScore score : scores) {
            String candidateId = score.getCandidateId();
            
            if (!candidatesWithDetails.containsKey(candidateId)) {
                // Fetch candidate details
                Optional<Candidate> candidateOpt = candidateRepository.findById(candidateId);
                if (candidateOpt.isPresent()) {
                    Candidate candidate = candidateOpt.get();
                    Map<String, Object> candidateInfo = new HashMap<>();
                    candidateInfo.put("firstName", candidate.getFirstName());
                    candidateInfo.put("lastName", candidate.getLastName());
                    candidateInfo.put("middleName", candidate.getMiddleName());
                    candidateInfo.put("fullName", buildFullName(candidate.getFirstName(), candidate.getMiddleName(), candidate.getLastName()));
                    candidateInfo.put("email", candidate.getEmail());
                    candidateInfo.put("scores", new ArrayList<RecruiterScore>());
                    candidatesWithDetails.put(candidateId, candidateInfo);
                } else {
                    Map<String, Object> candidateInfo = new HashMap<>();
                    candidateInfo.put("firstName", "Unknown");
                    candidateInfo.put("lastName", "Unknown");
                    candidateInfo.put("middleName", "");
                    candidateInfo.put("fullName", "Unknown Candidate");
                    candidateInfo.put("email", "Unknown");
                    candidateInfo.put("scores", new ArrayList<RecruiterScore>());
                    candidatesWithDetails.put(candidateId, candidateInfo);
                }
            }

            Map<String, Object> candidateInfo = candidatesWithDetails.get(candidateId);
            @SuppressWarnings("unchecked")
            List<RecruiterScore> candidateScores = (List<RecruiterScore>) candidateInfo.get("scores");
            candidateScores.add(score);
        }
        
        details.put("candidates", candidatesWithDetails);
        
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(details), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> clearUserScores(String userId) {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        List<RecruiterScore> scores = recruiterScoreRepository.findByCompanyIdAndUserId(companyId, userId);
        
        if (!scores.isEmpty()) {
            recruiterScoreRepository.deleteAll(scores);
        }
        
        Map<String, Object> response = new HashMap<>();
        response.put("message", "All scores cleared for user: " + userId);
        response.put("clearedScores", scores.size());
        
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(response), HttpStatus.OK);
    }
}