package com.soarswell.tracker.database;

import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.http.HttpStatus;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationDataInitializer.class);

    @Override
    public void initialize(ConfigurableApplicationContext applicationContext) throws TrackerException {

        logger.info("creating Tracker Database");
        ConfigurableEnvironment environment = applicationContext.getEnvironment();
        String url = environment.getProperty(Constants.DATABASE_URL);
        String username = environment.getProperty(Constants.DATABASE_USERNAME);
        String password = environment.getProperty(Constants.DATABASE_PASSWORD);

        try (Connection con = DriverManager.getConnection(url, username, password)) {
            Statement stm = con.createStatement();
            stm.executeUpdate(Constants.CREATE_DATABASE_QUERY); // Make sure this uses IF NOT EXISTS
            logger.info("Database is created or already exists");
        } catch (SQLException e) {
            logger.error("Error initializing database");
            throw new TrackerException(ErrorMessageKey.ERROR_INIT_DATABASE.getStatusCode(), HttpStatus.BAD_REQUEST);
        }
    }

}
