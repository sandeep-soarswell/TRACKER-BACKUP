package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;
import com.soarswell.tracker.util.RegExConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientUpdateRequest {

    @Schema(example = "John Smith")
    @Size(min = 3, max = 25, message = "{client.contactPersonName.size.message}")
    @Pattern(
            regexp = RegExConstants.NAME_PATTERN,
            message = "{client.contactPersonName.pattern.message}"
    )
    private String contactPersonName;

    @Schema(example = "9876543210")
    @ValidPhoneNumber(message = "{invalid.mobile.number}")
    private String contactPersonNumber;

    @Schema(example = "123, Tech Park Road, Hyderabad, India")
    @Size(min = 5, max = 100, message = "{client.address.size.message}")
    private String address;

    @Schema(example = "https://soarswell.com")
    @Pattern(
            regexp = RegExConstants.WEBSITE,
            message = "{client.website.pattern.message}"
    )
    private String website;

    @Schema(example = "India")
    @Pattern(regexp = RegExConstants.COUNTRY_PATTERN,
            message = "{invalid.country.pattern}"
    )
    @Size(min = 2, max = 50, message = "{country.size.message}")
    private String country;

    @Schema(example = "Telangana")
    @Pattern(regexp = RegExConstants.STATE_PATTERN,message = "{invalid.state.pattern}")
    private String state;

    @Schema(example = "500081")
    @Pattern(regexp = RegExConstants.ZIPCODE_PATTERN,message = "{invalid.zipCode.pattern}")
    private String zipCode;

    @Schema(example = "active")
    @Pattern(regexp = RegExConstants.STATUS_PATTERN, message = "{status.pattern.message}")
    private String status;

    @Schema(example = "90")
    private Integer coolingPeriod;
}
