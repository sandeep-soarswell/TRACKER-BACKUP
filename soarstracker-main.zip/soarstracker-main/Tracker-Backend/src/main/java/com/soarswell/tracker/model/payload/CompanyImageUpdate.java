 package com.soarswell.tracker.model.payload;

import jakarta.validation.constraints.NotNull;
import lombok.*;

 @Getter
 @Setter
 @Builder
 @NoArgsConstructor
 @AllArgsConstructor
 public class CompanyImageUpdate {

     @NotNull(message = "{image.notnull}")
     private String image;
 }
