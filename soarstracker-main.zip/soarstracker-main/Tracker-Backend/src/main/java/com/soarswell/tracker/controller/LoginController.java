package com.soarswell.tracker.controller;

import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.model.payload.*;
import com.soarswell.tracker.service.AuthService;
import com.soarswell.tracker.util.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.context.SecurityContextHolder;

@RestController
@RequestMapping("/")
@Tag(name = Constants.API_TAG_AUTH)
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
@ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = Constants.API_RESPONSE_OK, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "400", description = Constants.VALIDATION_ERROR, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "401", description = Constants.API_RESPONSE_UNAUTHORIZED, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "404", description = Constants.API_RESPONSE_NOT_FOUND, content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "500", description = Constants.API_RESPONSE_ERROR, content = @Content(schema = @Schema(implementation = ResponseObject.class)))
})
public class LoginController {

    private final AuthService authService;

    @Operation(summary = Constants.API_AUTH_SIGNIN)
    @PostMapping("user/login")
    public ResponseEntity<?> authenticate(
            @Parameter(description = Constants.LOGIN_CREDENTIALS, required = true) @Valid @RequestBody LoginRequest request) {
        return authService.authenticate(request);
    }

    @PostMapping("change-password")
    @Operation(summary = Constants.API_AUTH_CHANGE_PASSWORD)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> changePassword(
            @Valid @RequestBody ChangePasswordRequest request) {
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return authService.changePassword(username, request);
    }

    @Operation(summary = Constants.API_AUTH_FORGOT_PASSWORD)
    @PostMapping("forgot-password")
    public ResponseEntity<?> forgotPassword(
            @Parameter(description = Constants.FORGOT_DETAILS, required = true) @Valid @RequestBody ForgotPasswordRequest request) {
        return authService.forgotPassword(request);
    }

    @Operation(summary = Constants.API_AUTH_VALIDATE_OTP)
    @PostMapping("validate-otp")
    public ResponseEntity<?> validateOtp(
            @Parameter(description = Constants.OTP_DETAILS, required = true) @Valid @RequestBody ValidateOtpRequest request) {
        return authService.validateOtp(request);
    }

    @PostMapping("token/validate")
    @Operation(summary = Constants.VALIDATE_JWT_TOKEN, description = Constants.TOKEN_VALIDATE_DESCRIPTION)
    public ResponseEntity<?> validateToken(
            @RequestBody @Valid ValidateLoginRequest request) {
        return authService.validateToken(request.getToken());
    }

    @PostMapping("user/logout")
    @Operation(summary = Constants.LOGOUT, description = Constants.LOGOUT_DESCRIPTION)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> logout() {
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return authService.logout(username);
    }

    @PostMapping("resend-otp")
    @Operation(summary = Constants.API_AUTH_RESEND_OTP,description = Constants.API_AUTH_RESEND_OTP_DESCRIPTION)
    public ResponseEntity<?> sendOtp(
            @RequestParam(required = true) String username) {
        return authService.reSendOtp(username);
    }
}