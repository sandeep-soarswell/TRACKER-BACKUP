import api from '../api/api.services';
import type { Comment, CommentFormData } from '~/pages/comments/Commentstype';

type Listener = (comments: Comment[]) => void;
let listeners: Listener[] = [];
let currentComments: Comment[] = [];

const notifyListeners = () => {
  listeners.forEach((listener) => listener(currentComments));
};
export const getAllByClientId = async (clientId: string): Promise<Comment[]> => {
  const response = await api.get(`/comment/client/${clientId}`);

  let commentList: Comment[] = [];

  if (Array.isArray(response.data?.data)) {
    commentList = response.data.data;
  } else if (response.data?.data) {
    commentList = [response.data.data];
  }

  currentComments = commentList;
  notifyListeners();
  return currentComments;
};
export const addComment = async (
  clientId: string,
  data: CommentFormData
): Promise<Comment> => {
  const response = await api.post(`/comment/client/${clientId}`, {
    content: data.text,
  });
  await getAllByClientId(clientId);

  return response.data?.data;
};
export const subscribe = (_channel: string, listener: Listener) => {
  listeners.push(listener);

  if (Array.isArray(currentComments)) {
    listener(currentComments);
  }

  return () => {
    listeners = listeners.filter((l) => l !== listener);
  };
};
