import React from "react";

const Settings: React.FC = () => {
  return (
    <div className="flex items-center justify-center m-90 ">
      <h1 className="text-2xl md:text-3xl font-semibold text-gray-700 text-center">
        Settings Page is Under Development
      </h1>
    </div>
  );
};

export default Settings;
