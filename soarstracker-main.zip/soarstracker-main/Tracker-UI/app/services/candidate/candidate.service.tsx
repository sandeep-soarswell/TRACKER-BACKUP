import api from "../api/api.services";
import { type Candidate } from '~/pages/types/types';
import { DEFAULT_CANDIDATE_STATUSES, getCanonicalStatus } from '~/pages/candidate/CandidateUtils';
type Listener = (candidates: Candidate[]) => void;

let listeners: Listener[] = [];
let currentCandidates: Candidate[] = [];

const notifyListeners = () => {
  listeners.forEach((listener) => listener(currentCandidates));
};


const candidateService = {
getAll: async (
  page: number,
  size: number,
  searchTerm: string = "",
  filter: string = "ALL",
  statusFilter: string = "*",
  sortByField: string = "createDate",
  desc: string = "desc",
  clientId: string = "",
  genderFilter: string = "*"
) => {
  try {
    let url = `/candidate?page=${page}&size=${size}&sortByField=${sortByField}&desc=${desc}`;
    if (searchTerm) url += `&keyword=${encodeURIComponent(searchTerm)}`;
    if (filter && filter.toUpperCase() !== 'ALL') url += `&filter=${encodeURIComponent(filter)}`;
    if (statusFilter && statusFilter.toUpperCase() !== 'ALL') url += `&statusfilter=${encodeURIComponent(statusFilter)}`;
    if (clientId) url += `&clientId=${encodeURIComponent(clientId)}`;
     if (genderFilter && genderFilter.toUpperCase() !== "ALL")
        url += `&gender=${encodeURIComponent(genderFilter)}`;


    const response = await api.get(url);
    const dataPayload = response.data?.data || {};
    const candidates = dataPayload.data || [];
    const total = dataPayload.totalEntries || 0;

    return {
      content: candidates,
      totalElements: total,
    };
  } catch (error) {
    throw error;
  }
},



  getById: async (id: string) => {
    const response = await api.get(`/candidate/${id}`);
    return response.data.data;
  },


  create: async (candidateData: any, resumeFile: File) => {
    const formData = new FormData();
    formData.append("candidate", JSON.stringify(candidateData));
    formData.append("resume", resumeFile);

    const response = await api.post("/candidate", formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  update: async (id: string, payload: any) => {
    const response = await api.patch(`/candidate/${id}`, payload);
    return response.data.data;
  },

  updateStatus: async (id: string, payload: any) => {
    // Normalize status to canonical form before sending to backend
    if (payload.candidatureStatus) {
      payload.candidatureStatus = getCanonicalStatus(payload.candidatureStatus);
    }
    const response = await api.post(`/candidate/${id}`, payload);
    return response.data.data;
  },


  delete: async (id: string) => {
    await api.delete(`/candidate/${id}`);
  },
  uploadCSV: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await api.post('/candidate/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },
  subscribe: (listener: Listener) => {
    listeners.push(listener);
    listener(currentCandidates);

    return () => {
      listeners = listeners.filter((l) => l !== listener);
    };
  },

  getBySkills: async (jobId: string) => {
    const params = {
      "jobId": jobId
    }
    const response = await api.get(`/job/skills/candidates?${new URLSearchParams(params)}`);
    return response.data;
  },

  getUniqueCandidatureStatuses: async () => {
    try {
      const response = await candidateService.getAll(0, 1000, "", "ALL", "ALL");
      const candidates = response.content || [];

      const statusSet = new Set<string>();
      candidates.forEach((candidate: any) => {
        if (candidate.candidatureStatus && candidate.candidatureStatus.trim()) {
          const canonicalStatus = getCanonicalStatus(candidate.candidatureStatus);
          statusSet.add(canonicalStatus);
        }
      });

      const uniqueStatuses = Array.from(statusSet).sort();
      
      const allStatuses = [...DEFAULT_CANDIDATE_STATUSES];
      uniqueStatuses.forEach(status => {
        if (!DEFAULT_CANDIDATE_STATUSES.includes(status)) {
          allStatuses.push(status);
        }
      });
      
      return allStatuses;
    } catch (error) {

      return DEFAULT_CANDIDATE_STATUSES;
    }
    },
  
  parseResume: async (resumeFile: File) => {
    const formData = new FormData();
    formData.append('resumeFile', resumeFile);
    const response = await api.post('/candidate/parse-resume', formData, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    });
    return response.data;
  }
};
export default candidateService;