import React from "react";
import type { Employee } from "~/pages/types/types";
import DrawerLayout from "~/components/layout/DrawerLayout";

interface EmployeeDetailsDrawerProps {
  employee: Employee | null;
  open: boolean;
  onClose: () => void;
}

const EmployeeDetailsDrawer: React.FC<EmployeeDetailsDrawerProps> = ({
  employee,
  open,
  onClose,
}) => {
  if (!employee || !open) return null;

  const fields = [
    { label: "First Name", value: employee.firstName },
    { label: "Middle Name", value: employee.middleName || "—" },
    { label: "Last Name", value: employee.lastName },
    { label: "Email", value: employee.email },
    { label: "Phone Number", value: `${employee.phoneNumber}` },
    { label: "Role", value: employee.role },
  ];

  return (
    <DrawerLayout title="Employee Details" onClose={onClose}>
      <form className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4">
        {fields.map(({ label, value }) => (
          <div key={label}>
            <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
            <input
              type="text"
              value={typeof value === "string" || typeof value === "number" ? String(value) : "—"}
              readOnly
              className="w-full px-3 py-2 rounded-md text-sm !bg-gray-100 cursor-not-allowed focus:outline-none border-0"
              style={{ boxShadow: "none" }}
            />
          </div>
        ))}
      </form>
    </DrawerLayout>
  );
};

export default EmployeeDetailsDrawer;