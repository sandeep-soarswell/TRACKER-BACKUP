package com.soarswell.tracker.util;

public class RegExConstants {

    public static final String NAME_PATTERN ="^([A-Za-z]+(\\s[A-Za-z]+)*)?$";
    public static final String EMAIL_PATTERN = "^(?=.*[a-z])[a-z0-9._%+-]*[a-z][a-z0-9._%+-]*@[a-z0-9.-]+\\.[a-z]{2,6}$";
    public static final String COMPANY_NAME_PATTERN = "^[A-Za-z0-9&.\\'\\- ]{2,100}$";
    public static final String ROLE_VALIDATION_PATTERN="(?i)company_admin|manager|recruiter|\\*";
    public static final String WEBSITE="^(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})([/\\w .-]*)*/?$";
    public static final String PASSWORD_PATTERN="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*\\W)(?!.* ).{6,16}$";
    public static final String LOCATION="^[A-Za-z0-9, ]+$";
    public static final String R_NO="^[A-Za-z0-9\\-\\/]{6,21}$";
    public static final String COUNTRY_PATTERN="^[A-Z][a-zA-ZÀ-ÿ'.-]*(?: [A-Z][a-zA-ZÀ-ÿ'.-]*)*$";
    public static final String CANDIDATE_ROLE="^[A-Za-z][A-Za-z0-9 &\\-]{1,99}$";
    public static final String STATUS_VALIDATION_PATTERN="(?i)active|\\*";
    public static final String ZIPCODE_PATTERN = "^$|^[a-zA-Z0-9]{5,10}$";
    public static final String STATE_PATTERN = "^$|^[a-zA-Z ]{2,50}$";
    public static final String STATUS_PATTERN = "^(?i)active$";
    public static final String JOB_ID_PATTERN =  "^(?=.{4,}$)[A-Za-z0-9]+(-[A-Za-z0-9]+)*$";
}
