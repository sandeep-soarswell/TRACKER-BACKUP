import React from 'react';
import { PersonIcon, BusinessCenterIcon, GroupsIcon, ClockIcon, MailIcon, PhoneIcon, ChatBubbleOutlineIcon } from '~/components/ui/Icons';
import type { CalendarEvent } from './CalendarType';

interface EventTooltipProps {
  event: CalendarEvent | null;
  position: { x: number; y: number };
  isVisible: boolean;
}

const EventTooltip: React.FC<EventTooltipProps> = ({ event, position, isVisible }) => {
  if (!isVisible || !event) return null;

  return (
    <div
      className="fixed z-50 bg-white rounded-lg shadow-xl border border-gray-200 p-6 min-w-[340px] max-w-[400px] pointer-events-none"
      style={{
        left: `${position.x + 15}px`,
        top: `${position.y - 15}px`,
      }}
    >
      <div className="space-y-3">
        <div className="flex items-start">
          <h3 className="font-semibold text-[#0A2463] text-base leading-tight">{event.tooltip?.title || event.title}</h3>
        </div>
        <div className="space-y-2 text-xs">
          {event.tooltip && (event.tooltip.name || event.tooltip.email || event.tooltip.phoneNumber || event.tooltip.jobTitle || event.tooltip.clientName) && (
            <div className="flex flex-col gap-2 text-gray-600">
              {event.tooltip.name && (
                <div className="flex items-center">
                  <PersonIcon fontSize="small" className="text-[#0A2463] mr-2" />
                  <span className="font-medium text-gray-900 text-base">{event.tooltip.name}</span>
                </div>
              )}
              {event.tooltip.email && (
                <div className="flex items-center">
                  <MailIcon fontSize="small" className="text-[#0A2463] mr-2" />
                  <span className="text-sm">{event.tooltip.email}</span>
                </div>
              )}
              {event.tooltip.phoneNumber && (
                <div className="flex items-center">
                  <PhoneIcon fontSize="small" className="text-[#0A2463] mr-2" />
                  <span className="text-sm">{event.tooltip.phoneNumber}</span>
                </div>
              )}
              {event.tooltip.jobTitle && (
                <div className="flex items-center">
                  <BusinessCenterIcon fontSize="small" className="text-[#0A2463] mr-2" />
                  <span className="text-sm">{event.tooltip.jobTitle}</span>
                </div>
              )}
              {event.tooltip.clientName && (
                <div className="flex items-center">
                  <GroupsIcon fontSize="small" className="text-[#0A2463] mr-2" />
                  <span className="text-sm">{event.tooltip.clientName}</span>
                </div>
              )}
            </div>
          )}
          <div className="flex items-center text-gray-600">
            <ClockIcon fontSize="small" className="text-[#0A2463] mr-2" />
            <span className="text-sm">
              {event.tooltip?.startTime || event.startTime} - {event.tooltip?.endTime || event.endTime}
            </span>
          </div>
          {(event.tooltip?.description || event.description) && (
            <div className="flex items-center">
              <ChatBubbleOutlineIcon fontSize="small" className="text-[#0A2463] mr-2" />
              <span className="text-sm text-gray-700" style={{ whiteSpace: 'pre-line' }}>{event.tooltip?.description || event.description}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EventTooltip;