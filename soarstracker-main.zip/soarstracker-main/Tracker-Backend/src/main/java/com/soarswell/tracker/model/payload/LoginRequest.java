package com.soarswell.tracker.model.payload;

import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.RegExConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LoginRequest {

    @NotBlank(message = "{login.username.required}")
    @Pattern(regexp = RegExConstants.EMAIL_PATTERN, message = "{error.invalid.email}")
    @Schema(description = "username", example = "admin@soarswell.com", required = true)
    private String username;

    @NotBlank(message = "{login.password.required}")
    @Schema(description = Constants.PASSWORD_DESC, example = Constants.PASSWORD_EXAMPLE, required = true)
    private String password;
}