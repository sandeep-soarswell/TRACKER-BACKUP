import React, { useState, useEffect, useMemo } from 'react';
import { useFormik } from "formik";
import * as Yup from "yup";
import DrawerLayout from "~/components/layout/DrawerLayout";
import candidateService from "~/services/candidate/candidate.service";
import type { Candidate, FormValues } from "~/pages/types/types";
import Button from "~/components/ui/Button";
import CustomSnackbar from '~/components/ui/Customsnackbar';
import 'react-international-phone/style.css';
import { isValidPhoneNumber } from 'libphonenumber-js';
import { PhoneInput } from "react-international-phone";
import { formatSalaryWithCommas } from "~/components/util/util.services";
import getChangedFields from "~/components/util/update-util";
import { getCountryCallingCodeLength } from "~/components/util/phone-utils";

interface CandidateFormProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialData?: Candidate;
}

const skillsOptions = ["Java", "Spring Boot", "React", "SQL", "JavaScript"];
const noticePeriodOptions = [
  "Immediately",
  "15 Days",
  "30 Days",
  "45 Days",
  "60 Days",
  "90 Days",
];

const nameRegex = /^[A-Za-z\s]+$/;

const validationSchema = Yup.object({
  firstName: Yup.string()
    .matches(nameRegex, "Only letters allowed")
    .min(3, "First name must be at least 3 characters")
    .max(50, "First name must be at most 50 characters")
    .required("First name is required"),
  middleName: Yup.string()
    .matches(nameRegex, "Only letters allowed")
    .max(50, "Middle name must be at most 50 characters")
    .notRequired(),
  lastName: Yup.string()
    .matches(nameRegex, "Only letters allowed")
    .min(3, "Last name must be at least 3 characters")
    .max(50, "Last name must be at most 50 characters")
    .required("Last name is required"),
  dateOfBirth: Yup.date()
    .max(new Date(), "Date of birth cannot be in the future")
    .required("Date of birth is required")
    .test('year-format', 'Year must be a 4-digit year', value => {
      if (!value) return false;
      const year = new Date(value).getFullYear();
      return year >= 1000 && year <= 9999;
    }),
  gender: Yup.string()
    .oneOf(['Male', 'Female', 'Others'], 'Please select a valid gender')
    .required("Gender is required"),
  phoneNumber: Yup.string()
    .trim()
    .required('Phone number is required')
    .test('is-valid-phone', 'Invalid phone number for selected country', function (value) {
      if (!value) return false;
      return isValidPhoneNumber(value);
    }),
  alternatePhoneNumber: Yup.string()
    .trim()
    .nullable()
    .test('is-valid-phone', 'Invalid phone number for selected country', function (value) {
      if (!value) return true;
      if (getCountryCallingCodeLength(this.parent.phoneNumber) >= value.length) return true;
      return isValidPhoneNumber(value);
    })
    .test('different-from-primary-phone', 'Must be different from primary phone', function (value) {
      if (!value) return true;
      return value !== this.parent.phoneNumber;
    }),
  email: Yup.string()
    .trim()
    .required("Email is required")
    .matches(/^[a-z][a-z0-9._%+-]*@[a-z0-9.-]+\.[a-z]{2,}$/, "Enter a valid email"),
  alternateEmail: Yup.string()
    .email("Must be a valid email")
    .notRequired()
    .test("different-from-primary-email", "Must be different from primary email", function (value) {
      const primaryEmail = this.parent.email;
      return !value || value.toLowerCase() !== primaryEmail?.toLowerCase();
    }),
  address: Yup.string()
    .max(500, "Address must be at most 500 characters")
    .required("Address is required"),
  skills: Yup.array()
    .of(Yup.string().max(500, "Skills must be at most 500 characters"))
    .min(1, "Select at least one skill")
    .required("Skills are required"),
  candidateRole: Yup.string()
    .max(500, "Candidate role must be at most 500 characters")
    .required("Candidate role is required"),
  experience: Yup.string()
    .max(100, "Experience must be at most 100 characters")
    .required("Experience is required"),
  noticePeriod: Yup.string()
    .max(100, "Notice period must be at most 100 characters")
    .required("Notice period is required"),
  currentSalary: Yup.string()
    .required('Current Salary is required')
    .test('is-valid-current-salary', 'Current Salary must be greater than or equal to 0', (value) => {
      if (!value) return false;
      const numericValue = parseFloat(value.replace(/,/g, ''));
      return !isNaN(numericValue) && numericValue >= 0;
    }),
  expectedSalary: Yup.string()
    .required('Expected Salary is required')
    .test('is-valid-expected-salary', 'Expected Salary must be greater than 0', (value) => {
      if (!value) return false;
      const numericValue = parseFloat(value.replace(/,/g, ''));
      return !isNaN(numericValue) && numericValue > 0;
    }),
  availabilityOfJoining: Yup.date()
    .min(new Date(), "Availability date must be in the future")
    .required("Availability date is required")
    .test('year-format', 'Year must be a 4-digit year', value => {
      if (!value) return false;
      const year = new Date(value).getFullYear();
      return year >= 1000 && year <= 9999;
    }),
  resume: Yup.mixed().required("Resume is required"),
  status: Yup.string().oneOf(['active', 'inactive']).notRequired(),
  offersInHand: Yup.boolean().required("Please select whether you have offers in hand"),
  numberOfOffers: Yup.string().when('offersInHand', {
    is: true,
    then: (schema) => schema.required("Number of offers is required when you have offers in hand"),
    otherwise: (schema) => schema.notRequired(),
  }),
});

const CandidateForm: React.FC<CandidateFormProps> = ({ open, onClose, onSuccess, initialData }) => {
  const isEditMode = Boolean(initialData?.id);
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: "success" | "error"; }>({ open: false, message: "", severity: "success" });
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [aiSummary, setAiSummary] = useState('');
  const [aiRatings, setAiRatings] = useState({
    collegeRating: 0,
    companyRating: 0,
    experienceRating: 0,
    skillsRating: 0,
  });
  const [isParsing, setIsParsing] = useState(false);

  const handleSnackbarClose = () => setSnackbar({ ...snackbar, open: false });

  const handleResumeUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIsParsing(true);
      formik.setFieldValue('resume', file);
      setResumeFile(file);

      try {
        const response = await candidateService.parseResume(file);

        const currentValues = formik.values;
        const fieldsToUpdate: Partial<FormValues> = {};

        if (!currentValues.firstName && response.firstName) fieldsToUpdate.firstName = response.firstName;
        if (!currentValues.middleName && response.middleName) fieldsToUpdate.middleName = response.middleName;
        if (!currentValues.lastName && response.lastName) fieldsToUpdate.lastName = response.lastName;
        if (!currentValues.email && response.email) fieldsToUpdate.email = response.email;
        if (!currentValues.phoneNumber && response.phoneNumber) fieldsToUpdate.phoneNumber = response.phoneNumber;
        if (!currentValues.address && response.address) fieldsToUpdate.address = response.address;
        if (!currentValues.candidateRole && response.candidateRole) fieldsToUpdate.candidateRole = response.candidateRole;
        if (!currentValues.experience && response.experience) fieldsToUpdate.experience = response.experience;
        if (!currentValues.alternateEmail && response.alternateEmail) fieldsToUpdate.alternateEmail = response.alternateEmail;
        if (!currentValues.alternatePhoneNumber && response.alternatePhoneNumber) fieldsToUpdate.alternatePhoneNumber = response.alternatePhoneNumber;
        if (!currentValues.dateOfBirth && response.dateOfBirth) fieldsToUpdate.dateOfBirth = response.dateOfBirth;
        if (!currentValues.gender && response.gender) fieldsToUpdate.gender = response.gender;
        if (!currentValues.noticePeriod && response.noticePeriod) fieldsToUpdate.noticePeriod = response.noticePeriod;
        if (!currentValues.currentSalary && response.currentSalary) fieldsToUpdate.currentSalary = response.currentSalary;
        if (!currentValues.expectedSalary && response.expectedSalary) fieldsToUpdate.expectedSalary = response.expectedSalary;
        if (!currentValues.availabilityOfJoining && response.availabilityOfJoining) fieldsToUpdate.availabilityOfJoining = response.availabilityOfJoining;

        if (currentValues.skills.length === 0 && response.skills) {
          if (typeof response.skills === 'string') {
            fieldsToUpdate.skills = response.skills.split(',').map((s: string) => s.trim()).filter((s: string) => s);
          } else if (Array.isArray(response.skills)) {
            fieldsToUpdate.skills = response.skills;
          }
        }
        Object.keys(fieldsToUpdate).forEach(key => {
          formik.setFieldValue(key, fieldsToUpdate[key as keyof FormValues]);
        });

        setAiSummary(response.aiSummary || response.summary || '');
        setAiRatings({
          collegeRating: response.collegeRating || 0,
          companyRating: response.companyRating || 0,
          experienceRating: response.experienceRating || 0,
          skillsRating: response.skillsRating || 0,
        });

        setSnackbar({
          open: true,
          message: "Resume parsed successfully!",
          severity: "success"
        });

      } catch (error) {
        console.error("Error parsing resume:", error);
        setSnackbar({ open: true, message: "Error parsing resume", severity: "error" });
      } finally {
        setIsParsing(false);
      }
    }
  };

  const formik = useFormik<FormValues>({
    initialValues: {
      id: initialData?.id ? String(initialData.id) : "",
      firstName: initialData?.firstName || "",
      middleName: initialData?.middleName || "",
      lastName: initialData?.lastName || "",
      dateOfBirth: initialData?.dateOfBirth?.slice(0, 10) || "",
      gender: initialData?.gender || "",
      email: initialData?.email || "",
      phoneNumber: initialData?.phoneNumber ? String(initialData.phoneNumber) : "",
      alternateEmail: initialData?.alternateEmail || "",
      alternatePhoneNumber: initialData?.alternatePhoneNumber ? String(initialData.alternatePhoneNumber) : "",
      address: initialData?.address || "",
      skills: Array.isArray(initialData?.skills)
        ? initialData.skills
        : typeof initialData?.skills === "string"
          ? initialData.skills.split(",").map((s) => s.trim())
          : [],
      candidateRole: initialData?.candidateRole || "",
      experience: initialData?.experience || "",
      noticePeriod: initialData?.noticePeriod || "",
      currentSalary: initialData?.currentSalary !== undefined ? String(initialData.currentSalary) : "",
      expectedSalary: initialData?.expectedSalary !== undefined ? String(initialData.expectedSalary) : "",
      availabilityOfJoining: initialData?.availabilityOfJoining?.slice(0, 10) || "",
      resume: initialData?.resume || "",
      status: initialData?.status?.toLowerCase() || 'active',
      offersInHand: initialData?.numberOfOffers ? Number(initialData.numberOfOffers) > 0 : false,
      numberOfOffers: initialData?.numberOfOffers ? String(initialData.numberOfOffers) : "",
    },
    enableReinitialize: true,
    validationSchema,
    onSubmit: async (values) => {
      try {
        const payload: any = {
          ...values,
          skills: Array.isArray(values.skills) ? values.skills.join(", ") : values.skills,
          currentSalary: values.currentSalary !== undefined ? String(values.currentSalary).replace(/,/g, '') : null,
          expectedSalary: values.expectedSalary !== undefined ? String(values.expectedSalary).replace(/,/g, '') : null,
          middleName: values.middleName || null,
          alternateEmail: values.alternateEmail || null,
          numberOfOffers: values.offersInHand ? values.numberOfOffers : null,
          offersInHand: !!values.offersInHand,
          alternatePhoneNumber: values.alternatePhoneNumber &&
            isValidPhoneNumber(values.alternatePhoneNumber) &&
            values.alternatePhoneNumber.length > getCountryCallingCodeLength(values.phoneNumber)
            ? values.alternatePhoneNumber.trim() : null,
          aiSummary: aiSummary,
          collegeRating: aiRatings.collegeRating,
          companyRating: aiRatings.companyRating,
          experienceRating: aiRatings.experienceRating,
          skillsRating: aiRatings.skillsRating,
        };

        Object.keys(payload).forEach(
          (key) => payload[key] === undefined && delete payload[key]
        );
        delete payload.resume;

        if (isEditMode && initialData?.id) {
          const changedFields = getChangedFields(initialData, payload);
          await candidateService.update(String(values.id), changedFields);
          setSnackbar({
            open: true,
            message: "Candidate updated successfully",
            severity: "success",
          });
        } else {
          if (resumeFile) {
            await candidateService.create(payload, resumeFile);
            setSnackbar({
              open: true,
              message: "Candidate registered successfully",
              severity: "success",
            });
          } else {
            setSnackbar({ open: true, message: "Please upload a resume.", severity: "error" });
            return;
          }
        }
        onSuccess();
        onClose();
      } catch (error: any) {
        const backendErrors = error?.response?.data?.error || {};
        const backendData = error?.response?.data?.data || {};
        let hasFieldError = false;

        if (backendErrors.EMAIL) { formik.setFieldError('email', backendErrors.EMAIL); hasFieldError = true; }
        if (backendErrors.PHONE) { formik.setFieldError('phoneNumber', backendErrors.PHONE); hasFieldError = true; }
        if (backendData.PHONE) { formik.setFieldError('alternatePhoneNumber', backendData.PHONE); hasFieldError = true; }

        Object.entries(backendErrors).forEach(([field, message]) => {
          if (field !== "message") { formik.setFieldError(field, message as string); hasFieldError = true; }
        });

        Object.entries(backendData).forEach(([field, message]) => {
          if (field !== "message") { formik.setFieldError(field, message as string); hasFieldError = true; }
        });

        if (!hasFieldError) {
          let backendMsg = error?.response?.data?.error?.message || error?.response?.data?.message || 'Unknown error occurred';
          if (!backendMsg || backendMsg === "Bad Request") {
            backendMsg = "Something went wrong. Please check your input and try again.";
          }
          setSnackbar({ open: true, message: backendMsg, severity: "error" });
        }
      }
    },
  });

  useEffect(() => {
    if (open) {
      if (!initialData?.id) {
        formik.resetForm();
        setResumeFile(null);
        setAiSummary('');
        setAiRatings({ collegeRating: 0, companyRating: 0, experienceRating: 0, skillsRating: 0 });
      } else {
        formik.resetForm({
          values: {
            id: initialData.id ? String(initialData.id) : "",
            firstName: initialData.firstName || "",
            middleName: initialData.middleName || "",
            lastName: initialData.lastName || "",
            dateOfBirth: initialData.dateOfBirth?.slice(0, 10) || "",
            gender: initialData.gender || "",
            email: initialData.email || "",
            phoneNumber: initialData.phoneNumber ? String(initialData.phoneNumber) : "",
            alternateEmail: initialData.alternateEmail || "",
            alternatePhoneNumber: initialData.alternatePhoneNumber ? String(initialData.alternatePhoneNumber) : "",
            address: initialData.address || "",
            skills: Array.isArray(initialData.skills)
              ? initialData.skills
              : typeof initialData.skills === "string"
                ? initialData.skills.split(",").map((s) => s.trim())
                : [],
            candidateRole: initialData.candidateRole || "",
            experience: initialData.experience || "",
            noticePeriod: initialData.noticePeriod || "",
            currentSalary: initialData.currentSalary !== undefined ? String(initialData.currentSalary) : "",
            expectedSalary: initialData.expectedSalary !== undefined ? String(initialData.expectedSalary) : "",
            availabilityOfJoining: initialData.availabilityOfJoining?.slice(0, 10) || "",
            status: initialData.status ? String(initialData.status).toLowerCase() : "active",
            offersInHand: initialData.offersInHand ?? false,
            numberOfOffers: initialData.numberOfOffers ? String(initialData.numberOfOffers) : "",
            resume: initialData.resume || "",
          },
        });
      }
    }
  }, [open, initialData]);

  const isButtonEnabled = () => {
    if (formik.isSubmitting || isParsing) return false;
    // Button is enabled if the form has been touched and is valid.
    // This works for both create and edit modes.
    return formik.dirty && formik.isValid;
  };

  if (!open) return null;

  return (
    <>
      <CustomSnackbar
        open={Boolean(snackbar.open)}
        message={snackbar.message}
        severity={snackbar.severity}
        onClose={handleSnackbarClose}
        autoHideDuration={4000}
      />
      <DrawerLayout
        title={initialData?.id ? "Edit Candidate" : "Register Candidate"}
        onClose={onClose}
        footer={
          <Button
            variant="primary"
            type="button"
            onClick={() => formik.handleSubmit()}
            disabled={!isButtonEnabled()}
          >
            {isParsing ? "Parsing Resume..." : isEditMode ? "Update" : "Create"}
          </Button>
        }
      >
        <form
          id="registerform"
          onSubmit={formik.handleSubmit}
          className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4"
        >
          <div className="md:col-span-2">
            {/* Field name label */}
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Upload Resume <span className="text-red-500">*</span>
            </label>

            {/* Container for the button and file name */}
            <div className="flex items-center gap-3">
              <label
                htmlFor="resume"
                className={`px-3 py-1 bg-blue-900 text-white rounded-md cursor-pointer transition-colors duration-200 hover:bg-blue-800 text-sm ${isParsing ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                style={{ minWidth: '90px' }}
              >
                Choose File
                <input
                  id="resume"
                  name="resume"
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={handleResumeUpload}
                  disabled={isParsing}
                  className="hidden"
                />
              </label>
              {resumeFile && (
                <span className="text-blue-900 text-sm font-medium">
                  {resumeFile.name}
                </span>
              )}
              {isParsing && <span className="text-blue-500 text-sm">(Parsing...)</span>}
            </div>

            {/* Error message */}
            {formik.touched.resume && formik.errors.resume && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.resume as string}</p>
            )}
          </div>


          {/* First Name Input */}
          <div>
            <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
              First Name <span className="text-red-500">*</span>
            </label>
            <input
              id="firstName"
              name="firstName"
              type="text"
              value={formik.values.firstName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.firstName && formik.errors.firstName ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.firstName && formik.errors.firstName && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.firstName}</p>
            )}
          </div>

          {/* Middle Name Input */}
          <div>
            <label htmlFor="middleName" className="block text-sm font-medium text-gray-700 mb-1">
              Middle Name
            </label>
            <input
              id="middleName"
              name="middleName"
              type="text"
              value={formik.values.middleName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.middleName && formik.errors.middleName ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.middleName && formik.errors.middleName && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.middleName}</p>
            )}
          </div>

          {/* Last Name Input */}
          <div>
            <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
              Last Name <span className="text-red-500">*</span>
            </label>
            <input
              id="lastName"
              name="lastName"
              type="text"
              value={formik.values.lastName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.lastName && formik.errors.lastName ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.lastName && formik.errors.lastName && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.lastName}</p>
            )}
          </div>

          {/* Date of Birth Input */}
          <div>
            <label htmlFor="dateOfBirth" className="block text-sm font-medium text-gray-700 mb-1">
              Date of Birth <span className="text-red-500">*</span>
            </label>
            <input
              id="dateOfBirth"
              name="dateOfBirth"
              type="date"
              value={formik.values.dateOfBirth}
              onChange={e => {
                let value = e.target.value;
                const parts = value.split('-');
                if (parts[0] && parts[0].length > 4) {
                  parts[0] = parts[0].slice(0, 4);
                  value = parts.join('-');
                }
                formik.setFieldValue('dateOfBirth', value);
              }}
              onBlur={formik.handleBlur}
              disabled={isEditMode}
              className={`w-full px-3 py-2 rounded-md border text-sm ${isEditMode ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'
                } ${formik.touched.dateOfBirth && formik.errors.dateOfBirth ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.dateOfBirth && formik.errors.dateOfBirth && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.dateOfBirth}</p>
            )}
          </div>

          {/* Gender Input */}
          <div>
            <label htmlFor="gender" className="block text-sm font-medium text-gray-700 mb-1">
              Gender <span className="text-red-500">*</span>
            </label>
            <select
              id="gender"
              name="gender"
              value={formik.values.gender}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.gender && formik.errors.gender ? 'border-red-500' : 'border-gray-300'
                }`}
            >
              <option value="">Select gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Others">Others</option>
            </select>
            {formik.touched.gender && formik.errors.gender && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.gender}</p>
            )}
          </div>

          {/* Email Input */}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
              Email <span className="text-red-500">*</span>
            </label>
            <input
              id="email"
              name="email"
              type="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled={isEditMode}
              className={`w-full px-3 py-2 rounded-md border text-sm ${isEditMode ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'
                } ${formik.touched.email && formik.errors.email ? 'border-red-500' : 'border-gray-300'}`}
            />
            {formik.touched.email && formik.errors.email && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.email}</p>
            )}
          </div>

          {/* Alternate Email Input */}
          <div>
            <label htmlFor="alternateEmail" className="block text-sm font-medium text-gray-700 mb-1">
              Alternate Email
            </label>
            <input
              id="alternateEmail"
              name="alternateEmail"
              type="email"
              value={formik.values.alternateEmail}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.alternateEmail && formik.errors.alternateEmail ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.alternateEmail && formik.errors.alternateEmail && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.alternateEmail}</p>
            )}
          </div>

          {/* Phone Number Input */}
          <div>
            <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
              Mobile Number <span className="text-red-500">*</span>
            </label>
            <PhoneInput
              defaultCountry="in"
              disabled={isEditMode}
              countrySelectorStyleProps={{
                buttonStyle: {
                  height: '40px',
                  border: formik.touched.phoneNumber && formik.errors.phoneNumber
                    ? '1px solid #ef4444'
                    : '1px solid #d1d5db',
                  borderRadius: '6px 0 0 6px',
                  background: '#fff',
                  padding: '0 8px',
                  cursor: isEditMode ? 'not-allowed' : 'pointer',
                  color: isEditMode ? '#6b7280' : 'inherit',
                },
              }}
              value={formik.values.phoneNumber}
              onChange={(value) => {
                formik.setFieldValue('phoneNumber', value);
              }}
              onBlur={() => formik.setFieldTouched('phoneNumber', true)}
              forceDialCode
              inputProps={{
                disabled: isEditMode,
                name: 'phoneNumber',
                className: `w-full px-3 py-2 rounded-r-md border text-sm ${isEditMode ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-white text-gray-900'
                  } ${formik.touched.phoneNumber && formik.errors.phoneNumber ? 'border-red-500' : 'border-gray-300'}`,
                style: { height: '40px' },
              }}
              style={{
                display: 'flex',
                alignItems: 'center',
              }}
              inputStyle={{
                borderRadius: '0 6px 6px 0',
                borderLeft: 'none',
              }}
            />
            {formik.touched.phoneNumber && formik.errors.phoneNumber && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.phoneNumber}</p>
            )}
          </div>

          {/* Alternate Phone Number Input */}
          <div>
            <label htmlFor="alternatePhoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
              Alternate PhoneNumber
            </label>
            <PhoneInput
              defaultCountry="in"
              value={formik.values.alternatePhoneNumber}
              onChange={(value) => {
                formik.setFieldValue('alternatePhoneNumber', value);
              }}
              onBlur={() => formik.setFieldTouched('alternatePhoneNumber', true)}
              forceDialCode
              inputProps={{
                id: 'alternatePhoneNumber',
                name: 'alternatePhoneNumber',
                className: `w-full px-3 py-2 rounded-r-md border text-sm bg-white ${formik.touched.alternatePhoneNumber && formik.errors.alternatePhoneNumber
                    ? 'border-red-500'
                    : 'border-gray-300'
                  }`,
                style: { height: '40px' },
              }}
              style={{
                display: 'flex',
                alignItems: 'center',
              }}
              countrySelectorStyleProps={{
                buttonStyle: {
                  height: '40px',
                  border: formik.touched.alternatePhoneNumber && formik.errors.alternatePhoneNumber
                    ? '1px solid #ef4444'
                    : '1px solid #d1d5db',
                  borderRadius: '6px 0 0 6px',
                  background: '#fff',
                  padding: '0 8px',
                },
              }}
              inputStyle={{
                borderRadius: '0 6px 6px 0',
                borderLeft: 'none',
              }}
            />
            {formik.touched.alternatePhoneNumber && formik.errors.alternatePhoneNumber && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.alternatePhoneNumber}</p>
            )}
          </div>

          {/* Address Input */}
          <div>
            <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
              Address <span className="text-red-500">*</span>
            </label>
            <input
              id="address"
              name="address"
              type="text"
              value={formik.values.address}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.address && formik.errors.address ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.address && formik.errors.address && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.address}</p>
            )}
          </div>

          {/* Current Salary Input */}
          <div>
            <label htmlFor="currentSalary" className="block text-sm font-medium text-gray-700 mb-1">
              Current Salary <span className="text-red-500">*</span>
            </label>
            <input
              id="currentSalary"
              name="currentSalary"
              type="text"
              value={formik.values.currentSalary}
              onChange={(e) => {
                const formatted = formatSalaryWithCommas(e.target.value);
                formik.setFieldValue('currentSalary', formatted);
              }}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.currentSalary && formik.errors.currentSalary ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.currentSalary && formik.errors.currentSalary && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.currentSalary}</p>
            )}
          </div>

          {/* Expected Salary Input */}
          <div>
            <label htmlFor="expectedSalary" className="block text-sm font-medium text-gray-700 mb-1">
              Expected Salary <span className="text-red-500">*</span>
            </label>
            <input
              id="expectedSalary"
              name="expectedSalary"
              type="text"
              value={formik.values.expectedSalary}
              onChange={(e) => {
                const formatted = formatSalaryWithCommas(e.target.value);
                formik.setFieldValue('expectedSalary', formatted);
              }}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.expectedSalary && formik.errors.expectedSalary
                  ? 'border-red-500'
                  : 'border-gray-300'
                }`}
            />
            {formik.touched.expectedSalary && formik.errors.expectedSalary && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.expectedSalary}</p>
            )}
          </div>

          {/* Availability of Joining Input */}
          <div>
            <label htmlFor="availabilityOfJoining" className="block text-sm font-medium text-gray-700 mb-1">
              Availability of Joining <span className="text-red-500">*</span>
            </label>
            <input
              id="availabilityOfJoining"
              name="availabilityOfJoining"
              type="date"
              value={formik.values.availabilityOfJoining}
              onChange={e => {
                let value = e.target.value;
                const parts = value.split('-');
                if (parts[0] && parts[0].length > 4) {
                  parts[0] = parts[0].slice(0, 4);
                  value = parts.join('-');
                }
                formik.setFieldValue('availabilityOfJoining', value);
              }}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.availabilityOfJoining && formik.errors.availabilityOfJoining ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.availabilityOfJoining && formik.errors.availabilityOfJoining && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.availabilityOfJoining}</p>
            )}
          </div>

          {/* Candidate Role Input */}
          <div>
            <label htmlFor="candidateRole" className="block text-sm font-medium text-gray-700 mb-1">
              Candidate Role <span className="text-red-500">*</span>
            </label>
            <input
              id="candidateRole"
              name="candidateRole"
              type="text"
              value={formik.values.candidateRole}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.candidateRole && formik.errors.candidateRole ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.candidateRole && formik.errors.candidateRole && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.candidateRole}</p>
            )}
          </div>

          {/* Experience Input */}
          <div>
            <label htmlFor="experience" className="block text-sm font-medium text-gray-700 mb-1">
              Experience <span className="text-red-500">*</span>
            </label>
            <input
              id="experience"
              name="experience"
              type="text"
              value={formik.values.experience}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.experience && formik.errors.experience ? 'border-red-500' : 'border-gray-300'
                }`}
            />
            {formik.touched.experience && formik.errors.experience && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.experience}</p>
            )}
          </div>

          {/* Notice Period Input */}
          <div>
            <label htmlFor="noticePeriod" className="block text-sm font-medium text-gray-700 mb-1">
              Notice Period <span className="text-red-500">*</span>
            </label>
            <select
              id="noticePeriod"
              name="noticePeriod"
              value={formik.values.noticePeriod}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.noticePeriod && formik.errors.noticePeriod ? 'border-red-500' : 'border-gray-300'
                }`}
            >
              <option value="">Select notice period</option>
              {noticePeriodOptions.map((np) => (
                <option key={np} value={np}>{np}</option>
              ))}
            </select>
            {formik.touched.noticePeriod && formik.errors.noticePeriod && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.noticePeriod}</p>
            )}
          </div>

          {/* Skills Input */}
          <div>
            <label htmlFor="skills" className="block text-sm font-medium text-gray-700 mb-1">
              Skills <span className="text-red-500">*</span>
            </label>
            <input
              id="skillsInput"
              type="text"
              placeholder="Type a skill and press Enter"
              className="w-full px-3 py-2 rounded-md border text-sm bg-white mb-2"
              list="skillsOptions"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  const value = (e.target as HTMLInputElement).value.trim();
                  if (!value) return;

                  const lowerValue = value.toLowerCase();
                  if (!formik.values.skills.map((s) => s.toLowerCase()).includes(lowerValue)) {
                    formik.setFieldValue('skills', [...formik.values.skills, value]);
                    formik.setFieldTouched('skills', true);
                  }
                  (e.target as HTMLInputElement).value = '';
                }
              }}
            />
            <datalist id="skillsOptions">
              {skillsOptions.map((skill) => (
                <option key={skill} value={skill} />
              ))}
            </datalist>
            <div className="flex flex-wrap gap-2 mt-2">
              {formik.values.skills.map((skill: string, idx: number) => (
                <span
                  key={skill + idx}
                  className="inline-flex items-center px-3 py-1 bg-gray-600 text-white rounded text-xs max-w-[48%] break-words"
                >
                  {skill}
                  <button
                    type="button"
                    className="ml-2 text-white hover:text-red-300 cursor-pointer"
                    onClick={() => {
                      const newSkills = formik.values.skills.filter((_, i) => i !== idx);
                      formik.setFieldValue('skills', newSkills);
                      formik.setFieldTouched('skills', true);
                    }}
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
            {formik.touched.skills && formik.errors.skills && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.skills as string}</p>
            )}
          </div>

          {/* Offers in Hand Input */}
          <div>
            <label htmlFor="offersInHand" className="block text-sm font-medium text-gray-700 mb-1">
              Offers in Hand? <span className="text-red-500">*</span>
            </label>
            <select
              id="offersInHand"
              name="offersInHand"
              value={formik.values.offersInHand ? 'yes' : 'no'}
              onChange={(e) => {
                const hasOffers = e.target.value === 'yes';
                formik.setFieldValue('offersInHand', hasOffers);
                if (!hasOffers) {
                  formik.setFieldValue('numberOfOffers', '');
                }
                formik.setFieldTouched('offersInHand', true);
              }}
              onBlur={formik.handleBlur}
              className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.offersInHand && formik.errors.offersInHand ? 'border-red-500' : 'border-gray-300'
                }`}
            >
              <option value="no">No</option>
              <option value="yes">Yes</option>
            </select>
            {formik.touched.offersInHand && formik.errors.offersInHand && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.offersInHand as string}</p>
            )}
          </div>

          {/* Number of Offers Input */}
          {formik.values.offersInHand && (
            <div>
              <label htmlFor="numberOfOffers" className="block text-sm font-medium text-gray-700 mb-1">
                Number of Offers <span className="text-red-500">*</span>
              </label>
              <select
                id="numberOfOffers"
                name="numberOfOffers"
                value={formik.values.numberOfOffers}
                onChange={(e) => {
                  formik.setFieldValue('numberOfOffers', e.target.value);
                  formik.setFieldTouched('numberOfOffers', true);
                }}
                onBlur={formik.handleBlur}
                className={`w-full px-3 py-2 rounded-md border text-sm bg-white ${formik.touched.numberOfOffers && formik.errors.numberOfOffers ? 'border-red-500' : 'border-gray-300'
                  }`}
              >
                <option value="">Select number of offers</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4+">4 or more</option>
              </select>
              {formik.touched.numberOfOffers && formik.errors.numberOfOffers && (
                <p className="text-red-500 text-sm mt-1">{formik.errors.numberOfOffers}</p>
              )}
            </div>
          )}

          {/* AI Summary and Ratings Display */}
          {aiSummary && (
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">AI Summary</label>
              <textarea
                readOnly
                value={aiSummary}
                className="w-full px-3 py-2 rounded-md border text-sm bg-gray-100  border-gray-300"
                rows={4}
              />
            </div>
          )}
          {(aiRatings.collegeRating > 0 || aiRatings.companyRating > 0 || aiRatings.experienceRating > 0 || aiRatings.skillsRating > 0) && (
            <div className="md:col-span-2 grid grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">College Rating</label>
                <div className="flex items-center">
                  <span className="text-lg font-semibold text-blue-600">{aiRatings.collegeRating}</span>
                  <span className="text-gray-500 ml-1">/5</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Company Rating</label>
                <div className="flex items-center">
                  <span className="text-lg font-semibold text-green-600">{aiRatings.companyRating}</span>
                  <span className="text-gray-500 ml-1">/5</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Experience Rating</label>
                <div className="flex items-center">
                  <span className="text-lg font-semibold text-purple-600">{aiRatings.experienceRating}</span>
                  <span className="text-gray-500 ml-1">/5</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Skills Rating</label>
                <div className="flex items-center">
                  <span className="text-lg font-semibold text-orange-600">{aiRatings.skillsRating}</span>
                  <span className="text-gray-500 ml-1">/5</span>
                </div>
              </div>
            </div>
          )}
        </form>
      </DrawerLayout>
    </>
  );
};

export default CandidateForm;