export const formatDate = (dateString: string): string => {
  if (!dateString) return 'N/A';

  try {
    const safeDateString = dateString.includes('.')
      ? dateString.split('.')[0] + 'Z'
      : dateString;

    const date = new Date(safeDateString);

    if (isNaN(date.getTime())) return 'Invalid Date';

    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    }).format(date);
  } catch (e) {
    return 'Invalid Date';
  }
};
export const getStatusColor = (status?: string): string => {
  switch (status?.toLowerCase()) {
    case 'pending':
      return 'bg-yellow-500';
    case 'interviewing':
      return 'bg-blue-500';
    case 'hired':
      return 'bg-green-500';
    case 'rejected':
      return 'bg-red-500';
    case 'active':
      return 'bg-green-500';
    case 'inactive':
      return 'bg-gray-400';
    default:
      return 'bg-gray-500';
  }
};
export const getStatusText = (status?: string): string => {
  if (!status || typeof status !== 'string') return '';
  return status.charAt(0).toUpperCase() + status.slice(1).toLowerCase();
};

