package com.soarswell.tracker.model.payload;

import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.RegExConstants;

import jakarta.validation.constraints.Pattern;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import io.swagger.v3.oas.annotations.media.Schema;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserUpdateRequest {

    @Schema(example = Constants.FIRST_NAME)
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = Constants.FIRSTNAME_FORMAT)
    private String firstName;

    @Schema(example = Constants.MIDDLE_NAME)
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = Constants.MIDDLE_NAME_FORMAT)
    private String middleName;

    @Schema(example = Constants.LAST_NAME)
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = Constants.LASTNAME_FORMAT)
    private String lastName;

    @Schema(example = Constants.PHONE)
    @Min(value = Constants.PHONE_MIN, message = Constants.PHONE_MIN_MESSAGE)
    @ValidPhoneNumber(message = "{invalid.mobile.number}")
    String phoneNumber;

    @Schema(example=Constants.ROLE)
    @Pattern(regexp = RegExConstants.ROLE_VALIDATION_PATTERN,message="{role.invalid.format}")
    private String role;
}