import React, { useEffect, useState, useLayoutEffect, useRef } from "react";
import { useLocation } from "react-router";
import { VpnKey as VpnKeyIcon } from "@mui/icons-material";
import type { Comment, CommentFormData } from "~/pages/types/types";
import type { Client } from "~/pages/types/types";
import clientService from "~/services/client/client.services";
import {
  addComment,
  getAllByClientId as getComments,
  subscribe,
} from "~/services/client/client.comments";
import ClientHeader from "./ClientHeader";
import CommentList from "../comments/CommentList";
import CommentForm from "../comments/CommentForm";
import Card from "~/components/ui/Card";
import CustomSnackbar from "~/components/ui/Customsnackbar";
import { HomeIcon } from "~/components/ui/Icons";

const EachClient: React.FC = () => {
  const location = useLocation();
  const { clientId } = location.state || {};
  const [client, setClient] = useState<Client | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [newCommentIds, setNewCommentIds] = useState<Set<string>>(new Set());
  const scrollRef = useRef<HTMLDivElement>(null);
  const initialLoadRef = useRef(true);

  const [snackbar, setSnackbar] = useState<{
    message: string;
    severity: "success" | "error" | "info" | "warning";
    open: boolean;
  }>({ message: "", severity: "error", open: false });

  const NotFoundIcon = VpnKeyIcon;

  const sortByDate = (list: Comment[]) =>
    list.sort(
      (a, b) =>
        new Date(b.createDate).getTime() - new Date(a.createDate).getTime()
    );

  const clearNewCommentIds = (ids: string[]) => {
    setTimeout(() => {
      setNewCommentIds((prev) => {
        const updated = new Set(prev);
        ids.forEach((id) => updated.delete(id));
        return updated;
      });
    },); // delay so highlight shows briefly
  };

  useLayoutEffect(() => {
    if (!loading && initialLoadRef.current && scrollRef.current && comments.length > 0) {
      requestAnimationFrame(() => {
        if (scrollRef.current) {
          scrollRef.current.scrollTop = 0;
          initialLoadRef.current = false;
        }
      });
    }
  }, [loading, comments]);

  useEffect(() => {
    if (!clientId) return;

    const fetchData = async () => {
      setLoading(true);
      try {
        const clientData = await clientService.getClientById(clientId);
        if (!clientData) {
          setError("Client not found");
          return;
        }
        setClient(clientData);

        const commentList = await getComments(clientId);
        setComments(sortByDate(commentList));
      } catch (err) {
        setError("Failed to load data");
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    const unsubscribe = subscribe(clientId, (updatedComments: Comment[]) => {
      if (!Array.isArray(updatedComments)) return;

      setComments((prev) => {
        const map = new Map<string, Comment>();
        [...updatedComments, ...prev].forEach((c) => map.set(c.id, c));
        return sortByDate(Array.from(map.values()));
      });

      const newIds = updatedComments.map((c) => c.id);
      setNewCommentIds((prev) => {
        const updated = new Set(prev);
        newIds.forEach((id) => updated.add(id));
        return updated;
      });

      clearNewCommentIds(newIds);
    });

    return () => unsubscribe();
  }, [clientId]);

  const handleSubmitComment = async (data: CommentFormData) => {
    if (!client) return;

    setSubmitting(true);
    try {
      const newCommentFromServer = await addComment(client.id.toString(), data);
      const newComment: Comment = {
        ...newCommentFromServer,
        createDate: newCommentFromServer.createDate || new Date().toISOString(),
      };

      setSnackbar({
        message: "Comment added successfully!",
        severity: "success",
        open: true,
      });

      setComments((prev) => {
        const exists = prev.some((c) => c.id === newComment.id);
        const updated = exists ? prev : [newComment, ...prev];
        return sortByDate(updated);
      });

      setNewCommentIds((prev) => new Set(prev).add(newComment.id));
      clearNewCommentIds([newComment.id]);
    } catch (err: any) {
      const errorMsg =
        err?.response?.data?.error?.message || "Failed to add comment";
      setSnackbar({
        message: errorMsg,
        severity: "error",
        open: true,
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto p-4">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-32 w-32 bg-blue-200 rounded-full mb-4" />
          <div className="h-6 w-40 bg-gray-200 rounded mb-2" />
          <div className="h-4 w-64 bg-gray-200 rounded" />
        </div>
      </div>
    );
  }

  if (!client) {
    return (
      <div className="max-w-7xl mx-auto p-4 text-center">
        <NotFoundIcon className="text-gray-400 mb-4 mx-auto" sx={{ fontSize: 64 }} />
        <h1 className="text-2xl font-bold text-gray-700 mb-2">Client Not Found</h1>
        <p className="text-gray-500 mb-6">
          {error || "We couldn't find the Client you're looking for."}
        </p>
        <a
          href="/dashboard/clients"
          className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
        >
          Go Back Home
        </a>
      </div>
    );
  }

  return (
    <div className="max-w-8xl mx-auto p-2 flex flex-col overflow-hidden h-[calc(100vh-105px)] w-full">
      {/* Breadcrumb */}
      <div className="flex items-center px-4 py-2">
        <div className="flex items-center text-sm text-gray-600">
          <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
          <a
            href="/dashboard"
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
          >
            Dashboard
          </a>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="flex items-center text-sm text-gray-600">
          <a
            href="/dashboard/clients"
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
          >
            Clients
          </a>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="text-sm text-gray-600">Comments</div>
      </div>

      {/* Header */}
      <div className="flex-shrink-0">
        <ClientHeader Client={client} />
      </div>

      {/* Comments & Form */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto min-h-0">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            <Card>
              <CommentList
                comments={Array.isArray(comments) ? comments : []}
                newCommentIds={newCommentIds}
                isLoading={loading}
              />
            </Card>
          </div>
          <div className="md:col-span-1 space-y-4">
            <CommentForm onSubmit={handleSubmitComment} isSubmitting={submitting} />
          </div>
        </div>
      </div>

      {/* Snackbar */}
      <CustomSnackbar
        open={snackbar.open}
        message={snackbar.message}
        severity={snackbar.severity}
        onClose={() => setSnackbar((prev) => ({ ...prev, open: false }))}
      />
    </div>
  );
};

export default EachClient;
