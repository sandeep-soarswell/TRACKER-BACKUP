package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.ClientCommentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ClientCommentRepository extends JpaRepository<ClientCommentEntity,String> {
    public List<ClientCommentEntity> findByCompanyIdAndClientId(String companyId, String clientId);
}
