import React, { useEffect, useState } from 'react';
import { CalendarMonthIcon, DashboardIcon, BusinessIcon } from '~/components/ui/Icons';
import { StatCard } from './StatCard';
import companyService from '~/services/company/company.service';
import { useNavigate } from 'react-router';
import { getUserRolesFromToken } from '~/auth/rbac';
import RecruiterDashboard from './RecruiterDashboard';
import CompanyDashboard from './CompanyDashboard';
import ManagerDashboard from './ManagerDashboard';

export interface Activity {
  id: string;
  user: string;
  action: string;
  timestamp: string;
  details: string;
  type: 'login' | 'update' | 'delete' | 'create';
}

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [totalCompanies, setTotalCompanies] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [recentCompanies, setRecentCompanies] = useState<any[]>([]);
  const [monthlyRegistrations, setMonthlyRegistrations] = useState<number>(0);
  const [companyRegistrationData, setCompanyRegistrationData] = useState<{ month: string, companies: number }[]>([]);
  const [isClient, setIsClient] = useState<boolean>(false);
  const [ChartComponent, setChartComponent] = useState<any>(null);
  const [currentMonth, setCurrentMonth] = useState<number>(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState<number>(2025); // Explicitly set to 2025

  const userRoles = getUserRolesFromToken();
  const isCompanyAdmin = userRoles.includes('company_admin');
  const isRecruiter = userRoles.includes('recruiter');

  if (isRecruiter) {
    return <RecruiterDashboard />;
  }

  const isManager = userRoles.includes('manager');

  useEffect(() => {
    const fetchTotalCompanies = async () => {
      setLoading(true);
      try {
        const response = await companyService.getAll(0, 1, '', 'createDate', 'desc');
        setTotalCompanies(response.totalElements ?? 0);
      } catch (error) {
        setTotalCompanies(0);
      } finally {
        setLoading(false);
      }
    };

    fetchTotalCompanies();
  }, []);

  useEffect(() => {
    const fetchRecentCompanies = async () => {
      try {
        const response = await companyService.getAll(0, 1000, '', 'createDate', 'desc');
        setRecentCompanies(response.content);
      } catch (error) {
        setRecentCompanies([]);
      }
    };

    fetchRecentCompanies();
  }, []);

  useEffect(() => {
    const fetchMonthlyRegistrations = async () => {
      try {
        const response = await companyService.getAll(0, 1000, '', 'createDate', 'desc');
        const companies = response.content;
        const count = companies.filter((c: any) => {
          if (!c.createDate) return false;
          const d = new Date(c.createDate);
          return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
        }).length;
        setMonthlyRegistrations(count);
      } catch {
        setMonthlyRegistrations(0);
      }
    };

    fetchMonthlyRegistrations();
  }, [currentMonth, currentYear]);

  useEffect(() => {
    setIsClient(true);
    const loadChart = async () => {
      try {
        const { default: ReactApexChart } = await import('react-apexcharts');
        setChartComponent(() => ReactApexChart);
      } catch (error) {}
    };

    loadChart();
  }, []);

  useEffect(() => {
    const fetchCompanyRegistrationData = async () => {
      try {
        const response = await companyService.getAll(0, 1000, '', 'createDate', 'asc');
        const companies = response.content;
        const monthMap: Record<string, number> = {};
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

        companies.forEach((c: any) => {
          if (!c.createDate) return;
          const d = new Date(c.createDate);
          const monthKey = `${d.getFullYear()}-${d.getMonth()}`;
          monthMap[monthKey] = (monthMap[monthKey] || 0) + 1;
        });

        const lastSixMonths = [];
        for (let i = 5; i >= 0; i--) {
          const targetMonth = (currentMonth - i + 12) % 12;
          const targetYear = currentYear - (currentMonth - i < 0 ? 1 : 0); // Adjust year if month goes to previous year
          const monthKey = `${targetYear}-${targetMonth}`;
          const monthLabel = `${monthNames[targetMonth]} ${targetYear}`;
          lastSixMonths.push({
            month: monthLabel,
            companies: monthMap[monthKey] || 0,
          });
        }

        setCompanyRegistrationData(lastSixMonths);
      } catch {
        setCompanyRegistrationData([]);
      }
    };

    fetchCompanyRegistrationData();
  }, [currentMonth, currentYear]);

  // Month change detection
  useEffect(() => {
    const checkMonthChange = () => {
      const now = new Date();
      const newMonth = now.getMonth();
      const newYear = 2025; // Force year to 2025
      if (newMonth !== currentMonth || newYear !== currentYear) {
        setCurrentMonth(newMonth);
        setCurrentYear(newYear);
      }
    };

    const interval = setInterval(checkMonthChange, 60000);
    return () => clearInterval(interval);
  }, [currentMonth, currentYear]);

  if (isCompanyAdmin) {
    return <CompanyDashboard />;
  }

  if (isManager) {
    return <ManagerDashboard />;
  }

  return (
    <div className="space-y-6">
      <div className="bg-white from-blue-100 via-purple-100 to-pink-100 rounded-xl p-8 border border-blue-200/20">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2 bg-black from-blue-600 to-pink-600 bg-clip-text text-transparent">Welcome to the Dashboard!</h1>
            <p className="text-gray-700 text-lg">Monitor and manage your system from one central location</p>
          </div>
          <div className="hidden md:block">
            <DashboardIcon className="w-8 h-8 text-white" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Companies"
          icon={BusinessIcon}
          color="blue"
          active={totalCompanies}
          total={totalCompanies}
        />
        <StatCard
          title="Monthly Registrations"
          icon={CalendarMonthIcon}
          color="blue"
          active={monthlyRegistrations}
          total={totalCompanies}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/80 backdrop-blur-xl rounded-xl p-6 border border-gray-200/50">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Company Registrations -Next 6 Months</h3>
          <div className="relative">
            {isClient && ChartComponent && companyRegistrationData.length > 0 && (
              <ChartComponent
                options={{
                  chart: {
                    type: 'line',
                    toolbar: { show: false },
                    background: 'transparent',
                  },
                  stroke: { curve: 'smooth', width: 3, colors: ['#3b82f6'] },
                  fill: {
                    type: 'gradient',
                    gradient: {
                      shadeIntensity: 1,
                      opacityFrom: 0.7,
                      opacityTo: 0.1,
                      stops: [0, 90, 100],
                      colorStops: [
                        { offset: 0, color: '#3b82f6', opacity: 0.7 },
                        { offset: 100, color: '#8b5cf6', opacity: 0.1 },
                      ],
                    },
                  },
                  dataLabels: { enabled: false },
                  grid: {
                    borderColor: '#e5e7eb',
                    strokeDashArray: 4,
                    xaxis: { lines: { show: false } },
                    yaxis: { lines: { show: true } },
                  },
                  xaxis: {
                    categories: companyRegistrationData.map(d => d.month),
                    labels: {
                      style: { colors: '#6b7280', fontSize: '12px' },
                      rotate: -45,
                      rotateAlways: false,
                    },
                    axisBorder: { show: false },
                    axisTicks: { show: false },
                  },
                  yaxis: {
                    labels: { style: { colors: '#6b7280', fontSize: '12px' } },
                    title: { text: 'Companies', style: { color: '#6b7280', fontSize: '12px' } },
                  },
                  colors: ['#3b82f6'],
                  markers: {
                    size: 6,
                    colors: ['#3b82f6'],
                    strokeColors: '#ffffff',
                    strokeWidth: 2,
                    hover: { size: 8 },
                  },
                  tooltip: {
                    theme: 'dark',
                    y: { formatter: (val: number) => val + ' Companies' },
                  },
                  legend: { show: false },
                }}
                series={[{ name: 'Companies', data: companyRegistrationData.map(d => d.companies) }]}
                type="line"
                height={300}
              />
            )}
            {!isClient && (
              <div className="h-64 flex items-center justify-center">
                <div className="text-gray-500">Loading chart...</div>
              </div>
            )}
          </div>
          <div className="mt-4 text-center">
            <p className="text-sm text-gray-500">
              Total companies registered:
              <span className="font-semibold text-gray-700">
                {loading ? '...' : (totalCompanies ?? 0).toLocaleString()}
              </span>
            </p>
          </div>
        </div>

        <div className="bg-white/80 backdrop-blur-xl rounded-xl p-6 border border-gray-200/50">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Company Registrations</h3>
          <div className="space-y-3 max-h-90 overflow-y-5 pr-2">
            {recentCompanies.slice(0, 5).map((company, index) => (
              <div key={company.id} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors">
                <div className="flex items-center mb-1 gap-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">{company.companyName?.charAt(0) || '?'}</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{company.companyName}</p>
                    <p className="text-xs text-gray-500">ID: {company.companyRegNo}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span
                    className={`inline-flex px-2 bg-green-100 text-green-800 py-1 text-xs font-semibold rounded-full ${
                      company.status === 'Active'
                        ? 'bg-green-100 text-green-800'
                        : company.status === 'Pending'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {company.status}
                  </span>
                  <p className="text-xs text-gray-500 mt-1">{company.createDate ? new Date(company.createDate).toLocaleDateString() : ''}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;