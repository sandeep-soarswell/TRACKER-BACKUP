package com.soarswell.tracker.util;

import com.soarswell.tracker.model.ResourceType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.time.LocalTime;
import java.util.Date;

@Component
@Service
@Slf4j
public class ResourceIdUtils {

    public static String generateSuperAdminResourceId(String companyName) {
        return generateGlobalResourceId(ResourceType.TRACKER_ADMIN, companyName);
    }

    public static String generateCompanyResourceId(String id) {
        return generateGlobalResourceId(ResourceType.COMPANY, id);
    }

    public static String generateUserResourceId(String role,String id) {
        if(role.equalsIgnoreCase(Constants.RECRUITER)) {
            return generateGlobalResourceId(ResourceType.RECRUITER, id);
        }
        else if(role.equalsIgnoreCase(Constants.MANAGER)){
            return generateGlobalResourceId(ResourceType.MANAGER, id);
        }
        else if(role.equalsIgnoreCase(Constants.COMPANY_ADMIN)){
            return generateGlobalResourceId(ResourceType.COMPANY_ADMIN,id);
        }
        return null;
    }

    public static String generateEventResourceId(String companyId, LocalTime event) {
        return generateGlobalResourceId(ResourceType.EVENT, companyId, event);
    }
    public static String generateJobResourceId(String id) {
        return generateGlobalResourceId(ResourceType.JOB, id);
    }

    public static String generateCandidateResourceId(String companyId,String id) {
        return generateGlobalResourceId(ResourceType.CANDIDATE,companyId, id);
    }
    public static String generateClientResourceId(String companyId, String id){
        return generateGlobalResourceId(ResourceType.CLIENT,companyId,id);
    }
    public static String generateCommentResourceId(Date date){
        return generateGlobalResourceId(ResourceType.COMMENT,date);
    }
    public static String generateCandidateJobResourceId(String candidateId,String jobId,String clientId){
        String id=candidateId.concat(jobId).concat(clientId);
        return generateGlobalResourceId(ResourceType.CANDIDATE_JOB,id);
    }

    public static String generateCandidateUserResourceId(String candidateId, String userId) {
        String id = candidateId.concat(userId);
        return generateGlobalResourceId(ResourceType.CANDIDATE_USER, id);
    }

    public static String generateCandidateClientResourceId(String candidateId, String clientId) {
        String id = candidateId.concat(clientId);
        return generateGlobalResourceId(ResourceType.CLIENT, id);
    }

    public static  String generateClientCommentResourceId(String companyId, String clientId, Date date) {
      return generateGlobalResourceId(ResourceType.CILENT_COMMENT, companyId, clientId, date);
    }
    /**
     * Generate a global resource ID based on the resource type
     *
     * @param type The type of resource
     * @param args the values of attributes that uniquely identify the resource. The
     *             generator
     *             is sensitive to the order of the specified values
     */
    public static String generateGlobalResourceId(ResourceType type, Object... args) {
        boolean isCaseSensitive = false;
        final String prefix = ((type != null && type != ResourceType.UNDEFINED)
                ? type.persistValue()
                : Constants.DEFAULT)
                + "-";

        StringBuilder md5Input = new StringBuilder();
        for (Object arg : args) {
            if (arg != null) {
                if (md5Input.length() == 0) {
                    md5Input.append(arg.toString());
                } else {
                    md5Input.append(":").append(arg.toString());
                }
            }
        }
        String md5Hash;
        if (isCaseSensitive) {
            md5Hash = DigestUtils.md5DigestAsHex(md5Input.toString().getBytes()).toLowerCase();

        } else {
            md5Hash = DigestUtils.md5DigestAsHex(md5Input.toString().toLowerCase().getBytes()).toLowerCase();

        }
        return prefix + md5Hash;
    }

}