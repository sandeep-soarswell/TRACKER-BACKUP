import axios from 'axios';

const API_BASE_URL = 'https://localhost:8080';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  }
});
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('userToken')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config
})

api.interceptors.response.use(
  (response) => {
    const newToken = response.headers['authorization'] || response.data?.newToken;
    if (newToken) {
      const token = newToken.replace('Bearer ', '');
      localStorage.setItem('userToken', token);
      api.defaults.headers.Authorization = `Bearer ${token}`;
    }
    return response;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default api;

