import React from 'react';
import { PersonIcon, BusinessCenterIcon, GroupsIcon, ClockIcon, MailIcon, PhoneIcon, ChatBubbleOutlineIcon, CalendarMonthIcon, CloseIcon, } from '~/components/ui/Icons';
import type { CalendarEvent } from '~/pages/calendar/CalendarType';

interface EventDetailsModalProps {
  event: CalendarEvent | null;
  isOpen: boolean;
  onClose: () => void;
}

const EventDetailsModal: React.FC<EventDetailsModalProps> = ({
  event,
  isOpen,
  onClose,
}) => {
  if (!isOpen || !event) return null;

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4"
        style={{
          maxHeight: '90vh',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <div className="bg-[#0A2463] text-white px-6 py-4 rounded-t-lg flex items-center justify-between">
          <h2 className="text-xl font-semibold">Event Details</h2>
          <button
            onClick={onClose}
            className="text-white hover:text-gray-200  cursor-pointer transition-colors"
          >
            <CloseIcon fontSize="medium" />
          </button>
        </div>
        <div className="p-6 space-y-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 64px)' }}>
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <CalendarMonthIcon fontSize="small" className="mr-2 text-[#0A2463]" />
              Event Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title
                </label>
                <p className="text-gray-900 font-medium">{event.title}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date
                </label>
                <p className="text-gray-900">{formatDate(new Date(event.date))}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Start Time
                </label>
                <p className="text-gray-900 flex items-center">
                  <ClockIcon fontSize="small" className="mr-1 text-[#0A2463]" />
                  {event.startTime}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  End Time
                </label>
                <p className="text-gray-900 flex items-center">
                  <ClockIcon fontSize="small" className="mr-1 text-[#0A2463]" />
                  {event.endTime}
                </p>
              </div>
              {event.description && (
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <p className="text-gray-900 flex items-start" style={{ whiteSpace: 'pre-line' }}>
                    <ChatBubbleOutlineIcon fontSize="small" className="mr-1 mt-0.5 text-[#0A2463]" />
                    {event.description}
                  </p>
                </div>
              )}
            </div>
          </div>

          {event.tooltip && (event.tooltip.name || event.tooltip.email || event.tooltip.phoneNumber || event.tooltip.jobTitle || event.tooltip.clientName) && (
            <div className="bg-blue-50 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <PersonIcon fontSize="small" className="mr-2 text-[#0A2463]" />
                Candidate Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {event.tooltip.name && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Candidate Name
                    </label>
                    <p className="text-gray-900 font-medium flex items-center">
                      <PersonIcon fontSize="small" className="mr-1 text-[#0A2463]" />
                      {event.tooltip.name}
                    </p>
                  </div>
                )}
                {event.tooltip.email && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <p className="text-gray-900 flex items-center">
                      <MailIcon fontSize="small" className="mr-1 text-[#0A2463]" />
                      {event.tooltip.email}
                    </p>
                  </div>
                )}
                {event.tooltip.phoneNumber && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <p className="text-gray-900 flex items-center">
                      <PhoneIcon fontSize="small" className="mr-1 text-[#0A2463]" />
                      {event.tooltip.phoneNumber}
                    </p>
                  </div>
                )}
                {event.tooltip.jobTitle && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Job Title
                    </label>
                    <p className="text-gray-900 flex items-center">
                      <BusinessCenterIcon fontSize="small" className="mr-1 text-[#0A2463]" />
                      {event.tooltip.jobTitle}
                    </p>
                  </div>
                )}
                {event.tooltip.clientName && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Client Name
                    </label>
                    <p className="text-gray-900 flex items-center">
                      <GroupsIcon fontSize="small" className="mr-1 text-[#0A2463]" />
                      {event.tooltip.clientName}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EventDetailsModal;