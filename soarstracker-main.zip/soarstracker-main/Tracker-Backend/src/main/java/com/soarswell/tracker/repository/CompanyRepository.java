package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.Company;
import com.soarswell.tracker.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Optional;

@Repository
public interface CompanyRepository extends JpaRepository<Company, String> {
   public Optional<Company> findByEmailId(String emailId);
   public Page<Company> findAllByStatus(String status, Pageable pageable);
   @Query("SELECT c FROM Company c WHERE c.status IN :statuses AND (" +
           "LOWER(c.companyName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.emailId) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.companyAddress) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.companyRegNo) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.mobileNo) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.alternateNo) LIKE LOWER(CONCAT('%', :keyword, '%'))" +
           ")")
   Page<Company> searchAllFieldsByStatusIn(@Param("statuses") String status,
                                           @Param("keyword") String keyword,
                                           Pageable pageable);
   public boolean existsById(String companyId);
   public boolean existsByEmailId(String email);
   public boolean existsByCompanyRegNo(String companyRegNo);
   public boolean existsByCompanyName(String companyName);
   public boolean existsByMobileNo(String mobileNo);
   public boolean existsByAlternateNo(String alternateNo);
   public boolean existsByPersonalMailId(String personalMailId);
}