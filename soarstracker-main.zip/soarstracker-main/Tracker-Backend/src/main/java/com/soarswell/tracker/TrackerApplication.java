package com.soarswell.tracker;

import com.soarswell.tracker.database.DatabaseInitializer;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class TrackerApplication {
	public static void main(String[] args) {
		new SpringApplicationBuilder(TrackerApplication.class)
				.initializers(new DatabaseInitializer())
				.run(args);
	}
}
