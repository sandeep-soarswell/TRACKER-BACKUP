package com.soarswell.tracker.model.payload;

import com.soarswell.tracker.persistance.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JobResponse extends AbstractEntity {

    private String title;
    private String description;
    private String location;
    private String skills;
    private String salary;
    private Integer openings;
    private LocalDate deadline;
    private String status;
    private String experience;
    private String clientName;
    private String jobId;
    private String contactPersonName;
    private String contactPersonEmail;
    private String contactPersonPhone;

}
