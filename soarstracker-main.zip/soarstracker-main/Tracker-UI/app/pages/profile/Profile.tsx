import React, { useEffect, useState, useCallback } from 'react';
import { jwtDecode } from 'jwt-decode';
import { motion } from 'framer-motion';
import WorkIcon from '@mui/icons-material/Work';
import BusinessIcon from '@mui/icons-material/Business';
import GroupIcon from '@mui/icons-material/Group';
import AssignmentIcon from '@mui/icons-material/Assignment';
import VerifiedUserIcon from '@mui/icons-material/VerifiedUser';
import { useNavigate } from 'react-router';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import LoadingButton from '@mui/lab/LoadingButton';
import { Snackbar, Alert, CircularProgress, Tooltip } from '@mui/material';
import userService from '~/services/employee/employee.service';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import { isValidPhoneNumber } from 'libphonenumber-js';
import CustomTooltip from '~/components/layout/tooltip';

interface DecodedToken {
  sub: string;
  roles: string[];
  userId: string;
}

interface User {
  firstName: string;
  middleName?: string;
  lastName: string;
  phoneNumber?: string;
}

interface ProfilePageProps {
  onClose?: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ onClose }) => {
  const [decoded, setDecoded] = useState<DecodedToken>({ sub: '', roles: [], userId: '' });
  const [userData, setUserData] = useState<User | null>(null);
  const [editedData, setEditedData] = useState<Partial<User>>({});
  const [isEditing, setIsEditing] = useState(false);
  const [userName, setUserName] = useState<string>('');
  const [role, setRole] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<{ [key: string]: string[] }>({});
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error' | 'warning' | 'info',
  });

  const navigate = useNavigate();

  const showSnackbar = useCallback((message: string, severity: 'success' | 'error' | 'warning' | 'info' = 'success') => {
    setSnackbar({ open: true, message, severity });
  }, []);

  const getRoleInfo = useCallback((role: string) => {
    switch (role) {
      case 'SYS_ADMIN':
        return {
          title: 'Super Admin',
          description: 'You have full access to manage companies under your control.',
        };
      case 'COMPANY_ADMIN':
        return {
          title: 'Company Admin',
          description: 'You have full access to manage users, jobs, and system settings.',
        };
      case 'MANAGER':
        return {
          title: 'Manager',
          description: 'You can create jobs, manage candidates, and track hiring progress.',
        };
      case 'RECRUITER':
        return {
          title: 'Recruiter',
          description: 'You can view job listings, submit applications, and track candidate status.',
        };
      default:
        return { title: 'User', description: 'Welcome to your dashboard.' };
    }
  }, []);

  const getActionsByRole = useCallback((role: string) => {
    switch (role) {
      case 'SYS_ADMIN':
        return [{ label: 'Manage Companies', icon: BusinessIcon, href: '/dashboard/companies' }];
      case 'COMPANY_ADMIN':
      case 'MANAGER':
        return [
          { label: 'Manage Employees', icon: AssignmentIcon, href: '/dashboard/users' },
          { label: 'Manage Candidates', icon: GroupIcon, href: '/dashboard/candidates' },
          { label: 'Manage Clients', icon: VerifiedUserIcon, href: '/dashboard/clients' },
          { label: 'Manage Jobs', icon: WorkIcon, href: '/dashboard/jobs' },
        ];
      case 'RECRUITER':
        return [
          { label: 'Manage Candidates', icon: GroupIcon, href: '/dashboard/candidates' },
          { label: 'Manage Clients', icon: VerifiedUserIcon, href: '/dashboard/clients' },
          { label: 'Manage Jobs', icon: WorkIcon, href: '/dashboard/jobs' },
        ];
      default:
        return [];
    }
  }, []);
  const handleQuickActionClick = useCallback((route: string) => {
    try {
      navigate(route);
      if (onClose) onClose();
    } catch (error) {
      showSnackbar('Navigation failed. Please try again.', 'error');
    }
  }, [navigate, onClose, showSnackbar]);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem('userToken');
        if (!token) {
          showSnackbar('Please log in to access your profile', 'error');
          return;
        }
        let decodedToken: DecodedToken;
        try {
          decodedToken = jwtDecode(token);
        } catch (error) {
          showSnackbar('Invalid authentication token', 'error');
          localStorage.removeItem('userToken');
          return;
        }
        setDecoded(decodedToken);
        const userRole = decodedToken.roles[0];
        const userId = decodedToken.userId;
        const user = decodedToken.sub.split('@')[0];
        setUserName(user.replace(/[0-9]/g, ''));
        setRole(userRole);
        if (userId) {
          const res = await userService.getById(userId);
          if (res.error) {
            showSnackbar('Failed to load user data', 'error');
            return;
          }
          setUserData(res.data);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        showSnackbar('An unexpected error occurred', 'error');
      } finally {
        setLoading(false);
      }
    };
    fetchUserData();
  }, [showSnackbar]);

  const handleEdit = useCallback(() => {
    setEditedData({
      firstName: userData?.firstName || '',
      middleName: userData?.middleName || '',
      lastName: userData?.lastName || '',
      phoneNumber: userData?.phoneNumber || '',
    });
    setIsEditing(true);
    setFieldErrors({});
  }, [userData]);

  const handleCancel = useCallback(() => {
    setIsEditing(false);
    setEditedData({});
    setFieldErrors({});
  }, []);

  const handleInputChange = useCallback((field: keyof User, value: string) => {
    setEditedData((prev: any) => ({ ...prev, [field]: value }));
    if (typeof field === 'string' && fieldErrors[field]) {
      setFieldErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  }, [fieldErrors]);

  const handleSave = useCallback(async () => {
    setSaving(true);

    const errors: { [key: string]: string[] } = {};

    if (!editedData.firstName || editedData.firstName.trim() === '') {
      errors.firstName = ['First name is required'];
    }
    if (!editedData.lastName || editedData.lastName.trim() === '') {
      errors.lastName = ['Last name is required'];
    }
    if (!editedData.phoneNumber || editedData.phoneNumber.trim() === '') {
      errors.phoneNumber = ['Mobile number is required'];
    } else if (!isValidPhoneNumber(editedData.phoneNumber)) {
      errors.phoneNumber = ['Please enter a valid mobile number'];
    }

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      setSaving(false);
      return;
    }

    try {
      setFieldErrors({});
      const updated = { ...userData, ...editedData };
      const response = await userService.update(decoded.userId, updated);
      if (response.error && typeof response.error === 'object' && !Array.isArray(response.error)) {
        const formattedErrors: Record<string, string[]> = {};
        Object.entries(response.error).forEach(([field, message]) => {
          formattedErrors[field] = Array.isArray(message) ? message : [String(message)];
        });
        setFieldErrors(formattedErrors);
        console.error('Validation errors:', formattedErrors);
        return;
      }
      showSnackbar(response.data, 'success');
      setUserData(updated as User);
      setIsEditing(false);
      setEditedData({});
    } catch (error: any) {
      let errorMessages = 'An error occurred';
      if (error.response?.data?.error) {
        const err = error.response.data.error;
        if (typeof err === 'object' && !Array.isArray(err)) {
          const formattedErrors: Record<string, string[]> = {};
          Object.entries(err).forEach(([field, message]) => {
            formattedErrors[field] = Array.isArray(message) ? message : [String(message)];
          });
          setFieldErrors(formattedErrors);
        } else {
          errorMessages = Array.isArray(err)
            ? err.join(', ')
            : typeof err === 'string'
              ? err
              : JSON.stringify(err);
        }
      } else {
        errorMessages = error.message || 'An unexpected error occurred';
      }
      showSnackbar(errorMessages, 'error');
    } finally {
      setSaving(false);
    }
  }, [editedData, userData, decoded.userId, showSnackbar]);

  const { title, description } = getRoleInfo(role);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <CircularProgress size={48} />
          <p className="mt-4 text-gray-600">Loading your profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="max-w-4xl mx-auto px-4">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.4 }} className="space-y-8">
          <motion.div initial={{ x: -30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.1 }} className="flex items-center gap-6 bg-white p-6 rounded-2xl shadow-md">
            <div className="w-20 h-20 flex items-center justify-center">
              <img
                src={`https://api.dicebear.com/9.x/shapes/svg?seed=${decoded.sub}`}
                alt="avatar"
                className="rounded-full w-full h-full"
              />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-800">Welcome, {userName}</h1>
              <p className="text-lg text-[#0A2463] font-medium">{title}</p>
              <p className="text-sm text-gray-600 mt-1">{description}</p>
            </div>
          </motion.div>
          <motion.div initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }} className="bg-gradient-to-br from-[#D4E1F4] via-white to-[#F0F4FB] p-6 rounded-2xl shadow-md">
            <div className="flex items-center gap-3 mb-6">
              <span className="text-3xl">👤</span>
              <h2 className="text-xl font-semibold text-indigo-800">User Information</h2>
              {role !== 'SYS_ADMIN' && (
                !isEditing ? (
                  <Tooltip title="Edit Profile" placement='top' arrow>
                    <EditIcon
                      className="cursor-pointer text-indigo-700 ml-auto hover:text-indigo-900 transition-colors"
                      onClick={handleEdit}
                    />
                  </Tooltip>
                ) : (
                  <div className="flex gap-2 ml-auto">
                    <LoadingButton
                      loading={saving}
                      loadingPosition="start"
                      startIcon={<SaveIcon />}
                      variant="contained"
                      size="small"
                      onClick={handleSave}
                      sx={{ backgroundColor: '#0A2463', '&:hover': { backgroundColor: '#1e40af' } }}
                    >
                      Save
                    </LoadingButton>
                    <Tooltip title="Cancel Changes" placement='top' arrow>
                      <CancelIcon
                        className="cursor-pointer text-red-600 hover:text-red-800 transition-colors"
                        onClick={handleCancel}
                      />
                    </Tooltip>
                  </div>
                )
              )}
            </div>
            <div className="space-y-6 text-gray-700">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 ">Email Address</label>
                <div className={`p-3 bg-gray-100 rounded-lg ${isEditing ? 'cursor-not-allowed' : ''}`}>
                  <span className={`text-gray-900 ${isEditing ? 'cursor-not-allowed' : ''}`}>{decoded.sub}</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                {isEditing ? (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {['firstName', 'middleName', 'lastName'].map((field) => (
                      <div key={field}>
                        <input
                          className={`w-full border-2 p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors ${fieldErrors[field] ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                          value={editedData[field as keyof User] || ''}
                          onChange={(e) => handleInputChange(field as keyof User, e.target.value)}
                          placeholder={`${field.charAt(0).toUpperCase() + field.slice(1).replace("Name", " Name")}`}
                        />
                        {fieldErrors[field]?.map((msg, idx) => (
                          <p key={idx} className="text-red-500 text-xs mt-1 font-medium">{msg}</p>
                        ))}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-3 bg-gray-100 rounded-lg">
                    <span className="text-gray-900">
                      {role === 'SYS_ADMIN'
                        ? 'System Administrator'
                        : `${userData?.firstName || ''} ${userData?.middleName || ''} ${userData?.lastName || ''}`.trim() || 'Not provided'}
                    </span>
                  </div>
                )}
              </div>
              {(isEditing || (userData?.phoneNumber && userData.phoneNumber.trim() !== '')) && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Mobile Number</label>
                  {isEditing ? (
                    <div>
                      <PhoneInput
                        defaultCountry="in"
                        value={editedData.phoneNumber || ''}
                        onChange={(value) => handleInputChange('phoneNumber', value)}
                        onBlur={() => {
                          if (editedData.phoneNumber && editedData.phoneNumber.trim() !== '' && !isValidPhoneNumber(editedData.phoneNumber)) {
                            setFieldErrors(prev => ({
                              ...prev,
                              phoneNumber: ['Please enter a valid mobile number'],
                            }));
                          }
                        }}
                        forceDialCode
                        inputProps={{
                          name: 'phoneNumber',
                          className: `w-full px-3 py-2 rounded-r-md border text-sm bg-white ${fieldErrors.phoneNumber ? 'border-red-500' : 'border-gray-300'}`,
                          style: { height: '40px' },
                        }}
                        countrySelectorStyleProps={{
                          buttonStyle: {
                            height: '40px',
                            border: fieldErrors.phoneNumber ? '1px solid #ef4444' : '1px solid #d1d5db',
                            borderRadius: '6px 0 0 6px',
                            background: '#fff',
                            padding: '0 8px',
                          },
                        }}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                        }}
                        inputStyle={{
                          borderRadius: '0 6px 6px 0',
                          borderLeft: 'none',
                        }}
                      />
                      {fieldErrors.phoneNumber && (
                        fieldErrors.phoneNumber.map((msg, idx) => (
                          <p key={idx} className="text-red-500 text-xs mt-1 font-medium">{msg}</p>
                        ))
                      )}
                    </div>
                  ) : (
                    <div className="p-3 bg-gray-100 rounded-lg">
                      <span className="text-gray-900">{userData?.phoneNumber}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </motion.div>
          <motion.div initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.3 }}>
            <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center gap-2">
              <span>🧩</span> Quick Actions
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
              {getActionsByRole(role).map((action, index) => {
                const Icon = action.icon;
                const colors = ['bg-blue-100 text-blue-700', 'bg-green-100 text-green-700', 'bg-purple-100 text-purple-700', 'bg-orange-100 text-orange-700'];
                const color = colors[index % colors.length];
                const route = action.href.startsWith('#/') ? action.href.slice(1) : action.href;
                return (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.02, y: -2 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex items-center gap-4 p-6 rounded-2xl shadow-md border border-gray-200 hover:border-indigo-300 bg-white group transition-all duration-200 cursor-pointer"
                    onClick={() => handleQuickActionClick(route)}
                  >
                    <div className={`p-3 rounded-full ${color} group-hover:scale-110 transition-transform duration-200`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="font-medium text-gray-800 group-hover:text-indigo-700 transition-colors">{action.label}</span>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </motion.div>
      </div>
      {role !== 'SYS_ADMIN' && (
        <Snackbar 
          open={snackbar.open} 
          autoHideDuration={4000} 
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <Alert 
            onClose={() => setSnackbar({ ...snackbar, open: false })} 
            severity={snackbar.severity} 
            sx={{ width: '100%' }} 
            variant="filled"
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      )}
    </div>
  );
};

export default ProfilePage;