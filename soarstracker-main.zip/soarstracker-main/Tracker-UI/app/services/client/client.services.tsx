import type { get } from 'http';
import api from '../api/api.services';

const clientService = {

    getAll: async (
        page: number,
        size: number,
        searchTerm: string = "",
        filter: string = "ACTIVE",
        sortByField: string = "createDate",
        desc: string = "desc"
    ) => {
        try {
            const response = await api.get(
                `/clients?page=${page}&size=${size}&sortByField=${sortByField}&desc=${desc}&filter=${filter}${searchTerm ? `&keyword=${encodeURIComponent(searchTerm)}` : ""
                }`
            );
            const dataPayload = response.data?.data || {};
            const clients = dataPayload.data || [];
            const total = dataPayload.totalEntries || 0;

            return {
                content: clients,
                totalElements: total,
            };
        } catch (error) {
            throw error;
        }
    },


    getClientById: async (id: string) => {
        const response = await api.get(`/client/${id}`);
        return response.data.data;
    },

    create: async (payload: any) => {
        const response = await api.post('/clients', payload);
        return response.data;
    },

    update: async (id: string, payload: any) => {
        const response = await api.patch(`/client/${id}`, payload);
        return response.data;
    },

    delete: async (id: string) => {
        const response = await api.delete(`/client/${id}`);
        return response.data;
    },
};

export default clientService;