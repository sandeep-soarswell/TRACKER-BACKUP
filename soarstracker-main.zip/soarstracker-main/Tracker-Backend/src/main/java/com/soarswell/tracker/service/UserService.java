package com.soarswell.tracker.service;

import com.soarswell.tracker.model.payload.UserRegisterRequest;
import com.soarswell.tracker.model.payload.UserUpdateRequest;
import com.soarswell.tracker.exception.TrackerException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface UserService {
    public ResponseEntity<?> register(UserRegisterRequest user) throws TrackerException;
    ResponseEntity<?> getUsers(int page, int size, String sortByField, String order, String keyword,String role, String filter) throws TrackerException;
    public ResponseEntity<?> getUserById(String id) throws TrackerException;
    public ResponseEntity<?> deleteUser(String id) throws TrackerException;
    public ResponseEntity<?> updateUser(String id, UserUpdateRequest user) throws TrackerException;
    public ResponseEntity<?> getUserJobs(String userID,String clientId,int page ,int size)throws TrackerException;
    public ResponseEntity<?> getFreeUsers(int page, int size,String jobId,String role) throws TrackerException;
    public ResponseEntity<?> updateInactiveUserStatus(String userId, String status) throws TrackerException;
    public ResponseEntity<?> getUserAssignedCandidates(String userId, int page, int size,String filter,String statusFilter)  throws TrackerException;
    public ResponseEntity<?> getUserCreatedCandidates(String userId, int page, int size,String filter,String statusFilter) throws TrackerException;
}