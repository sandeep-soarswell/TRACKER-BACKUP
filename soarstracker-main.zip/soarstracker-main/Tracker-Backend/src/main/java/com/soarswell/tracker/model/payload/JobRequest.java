package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.RegExConstants;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JobRequest {

    @NotBlank(message = Constants.JOB_TITLE_REQUIRED)
    @Size(min = 2, max = 100, message = "{job.title.size}")
    @Schema(description = "Job title", example = Constants.SOFTWARE_ENGINEER, required = true)
    private String title;

    @NotBlank(message = Constants.DESCRIPTION_IS_REQUIRED)
    @Size(max = 1000, message = "{job.description.size}")
    @Schema(description = "Job description", example = Constants.JOB_DESCRIPTION)
    private String description;

    @NotBlank(message = Constants.LOCATION_IS_REQUIRED)
    @Size(max = 100, message = "{location.size}")
    @Pattern(regexp = RegExConstants.LOCATION, message = "{invalid.location.format}")
    @Schema(description = "Job location", example = Constants.JOB_LOCATION)
    private String location;

    @NotBlank(message = Constants.SKILLS_IS_REQUIRED)
    @Size(max = 500, message = "{skills.size}")
    @Schema(description = "Required skills", example = Constants.JOB_SKILLS)
    private String skills;

    @NotBlank(message = Constants.EXPERIENCE_IS_REQUIRED)
    @Schema(description = "Experience", example = Constants.JOB_EXPERIENCE)
    private String experience;


    @NotNull(message = Constants.SALARY_IS_REQUIRED)
    @Schema(description = "Salary offered", example = Constants.JOB_SALARY)
    private String salary;

    @Min(value = 1, message = "{minimum.openings}")
    @NotNull(message = Constants.OPENINGS_IS_REQUIRED)
    @Max(value = 1000, message = "{maximum.openings}")
    @Schema(description = "Number of openings", example = Constants.JOB_OPENINGS)
    private Integer openings;

    @Future(message = "{deadline.date}")
    @NotNull(message = Constants.DEADLINE_IS_REQUIRED)
    @Schema(description = "Application deadline", example = Constants.JOB_DEADLINE)
    private LocalDate deadline;

    @Schema(example = "JD-123")
    @Column(unique = true)
    @NotBlank(message = Constants.JOB_ID_REQUIRED)
    @Pattern(regexp = RegExConstants.JOB_ID_PATTERN, message = "{job.id.pattern}")
    private String jobId;

    @Schema(example = Constants.name)
    @NotBlank(message = "{contact.person.name.not.null}")
    @Size(min = 3, max = 25, message = "{contactPersonName.size.message}")
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = "{contactPersonName.pattern.message}")
    private String contactPersonName;

    @Schema(example = Constants.EMAIL)
    @NotBlank(message = "{contact.person.email.not.null}")
    @Email(message = "{invalid.email.format}")
    private String contactPersonEmail;

    @Schema(example = Constants.PHONE)
    @NotBlank(message = "{contact.person.phone.not.null}")
    @ValidPhoneNumber(message = "{invalid.mobile.number}")
    private String contactPersonPhone;
}
