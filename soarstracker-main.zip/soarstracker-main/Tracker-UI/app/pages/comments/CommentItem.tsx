import React from 'react';
import { formatDate } from '~/components/util/formatters';
import type { Comment } from '~/pages/types/types';
interface CommentItemProps {
  comment: Comment;
  isNew?: boolean;
}
const CommentItem: React.FC<CommentItemProps> = ({ comment, isNew = false }) => {
  return (
    <div
      className={`p-4 border-l-2 border-blue-500 mb-4 bg-white rounded-r-lg shadow-sm 
        ${isNew ? 'animate-fadeIn' : ''}
      `}
      style={isNew ? {
        animationDuration: '0.5s',
        animationFillMode: 'both'
      } : {}}
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-medium text-gray-800">
          {comment.createdBy || 'Anonymous'}
        </h3>
        <span className="text-sm text-gray-500">
          {formatDate(comment.createDate)}
        </span>
      </div>
      <p className="text-gray-700 whitespace-pre-line">
        {comment.content}
      </p>
    </div>
  );
};

export default CommentItem;