import React from "react";
import { Box, Typography } from "@mui/material";
import DrawerLayout from "~/components/layout/DrawerLayout";

interface ReadOnlyFieldProps {
  label: string;
  value: string | number | string[] | null | undefined;
}

const Field: React.FC<ReadOnlyFieldProps> = ({ label, value }) => (
  <Box sx={{ display: "flex", flexDirection: "column", mb: 3 }}>
    <Typography
      variant="subtitle2"
      color="text.secondary"
      fontWeight={600}
      sx={{ mb: 0.5 }}
    >
      {label}
    </Typography>
    <Typography
      variant="body1"
      fontWeight={400}
      color="text.primary"
      sx={{
        p: 1.5,
        bgcolor: "#F9FAFB",
        borderRadius: "4px",
        border: "1px solid #E5E7EB",
      }}
    >
      {value !== undefined && value !== null && value !== "" ? value : "—"}
    </Typography>
  </Box>
);

const JobDetailsDrawer = ({
  open,
  onClose,
  job,
}: {
  open: boolean;
  onClose: () => void;
  job: any;
}) => {
  if (!open || !job) return null;

  const fields = [
    { label: "Job ID", value: job.jobId },
    { label: "Title", value: job.title },
    { label: "Experience", value: job.experience },
    { label: "Location", value: job.location },
    { label: "Salary", value: job.salary },
    { label: "Skills Required", value: Array.isArray(job.skills) ? job.skills.join(", ") : job.skills },
    { label: "Description", value: job.description },
    { label: "Openings", value: job.openings },
    { label: "Contact Person Name", value: job.contactPersonName },
    { label: "Contact Person Email", value: job.contactPersonEmail },
    { label: "Contact Person Phone", value: job.contactPersonPhone },
    { label: "Deadline", value: job.deadline },
    { label: "Client", value: job.clientName },
  ];
  
   return (
    <DrawerLayout title="Job Details" onClose={onClose}>
      <form className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4">
        {fields.map(({ label, value }) => (
          <div key={label}>
            <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
            <input
              type="text"
              value={typeof value === "string" || typeof value === "number" ? String(value) : "—"}
              readOnly
              className="w-full px-3 py-2 rounded-md text-sm !bg-gray-100 cursor-not-allowed focus:outline-none border-0"
              style={{ boxShadow: "none" }}
            />
          </div>
        ))}
      </form>
    </DrawerLayout>
  );
};

export default JobDetailsDrawer;
