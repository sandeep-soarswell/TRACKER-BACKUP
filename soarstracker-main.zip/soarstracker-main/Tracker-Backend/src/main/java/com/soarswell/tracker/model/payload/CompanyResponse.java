package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.soarswell.tracker.persistance.AbstractEntity;
import com.soarswell.tracker.util.Constants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Response object for company operations")
public class CompanyResponse extends AbstractEntity {

    @Schema(description = Constants.COMPANY_NAME_DESC, example = Constants.COMPANY_NAME_EXAMPLE, required = true)
    private String companyName;

    @Schema(description = Constants.COMPANY_STATUS_DESC, example = Constants.COMPANY_STATUS_EXAMPLE, required = true)
    private String status;

    @Schema(description = Constants.COMPANY_EMAIL_DESC, example = Constants.COMPANY_EMAIL_EXAMPLE, required = true)
    private String emailId;

    @Schema(description = Constants.COMPANY_ADDRESS_DESC, example = Constants.COMPANY_ADDRESS_EXAMPLE)
    private String companyAddress;

    @Schema(description = Constants.COMPANY_REG_NO_DESC, example = Constants.COMPANY_REG_NO_EXAMPLE)
    private String companyRegNo;

    @Schema(description = Constants.COMPANY_MOBILE_DESC, example = Constants.COMPANY_MOBILE_EXAMPLE, required = true)
    private String mobileNo;

    @Schema(description = Constants.COMPANY_ALT_MOBILE_DESC, example = Constants.COMPANY_ALT_MOBILE_EXAMPLE)
    private String alternateNo;

    @Schema(description = Constants.CONTACT_EMAIL_DESC, example = Constants.CONTACT_EMAIL_EXAMPLE, required = true)
    private String personalMailId;

    @Schema(description = Constants.CONTACT_MOBILE_DESC, example = Constants.CONTACT_MOBILE_EXAMPLE, required = true)
    private String personalMobileNo;

    @Schema(description = Constants.CONTACT_ADDRESS_DESC, example = Constants.CONTACT_ADDRESS_EXAMPLE)
    private String address;

    @Schema(description = "Company image file name")
    private String imageFile;
}
