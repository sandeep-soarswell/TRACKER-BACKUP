package com.soarswell.tracker.service;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.ClientCommentRequest;
import com.soarswell.tracker.model.payload.CommentRequest;
import org.springframework.http.ResponseEntity;

public interface CommentService {

    ResponseEntity<?> addComment(String candidateId, CommentRequest commentRequest, RequestDetails requestDetails) throws TrackerException;

    ResponseEntity<?> getCommentsByCandidate(String candidateId) throws TrackerException;

    ResponseEntity<?> addSystemComment(String candidateId, String content, RequestDetails requestDetails) throws TrackerException;

    ResponseEntity<?> addClientComment(String clientId, ClientCommentRequest clientCommentRequest, RequestDetails requestDetails) throws TrackerException;

    ResponseEntity<?> getClientComments(String clientId, RequestDetails requestDetails) throws TrackerException;

    public void clientComments(String clientId, String content, RequestDetails requestDetails) throws TrackerException;
}
