package com.soarswell.tracker.controller;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.EventRequest;
import com.soarswell.tracker.model.payload.EventUpdateRequest;
import com.soarswell.tracker.service.EventService;
import com.soarswell.tracker.springsecurity.Authorities;
import com.soarswell.tracker.util.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/events")
@Tag(name = Constants.EVENT_TAG)
@ApiResponses({
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "400", description = "The request is malformed or invalid."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "403", description = "The user does not have the necessary privileges to perform the operation."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "500", description = "An internal server error occurred."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "401", description = "Access Denied."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "503", description = "A service is unreachable."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "504", description = "Gateway Timeout Error"),
        @ApiResponse(responseCode = "200"),
        @ApiResponse(responseCode = "202", content = @Content(schema = @Schema(implementation = ResponseObject.class)))
})
public class EventController {

    @Autowired
    private RequestDetails requestDetails;

    @Autowired
    private EventService eventService;

    @PostMapping
    @PreAuthorize(Authorities.EVENTS_CREATE)
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)}, summary = "${api.createEvent.tag}", description = "${api.createEvent.description}")
    @ApiResponse(responseCode = "200", description = "Successfully created event")
    public ResponseEntity<?> registerEvent(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTH_KEY) String authToken,
            @RequestBody @Valid  EventRequest eventRequest,
            @RequestParam(required = false) String CandidateId,
            @RequestParam(required = false) String JobId) throws TrackerException {
        return eventService.registerEvent(eventRequest, requestDetails, CandidateId, JobId);
    }

    @GetMapping
    @PreAuthorize("isAuthenticated()") // Added for consistency
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)}, summary = "${api.getEvents.tag}", description = "${api.getEvents.description}")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved events")
    public ResponseEntity<?> getEvents(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTH_KEY) String authToken) throws TrackerException{
        return eventService.getEvents(requestDetails);
    }

    @GetMapping(Constants.EVENT_ID)
    @PreAuthorize("isAuthenticated()") // Added for consistency
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)}, summary = "${api.getEventById.tag}", description = "${api.getEventById.description}")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved event by ID")
    public ResponseEntity<?> getEventById(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTH_KEY) String authToken,
            @PathVariable String eventId) throws TrackerException {
        return eventService.getEventById(eventId, requestDetails);
    }

    @RequestMapping(value=Constants.EVENT_ID,method = RequestMethod.PATCH)
    @PreAuthorize("isAuthenticated()") // Added for consistency
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)}, summary = "${api.updateEvent.tag}", description = "${api.updateEvent.description}")
    @ApiResponse(responseCode = "200", description = "Successfully updated event")
    public ResponseEntity<?> updateEvent(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTH_KEY) String authToken,
            @PathVariable String eventId,
            @RequestBody @Valid EventUpdateRequest eventUpdateRequest) throws TrackerException {
        return eventService.updateEvent(eventId, eventUpdateRequest, requestDetails);
    }

    @DeleteMapping(Constants.EVENT_ID)
    @PreAuthorize("isAuthenticated()") // Added for consistency
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)}, summary = "${api.deleteEvent.tag}", description = "${api.deleteEvent.description}")
    @ApiResponse(responseCode = "200", description = "Successfully deleted event")
    public ResponseEntity<?> deleteEvent(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader (Constants.AUTH_KEY) String authToken,
            @PathVariable String eventId) throws TrackerException {
        return eventService.deleteEvent(eventId, requestDetails);
    }

    // This is the updated notifications endpoint
    @GetMapping("/notifications")
    @PreAuthorize("isAuthenticated()") // Ensures the user is logged in
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)}, summary = "Get upcoming event notifications", description = "Retrieves notifications for events starting in the next 30 minutes.")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved event notifications")
    public ResponseEntity<?> getUpcomingEventsNotifications(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTH_KEY) String authToken) {
        return eventService.getUpcomingEventsNotifications(requestDetails);
    }

    @PatchMapping("/notifications")
    @PreAuthorize("isAuthenticated()")
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)}, summary = "Mark notification as Read")
    public ResponseEntity<?> markAsRead(
            @RequestParam(name="eventId") String eventId) {
        return eventService.markNotificationAsRead(eventId,requestDetails);
    }
}