import api from '../api/api.services';

const eventService = {
  create: async (payload: {
    title: string;
    date: string;
    startTime: string;
    endTime: string;
    description: string;
    candidateId?: string;
  }) => {
    const { candidateId, ...eventBody } = payload;
    const query = candidateId ? `?CandidateId=${encodeURIComponent(candidateId)}` : '';
    return api.post(`/events${query}`, eventBody);
  },
  
  getAll: async () => {
    // This assumes the /event endpoint has the nested structure { data: { data: [...] } }
    const response = await api.get('/events');
    return response.data.data;
  },

  update: async (eventId: string, payload:any) => {
    return api.patch(`/events/${eventId}`, payload);
  },

  delete: async (eventId: string) => {
    return api.delete(`/events/${eventId}`);
  },

  // CORRECTED FUNCTION
  getNotifications: async () => {
    const response = await api.get('/events/notifications');
    return response.data;
  },

  markEventAsRead: async ( { eventId }: { eventId: string} ) => {
    const params: any = { eventId };
    const response = await api.patch('/events/notifications', null, { params });
    return response.data;
  }
};

export default eventService;