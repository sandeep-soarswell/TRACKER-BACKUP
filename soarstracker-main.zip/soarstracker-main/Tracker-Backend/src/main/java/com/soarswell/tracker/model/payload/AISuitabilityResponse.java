package com.soarswell.tracker.model.payload;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AISuitabilityResponse {
    private String candidateId;
    private int suitabilityScore;
}