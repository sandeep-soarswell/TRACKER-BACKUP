package com.soarswell.tracker.serviceimpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseBuilder;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.*;
import com.soarswell.tracker.model.payload.*;
import com.soarswell.tracker.repository.*;
import com.soarswell.tracker.service.AiService;
import com.soarswell.tracker.service.CompanyService;
import com.soarswell.tracker.service.EmailService;
import com.soarswell.tracker.service.JobService;
import com.soarswell.tracker.util.*;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.soarswell.tracker.util.TrackerUtils.isValidFieldInClass;

@Slf4j
@Service
public class JobServiceImpl implements JobService {

    @Autowired
    private JobRepository jobRepository;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ClientRepository clientRepository;
    @Autowired
    private CandidateRepository candidateRepository;
    @Autowired
    private RequestDetails requestDetails;
    @Autowired
    AssignmentRepository assignmentRepository;
    @Autowired
    private Validator validator;

    @Autowired
    private CompanyService companyService;
    @Autowired
    private AiService aiService;

    @Autowired
    private EmailService emailService;

    private String getCompanyId() {
        return AuthTokenUtils.extractCompanyId(requestDetails);
    }

    @Override
    @Transactional
    public ResponseEntity<?> createJob(JobRequest jobRequest, String clientId,RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        Map<String,String> exceptions = new HashMap<>();
        companyService.getCompanyById(companyId,requestDetails);
        try {
            if (jobRequest.getTitle() == null || jobRequest.getTitle().trim().isEmpty()) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_TITLE_REQUIRED.getStatusCode()), HttpStatus.BAD_REQUEST);
            }

            if(jobRepository.existsByCompanyIdAndClientIdAndJobId(getCompanyId(),clientId,jobRequest.getJobId())){
                exceptions.put(Constants.JOB_ID,ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_ID_ALREADY_EXISTS.toString()));
            }
            if (!exceptions.isEmpty()) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body(ResponseBuilder.builder().build().createErrorResponse(exceptions));
            }
            Job job = objectMapper.convertValue(jobRequest, Job.class);
            job.setId(ResourceIdUtils.generateJobResourceId( new Date(Instant.now().toEpochMilli())+ "-" + clientId));
            job.setClientId(clientId);
            job.setCompanyId(companyId);
            job.setCreatedBy(requestDetails.getUserId());
            job.setCreateDate(new Date(Instant.now().toEpochMilli()));
            jobRepository.save(job);
            log.info("Job created with id: {}", job.getId());
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.JOB_CREATED),HttpStatus.OK);
        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error creating job: {}", e.getMessage());
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_TO_CREATE_JOB.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<?> getJob(String id) throws TrackerException {
        String companyId=getCompanyId();
        JobResponse job = jobRepository.findByIdAndCompanyIdAndStatus(id, companyId, Status.OPEN.getLongLabel())
                .map(j->{
                    JobResponse jobResponse= objectMapper.convertValue(j, JobResponse.class);
                    jobResponse.setClientName(clientRepository.findById(j.getClientId()).map(ClientEntity::getClientName).orElse("Unknown Client"));
                    return jobResponse;
                })
                .orElse(null);
        if (job != null) {
            return ResponseEntity.status(HttpStatus.OK).body(job);
        }
        TrackerException exception = new TrackerException(Constants.NO_JOB_FOUND, HttpStatus.NOT_FOUND);
        ResponseObject<?> response = ResponseBuilder.builder().build().createFailureResponse(exception);
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    @Override
    public ResponseEntity<?> getJobsByClientId(String clientId,int page,int size, String sortByField,String order,String keyword,String filter) throws TrackerException {
        String companyId=getCompanyId();
        if(!companyRepository.existsById(companyId)){
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_COMPANY_FOUND.getStatusCode()),HttpStatus.NOT_FOUND);
        }
        if(page<0 || size<=0){
            log.error("Invalid pagination parameters: page={}, size={}", page, size);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_PAGINATION_PARAMS.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        if (!isValidFieldInClass(sortByField, Job.class)) {
            log.error("Invalid sort field: {}", sortByField);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_SORTBYFIELD.getStatusCode()),HttpStatus.BAD_REQUEST);
        }
        Sort.Direction sortDirection = Constants.ASC.equalsIgnoreCase(order) ? Sort.Direction.ASC : Sort.Direction.DESC;
        PageRequest pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortByField));
        String status = "";
        if(filter!=null && !filter.trim().isEmpty()) {
            if (!Constants.FILTER_OPEN.equalsIgnoreCase(filter) && !Constants.FILTER_CLOSED.equalsIgnoreCase(filter)) {
                log.error("Invalid filter value: {}", filter);
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_FILTER_VALUE.name()), HttpStatus.BAD_REQUEST
                );
            }
            if (Constants.FILTER_CLOSED.equalsIgnoreCase(filter)) {
                status = Status.CLOSED.getLongLabel();
            } else {
                status = Status.OPEN.getLongLabel();
            }
        }

        Page<Job> jobPage = null;
        List<Job> openJobs = null;
        List<Job> closedJobs = null;
        try {
            if (clientId == null || clientId.trim().isEmpty()) {
                if(keyword != null && !keyword.trim().isEmpty()) {
                    jobPage = jobRepository.searchAllFieldsByCompanyIdAndStatus(companyId, status, keyword.trim(), pageable);
                }
                else {
                    jobPage = jobRepository.findByCompanyIdAndStatus(companyId, status, pageable);
                }
                openJobs = jobRepository.findByCompanyIdAndStatus(companyId, Status.OPEN.getLongLabel());
                closedJobs = jobRepository.findByCompanyIdAndStatus(companyId, Status.CLOSED.getLongLabel());
            }
            else{
                if (clientRepository.findById(clientId).isEmpty()) {
                    throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_CLIENT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND);
                }

                log.info("Client found, proceeding with job retrieval...");

                if(keyword != null && !keyword.trim().isEmpty()) {
                    log.info("Searching with keyword: {}", keyword.trim());
                    jobPage= jobRepository.searchAllFieldsByCompanyIdAndClientIdAndStatus(companyId,clientId,status,keyword.trim(),pageable);
                }
                else{
                    log.info("Searching without keyword, status: '{}'", status);
                    if (status.isEmpty()) {
                        log.info("No status filter, getting all jobs for client");
                        List<Job> allJobs = jobRepository.findByCompanyIdAndClientIdAndStatus(companyId,clientId, Status.OPEN.getLongLabel());
                        log.info("Found {} total jobs for client", allJobs.size());

                        // Create a custom page from the list
                        int start = (int) pageable.getOffset();
                        int end = Math.min((start + pageable.getPageSize()), allJobs.size());

                        if (start > allJobs.size()) {
                            jobPage = Page.empty(pageable);
                        } else {
                            List<Job> pageContent = allJobs.subList(start, end);
                            jobPage = new org.springframework.data.domain.PageImpl<>(pageContent, pageable, allJobs.size());
                        }
                    } else {
                        jobPage = jobRepository.findByCompanyIdAndClientIdAndStatus(companyId, clientId, status, pageable);
                    }
                }

                openJobs = jobRepository.findByCompanyIdAndClientIdAndStatus(companyId,clientId, Status.OPEN.getLongLabel());
                closedJobs = jobRepository.findByCompanyIdAndClientIdAndStatus(companyId,clientId,Status.CLOSED.getLongLabel());

                log.info("Repository results - Total in page: {}, Open jobs: {}, Closed jobs: {}",
                        jobPage.getTotalElements(), openJobs.size(), closedJobs.size());
            }
            List<JobResponse> responses = jobPage.getContent().stream()
                    .map(job->{
                        JobResponse jobResponse= objectMapper.convertValue(job, JobResponse.class);
                        jobResponse.setClientName(clientRepository.findById(job.getClientId()).map(ClientEntity::getClientName).orElse("Unknown Client"));
                        return jobResponse;
                    }).toList();

            long totalEntries = jobPage.getTotalElements();
            long totalOpenJobs = openJobs.size();
            long totalClosedJobs = closedJobs.size();
            Map<String,Object> res = new HashMap<>();
            res.put("data",responses);
            res.put("totalEntries", totalEntries);
            res.put("totalOpenJobs", totalOpenJobs);
            res.put("totalClosedJobs", totalClosedJobs);
            return new  ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(res),HttpStatus.OK);
        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error retrieving jobs for clientId {}: {}", clientId, e.getMessage());
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_TO_RETRIEVE_JOBS.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @Transactional
    public ResponseEntity<?> deleteJob(String id) {
        var jobOpt = jobRepository.findById(id);
        if (jobOpt.isEmpty()) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND);
        }
        var job = jobOpt.get();
        if (job.getStatus().equalsIgnoreCase(Status.CLOSED.getLongLabel())) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_ALREADY_CLOSED.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        job.setStatus(Status.CLOSED.getLongLabel());
        jobRepository.save(job);
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.JOB_STATUS_CLOSED),HttpStatus.OK);
    }

    @Override
    @Transactional
    public ResponseEntity<?> uploadjobs(MultipartFile file, RequestDetails requestDetails, String clientId) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        List<Job> jobs = new ArrayList<>();
        List<BulkValidationError>erroredRecords =new ArrayList<>();
        String fileName = file.getOriginalFilename();

        try {
            if (fileName == null || fileName.isEmpty()) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.SUPPORTED_FILES.getStatusCode()), HttpStatus.BAD_REQUEST);
            }

            if (fileName.endsWith(".csv")) {
                try (var reader = new java.io.BufferedReader(new java.io.InputStreamReader(file.getInputStream()));
                     var csvReader = new com.opencsv.CSVReader(reader)) {

                    String[] header = csvReader.readNext(); // skip header
                    int rowNum = 1;
                    String[] row;
                    while ((row = csvReader.readNext()) != null) {
                        rowNum++;
                        try {
                            JobRequest jobRequest = JobUtils.mapRowToJobRequest(row, rowNum);
                            Set<jakarta.validation.ConstraintViolation<JobRequest>> violations = validator.validate(jobRequest);
                            if (!violations.isEmpty()) {
                                StringBuilder sb = new StringBuilder();
                                for (var v : violations) {
                                    sb.append(v.getMessage()).append(".\n");
                                }
                                erroredRecords.add(new BulkValidationError(jobRequest,sb.toString()));
                                continue;
                            }

                            Job job = objectMapper.convertValue(jobRequest, Job.class);
                            job.setCompanyId(companyId);
                            job.setClientId(clientId);
                            job.setCreateDate(new java.util.Date());
                            job.setCreatedBy(requestDetails.getUserId());
                            job.setStatus(com.soarswell.tracker.model.Status.OPEN.getLongLabel());
                            job.setId(com.soarswell.tracker.util.ResourceIdUtils.generateJobResourceId(
                                    System.currentTimeMillis() + "-" + rowNum + "-" + UUID.randomUUID() + "-" + companyId
                            ));
                            jobs.add(job);
                        } catch (Exception e) {
                            erroredRecords.add(new BulkValidationError(null,e.getMessage()));
                        }
                    }
                }
            } else if (fileName.endsWith(".xlsx")) {
                try (var workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook(file.getInputStream())) {
                    for (int sheetIdx = 0; sheetIdx < workbook.getNumberOfSheets(); sheetIdx++) {
                        var sheet = workbook.getSheetAt(sheetIdx);
                        var rowIterator = sheet.iterator();
                        if (rowIterator.hasNext()) rowIterator.next(); // skip header
                        int rowNum = 1;
                        while (rowIterator.hasNext()) {
                            rowNum++;
                            var row = rowIterator.next();
                            try {
                                JobRequest jobRequest = com.soarswell.tracker.util.JobUtils.mapRowToJobRequest(row, rowNum);
                                Set<jakarta.validation.ConstraintViolation<JobRequest>> violations = validator.validate(jobRequest);
                                if (!violations.isEmpty()) {
                                    StringBuilder sb = new StringBuilder();
                                    for (var v : violations) {
                                        sb.append(v.getMessage()).append(".\n");
                                    }
                                    erroredRecords.add(new BulkValidationError(jobRequest,sb.toString()));
                                    continue;
                                }

                                Job job = objectMapper.convertValue(jobRequest, Job.class);
                                job.setCompanyId(companyId);
                                job.setClientId(clientId);
                                job.setCreateDate(new java.util.Date());
                                job.setCreatedBy(requestDetails.getUserId());
                                job.setStatus(com.soarswell.tracker.model.Status.OPEN.getLongLabel());
                                job.setId(com.soarswell.tracker.util.ResourceIdUtils.generateJobResourceId(
                                        System.currentTimeMillis() + "-" + rowNum + "-" + UUID.randomUUID() + "-" + companyId
                                ));
                                jobs.add(job);
                            } catch (Exception e) {
                                erroredRecords.add(new BulkValidationError(null,e.getMessage()));
                            }
                        }
                    }
                }
            } else {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.SUPPORTED_FILES.getStatusCode()), HttpStatus.BAD_REQUEST);
            }

            List<Job> validJobs = new ArrayList<>();
            for (Job job : jobs) {
                if (jobRepository.existsByCompanyIdAndClientIdAndJobId(getCompanyId(),clientId,job.getJobId())) {
                    continue;
                }
                validJobs.add(job);
            }
            if (!validJobs.isEmpty()) {
                jobRepository.saveAll(validJobs);
            }

            Map<String, Object> response = new HashMap<>();
            response.put("successfulRecords", validJobs.size());
            response.put("failedRecords",erroredRecords);
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(response), HttpStatus.OK);
        } catch (java.io.IOException e) {
            log.error("IO error during bulk job upload: {}", e.getMessage(), e);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_TO_PROCESS_FILE.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error during bulk job upload: {}", e.getMessage(), e);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_TO_PROCESS_FILE.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @Transactional
    public ResponseEntity<?> getUsersByJobId(String id) {
        String companyId=getCompanyId();
        Job job = jobRepository.findByIdAndCompanyIdAndStatus(id,companyId,Status.OPEN.getLongLabel()).orElseThrow(
                ()-> new TrackerException(ErrorMessageHandler.getMessage(
                        ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND));

        if (job.getStatus().equalsIgnoreCase(Status.CLOSED.getLongLabel())) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()),
                    HttpStatus.NOT_FOUND
            );
        }
        if (job.getUsers().isEmpty()) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.NO_USERS_ASSIGNED_JOB.getStatusCode()),
                    HttpStatus.NOT_FOUND
            );
        }
        List<UserResponse> responseList=job.getUsers().stream().map(user -> objectMapper.convertValue(user, UserResponse.class)).toList();
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(responseList));
    }

    @Override
    @Transactional
    public ResponseEntity<?> updateJob(String jobId, JobUpdateRequest jobUpdateRequest, RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        Map<String,String>exceptions=new HashMap<>();
        companyService.getCompanyById(companyId,requestDetails);
        try {
            Optional<Job> jobOpt = jobRepository.findById(jobId);
            if (jobOpt.isEmpty()) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND);
            }
            Job existingJob = jobOpt.get();
            if (existingJob.getStatus().equals(Status.CLOSED.getLongLabel())) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_ALREADY_CLOSED.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            if(jobRepository.existsByCompanyIdAndClientIdAndJobId(getCompanyId(),existingJob.getClientId(),jobUpdateRequest.getJobId())){
                exceptions.put(Constants.JOB_ID,ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_ID_ALREADY_EXISTS.toString()));
            }
            if (!exceptions.isEmpty()) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body(ResponseBuilder.builder().build().createErrorResponse(exceptions));
            }
            boolean flag= PatchHelper.updateValue(existingJob,jobUpdateRequest);
            if(flag) {
                existingJob.setNotificationSent(false);
                existingJob.setUpdateDate(new Date(Instant.now().toEpochMilli()));
                existingJob.setUpdatedBy(requestDetails.getUserId());
                jobRepository.save(existingJob);
                log.info("Job updated successfully with ID: {}", existingJob.getId());
                ResponseObject<String> response = ResponseBuilder.builder().build().createSuccessResponse(Constants.JOB_UPDATED);
                return ResponseEntity.ok(response);
            }
            ResponseObject<String> response = ResponseBuilder.builder().build()
                    .createSuccessResponse(Constants.NO_CHANGES_DETECTED);
            return ResponseEntity.ok(response);
        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error updating job: {}", e.getMessage());
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_TO_UPDATE_JOB.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @Transactional
    public ResponseEntity<?> JobAssignToCandidate(String candidateId,String jobId, RequestDetails requestDetails) throws TrackerException{
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId,requestDetails);
        String currentLoggedInUserMail=requestDetails.getUserId();
        Map<String,String> response=new HashMap<>();
        Candidate candidate=candidateRepository.findByCompanyIdAndIdAndStatus(companyId,candidateId,Status.ACTIVE.getLongLabel())
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND));

        Job job=jobRepository.findByIdAndCompanyIdAndStatus(jobId,companyId,Status.OPEN.getLongLabel())
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND));

        ClientEntity client= clientRepository.findByCompanyIdAndIdAndStatus(companyId,job.getClientId(),Status.ACTIVE.getLongLabel())
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_CLIENT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND));
        boolean flag=userRepository.findByEmail(currentLoggedInUserMail)
                .orElseThrow().getJobs().contains(job);

        boolean hasAdmin=requestDetails.getRoles().stream().anyMatch(role->role.equalsIgnoreCase(Roles.COMPANY_ADMIN.getLongLabel()));
        boolean hasManager=requestDetails.getRoles().stream().anyMatch(role->role.equalsIgnoreCase(Roles.MANAGER.getLongLabel()));
        if(!flag) {
            if(hasAdmin || hasManager){
                log.info("assigning by admin or manager");
            }
            else {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_ACCESS_TO_ASSIGN_TO_JOB.getStatusCode()),HttpStatus.FORBIDDEN);
            }
        }

        if(candidate.getJobAssignment()!=null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResponseBuilder.builder().build().createErrorResponse(
                    ApiResponses.ALREADY_ASSIGNED_TO_CANDIDATE));
        }
        String check_id= ResourceIdUtils.generateCandidateJobResourceId(candidateId,jobId,client.getId());
        if(assignmentRepository.existsByIdAndCandidatureStatus(check_id,Status.REJECTED.getShortLabel())) {
            CandidateJobAssign assignment = assignmentRepository.findById(check_id).orElseThrow();
            if (assignment.getRejectedDate() != null && assignment.getRejectedDate().plusDays(client.getCoolingPeriod()).isAfter(LocalDate.now())) {

                long daysRemaining = assignment.getRejectedDate()
                        .plusDays(client.getCoolingPeriod())
                        .toEpochDay() - LocalDate.now().toEpochDay();
                response.put("daysRemaining",String.valueOf(daysRemaining));
                String message = ErrorMessageHandler.getMessage(ErrorMessageKey.COOLING_PERIOD_NOT_OVER.getStatusCode());
                response.put("cause",message);
                response.put("cooldownDate",assignment.getRejectedDate().plusDays(client.getCoolingPeriod()).toString());
                return ResponseEntity.status(HttpStatus.CONFLICT).body(ResponseBuilder.builder().build().createErrorResponse(response));
            }
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_ASSIGNMENT.getStatusCode()),HttpStatus.BAD_REQUEST);
        }
        String checkClientId=ResourceIdUtils.generateCandidateClientResourceId(candidateId,job.getClientId());
        if(assignmentRepository.existsByClientIdAndCandidatureStatus(checkClientId,Status.REJECTED.getShortLabel())) {
            CandidateJobAssign assign = assignmentRepository.findByClientId(checkClientId)
                    .stream()
                    .filter(a -> a.getRejectedDate() != null)
                    .max(Comparator.comparing(CandidateJobAssign::getAssignedDate))
                    .orElseThrow();
            if (assign.getRejectedDate().plusDays(client.getCoolingPeriod()).isAfter(LocalDate.now())) {
                String message = ErrorMessageHandler.getMessage(ErrorMessageKey.COOLING_PERIOD_NOT_OVER.getStatusCode());
                long daysRemaining = assign.getRejectedDate()
                        .plusDays(client.getCoolingPeriod())
                        .toEpochDay() - LocalDate.now().toEpochDay();
                response.put("daysRemaining", String.valueOf(daysRemaining));
                response.put("cause", message);
                response.put("cooldownDate", assign.getRejectedDate().plusDays(client.getCoolingPeriod()).toString());
                return ResponseEntity.status(HttpStatus.CONFLICT).body(ResponseBuilder.builder().build().createErrorResponse(response));
            }
        }
        //if no assignment found
        CandidateJobAssign newAssignment=new CandidateJobAssign();
        newAssignment.setId(check_id);
        newAssignment.setAssignedDate(LocalDateTime.now());
        newAssignment.setAssignedBy(currentLoggedInUserMail);
        newAssignment.getCandidates().add(candidate);
        newAssignment.setJob(job);
        newAssignment.setClientId(checkClientId);
        newAssignment.setCandidatureStatus(Status.ASSIGNED.getShortLabel());
        candidate.setJobAssignment(assignmentRepository.save(newAssignment));
        candidate.setCandidatureStatus(Status.ASSIGNED.getShortLabel());
        candidateRepository.save(candidate);
        ResponseObject<String> responseObject= ResponseBuilder.builder().build().createSuccessResponse(Constants.JOB_ASSIGNED);
        return ResponseEntity.status(HttpStatus.OK).body(responseObject);
    }

    @Override
    @Transactional
    public ResponseEntity<?> JobAssignToUser(String recruiterId, String jobId) throws TrackerException{
        String companyId=getCompanyId();
        if(!companyRepository.existsById(companyId)){
            throw new TrackerException(ApiResponses.NO_COMPANY_FOUND, HttpStatus.NOT_FOUND);
        }

        Job job=jobRepository.findById(jobId)
                .filter(j->j.getStatus().equalsIgnoreCase(Status.OPEN.getShortLabel()))
                .orElseThrow(()->new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND));

        User user=userRepository.findByIdAndCompanyId(recruiterId,companyId)
                .filter(u->u.getStatus().equalsIgnoreCase(Status.ACTIVE.getShortLabel()))
                .orElseThrow(()->new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND));

        if(user.getJobs().contains(job)){
            throw new TrackerException(ApiResponses.ALREADY_ASSIGNED, HttpStatus.BAD_REQUEST);
        }
        // saving assignment data in intermediate table
        job.getUsers().add(user);
        user.getJobs().add(job);
        jobRepository.save(job);

        ResponseObject<?> response=ResponseBuilder.builder().build().createSuccessResponse(Constants.JOB_ASSIGNED);
        return ResponseEntity.ok(response);
    }


    @Override
    @Transactional
    public ResponseEntity<?> getCandidatesByJobId(String id){
        String companyId=getCompanyId();
        Job job = jobRepository.findByIdAndCompanyIdAndStatus(id,companyId,Status.OPEN.getLongLabel()).orElseThrow(
                ()-> new TrackerException(ErrorMessageHandler.getMessage(
                        ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND));
        if (job.getCandidateJobAssignments().isEmpty()) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_CANDIDATES_ASSIGNED.getStatusCode()), HttpStatus.NOT_FOUND);
        }
        List<CandidateResponse> responseList = job.getCandidateJobAssignments().stream()
                .map(CandidateJobAssign::getCandidates)
                .filter(candidates -> !candidates.isEmpty())
                .map(candidates -> candidates.iterator().next()) // first candidate
                .map(candidate -> {
                    if(candidate.getJobAssignment()!=null || candidate.getAssignment()!=null){
                        CandidateResponse candidateResponse = objectMapper.convertValue(candidate,CandidateResponse.class);
                        if(candidate.getJobAssignment() != null) {
                            log.info("Mapping candidate response for job with client ID: {}", candidate.getJobAssignment().getJob().getTitle());
                            String  clientName= clientRepository.findById(candidate.getJobAssignment().getJob().getClientId())
                                    .map(ClientEntity::getClientName)
                                    .orElse("Unknown Client");
                            log.info("Client name found: {}", clientName);
                            candidateResponse.setJobTitle(candidate.getJobAssignment().getJob().getTitle());
                            candidateResponse.setClientName(clientName);
                            candidateResponse.setJobId(candidate.getJobAssignment().getJob().getJobId());
                        }
                        if( candidate.getAssignment() != null) {
                            candidateResponse.setUserId(candidate.getAssignment().getUser().getId());
                            String fullName=CandidateUtils.safeJoin(candidate.getAssignment().getUser().getFirstName(),
                                    candidate.getAssignment().getUser().getMiddleName(),
                                    candidate.getAssignment().getUser().getLastName());
                            candidateResponse.setUserName(fullName);
                        }
                        return candidateResponse;
                    }

                    return objectMapper.convertValue(candidate, CandidateResponse.class);

                })
                .toList();
        log.info("{}",responseList.stream().findFirst().get());

        return ResponseEntity.ok(
                ResponseBuilder.builder().build().createSuccessResponse(responseList)
        );
    }


    public ResponseEntity<?> getCandidatesByJobIdWithSkills(String jobId,RequestDetails requestDetails) {
        String companyId=AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId,requestDetails);
        String currentLoggedInUserMail=requestDetails.getUserId();
        String currentLoggedInUserRole=requestDetails.getRoles().getFirst();
        Job job = jobRepository.findByIdAndCompanyIdAndStatus(jobId,companyId,Status.OPEN.getLongLabel())
                .orElseThrow(()-> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND));
        if (job.getSkills() == null || job.getSkills().trim().isEmpty()) {
            return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(Collections.emptySet()));
        }
        Set<String> jobSkills = Arrays.stream(job.getSkills().split(","))
                .map(String::trim)
                .map(String::toLowerCase)
                .collect(Collectors.toSet());

        Set<Candidate> matchedCandidates = candidateRepository.findByCompanyIdAndStatus(companyId,Status.ACTIVE.getShortLabel()).stream()
                .filter(candidate -> {
                    if(Objects.isNull(candidate.getJobAssignment())) return true;
                    return currentLoggedInUserRole.equalsIgnoreCase(Roles.RECRUITER.getShortLabel()) && candidate.getAssignment().getUser().getEmail().equals(currentLoggedInUserMail);
                })
                .filter(candidate -> {
                    if (Objects.isNull(candidate.getSkills())) return false;
                    Set<String> candidateSkills = Arrays.stream(candidate.getSkills().split(","))
                            .map(String::trim)
                            .map(String::toLowerCase)
                            .collect(Collectors.toSet());

                    return candidateSkills.stream().anyMatch(jobSkills::contains);
                })
                .collect(Collectors.toSet());
        if(matchedCandidates.isEmpty()){
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATES_NOT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(matchedCandidates));
    }

    @Override
    @Transactional
    public ResponseEntity<?> JobUnassignFromCandidate(String candidateId, String jobId) throws TrackerException {
        String companyId = getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ApiResponses.NO_COMPANY_FOUND, HttpStatus.NOT_FOUND);
        }
        String requestedUser=requestDetails.getUserId();
        Job job = jobRepository.findById(jobId)
                .filter(j -> j.getStatus().equalsIgnoreCase(Status.OPEN.getShortLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND));

        Candidate candidate = candidateRepository.findByCompanyIdAndId(companyId, candidateId)
                .filter(c -> c.getStatus().equalsIgnoreCase(Status.ACTIVE.getShortLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND));
        if (Objects.isNull(candidate.getJobAssignment()) || !candidate.getJobAssignment().getJob().getId().equals(jobId)) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_ASSIGNED_TO_JOB.getStatusCode()), HttpStatus.NOT_FOUND);
        }
        if(!candidate.getAssignment().getUser().getEmail().equals(requestedUser)){
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()),HttpStatus.FORBIDDEN);
        }

        String checkId = ResourceIdUtils.generateCandidateJobResourceId(candidateId, jobId, job.getClientId());
        if (!assignmentRepository.existsById(checkId)) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_ASSIGNED_TO_JOB.getStatusCode()),
                    HttpStatus.NOT_FOUND
            );
        }
        CandidateJobAssign assignment = assignmentRepository.findById(checkId).orElseThrow();
        if(assignment.getCandidatureStatus().equalsIgnoreCase(Status.ASSIGNED.getLongLabel())) {
            assignmentRepository.delete(assignment);
            // removing assignment data
            job.getCandidateJobAssignments().remove(candidate.getJobAssignment());
            candidate.setJobAssignment(null);
            candidate.setCandidatureStatus(Status.CREATED.getShortLabel());
            candidateRepository.save(candidate);

            return new ResponseEntity<>(
                    ResponseBuilder.builder().build().createSuccessResponse(Constants.JOB_UNASSIGNED_FROM_CANDIDATE),
                    HttpStatus.OK
            );
        }
        else{
            ResponseObject<TrackerException> failureResponse =  ResponseBuilder.builder().build().createFailureResponse(
                    new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNASSIGN_FAILED.getStatusCode()), HttpStatus.BAD_REQUEST));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(failureResponse);
        }

    }

    @Override
    @Transactional
    public ResponseEntity<?> JobUnassignFromUser(String userId, String jobId) throws TrackerException {
        String companyId = getCompanyId();
        if (!companyRepository.existsById(companyId)) {
            throw new TrackerException(ApiResponses.NO_COMPANY_FOUND, HttpStatus.NOT_FOUND);
        }

        Job job = jobRepository.findById(jobId)
                .filter(j -> j.getStatus().equalsIgnoreCase(Status.OPEN.getShortLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND));

        User user = userRepository.findByIdAndCompanyId(userId, companyId)
                .filter(u -> u.getStatus().equalsIgnoreCase(Status.ACTIVE.getShortLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND));

        if (!(user.getJobs().contains(job)) || !(job.getUsers().contains(user))) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_ASSIGNED_TO_JOB.getStatusCode()),
                    HttpStatus.BAD_REQUEST
            );
        }
        // removing assignment data
        job.getUsers().remove(user);
        user.getJobs().remove(job);
        return new ResponseEntity<>(
                ResponseBuilder.builder().build().createSuccessResponse(Constants.JOB_UNASSIGNED_FROM_USER),
                HttpStatus.OK
        );
    }

    @Override
    public ResponseEntity<?> getUpcomingJobDeadlineNotifications(RequestDetails requestDetails) {
        String username = requestDetails.getUserId();
        List<JobNotificationResponse> notifications = getJobNotificationsForUser(username);
        return ResponseEntity.ok(notifications);
    }

    private List<JobNotificationResponse> getJobNotificationsForUser(String username) {
        User user = userRepository.findByEmail(username).orElse(null);
        if (user == null) {
            return Collections.emptyList();
        }

        return user.getJobs().stream()
                .filter(job -> job.getDeadline().isEqual(LocalDate.now()))
                .sorted(Comparator.comparing(Job::getCreateDate).reversed())
                .map(job -> new JobNotificationResponse(
                        job.getId(),
                        job.getTitle(),
                        job.getDeadline().toString(),
                        job.getIsRead()
                ))
                .collect(Collectors.toList());
    }

    @Scheduled(cron = "0 0 9 * * *")
    @Transactional
    public void sendJobDeadlineReminder() {
        List<Job> jobs = jobRepository.findByDeadline(LocalDate.now());
        if (jobs.isEmpty()) {
            return;
        }
        log.info("Scheduler: Found {} jobs with deadlines today to notify via email.", jobs.size());
        for (Job job : jobs) {
            for (User user : job.getUsers()) {
                if (user.getEmail() == null || user.getEmail().isBlank()) {
                    continue;
                }
                log.info("Processing job deadline reminder for job ID {} ('{}') for user {}", job.getId(), job.getTitle(), user.getEmail());
                emailService.sendJobDeadlineEmail(user.getEmail(), job.getTitle(), job.getDeadline().toString());
            }
            job.setNotificationSent(true);
            jobRepository.save(job);
            log.info("Job deadline reminder emails queued for job ID {} and notification flag set to true.", job.getId());
        }
    }

    @Override
    public ResponseEntity<?> markNotificationAsRead(String jobId, RequestDetails requestDetails) throws TrackerException{
        Job job=jobRepository.findById(jobId)
                .orElseThrow();
        job.setRead(true);
        jobRepository.save(job);
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(Constants.JOB_READ));
    }

    @Override
    public List<MatchedCandidateResponse> findMatchingCandidates(String jobId) {
        String companyId = getCompanyId();
        Job job = jobRepository.findByIdAndCompanyIdAndStatus(jobId, companyId, Status.OPEN.getLongLabel())
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));

        List<Candidate> allCandidates = candidateRepository.findByCompanyIdAndStatus(companyId, Status.ACTIVE.getLongLabel());
        if (allCandidates.isEmpty()) {
            return Collections.emptyList();
        }

        List<AISuitabilityResponse> suitabilityResults = aiService.getSuitabilityScores(job, allCandidates);
        Map<String, Integer> scoreMap = suitabilityResults.stream()
                .collect(Collectors.toMap(AISuitabilityResponse::getCandidateId, AISuitabilityResponse::getSuitabilityScore));

        return allCandidates.stream()
                .filter(candidate -> scoreMap.containsKey(candidate.getId()))
                .map(candidate -> new MatchedCandidateResponse(candidate, scoreMap.get(candidate.getId())))
                .sorted(Comparator.comparing(MatchedCandidateResponse::getSuitabilityScore).reversed())
                .collect(Collectors.toList());
    }
}