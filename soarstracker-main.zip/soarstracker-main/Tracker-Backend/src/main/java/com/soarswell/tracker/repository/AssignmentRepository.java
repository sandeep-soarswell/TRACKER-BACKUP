package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.CandidateJobAssign;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AssignmentRepository extends JpaRepository<CandidateJobAssign,String> {

    public boolean existsByIdAndCandidatureStatus(String id,String status);
    public boolean existsByClientIdAndCandidatureStatus(String clientId,String status);
    public List<CandidateJobAssign> findByClientId(String clientId);
}
