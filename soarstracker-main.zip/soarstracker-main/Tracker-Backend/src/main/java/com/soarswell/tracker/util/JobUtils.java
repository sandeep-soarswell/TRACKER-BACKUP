package com.soarswell.tracker.util;

import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.JobRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.http.HttpStatus;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Locale;

@Slf4j
public class JobUtils {
    public static JobRequest mapRowToJobRequest(String[] row, int rowNum) throws TrackerException {
        try {
            JobRequest.JobRequestBuilder builder = JobRequest.builder();
            builder.title(getStringValue(row, 0));
            builder.description(getStringValue(row, 1));
            builder.location(getStringValue(row, 2));
            builder.skills(getStringValue(row, 3));
            builder.experience(getStringValue(row, 4));
            builder.salary(getStringValue(row, 5));
            builder.openings(safeParseInteger(getStringValue(row, 6)));
            builder.deadline(safeMapDate(row[7]));
            builder.jobId(getStringValue(row, 8));
            builder.contactPersonName(getStringValue(row, 9));
            builder.contactPersonEmail(getStringValue(row, 10));
            builder.contactPersonPhone(getStringValue(row, 11));
            return builder.build();
        } catch (Exception e) {
            throw new TrackerException("Error parsing row " + rowNum + ": " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    public static JobRequest mapRowToJobRequest(Row row, int rowNum) throws TrackerException {
        try {
            JobRequest.JobRequestBuilder builder = JobRequest.builder();
            builder.title(getCellStringValue(row.getCell(0)));
            builder.description(getCellStringValue(row.getCell(1)));
            builder.location(getCellStringValue(row.getCell(2)));
            builder.skills(getCellStringValue(row.getCell(3)));
            builder.experience(getCellStringValue(row.getCell(4)));
            builder.salary(getCellStringValue(row.getCell(5)));
            builder.openings(safeParseInteger(getCellStringValue(row.getCell(6))));
            builder.deadline(safeMapDate(row.getCell(7).toString()));
            builder.jobId(getCellStringValue(row.getCell(8)));
            builder.contactPersonName(getCellStringValue(row.getCell(9)));
            builder.contactPersonEmail(getCellStringValue(row.getCell(10)));
            builder.contactPersonPhone(getCellStringValue(row.getCell(11)));
            return builder.build();
        } catch (Exception e) {
            throw new TrackerException("Error parsing row " + rowNum + ": " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    private static String getStringValue(String[] row, int index) {
        return index < row.length && row[index] != null && !row[index].trim().isEmpty() ? row[index].trim() : null;
    }

    private static String getCellStringValue(Cell cell) {
        if (cell == null) return null;
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                double val = cell.getNumericCellValue();
                long longVal = (long) val;
                if (val == longVal) {
                    return String.valueOf(longVal);
                } else {
                    return String.valueOf(val);
                }
            default:
                return null;
        }
    }

    private static LocalDate safeMapDate( String fetchedDate) {
        try {
            Date date = DateUtils.parseDate(fetchedDate, Locale.ENGLISH, Constants.DATE_PATTERNS);
            return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        } catch (Exception e) {
            log.error("invalid-date{}",fetchedDate);
        }
        return null;
    }

    private static Integer safeParseInteger(String value) {
        try {
            return value == null ? null : Integer.parseInt(value.trim());
        } catch (Exception e) {
            return null;
        }
    }
}