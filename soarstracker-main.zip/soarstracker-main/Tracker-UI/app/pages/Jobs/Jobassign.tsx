import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router";
import Card from "~/components/ui/Card";
import Button from "~/components/ui/Button";
import {CircularProgress } from "@mui/material";
import jobService from "~/services/job/job.services";
import userService from "~/services/employee/employee.service";
import candidateService from "~/services/candidate/candidate.service";
import assignService from "~/services/assignments/job.assign";
import { AddIcon, HomeIcon } from "~/components/ui/Icons";
import type { Job, Employee, Candidate } from "~/pages/types/types";
import CustomSnackbar from "~/components/ui/Customsnackbar";

const JobAssign: React.FC = () => {
    const location = useLocation();
    const { jobId } = location.state || {};
    const [job, setJob] = useState<Job | null>(null);
    const [clientName, setClientName] = useState<string>("");
    const [assignedUsers, setAssignedUsers] = useState<Employee[]>([]);
    const [unassignedUsers, setUnassignedUsers] = useState<Employee[]>([]);
    const [matchedCandidates, setMatchedCandidates] = useState<Candidate[]>([]);
    const [assignedCandidates, setAssignedCandidates] = useState<Candidate[]>([]);
    const [loading, setLoading] = useState(false);
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");
    const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");
    const [selectedAssignedUserIds, setSelectedAssignedUserIds] = useState<string[]>([]);
    const [selectedUnassignedUserIds, setSelectedUnassignedUserIds] = useState<string[]>([]);
    const [selectedCandidateIds, setSelectedCandidateIds] = useState<string[]>([]);
    const [selectedAssignedCandidateIds, setSelectedAssignedCandidateIds] = useState<string[]>([]);
    const token = localStorage.getItem("userToken");
    const decodedToken = token ? JSON.parse(atob(token.split(".")[1])) : null;
    const role = decodedToken?.roles[0] || "";
    const navigate = useNavigate();

    const fetchJobDetails = async () => {
        if (!jobId) return;
        try {
            setLoading(true);
            const response = await jobService.getById(jobId);
            setJob(response);
            if (response.clientName) {
                setClientName(response.clientName);
            }
        } catch (err) {
            showSnackbar("Failed to fetch job details.", "error");
        } finally {
            setLoading(false);
        }
    };

    const fetchUnassignedUsers = async () => {
        try {
            setLoading(true);
            const response = await userService.getFreeUsers(0, 1000, "*", jobId);
            setUnassignedUsers([...response.data.records || []]);
        } catch (err) {
            setUnassignedUsers([]);
        } finally {
            setLoading(false);
        }
    };

    const fetchAssignedUsers = async () => {
        if (!jobId) return;
        try {
            setLoading(true);
            const response = await jobService.getAssignedUsers(jobId);
            setAssignedUsers([...response.data || []]);
        } catch (err) {
            setAssignedUsers([]);
        } finally {
            setLoading(false);
        }
    };

    const fetchCandidates = async () => {
        try {
            setLoading(true);
            const response = await candidateService.getBySkills(`${jobId}`);
            setMatchedCandidates(response.data || []);
        } catch (err) {
            setMatchedCandidates([]);
        } finally {
            setLoading(false);
        }
    };

    const fetchAssignedCandidates = async () => {
        if (!jobId) return;
        try {
            setLoading(true);
            const response = await jobService.getAssignedCandidates(jobId);
            setAssignedCandidates(response.data || []);
        } catch (err) {
            setAssignedCandidates([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchJobDetails();
        fetchUnassignedUsers();
        fetchAssignedUsers();
        fetchCandidates();
        fetchAssignedCandidates();
    }, []);

    const showSnackbar = (message: string, severity: "success" | "error" = "success") => {
        setSnackbarMessage(message);
        setSnackbarSeverity(severity);
        setSnackbarOpen(true);
    };

    const handleAssignCandidates = async (selectedCandidateIds: string[]) => {
        if (!jobId || !selectedCandidateIds || selectedCandidateIds.length === 0) return;
        let lastResponse;
        try {
            setLoading(true);
            for (const candidateId of selectedCandidateIds) {
                lastResponse = await assignService.assignJobToCandidate(jobId, candidateId);
            }
            await fetchCandidates();
            await fetchAssignedCandidates();
            showSnackbar(lastResponse.data, "success");
            setSelectedCandidateIds([]);
            setSelectedAssignedCandidateIds([]);
        } catch (err) {
            if (
                typeof err === "object" &&
                err !== null &&
                "response" in err &&
                typeof (err as any).response === "object" &&
                (err as any).response !== null
            ) {
                const response = (err as any).response;
                if (response.status === 409 && response.data && response.data.error) {
                    const errorCause = response.data.error.cause;
                    const cooldownDate = response.data.error.cooldownDate;
                    const daysRemaining = response.data.error.daysRemaining;
                    showSnackbar(`Cooling period is still active. Please try again after ${cooldownDate}.`, "error");
                } else {
                    showSnackbar("Something went wrong, please try again.", "error");
                }
            } else {
                showSnackbar("Network error, please check your connection.", "error");
                navigate("/");
            }
        }
        finally {
            setLoading(false);
        }
    }

    const handleUnassignCandidates = async (selectedCandidateIds: string[]) => {

        if (!jobId || !selectedCandidateIds || selectedCandidateIds.length === 0) return;
        let lastResponse;
        try {
            setLoading(true);
            for (const candidateId of selectedCandidateIds) {
                lastResponse = await assignService.unassignJobToCandidate(jobId, candidateId);
            }
            await fetchCandidates();
            await fetchAssignedCandidates();
            showSnackbar(lastResponse.data, "success");
            setSelectedCandidateIds([]);
            setSelectedAssignedCandidateIds([]);
        } catch (err: any) {
            showSnackbar(err.response.data.message, "error");
        } finally {
            setLoading(false);
        }
    }


    const handleAssignUsers = async (selectedUserIds: string[]) => {
        if (!jobId || !selectedUserIds || selectedUserIds.length === 0) return;
        let lastResponse;
        try {
            setLoading(true);
            for (const userId of selectedUserIds) {
                lastResponse = await assignService.assignJobToUser(userId, jobId);
            }
            const successMessage = lastResponse?.data || "User(s) assigned successfully!";
            await fetchAssignedUsers();
            await fetchUnassignedUsers();
            showSnackbar(successMessage, "success");
            setSelectedUnassignedUserIds([]);
        } catch (err) {
            showSnackbar(lastResponse.data, "error");
        } finally {
            setLoading(false);
        }
    };



    const handleUnassignUsers = async (selectedUserIds: string[]) => {
        if (role === "RECRUITER") {
            showSnackbar("You do not have permission to unassign candidates.", "error");
            return;
        }
        if (!jobId || !selectedUserIds || selectedUserIds.length === 0) return;
        let lastResponse;
        try {
            setLoading(true);
            for (const userId of selectedUserIds) {
                lastResponse = await assignService.unassignJobToUser(jobId, userId);
            }
            const successMessage = lastResponse?.data || "User(s) unassigned successfully!";
            await fetchAssignedUsers();
            await fetchUnassignedUsers();
            showSnackbar(successMessage, "success");
            setSelectedAssignedUserIds([]);

        } catch (err: any) {
            showSnackbar(err.response.data, "error");
        } finally {
            setLoading(false);
        }
    };

    const getAssignLabel = (count: number) => {
        if (count > 1) return "Assign Selected";
        return "Assign";
    };

    const getUnassignLabel = (count: number) => {
        if (count > 1) return "Unassign Selected";
        return "Unassign";
    }

    return (
        <div className="h-[calc(100vh-100px)]">
            <div className="flex items-center px-4 py-2">
                <div className="flex items-center text-sm text-gray-600">
                    <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
                    <a
                        href="/dashboard"
                        className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                    >
                        Dashboard
                    </a>
                </div>
                <span className="mx-2 text-gray-400">/</span>
                <div className="text-sm text-gray-600">
                    <a
                        href="/dashboard/jobs"
                        className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                    >
                        Jobs
                    </a>
                </div>
                <span className="mx-2 text-gray-400">/</span>
                <div className="text-sm text-gray-600">
                    Jobs Assign
                </div>
            </div>
            <CustomSnackbar
                open={snackbarOpen}
                message={snackbarMessage}
                severity={snackbarSeverity}
                onClose={() => setSnackbarOpen(false)}
            />


            <div className="flex items-center space-x-6 mb-4">
                <h1 className="text-2xl font-semibold text-gray-900">
                    {job ? `Job Title: ${job.title}` : <CircularProgress size={24} />}
                </h1>
                <h1 className="text-2xl font-semibold text-gray-900">
                    {clientName ? `Client Name: ${clientName}` : <CircularProgress size={24} />}
                </h1>
            </div>

            {loading ? (
                <div className="flex justify-center items-center h-[300px]">
                    <CircularProgress color="primary" />
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card className="p-4">
                        <div className="flex justify-between">
                            <h2 className="text-lg font-semibold">Assigned Users</h2>
                            {role !== "RECRUITER" && (
                                <Button
                                    disabled={!selectedAssignedUserIds.length}
                                    onClick={() => handleUnassignUsers(selectedAssignedUserIds)}
                                    className="flex items-center space-x-2"
                                >
                                    <AddIcon className="mr-2" />
                                    {getUnassignLabel(selectedAssignedUserIds.length)}
                                </Button>
                            )}

                        </div>
                        <div className="mb-3 ml-2">
                            {role !== "RECRUITER" && (
                                <label className="flex items-center gap-2 text-sm">
                                    <input
                                        type="checkbox"
                                        checked={
                                            selectedAssignedUserIds.length > 0 &&
                                            selectedAssignedUserIds.length === assignedUsers.length
                                        }
                                        onChange={(e) => {
                                            const checked = e.target.checked;
                                            setSelectedAssignedUserIds(
                                                checked
                                                    ? assignedUsers.map(u => u.id).filter((id): id is string => typeof id === "string")
                                                    : []
                                            );
                                        }}
                                    />
                                    Select All
                                </label>
                            )}
                        </div>
                        <div className="space-y-2 max-h-64 overflow-y-auto">
                            {assignedUsers.length > 0 ? (
                                assignedUsers.map((user) => (
                                    <div key={user.id} className="p-2 bg-gray-50 rounded-lg flex items-center gap-2">
                                        {role !== "RECRUITER" && (
                                            <input
                                                type="checkbox"
                                                checked={typeof user.id === "string" && selectedAssignedUserIds.includes(user.id)}
                                                onChange={(e) => {
                                                    const checked = e.target.checked;
                                                    setSelectedAssignedUserIds(prev =>
                                                        checked
                                                            ? [...prev, user.id].filter((id): id is string => typeof id === "string")
                                                            : prev.filter(id => id !== user.id)
                                                    );
                                                }}
                                            />
                                        )}
                                        <span>{user.firstName} {user.middleName} {user.lastName} ({user.role})</span>
                                    </div>
                                ))
                            ) : (
                                <p className="text-gray-500">No users assigned.</p>
                            )}
                        </div>
                    </Card>

                    {role !== "RECRUITER" && (
                        <Card className="p-4">
                            <div className="flex justify-between">
                                <h2 className="text-lg font-semibold">Unassigned Users</h2>
                                <Button
                                    disabled={!selectedUnassignedUserIds.length}
                                    onClick={() => {
                                        const userIdsToAssign = [...selectedUnassignedUserIds];
                                        handleAssignUsers(userIdsToAssign);
                                    }}
                                >
                                    <AddIcon className="mr-2" />
                                    {getAssignLabel(selectedUnassignedUserIds.length)}
                                </Button>
                            </div>
                            <div className="mb-3 ml-2">
                                <label className="flex items-center gap-2 text-sm">
                                    <input
                                        type="checkbox"
                                        checked={
                                            unassignedUsers.length > 0 &&
                                            selectedUnassignedUserIds.length === unassignedUsers.length
                                        }
                                        onChange={(e) => {
                                            const checked = e.target.checked;
                                            setSelectedUnassignedUserIds(
                                                checked
                                                    ? unassignedUsers.map(u => u.id).filter((id): id is string => typeof id === "string")
                                                    : []
                                            );
                                        }}
                                    />
                                    Select All
                                </label>
                            </div>
                            <div className="space-y-2 max-h-64 overflow-y-auto">
                                {unassignedUsers.length > 0 ? (
                                    unassignedUsers.map((user) => (
                                        <div key={user.id} className="p-2 bg-gray-50 rounded-lg flex items-center gap-2">
                                            <input
                                                type="checkbox"
                                                checked={typeof user.id === "string" && selectedUnassignedUserIds.includes(user.id)}
                                                onChange={(e) => {
                                                    const checked = e.target.checked;
                                                    setSelectedUnassignedUserIds(prev =>
                                                        checked
                                                            ? [...prev, user.id].filter((id): id is string => typeof id === "string")
                                                            : prev.filter(id => id !== user.id)
                                                    );
                                                }}
                                            />
                                            <span>{user.firstName} {user.middleName} {user.lastName}</span>
                                        </div>
                                    ))
                                ) : (
                                    <p className="text-gray-500">No unassigned users available.</p>
                                )}
                            </div>
                        </Card>
                    )}

                    <Card className="p-4">
                        <div className="flex justify-between">
                            <h2 className="text-lg font-semibold">Assigned Candidates</h2>
                            <Button
                                disabled={!selectedAssignedCandidateIds.length}
                                onClick={() => {
                                    const candidateIdsToUnassign = [...selectedAssignedCandidateIds];
                                    handleUnassignCandidates(candidateIdsToUnassign);
                                }}
                            >
                                <AddIcon className="mr-2" />
                                {getUnassignLabel(selectedAssignedCandidateIds.length)}
                            </Button>
                        </div>

                        <div className="mb-3 ml-2">
                            <label className="flex items-center gap-2 text-sm">
                                <input
                                    type="checkbox"
                                    checked={
                                        assignedCandidates.length > 0 &&
                                        selectedAssignedCandidateIds.length === assignedCandidates.length
                                    }
                                    onChange={(e) => {
                                        const checked = e.target.checked;
                                        setSelectedAssignedCandidateIds(
                                            checked ? assignedCandidates.map(c => c.id) : []
                                        );
                                    }}
                                />
                                Select All
                            </label>
                        </div>

                        <div className="space-y-2 max-h-64 overflow-y-auto">
                            {assignedCandidates.length > 0 ? (
                                assignedCandidates.map((candidate) => (
                                    <div key={candidate.id} className="p-2 bg-gray-50 rounded-lg flex items-center gap-2">
                                        <input
                                            type="checkbox"
                                            checked={selectedAssignedCandidateIds.includes(candidate.id)}
                                            onChange={(e) => {
                                                const checked = e.target.checked;
                                                setSelectedAssignedCandidateIds((prev) =>
                                                    checked
                                                        ? [...prev, candidate.id]
                                                        : prev.filter(id => id !== candidate.id)
                                                );
                                            }}
                                        />
                                        <span>{candidate.firstName} {candidate.middleName} {candidate.lastName}</span>
                                    </div>
                                ))
                            ) : (
                                <p className="text-gray-500">No candidates assigned.</p>
                            )}
                        </div>
                    </Card>

                    <Card className="p-4">
                        <div className="flex justify-between">
                            <h2 className="text-lg font-semibold">Candidates with Matched Skills</h2>
                            <Button
                                disabled={!selectedCandidateIds.length}
                                onClick={() => {
                                    const candidateIdsToAssign = [...selectedCandidateIds];
                                    handleAssignCandidates(candidateIdsToAssign);
                                }}
                            >
                                <AddIcon className="mr-2" />
                                {getAssignLabel(selectedCandidateIds.length)}
                            </Button>
                        </div>

                        <div className="mb-3 ml-2">
                            <label className="flex items-center gap-2 text-sm">
                                <input
                                    type="checkbox"
                                    checked={
                                        matchedCandidates.length > 0 &&
                                        selectedCandidateIds.length === matchedCandidates.length
                                    }
                                    onChange={(e) => {
                                        const checked = e.target.checked;
                                        setSelectedCandidateIds(
                                            checked ? matchedCandidates.map(c => c.id) : []
                                        );
                                    }}
                                />
                                Select All
                            </label>
                        </div>

                        <div className="space-y-2 max-h-64 overflow-y-auto">
                            {matchedCandidates.length > 0 ? (
                                matchedCandidates.map((candidate) => (
                                    <div key={candidate.id} className="p-2 bg-gray-50 rounded-lg flex items-center gap-2">
                                        <input
                                            type="checkbox"
                                            checked={selectedCandidateIds.includes(candidate.id)}
                                            onChange={(e) => {
                                                const checked = e.target.checked;
                                                setSelectedCandidateIds(prev =>
                                                    checked
                                                        ? [...prev, candidate.id]
                                                        : prev.filter(id => id !== candidate.id)
                                                );
                                            }}
                                        />
                                        <span>{candidate.firstName} {candidate.middleName} {candidate.lastName}</span>
                                    </div>
                                ))
                            ) : (
                                <p className="text-gray-500">No candidates with matched skills.</p>
                            )}
                        </div>
                    </Card>
                </div>
            )}
        </div>
    );
};

export default JobAssign;