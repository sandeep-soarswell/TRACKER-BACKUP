package com.soarswell.tracker.util;

public class SecurityConstants {

    private SecurityConstants() {
        // Prevent instantiation
    }

    public static final String[] PUBLIC_URLS = {
            "/swagger-ui/**",
            "/swagger-ui/index.html",
            "/swagger-resources/**",
            "/user/login",
            "/api-docs/swagger-config",
            "api-docs",
            "/tracker/api-docs/swagger-config",
            "/tracker/api-docs/**",
            "/forgot-password",
            "/validate-otp",
            "/token/validate",
            "/error",
            "/actuator/**",
            "/health",
            "/resend-otp"
    };
}
