import React, { useEffect, useRef } from 'react';
import { Box, TextField } from '@mui/material';

interface CustomOtpInputProps {
  value: string;
  onChange: (value: string) => void;
  length?: number;
  autoFocus?: boolean;
}

const CustomOtpInput: React.FC<CustomOtpInputProps> = ({
  value,
  onChange,
  length = 6,
  autoFocus = true,
}) => {
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

  const handleInputChange = (index: number, val: string) => {
    if (!/^\d?$/.test(val)) return;
    const otpArray = value.split('');
    otpArray[index] = val;
    const newValue = otpArray.join('');
    onChange(newValue);

    if (val && index < length - 1) {
      inputsRef.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
    if (e.key === 'Backspace' && !value[index] && index > 0) {
      inputsRef.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const paste = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, length);
    const newOtp = Array(length).fill('').map((_, i) => paste[i] || '');
    onChange(newOtp.join(''));
    inputsRef.current[Math.min(paste.length, length - 1)]?.focus();
  };

  useEffect(() => {
    if (autoFocus) {
      inputsRef.current[0]?.focus();
    }
  }, [autoFocus]);

  return (
    <Box display="flex" gap={2} justifyContent="center">
      {Array.from({ length }).map((_, index) => (
        <TextField
          sx={{
            '& .MuiOutlinedInput-root': {
              borderRadius: '12px',
            },
            '& .MuiOutlinedInput-root.Mui-focused': {
              borderRadius: '12px',
            },
            '& .MuiOutlinedInput-root.Mui-error': {
              borderRadius: '12px',
            },
          }}
          key={index}
          inputRef={(el) => (inputsRef.current[index] = el)}
          value={value[index] || ''}
          onChange={(e) => handleInputChange(index, e.target.value)}
          onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => handleKeyDown(e, index)}
          onPaste={handlePaste}
          onFocus={(e) => e.target.select()}
          color="primary"
          autoComplete="one-time-code"
          inputProps={{
            maxLength: 1,
            style: {
              width: '40px',
              textAlign: 'center',
              fontSize: '18px',
              padding: '10px',
              borderRadius: '20px',
            },
          }}
        />
      ))}
    </Box>
  );
};

export default CustomOtpInput;
