package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.soarswell.tracker.util.RegExConstants;
import com.soarswell.tracker.util.Constants;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(description = Constants.REQUEST_CHANGE)
public class ChangePasswordRequest {

    @NotBlank(message = "{password.new.required}")
    @Pattern(regexp = RegExConstants.PASSWORD_PATTERN, message = "{password.pattern.invalid}")
    @Schema(description = "{password.new}", example = Constants.PASSWORD_EXAMPLE, required = true)
    private String newPassword;
}