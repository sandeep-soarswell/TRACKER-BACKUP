import React, { useEffect, useState, useMemo } from "react";
import { DataGrid, type GridRenderCellParams } from '@mui/x-data-grid';
import { HomeIcon } from "~/components/ui/Icons";
import Card from "~/components/ui/Card";
import { Typography, Box, Button } from '@mui/material';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import userService from '~/services/employee/employee.service';
import jobService from '~/services/job/job.services';
import type { Employee as EmployeeType, Candidate, Job } from '~/pages/types/types';
import { useLocation, useNavigate } from 'react-router';

interface TableRow {
  id: string | number;
  sno: number;
  type: 'job';
  title?: string;
  clientName?: string;
  clientId?: string;
  candidateNames?: string[];
}
const InfoBox: React.FC<{ label: string; value?: string }> = ({ label, value }) => (
  <div className="rounded-md w-full">
    <Typography variant="subtitle2" className="text-blue-100 text-sm mb-1">{label}</Typography>
    <Typography variant="body1" className="text-white font-medium">{value || 'N/A'}</Typography>
  </div>
);
const formatRole = (role: string): string => {
  return role
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
};
const EmployeeHeader: React.FC<{ employee: EmployeeType | null }> = ({ employee }) => {
  const { firstName, middleName, lastName, email, role, phoneNumber } = employee || {
    firstName: 'N/A',
    middleName: '',
    lastName: 'N/A',
    email: 'N/A',
    role: 'N/A',
    phoneNumber: 'N/A'
  };
  return (
    <div className="rounded-lg overflow-hidden transition-all duration-300">
      <div className="bg-gradient-to-r from-[#0A2463] to-[#0A2463] p-6 text-white">
        <Typography variant="h5" className="font-bold mb-6">
          {`${firstName} ${middleName || ''} ${lastName}`.trim() || 'Unknown Employee'}
        </Typography>
        <div className="grid grid-cols-1 sm:grid-cols-3">
          <InfoBox label="Email" value={email} />
          <InfoBox
            label="Role"
            value={role ? (Array.isArray(role) ? role.join(', ') : role === 'COMPANY_ADMIN' ? 'Company Admin' : formatRole(role)) : undefined}
          />
          <InfoBox label="Phone Number" value={phoneNumber} />
        </div>
      </div>
    </div>
  );
};
const EmployeeAssignes: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const userId = location.state?.id || '';
  const [employee, setEmployee] = useState<EmployeeType | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [candidateNames, setCandidateNames] = useState<string[][]>([]);
  const [loading, setLoading] = useState(true);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");
  const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 10 });
  const showSnackbar = (message: string, severity: "success" | "error" = "success") => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  };
  const fetchEmployeeData = async () => {
    if (!userId) {
      showSnackbar("No user ID provided.", "error");
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const response = await userService.getById(userId);
      const employeeData = response?.data || null;
      if (!employeeData) {
        throw new Error('No user found for ID: ' + userId);
      }
      setEmployee(employeeData);
    } catch (err: any) {
      const errorMsg = err?.response?.data?.error?.message || 'Failed to load employee data';
      showSnackbar(errorMsg, "error");
      setEmployee(null);
      setLoading(false);
      return;
    }
    // Fetch jobs separately
    try {
      const jobsResponse = await userService.getJobsByUserId(userId, '');
      const jobsList = Array.isArray(jobsResponse?.data?.records) ? jobsResponse.data.records : [];
      const candidateNamesByJob = await Promise.all(
        jobsList.map(async (job: Job) => {
          try {
            const candidatesData = await jobService.getAssignedCandidates(String(job.id));
            const candidates = Array.isArray(candidatesData?.data) ? candidatesData.data : [];
            return candidates
              .filter((candidate: Candidate) => candidate.userId === userId)
              .map((candidate: Candidate) => `${candidate.firstName} ${candidate.lastName}`.trim());
          } catch (err) {
            return [];
          }
        })
      );
      setJobs(jobsList);
      setCandidateNames(candidateNamesByJob);
    } catch (err: any) {
      if (err?.response?.status === 404) {
        setJobs([]);
        setCandidateNames([]);
      } else {
        const errorMsg = err?.response?.data?.error?.message || 'Failed to load jobs data';
        showSnackbar(errorMsg, "error");
        setJobs([]);
        setCandidateNames([]);
      }
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchEmployeeData();
  }, [userId]);
  const rows = useMemo(() => {
    return jobs.map((job, index) => ({
      id: job.id ?? `job-${index}`,
      sno: index + 1,
      type: 'job' as const,
      title: job.title,
      clientName: job.clientName || 'N/A',
      clientId: job.clientId || '',
      candidateNames: candidateNames[index] || [],
    }));
  }, [jobs, candidateNames]);
  if (loading) {
    return (
      <div className="h-[calc(100vh-100px)]">
        <div className="max-w-7xl mx-auto p-4">
          <div className="rounded-lg overflow-hidden bg-[#0A2463] p-6">
            <div className="animate-pulse">
              <div className="h-8 w-48 bg-blue-200 rounded mb-4" />
              <div className="h-5 w-32 bg-blue-200 rounded mb-2" />
              <div className="h-5 w-48 bg-blue-200 rounded" />
            </div>
          </div>
        </div>
      </div>
    );
  }
  if (!employee) {
    return (
      <div className="h-[calc(100vh-100px)] p-4">
        <CustomSnackbar
          open={snackbarOpen}
          message={snackbarMessage}
          severity={snackbarSeverity}
          onClose={() => setSnackbarOpen(false)}
          autoHideDuration={3000}
        />
        <Typography variant="h6" color="error">{snackbarMessage || 'No employee data available'}</Typography>
        <Button
          variant="contained"
          color="primary"
          onClick={() => navigate('/dashboard/users')}
          sx={{ mt: 2 }}
        >
          Back to Employees
        </Button>
      </div>
    );
  }
  return (
    <div className="h-[calc(100vh-100px)]">
      <CustomSnackbar
        open={snackbarOpen}
        message={snackbarMessage}
        severity={snackbarSeverity}
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={3000}
      />
      <div className="flex items-center">
        <div className="flex items-center text-sm text-gray-600">
          <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
          <span
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors cursor-pointer"
            onClick={() => navigate('/dashboard')}
          >
            Dashboard
          </span>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="flex items-center text-sm text-gray-600">
          <span
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors cursor-pointer"
            onClick={() => navigate('/dashboard/users')}
          >
            Employees
          </span>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="text-sm text-gray-600">Employee Assignees</div>
      </div>
      <div className="flex justify-between items-center mt-2 mb-4">
        <h1 className="text-2xl font-bold text-gray-900">
          Assigned Jobs
        </h1>
      </div>
      <EmployeeHeader employee={employee} />
      <div className="mt-4">
        {rows.length > 0 ? (
          <Card className="h-[calc(100vh-320px)] w-full">
            <DataGrid
              rows={rows}
              columns={[
                { field: 'sno', headerName: '#', flex: 0.3 },
                {
                  field: 'clientName',
                  headerName: 'Client Name',
                  flex: 1,
                  renderCell: (params: GridRenderCellParams<TableRow>) => (
                    <div
                      onClick={() => navigate('/dashboard/jobs', { state: { clientName: params.row.clientName, fromEmployeeAssignes: true, userId } })}
                      className="text-blue-600 hover:underline cursor-pointer font-medium w-full h-full flex items-center"
                      role="button"
                      tabIndex={0}
                    >
                      {String(params.value || 'N/A')}
                    </div>
                  )
                },
                {
                  field: 'title',
                  headerName: 'Job Title',
                  flex: 1,
                  renderCell: (params: GridRenderCellParams<TableRow>) => (
                    <div
                      onClick={() => navigate('/dashboard/jobs', { state: { jobId: params.row.id, jobTitle: params.row.title, fromEmployeeAssignes: true, userId } })}
                      className="text-blue-600 hover:underline cursor-pointer font-medium w-full h-full flex items-center"
                      role="button"
                      tabIndex={0}
                    >
                      {String(params.value || 'N/A')}
                    </div>
                  )
                },
                {
                  field: 'candidateNames',
                  headerName: 'Candidates',
                  flex: 1,
                  renderCell: (params: GridRenderCellParams<TableRow>) => {
                    const candidates = params.value || [];
                    const count = candidates.length;
                    const label = count === 1 ? 'candidate' : 'candidates';
                    return (
                      <Box display="flex" alignItems="center" height="100%">
                        <Typography
                          variant="body2"
                          color="primary"
                          sx={{ cursor: 'pointer', textDecoration: 'underline' }}
                          onClick={() => {
                            navigate('/dashboard/employee/candidates', {
                              state: {
                                clientName: params.row.clientName || '',
                                jobTitle: params.row.title || '',
                                jobId: params.row.id,
                                userId: userId,
                                candidateNames: candidates
                              }
                            });
                          }}
                        >
                          {`${count} ${label}`}
                        </Typography>
                      </Box>
                    );
                  }
                }
              ]}
              pagination
              paginationMode="client"
              pageSizeOptions={[5, 10, 20, 50]}
              paginationModel={paginationModel}
              onPaginationModelChange={setPaginationModel}
              rowCount={jobs.length}
              disableRowSelectionOnClick
              sx={{
                width: '100%',
                '& .MuiDataGrid-columnHeaders': { backgroundColor: '#f1f5f9 !important' },
                '& .MuiDataGrid-columnHeader': { backgroundColor: '#f1f1f1' },
                '& .MuiDataGrid-columnHeaderTitle': { fontWeight: 'bold', textTransform: 'uppercase' },
                '& .MuiDataGrid-row:hover': { backgroundColor: 'inherit' },
                '& .MuiDataGrid-main': { padding: 0 },
                '& .MuiDataGrid-footerContainer': { justifyContent: 'flex-end' },
              }}
            />
          </Card>
        ) : (
          <Card className="h-[calc(100vh-320px)] w-full flex items-center justify-center">
            <Typography variant="h6" color="textSecondary">
              There are no assignments for this employee
            </Typography>
          </Card>
        )}
      </div>
    </div>
  );
};
export default EmployeeAssignes;