package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.CandidateUserAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface CandidateAssignmentRepository extends JpaRepository<CandidateUserAssignment, String> {
    Optional<CandidateUserAssignment> findByCandidate_Id(String candidateId);
    boolean existsByCandidateId(String candidateId);
    boolean existsByCandidateIdAndUserId(String candidateId, String userId);
    List<CandidateUserAssignment> findByUserId(String userId);
}