package com.soarswell.tracker.model.payload;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class BulkValidationError {

    private Object request;
    private String error;
}
