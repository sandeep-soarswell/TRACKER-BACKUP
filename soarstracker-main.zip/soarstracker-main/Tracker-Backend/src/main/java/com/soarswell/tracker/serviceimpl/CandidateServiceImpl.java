package com.soarswell.tracker.serviceimpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseBuilder;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.*;
import com.soarswell.tracker.model.payload.*;
import com.soarswell.tracker.repository.*;
import com.soarswell.tracker.service.CandidateService;
import com.soarswell.tracker.service.CommentService;
import com.soarswell.tracker.service.CompanyService;
import com.soarswell.tracker.service.AiService;
import com.soarswell.tracker.util.*;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.*;
import com.soarswell.tracker.service.EmailService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import com.soarswell.tracker.service.ScoringService;
import static com.soarswell.tracker.util.TrackerUtils.isValidFieldInClass;

@Service
@Slf4j
public class CandidateServiceImpl implements CandidateService {

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CandidateAssignmentRepository candidateAssignmentRepository;

    @Autowired
    private ClientRepository ClientRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private RequestDetails requestDetails;

    @Autowired
    private AssignmentRepository assignmentRepository;

    @Autowired
    private Validator validator;
    @Autowired
    private AiService aiService;
    @Autowired
    private EmailService emailService;

    @Value("${file.upload.path}")
    private String folderPath;

    @Autowired
    private ScoringService scoringService;

    @Autowired
    private CompanyService companyService;

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private CommentService commentService;
    @Autowired
    private ErrorMessageHandler errorMessageHandler;

    private String getCompanyId(){
        return AuthTokenUtils.extractCompanyId(requestDetails);
    }

    @Override
    @Transactional
    public ResponseEntity<?> register(CandidateRequest candidateRequest, MultipartFile resumeFile, RequestDetails requestDetails) throws TrackerException {
        if (resumeFile == null || resumeFile.isEmpty()) {
            throw new TrackerException("Resume file is required.", HttpStatus.BAD_REQUEST);
        }
        Path resumeDir = Paths.get(System.getProperty(Constants.DIRECTORY)).getParent().resolve(folderPath).resolve("resumes");
        String uniqueFilename = UUID.randomUUID().toString() + "_" + StringUtils.cleanPath(Objects.requireNonNull(resumeFile.getOriginalFilename()));
        Path filePath = resumeDir.resolve(uniqueFilename);

        try {
            Files.createDirectories(resumeDir); // Ensure the resumes directory exists
            Files.copy(resumeFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
            log.info("Saved new resume file: {}", filePath);
        } catch (Exception ex) {
            log.error("Failed to store resume file", ex);
            throw new TrackerException("Failed to store resume file.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/files/download/").path(uniqueFilename).toUriString();
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        Map<String,String> exceptions = new HashMap<>();
        if (candidateRequest.getEmail() == null || candidateRequest.getEmail().trim().isEmpty()) {
            log.error("Email is null or empty");
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INTERNAL_SERVER_ERROR.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if (candidateRepository.existsByCompanyIdAndEmail(companyId,candidateRequest.getEmail())) {
            exceptions.put(Constants.ERROR_EMAIL,ErrorMessageHandler.getMessage(ErrorMessageKey.EMAIL_EXISTS.getStatusCode()));
        }
        if(candidateRequest.getEmail().equals(candidateRequest.getAlternateEmail())){
            exceptions.put(Constants.ERROR_EMAIL,ErrorMessageHandler.getMessage(ErrorMessageKey.ALTERNATE_EMAIL_CANNOT_BE_SAME.getStatusCode()));
        }
        if(candidateRequest.getPhoneNumber().equals(candidateRequest.getAlternatePhoneNumber())){
            exceptions.put(Constants.ERROR_PHONE,ErrorMessageHandler.getMessage(ErrorMessageKey.ALTERNATE_PHONE_CANNOT_BE_SAME.getStatusCode()));
        }
        if(candidateRepository.existsByCompanyIdAndPhoneNumber(companyId,candidateRequest.getPhoneNumber())){
            exceptions.put(Constants.ERROR_PHONE,ErrorMessageHandler.getMessage(ErrorMessageKey.USER_PHONE_EXISTS.getStatusCode()));
        }
        if (!exceptions.isEmpty()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResponseBuilder.builder().build().createErrorResponse(exceptions));
        }
        Candidate candidate = objectMapper.convertValue(candidateRequest, Candidate.class);
        try {
            candidate.setId(ResourceIdUtils.generateCandidateResourceId(companyId,candidate.getEmail()));
            log.info("Registering new candidate with email: {}", candidate.getEmail());
            candidate.setStatus(Status.ACTIVE.getLongLabel());
            candidate.setCompanyId(companyId);
            candidate.setCandidatureStatus(Status.CREATED.getLongLabel());
            candidate.setCreateDate(new Date(Instant.now().toEpochMilli()));
            candidate.setCreatedBy(requestDetails.getUserId());

            try {
                candidate.setResume(new URL(fileDownloadUri));
            } catch (Exception e) {
                log.error("Could not create URL from string: {}", fileDownloadUri, e);
            }

            candidateRepository.save(candidate);
            String systemComment = "Candidate created with email: " + candidate.getEmail() + " by user: " + requestDetails.getUserId();
            commentService.addSystemComment(candidate.getId(), systemComment, requestDetails);
        }catch(TrackerException e){
            throw e;
        }
        catch (Exception e) {
            log.error("Error creating candidate: {}", e.getMessage());
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_TO_CREATE_CANDIDATE.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.CANDIDATE_CREATED), HttpStatus.CREATED);
    }

    @Override
    public FullAIResponse parseResumeForAutofill(MultipartFile resumeFile) {
        if (resumeFile == null || resumeFile.isEmpty()) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.PARSING_RESUME.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        Path tempFile = null;
        try {
            tempFile = Files.createTempFile("resume-", ".tmp");
            Files.copy(resumeFile.getInputStream(), tempFile, StandardCopyOption.REPLACE_EXISTING);

            String resumeText = DocumentParserUtil.parseTextFromFileWithOcr(tempFile);
            if (resumeText == null || resumeText.trim().isEmpty()) {
                log.warn("Parsed resume text is empty.");
                return new FullAIResponse();
            }
            return aiService.processResume(resumeText);

        } catch (Exception e) {
            log.error("Failed to parse resume for autofill", e);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.RESUME_PROCESS.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        } finally {
            if (tempFile != null) {
                try { Files.delete(tempFile); }
                catch (IOException e) { log.error("Could not delete temporary file: {}", tempFile, e); }
            }
        }
    }

    @Override
    public ResponseEntity<?> getAllCandidates(int page, int size, RequestDetails requestDetails, String sortByField, String order,String keyword,String filter,String gender,String statusfilter,String clientId) throws TrackerException{
        String companyId= AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId,requestDetails);
        try {
            if (page < 0 || size <= 0) {
                log.error("Invalid pagination parameters: page={}, size={}", page, size);
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_PAGINATION_PARAMS.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            if (!isValidFieldInClass(sortByField,Candidate.class)) {
                log.error("Invalid sort field: {}", sortByField);
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_SORTBYFIELD.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            log.info("Fetching all candidates");
            Sort.Direction sortDirection = "asc".equalsIgnoreCase(order) ? Sort.Direction.ASC : Sort.Direction.DESC;
            PageRequest pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortByField));
            String status;
            Page<Candidate> candidatePage = null;
            if (filter != null && !filter.trim().isEmpty()) {
                if (!Constants.FILTER_ACTIVE.equalsIgnoreCase(filter) && !Constants.FILTER_INACTIVE.equalsIgnoreCase(filter)) {
                    log.error("Invalid filter value: {}", filter);
                    throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_FILTER_VALUE.name()), HttpStatus.BAD_REQUEST);
                }
                if (Constants.FILTER_INACTIVE.equalsIgnoreCase(filter)) {
                    status = Status.INACTIVE.getLongLabel();
                } else {
                    status = Status.ACTIVE.getLongLabel();
                }
                if (clientId == null) {
                    if (keyword != null && !keyword.trim().isEmpty()) {
                        if (statusfilter.equals("*")) {
                            candidatePage = candidateRepository.searchAllFieldsByCompanyIdAndStatus(companyId, status, keyword.trim(), pageable);
                        } else {
                            candidatePage = candidateRepository.searchAllFieldsByCompanyIdAndStatusAndCandidatureStatus(companyId, status, keyword.trim(), statusfilter, pageable);
                        }
                    } else {
                        if (statusfilter.equals("*")) {
                            if(!gender.equals("*"))
                            {
                                candidatePage = candidateRepository.findByCompanyIdAndStatusAndGenderIgnoreCase(companyId, status,gender, pageable);
                            }
                            else{
                                candidatePage = candidateRepository.findByCompanyIdAndStatus(companyId, status, pageable);
                            }

                        } else {
                            if(!gender.equals("*"))
                            {
                                candidatePage = candidateRepository.findByCompanyIdAndStatusAndCandidatureStatusAndGenderIgnoreCase(companyId, status, statusfilter,gender, pageable);
                            }else{
                                candidatePage = candidateRepository.findByCompanyIdAndStatusAndCandidatureStatus(companyId, status, statusfilter, pageable);
                            }

                        }
                    }
                } else {
                    List<Candidate> candidates = candidateRepository.findAllByCompanyId(companyId)
                            .stream().filter(candidate -> candidate.getJobAssignment() != null && candidate.getJobAssignment().getJob().getClientId().equals(clientId))
                            .filter(candidate -> candidate.getStatus().equalsIgnoreCase(filter))
                            .toList();
                    log.info("Filtering candidates by client ID: {},candidate size:{}", candidates, candidates.size());
                    if (keyword != null) {
                        if (statusfilter.equals("*")) {
                            candidatePage = candidateRepository.searchCandidateForParticularClient(companyId, candidates, keyword.trim(), pageable);
                        } else {
                            candidatePage = candidateRepository.searchCandidateForParticularClientStatus(companyId, statusfilter, candidates, keyword.trim(), pageable);
                        }
                    } else {
                        if (statusfilter.equals("*")) {
                            if(!gender.equals("*")) {
                                candidatePage = candidateRepository.candidateForParticularClientAndGender(companyId, candidates,gender, pageable);
                            }
                            else{
                                candidatePage = candidateRepository.candidateForParticularClient(companyId, candidates, pageable);
                            }
                        } else {
                            if(!gender.equals("*")) {
                                candidatePage = candidateRepository.candidateForParticularClientStatusAndGender(companyId, statusfilter, candidates,gender, pageable);
                            }
                            else{
                                candidatePage = candidateRepository.candidateForParticularClientStatus(companyId, statusfilter, candidates, pageable);
                            }
                        }
                    }
                }
            }
            List<CandidateResponse> responses = candidatePage.getContent().stream()
                    .map(
                            response -> {
                                if (response.getJobAssignment() != null || response.getAssignment() != null) {
                                    CandidateResponse candidateResponse = objectMapper.convertValue(response, CandidateResponse.class);
                                    if (response.getJobAssignment() != null) {
                                        log.info("Mapping candidate response for job with client ID: {}", response.getJobAssignment().getJob().getTitle());
                                        log.info("Fetching client name for job with ID: {}", response.getJobAssignment().getJob().getClientId());
                                        String clientName = ClientRepository.findById(response.getJobAssignment().getJob().getClientId())
                                                .map(ClientEntity::getClientName)
                                                .orElse("Unknown Client");
                                        log.info("Client name found: {}", clientName);
                                        candidateResponse.setJobTitle(response.getJobAssignment().getJob().getTitle());
                                        candidateResponse.setClientName(clientName);
                                        candidateResponse.setJobId(response.getJobAssignment().getJob().getJobId());
                                    }
                                    if (response.getAssignment() != null) {
                                        candidateResponse.setUserId(response.getAssignment().getUser().getId());
                                        String fullName = CandidateUtils.safeJoin(response.getAssignment().getUser().getFirstName(),
                                                response.getAssignment().getUser().getMiddleName(),
                                                response.getAssignment().getUser().getLastName());
                                        candidateResponse.setUserName(fullName);
                                    }
                                    return candidateResponse;

                                }
                                return objectMapper.convertValue(response, CandidateResponse.class);
                            }).toList();


            long totalEntries = candidatePage.getTotalElements();
            Map<String, Object> res = new HashMap<>();
            res.put("data", responses);
            res.put("totalEntries", totalEntries);
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(res), HttpStatus.OK);
        }catch(TrackerException e){
            throw e;
        } catch(Exception e){
            log.error("Exception while fetching all candidates: {}", e.getMessage(), e);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_CANDIDATES.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<?> getCandidateById(String id) throws TrackerException {
        String companyId= getCompanyId();
        companyService.getCompanyById(companyId,requestDetails);
        if (id == null || id.trim().isEmpty()) {
            log.error("Candidate ID is null or empty");
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_ID_NULL_OR_EMPTY.getStatusCode()),
                    HttpStatus.BAD_REQUEST
            );
        }

        try {
            log.info("Fetching candidate with ID: {}", id);
            CandidateResponse candidate = candidateRepository.findByCompanyIdAndId(companyId,id)
                    .filter(c-> c.getStatus().equalsIgnoreCase(Status.ACTIVE.getLongLabel()))
                    .map(response->{
                        if(response.getJobAssignment()!=null || response.getAssignment()!=null){
                            CandidateResponse candidateResponse = objectMapper.convertValue(response,CandidateResponse.class);
                            if( response.getJobAssignment() != null) {
                                log.info("Mapping candidate response for job with client ID: {}", response.getJobAssignment().getJob().getTitle());
                                String  clientName= ClientRepository.findById(response.getJobAssignment().getJob().getClientId())
                                        .map(ClientEntity::getClientName)
                                        .orElse("Unknown Client");
                                log.info("Client name found: {}", clientName);
                                candidateResponse.setJobTitle(response.getJobAssignment().getJob().getTitle());
                                candidateResponse.setClientName(clientName);
                                candidateResponse.setJobId(response.getJobAssignment().getJob().getJobId());
                            }
                            if( response.getAssignment() != null) {
                                candidateResponse.setUserId(response.getAssignment().getUser().getId());
                                String fullName=CandidateUtils.safeJoin(response.getAssignment().getUser().getFirstName(),
                                        response.getAssignment().getUser().getMiddleName(),
                                        response.getAssignment().getUser().getLastName());
                                candidateResponse.setUserName(fullName);
                            }
                            return candidateResponse;
                        }

                        return objectMapper.convertValue(response, CandidateResponse.class);

                    })
                    .orElseThrow(()-> new TrackerException(
                            ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND.getStatusCode()),
                            HttpStatus.NOT_FOUND
                    ));
            log.info("Successfully fetched candidate with ID: {}", id);

            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(candidate), HttpStatus.OK);

        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Exception while fetching candidate details {} , {}", id, e.getMessage());
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_CANDIDATE.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    @Override
    @Transactional
    public ResponseEntity<?> deleteCandidateById(String id,RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId,requestDetails);
        if (id == null || id.trim().isEmpty()) {
            log.error("Candidate ID is null or empty");
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_ID_NULL_OR_EMPTY.getStatusCode()),
                    HttpStatus.BAD_REQUEST
            );
        }

        Optional<Candidate> optionalCandidate = candidateRepository.findByCompanyIdAndId(companyId, id);
        try {
            log.info("Attempting to delete candidate with ID: {}", id);

            if (optionalCandidate.isEmpty()) {
                log.error("Candidate not found or already inactive: ID = {}", id);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND_WITH_ID.getStatusCode()),
                        HttpStatus.NOT_FOUND
                );
            }
            Candidate candidate = optionalCandidate.get();
            if(candidate.getStatus().equalsIgnoreCase(Constants.INACTIVE)){
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ALREADY_CANDIDATE_DELETED.getStatusCode()),HttpStatus.BAD_REQUEST);
            }
            candidate.setStatus(Status.INACTIVE.getLongLabel());
            candidateRepository.save(candidate);
            log.info("Successfully deleted candidate with ID: {}", id);

        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Failed to delete candidate {}: {}", id, e.getMessage(), e);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_DELETE_CANDIDATE.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.CANDIDATE_DELETED), HttpStatus.OK);
    }

    @Override
    @Transactional
    public ResponseEntity<?> updateCandidate(String id, CandidateUpdate candidateUpdate,RequestDetails requestDetails) throws TrackerException {
        String companyId =  AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        Map <String, String> exceptions = new HashMap<>();
        if (id == null || id.trim().isEmpty()) {
            log.error("Candidate ID is null or empty");
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_ID_REQUIRED_UPDATE.getStatusCode()),
                    HttpStatus.BAD_REQUEST
            );
        }
        Candidate existingCandidate = candidateRepository.findByCompanyIdAndId(companyId,id)
                .orElseThrow(()->new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND_WITH_ID.getStatusCode()),HttpStatus.NOT_FOUND));
        if(existingCandidate.getEmail().equals(candidateUpdate.getAlternateEmail())) {
            exceptions.put(Constants.ERROR_EMAIL, ErrorMessageHandler.getMessage(ErrorMessageKey.ALTERNATE_EMAIL_CANNOT_BE_SAME.getStatusCode()));
        }
        if(existingCandidate.getPhoneNumber().equals(candidateUpdate.getAlternatePhoneNumber())){
            exceptions.put(Constants.ERROR_PHONE,ErrorMessageHandler.getMessage(ErrorMessageKey.ALTERNATE_PHONE_CANNOT_BE_SAME.getStatusCode()));
        }
        if(!exceptions.isEmpty()){
            log.error("Validation errors occurred: {}", exceptions);
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(exceptions), HttpStatus.CONFLICT);
        }
        boolean flag= PatchHelper.updateValue(existingCandidate,candidateUpdate);
        try {
            if(flag) {
                existingCandidate.setUpdateDate(new Date(Instant.now().toEpochMilli()));
                existingCandidate.setUpdatedBy(requestDetails.getUserId());
                candidateRepository.save(existingCandidate);
                log.info("Successfully updated candidate with ID: {}", id);
                return new ResponseEntity<>(
                        ResponseBuilder.builder().build().createSuccessResponse(Constants.CANDIDATE_UPDATED),
                        HttpStatus.OK
                );
            }
        } catch (Exception e) {
            log.error("Unable to update candidate {}", id, e);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_SAVE_CANDIDATE.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
        return ResponseEntity.ok( ResponseBuilder.builder().build()
                .createSuccessResponse(Constants.NO_CHANGES_DETECTED));
    }

    @Override
    public ResponseEntity<?> updateStatus(String id, CandidateStatusRequest candidateStatusRequest, RequestDetails requestDetails) throws TrackerException{
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId,requestDetails);
        if (id == null || id.trim().isEmpty()) {
            log.error("Candidate ID is null or empty");
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_ID_NULL_OR_EMPTY.getStatusCode()),
                    HttpStatus.BAD_REQUEST
            );
        }
        try {

            if (!candidateRepository.existsById(id)) {
                log.error("Candidate not found or already inactive: ID = {}", id);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND_WITH_ID.getStatusCode()),
                        HttpStatus.NOT_FOUND
                );
            }
            Optional<Candidate> optionalCandidate = candidateRepository.findByCompanyIdAndId(companyId,id);
            if (optionalCandidate.isEmpty()) {
                log.error("Candidate not found with ID: {}", id);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND_WITH_ID.getStatusCode()),
                        HttpStatus.NOT_FOUND
                );
            }
            Candidate candidate = optionalCandidate.get();
            if(candidateStatusRequest.getCandidatureStatus()!=null && candidate.getCandidatureStatus().equalsIgnoreCase(Status.HIRED.getShortLabel())){
                log.error("Candidate with ID {} is already hired", id);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_ALREADY_HIRED.getStatusCode()),
                        HttpStatus.BAD_REQUEST
                );
            }

            if(candidateStatusRequest.getCandidatureStatus().equalsIgnoreCase(Status.CREATED.getShortLabel()) && candidate.getJobAssignment()!=null){
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_ALREADY_ASSIGNED.getStatusCode()),
                        HttpStatus.BAD_REQUEST
                );
            }
            if(candidate.getJobAssignment()==null){
                log.error("Candidate with ID {} has no job assignment", id);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NO_JOB_ASSIGNMENT.getStatusCode()),
                        HttpStatus.BAD_REQUEST
                );
            }
            if(candidate.getAssignment()==null){
               throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_USER_ASSIGNED_CANDIDATE.getStatusCode()),HttpStatus.BAD_REQUEST);
            }
            else{
                CandidateJobAssign assignment=assignmentRepository.findById(candidate.getJobAssignment().getId()).orElseThrow();
                assignment.setCandidatureStatus(candidateStatusRequest.getCandidatureStatus());
                if(candidateStatusRequest.getCandidatureStatus().equalsIgnoreCase(Status.REJECTED.getShortLabel())){
                    assignment.setRejectedDate(LocalDate.now());
                    candidate.setCandidatureStatus(Status.CREATED.getShortLabel());
                    candidate.setJobAssignment(null);
                }
                if(candidateStatusRequest.getCandidatureStatus().equalsIgnoreCase(Status.HIRED.getShortLabel())){
                    candidate.setAcceptedPackage(candidateStatusRequest.getAcceptedPackage());
                    candidateRepository.save(candidate);
                }
                assignmentRepository.save(assignment);
                                if(!candidateStatusRequest.getCandidatureStatus().equalsIgnoreCase(Status.REJECTED.getShortLabel())){
                    candidate.setCandidatureStatus(candidateStatusRequest.getCandidatureStatus());
                }
                candidate.setUpdateDate(new Date(Instant.now().toEpochMilli()));
                candidate.setUpdatedBy(requestDetails.getUserId());

                String newStatus = candidateStatusRequest.getCandidatureStatus();
                String assignedUserId = candidate.getAssignment().getUser().getId();
                if (Status.HIRED.getShortLabel().equalsIgnoreCase(newStatus)
                        || Status.HIRED.getLongLabel().equalsIgnoreCase(newStatus)) {
                    scoringService.addScore(assignedUserId, id, 0, "HIRED");
                }
                if (Status.INTERVIEW.getShortLabel().equalsIgnoreCase(newStatus)
                        || Status.INTERVIEW.getLongLabel().equalsIgnoreCase(newStatus)
                        || "INTERVIEWING".equalsIgnoreCase(newStatus)) {
                    scoringService.addScore(assignedUserId, id, 0, "INTERVIEWING");
                }
                String systemComment = "Candidate status updated to: " + candidateStatusRequest.getCandidatureStatus() + " by user: " + requestDetails.getUserId();
                commentService.addSystemComment(id, systemComment, requestDetails);
                candidateRepository.save(candidate);

            }
            log.info("Successfully deleted candidate with ID: {}", id);
        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Failed to delete candidate {}: {}", id, e.getMessage(), e);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_DELETE_CANDIDATE.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.CANDIDATE_UPDATED),HttpStatus.OK);
    }

    @Override
    @Transactional
    public ResponseEntity<?> uploadCandidatesFile(MultipartFile file, RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        List<Candidate> candidates = new ArrayList<>();
        List<BulkValidationError>erroredRecords =new ArrayList<>();
        try {
            String fileName = file.getOriginalFilename();
            if (fileName == null || fileName.isEmpty()) {
                log.error("No file provided");
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.SUPPORTED_FILES.getStatusCode()), HttpStatus.BAD_REQUEST);
            }

            if (fileName.endsWith(".csv")) {
                try (
                        CSVReader csvReader = new CSVReaderBuilder(
                                new InputStreamReader(file.getInputStream()))
                                .withCSVParser(new CSVParserBuilder()
                                        .withSeparator(',')
                                        .withQuoteChar('"')
                                        .build())
                                .build()
                ){
                    csvReader.readNext();
                    for(String[] row=csvReader.readNext();row!=null;row=csvReader.readNext())
                    {
                        try {
                            CandidateRequest candidateRequest = CandidateUtils.mapRowToCandidateRequest(row);
                            Set<ConstraintViolation<CandidateRequest>> violations = validator.validate(candidateRequest);
                            if (!violations.isEmpty()) {
                                StringBuilder sb = new StringBuilder();
                                for (ConstraintViolation<CandidateRequest> v : violations) {
                                    sb.append(v.getMessage().concat(".\n"));
                                }
                                erroredRecords.add(new BulkValidationError(candidateRequest,sb.toString()));
                                continue;
                            }
                            Candidate candidate = objectMapper.convertValue(candidateRequest, Candidate.class);
                            candidate.setCompanyId(companyId);
                            candidate.setCreateDate(new Date(Instant.now().toEpochMilli()));
                            candidate.setCreatedBy(null);
                            candidate.setStatus(Status.ACTIVE.getLongLabel());
                            candidate.setCandidatureStatus(Status.CREATED.getLongLabel());
                            candidate.setId(ResourceIdUtils.generateCandidateResourceId(companyId,candidate.getEmail()));
                            candidates.add(candidate);
                        } catch (TrackerException e) {
                            erroredRecords.add(new BulkValidationError(null,e.getMessage().concat(".\n")));
                        }
                    }
                }
            } else if (fileName.endsWith(".xlsx")) {
                try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
                    for (int sheetIdx = 0; sheetIdx < workbook.getNumberOfSheets(); sheetIdx++) {
                        Sheet sheet = workbook.getSheetAt(sheetIdx);
                        Iterator<Row> rowIterator = sheet.iterator();
                        if (rowIterator.hasNext()) rowIterator.next();
                        while (rowIterator.hasNext()) {
                            Row row = rowIterator.next();
                            try {
                                CandidateRequest candidateRequest = CandidateUtils.mapRowToCandidateRequest(row);
                                Set<ConstraintViolation<CandidateRequest>> violations = validator.validate(candidateRequest);
                                if (!violations.isEmpty()) {
                                    StringBuilder sb = new StringBuilder();
                                    for (ConstraintViolation<CandidateRequest> v : violations) {
                                        sb.append(v.getMessage().concat(".\n"));
                                    }
                                    erroredRecords.add(new BulkValidationError(candidateRequest,sb.toString()));
                                    continue;
                                }
                                Candidate candidate = objectMapper.convertValue(candidateRequest, Candidate.class);
                                candidate.setCompanyId(companyId);
                                candidate.setCreateDate(new Date(Instant.now().toEpochMilli()));
                                candidate.setCreatedBy(null);
                                candidate.setStatus(Status.ACTIVE.getLongLabel());
                                candidate.setCandidatureStatus(Status.CREATED.getLongLabel());
                                candidate.setId(ResourceIdUtils.generateCandidateResourceId(companyId,candidate.getEmail()));
                                candidates.add(candidate);
                            } catch (TrackerException e) {
                               erroredRecords.add(new BulkValidationError(null,e.getMessage().concat(".\n")));
                            }
                        }
                    }
                }
            } else {
                log.error("Unsupported file type: {}", fileName);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.SUPPORTED_FILES.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            List<Candidate> validCandidates = new ArrayList<>();
            for (Candidate candidate : candidates) {
                if (candidateRepository.existsByCompanyIdAndEmail(companyId,candidate.getEmail())) {
                    continue;
                }
                validCandidates.add(candidate);
            }
            if (!validCandidates.isEmpty()) {
                candidateRepository.saveAll(validCandidates);
                log.info("Successfully saved {} candidates", validCandidates.size());
            }
            Map<String, Object> response = new HashMap<>();
            response.put("successfulRecords", validCandidates.size());
            response.put("failedRecords",erroredRecords);
            return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(response), HttpStatus.OK);
        } catch (java.io.IOException e) {
            log.error("Error processing file: {}", e.getMessage());
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_TO_PROCESS_FILE.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR
            );
        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error during file upload: {}", e.getMessage(), e);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_TO_UPLOAD_CANDIDATE.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    @Override
    public ResponseEntity<?> getJobByCandidateId(String id,RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        Candidate candidate=candidateRepository.findByCompanyIdAndId(companyId,id)
                .filter(c-> c.getStatus().equals(Status.ACTIVE.getLongLabel()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND_WITH_ID.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));
        if(candidate.getJobAssignment().getJob()==null){
            log.error("Job not found for candidate with ID: {}", id);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND_FOR_CANDIDATE.getStatusCode()),
                    HttpStatus.NOT_FOUND
            );
        }
        return new ResponseEntity<>(
                ResponseBuilder.builder().build().createSuccessResponse(objectMapper.convertValue(candidate.getJobAssignment().getJob(), JobResponse.class)),
                HttpStatus.OK
        );
    }

    @Override
    @Transactional
    public ResponseEntity<?> candidateAssignToUser(String userId, String candidateId) throws TrackerException {
        if (userId == null || userId.trim().isEmpty() || candidateId == null || candidateId.trim().isEmpty()) {
            log.error("User ID or Candidate ID is null or empty");
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_ID_NULL_OR_EMPTY.getStatusCode()),
                    HttpStatus.BAD_REQUEST
            );
        }
        String companyId = getCompanyId();
        log.info("Assigning candidate {} to user {} for company {}", candidateId, userId, companyId);

        if (!companyRepository.existsById(companyId)) {
            log.error("Company not found with ID: {}", companyId);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.NO_COMPANY_FOUND.getStatusCode()),
                    HttpStatus.NOT_FOUND
            );
        }
        Candidate candidate = candidateRepository.findByCompanyIdAndId(companyId,candidateId)
                .filter(j -> Status.ACTIVE.getLongLabel().equalsIgnoreCase(j.getStatus()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));
        User user = userRepository.findByIdAndCompanyId(userId, companyId)
                .filter(u -> Status.ACTIVE.getLongLabel().equalsIgnoreCase(u.getStatus()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));
        if (candidate.getId() == null || user.getId() == null) {
            log.error("Candidate or User entity contains null ID");
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.ENTITY_INVALID.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
        if (candidateAssignmentRepository.existsByCandidateId(candidateId)) {
            if (candidateAssignmentRepository.existsByCandidateIdAndUserId(candidateId, userId)) {
                log.warn("Candidate {} is already assigned to user {}", candidateId, userId);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.ALREADY_ASSIGNED_TO_SAME_USER.getStatusCode()),
                        HttpStatus.CONFLICT
                );
            } else {
                log.warn("Candidate {} is already assigned to another user", candidateId);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.ALREADY_ASSIGNED.getStatusCode()),
                        HttpStatus.BAD_REQUEST
                );
            }
        }
        String check_id=ResourceIdUtils.generateCandidateUserResourceId(candidateId,userId);
        CandidateUserAssignment assignment = new CandidateUserAssignment();
        assignment.setId(check_id);
        assignment.setCandidate(candidate);
        assignment.setUser(user);

        CandidateUserAssignment savedAssignment;
        try {
            savedAssignment = candidateAssignmentRepository.save(assignment);
            String candidateFullName = CandidateUtils.safeJoin(candidate.getFirstName(), candidate.getMiddleName(), candidate.getLastName());
            emailService.senduserAssigedtocanduidateEmail(user.getEmail(), user.getFirstName(), user.getLastName(), candidateFullName);
        } catch (DataIntegrityViolationException ex) {
            log.error("Database constraint violated while assigning candidate {}: {}", candidateId, ex.getMessage());
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.ALREADY_ASSIGNED.getStatusCode()),
                    HttpStatus.CONFLICT
            );
        } catch (Exception ex) {
            log.error("Unexpected error while saving candidate assignment for candidate {}: {}", candidateId, ex.getMessage());
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.SAVE_FAILED.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
        if (savedAssignment.getId() == null) {
            log.error("Candidate assignment not saved correctly for candidate {}", candidateId);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.SAVE_FAILED.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        if(Objects.isNull(candidate.getCreatedBy())){
            candidate.setCreatedBy(user.getEmail());
        }

        candidate.setAssignment(savedAssignment);
        user.getAssignments().add(savedAssignment);
        candidateRepository.save(candidate);
        String role= Optional.ofNullable(user.getRole()).orElse("").toUpperCase();

        // Scoring: assignment => 10 points
        scoringService.addScore(userId, candidateId, 10, "ASSIGNED");

        String successMessage = switch (role.toUpperCase()) {
            case "RECRUITER" -> Constants.CANDIDATE_RECRUITER;
            case "COMPANY_ADMIN" -> Constants.CANDIDATE_COMPANY_ADMIN;
            case "MANAGER" -> Constants.CANDIDATE_MANAGER;
            default -> Constants.CANDIDATE_DEFAULT;
        };
        User assignedUser = userRepository.findById(userId)
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));
        String systemComment = "Candidate assigned to user: " + assignedUser.getEmail();
        commentService.addSystemComment(candidateId, systemComment, requestDetails);
        ResponseObject<?> response = ResponseBuilder.builder()
                .build()
                .createSuccessResponse(successMessage);

        return ResponseEntity.ok(response);
    }

    @Override
    @Transactional
    public ResponseEntity<?> candidateUnassignFromUser(String candidateId, String userId) throws TrackerException {
        String companyId = getCompanyId();
        Candidate candidate = candidateRepository.findByCompanyIdAndId(companyId,candidateId)
                .filter(c -> Status.ACTIVE.getLongLabel().equalsIgnoreCase(c.getStatus()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND_WITH_ID.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));
        User user = userRepository.findByIdAndCompanyId(userId, companyId)
                .filter(u -> Status.ACTIVE.getLongLabel().equalsIgnoreCase(u.getStatus()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_ASSIGNED_TO_USER.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));
        if(user.getAssignments().isEmpty()) {
            log.error("User {} has no candidate assignments", userId);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.USER_HAS_NO_CANDIDATE_ASSIGNMENTS.getStatusCode()),
                    HttpStatus.NOT_FOUND
            );
        }
        String check_id=ResourceIdUtils.generateCandidateUserResourceId(candidateId,userId);
        boolean hasAssignment = candidateAssignmentRepository.existsById(check_id);
        if(hasAssignment){
            log.info("Unassigning candidate {} from user {}", candidateId, userId);
            CandidateUserAssignment assignment = candidateAssignmentRepository.findById(check_id)
                    .orElseThrow(() -> new TrackerException(
                            ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_ASSIGNED_TO_USER.getStatusCode()),
                            HttpStatus.NOT_FOUND
                    ));
            candidateAssignmentRepository.delete(assignment);
            candidate.setAssignment(null);
            candidateRepository.save(candidate);
            // Remove the ASSIGNED score (10 points) for this user-candidate pair
            scoringService.removeScore(userId, candidateId, "ASSIGNED");
            log.info("Successfully unassigned candidate {} from user {}", candidateId, userId);
            User assignedUser = userRepository.findById(userId)
                    .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));
            String systemComment = "Candidate unassigned from user: " + assignedUser.getEmail();
            commentService.addSystemComment(candidateId, systemComment, requestDetails);
        }
        return new ResponseEntity<>(
                ResponseBuilder.builder().build().createSuccessResponse(Constants.CANDIDATE_UNASSIGNED_FROM_USER),
                HttpStatus.OK
        );
    }

    public ResponseEntity<?> candidateReassignUser(String candidateId, String userId) {
        String companyId = getCompanyId();

        if (!companyRepository.existsById(companyId)) {
            log.error("Company does not exist in the database! CompanyId: {}", companyId);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.NO_COMPANY_FOUND.getStatusCode()),
                    HttpStatus.NOT_FOUND
            );
        }

        Candidate candidate = candidateRepository.findByCompanyIdAndId(companyId, candidateId)
                .filter(c -> Status.ACTIVE.getLongLabel().equalsIgnoreCase(c.getStatus()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));

        User user = userRepository.findByIdAndCompanyId(userId, companyId)
                .filter(u -> Status.ACTIVE.getLongLabel().equalsIgnoreCase(u.getStatus()))
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                ));

        String check_id = ResourceIdUtils.generateCandidateUserResourceId(candidateId, userId);
        boolean existsByAssignmentId = candidateAssignmentRepository.existsById(check_id);
        if (existsByAssignmentId) {
            Optional<CandidateUserAssignment> existingAssignmentOpt = candidateAssignmentRepository.findById(check_id);

            if (existingAssignmentOpt.isEmpty()) {
                log.error("No existing candidate assignment found for candidateId: {}", candidateId);
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND.getStatusCode()),
                        HttpStatus.NOT_FOUND
                );
            }

            CandidateUserAssignment candidateAssignment = existingAssignmentOpt.get();
            candidateAssignment.setUser(user);
            candidate.setAssignment(candidateAssignmentRepository.save(candidateAssignment));
            candidateRepository.save(candidate);

            String role = Optional.ofNullable(user.getRole()).orElse("").toUpperCase();

            String successMessage = switch (role) {
                case "RECRUITER" -> Constants.CANDIDATE_RECRUITER;
                case "COMPANY_ADMIN" -> Constants.CANDIDATE_COMPANY_ADMIN;
                case "MANAGER" -> Constants.CANDIDATE_MANAGER;
                default -> Constants.CANDIDATE_DEFAULT;
            };

            ResponseObject<?> response = ResponseBuilder.builder()
                    .build()
                    .createSuccessResponse(successMessage);

            return ResponseEntity.ok(response);
        }
        else{
            CandidateUserAssignment assignment = new CandidateUserAssignment();
            assignment.setId(check_id);
            assignment.setCandidate(candidate);
            assignment.setUser(user);

            candidate.setAssignment(candidateAssignmentRepository.save(assignment));
            candidateRepository.save(candidate);
            log.info("Successfully assigned candidate {} to user {}", candidateId, userId);
            String systemComment = "Candidate reassigned from user: " + candidate.getAssignment().getUser().getEmail() + " to user: " + user.getEmail();
            commentService.addSystemComment(candidateId, systemComment, requestDetails);
            String role= Optional.ofNullable(user.getRole()).orElse("").toUpperCase();

            String successMessage = switch (role.toUpperCase()) {
                case "RECRUITER" -> Constants.CANDIDATE_RECRUITER;
                case "COMPANY_ADMIN" -> Constants.CANDIDATE_COMPANY_ADMIN;
                case "MANAGER" -> Constants.CANDIDATE_MANAGER;
                default -> Constants.CANDIDATE_DEFAULT;
            };

            ResponseObject<?> response = ResponseBuilder.builder()
                    .build()
                    .createSuccessResponse(successMessage);

            return ResponseEntity.ok(response);
        }
    }

}
