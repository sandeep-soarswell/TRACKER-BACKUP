package com.soarswell.tracker.config;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.util.Constants;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.util.List;
import java.util.Map;

@Aspect
@Configuration
@Slf4j
public class OperationAspect {

    @Autowired
    private Environment environment;

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private RequestDetails requestDetails;

    @Pointcut("@within(org.springframework.web.bind.annotation.RestController)")
    public void restControllerMethods() {}

    @Around("@annotation(operation)")
    public Object operationValue(ProceedingJoinPoint joinPoint, Operation operation) throws Throwable {
        String tag = operation.summary();
        String tagProperty = "";

        if (StringUtils.isNotEmpty(tag) && tag.length() > 3) {
            tagProperty = tag.substring(2, tag.length() - 1); // Safe parse
        }

        String user = null;
        long startTime = System.currentTimeMillis();

        // Extract token from header
        String authHeader = request.getHeader(Constants.AUTH_KEY);
        if (authHeader != null && authHeader.split(" ").length > 1) {
            String token = authHeader.split(" ")[1];
            if (StringUtils.isNotEmpty(token) && !token.equalsIgnoreCase(Constants.NULL)) {
                requestDetails.setAuthToken(token);
                try {
                    DecodedJWT jwt = JWT.decode(token);
                    Map<String, Claim> claims = jwt.getClaims();

                    if (claims.get(Constants.EMPLOYEE) != null) {
                        user = claims.get(Constants.EMPLOYEE).asString();
                        requestDetails.setUserName(user);
                    }
                    if (claims.get(Constants.ROLES) != null) {
                        List<String> roles = claims.get(Constants.ROLES).asList(String.class);
                        requestDetails.setRoles(roles);
                    }
                    if (claims.get(Constants.SUB) != null) {
                        user = claims.get(Constants.SUB).asString();
                        requestDetails.setUserId(user);
                    }
                } catch (Exception jwtEx) {
                    log.warn("Failed to decode JWT: {}", jwtEx.getMessage());
                }
            }
        }

        try {
            Object response = joinPoint.proceed();
            long elapsedTime = System.currentTimeMillis() - startTime;

            log.info("API Success: {}() completed in {} ms | User: {} | Tag: {}",
                    joinPoint.getSignature().getName(),
                    elapsedTime,
                    requestDetails.getUserId(),
                    tagProperty);

            return response;
        } catch (Exception ex) {
            long elapsedTime = System.currentTimeMillis() - startTime;

            log.error("API Failure: {}() failed in {} ms | User: {} | Exception: {}",
                    joinPoint.getSignature().getName(),
                    elapsedTime,
                    requestDetails.getUserId(),
                    ex.getMessage());

            throw ex;
        }
    }
}
