import { defineConfig } from "vite";
import tsconfigPaths from "vite-tsconfig-paths";
import tailwindcss from "@tailwindcss/vite";
import { reactRouter } from "@react-router/dev/vite";
import fs from "fs";
import * as path from "path";
import * as dotenv from "dotenv";
dotenv.config();

export default defineConfig(() => {
  const certPath = process.env.VITE_SSL_CERT_PATH;
  const keyPath = process.env.VITE_SSL_KEY_PATH;

  if (!certPath || !keyPath) {
    throw new Error("Missing VITE_SSL_CERT_PATH or VITE_SSL_KEY_PATH in environment variables.");
  }
  const resolvedCertPath = path.resolve(__dirname, certPath);
  const resolvedKeyPath = path.resolve(__dirname, keyPath);

  return {
    plugins: [tailwindcss(), reactRouter(), tsconfigPaths()],
    server: {
      https: {
        cert: fs.readFileSync(resolvedCertPath),
        key: fs.readFileSync(resolvedKeyPath),
      },
    },
  };
});
