package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.soarswell.tracker.util.Constants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@Schema(description = "Standard error response")
public class ErrorResponse {

    @Schema(description = "HTTP status code")
    private int status;

    @Schema(description = "Error message")
    private String message;

    @Schema(description = "Detailed error description")
    private String detail;

    @Schema(description = "Path where the error occurred")
    private String path;

    @Schema(description = "List of validation errors")
    private List<ValidationError> errors;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.ERROR_RESPONSE_TIMESTAMP_PATTERN)
    @Schema(description = "Timestamp when the error occurred")
    private LocalDateTime timestamp;

    public static ErrorResponse defaultError(int status, String path) {
        return ErrorResponse.builder()
                .status(status)
                .message(Constants.ERROR_RESPONSE_DEFAULT_MESSAGE)
                .detail(Constants.ERROR_RESPONSE_DEFAULT_DETAIL)
                .path(path)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public static ErrorResponse validationError(int status, String path, List<ValidationError> errors) {
        return ErrorResponse.builder()
                .status(status)
                .message(Constants.ERROR_RESPONSE_VALIDATION_MESSAGE)
                .path(path)
                .errors(errors)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public static ErrorResponse authError(int status, String path, String detail) {
        return ErrorResponse.builder()
                .status(status)
                .message(Constants.ERROR_RESPONSE_AUTH_MESSAGE)
                .detail(detail)
                .path(path)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public static ErrorResponse notFoundError(int status, String path, String detail) {
        return ErrorResponse.builder()
                .status(status)
                .message(Constants.ERROR_RESPONSE_NOT_FOUND_MESSAGE)
                .detail(detail)
                .path(path)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public static ErrorResponse forbiddenError(int status, String path, String detail) {
        return ErrorResponse.builder()
                .status(status)
                .message(Constants.ERROR_RESPONSE_FORBIDDEN_MESSAGE)
                .detail(detail)
                .path(path)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public static ErrorResponse conflictError(int status, String path, String detail) {
        return ErrorResponse.builder()
                .status(status)
                .message(Constants.ERROR_RESPONSE_CONFLICT_MESSAGE)
                .detail(detail)
                .path(path)
                .timestamp(LocalDateTime.now())
                .build();
    }

    @Data
    @Builder
    public static class ValidationError {
        @Schema(description = "Field that caused the error")
        private String field;

        @Schema(description = "Error message for the field")
        private String message;

        @Schema(description = "Rejected value")
        private Object rejectedValue;
    }
}