package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.Session;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Transactional
public interface SessionRepository extends JpaRepository<Session, Long> {
    public void deleteAllByUsername(String username);

    public Optional<Session> findByToken(String token);

    public void deleteByToken(String token);
}
