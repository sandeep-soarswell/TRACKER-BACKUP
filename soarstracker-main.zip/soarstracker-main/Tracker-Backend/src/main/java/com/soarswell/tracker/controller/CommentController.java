package com.soarswell.tracker.controller;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.config.SwaggerConfig;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.ClientCommentRequest;
import com.soarswell.tracker.model.payload.CommentRequest;
import com.soarswell.tracker.model.payload.CommentResponse;
import com.soarswell.tracker.service.CommentService;
import com.soarswell.tracker.springsecurity.Authorities;
import com.soarswell.tracker.util.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/comment")
@Tag(name= SwaggerConfig.COMMENT_TAG)
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = Constants.VALIDATION_ERROR,
                content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "401", description = Constants.API_RESPONSE_UNAUTHORIZED,
                content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "404", description = Constants.API_RESPONSE_NOT_FOUND,
                content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "500", description = Constants.API_RESPONSE_ERROR,
                content = @Content(schema = @Schema(implementation = ResponseObject.class)))
})
public class CommentController {

    @Autowired
    private CommentService commentService;

    @Autowired
    private RequestDetails requestDetails;

    @PostMapping("/{candidateId}")
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    @Operation(summary = "${api.addComment.tag}", description = "${api.addComment.description}")
    @ApiResponse(responseCode = "201", description = "Comment added successfully",
            content = @Content(schema = @Schema(implementation = CommentResponse.class)))
    @PreAuthorize(Authorities.COMMENTS_CREATE)
    public ResponseEntity<?> addComment(
            @Parameter(description = "Candidate ID", required = true)
            @PathVariable String candidateId,
            @Parameter(description = "Comment details", required = true)
            @Valid @RequestBody CommentRequest commentRequest,
            Authentication authentication) throws TrackerException {
        return commentService.addComment(candidateId, commentRequest, requestDetails);
    }

    @Operation(summary = "${api.getCommentsByCandidate.tag}", description = "${api.getCommentsByCandidate.description}")
    @ApiResponse(responseCode = "200", description = "List of comments for a candidate",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommentResponse.class))))
    @GetMapping("/{candidateId}")
    @PreAuthorize(Authorities.COMMENTS_LIST)
    @SecurityRequirement(name = Constants.AUTHORIZATION)
    public ResponseEntity<?> getCommentsByCandidate(
            @Parameter(description = "Candidate ID", required = true)
            @PathVariable String candidateId) throws TrackerException {
        return commentService.getCommentsByCandidate(candidateId);
    }

    @PreAuthorize(Authorities.COMMENTS_CREATE)
    @PostMapping("/client/{clientId}")
    @Operation(security = {@SecurityRequirement(name = Constants.AUTHORIZATION)}, summary = "${api.addClientComment.tag}", description = "${api.addClientComment.description}")
    @ApiResponse(responseCode = "200", description = "Successfully added client comment")
    public ResponseEntity<?> addClientComment(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef}")
            @RequestHeader(Constants.AUTHORIZATION) String authToken,
            @PathVariable String clientId,
            @RequestBody @Valid ClientCommentRequest clientCommentRequest
    ) throws TrackerException {
        return commentService.addClientComment(clientId, clientCommentRequest, requestDetails);
    }

    @PreAuthorize(Authorities.COMMENTS_LIST)
    @Operation(security = {@SecurityRequirement(name = Constants.AUTHORIZATION)}, summary = "${api.getClientComments.tag}", description = "${api.getClientComments.description}")
    @GetMapping("/client/{clientId}")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved client comments")
    public ResponseEntity<?> getClientComments(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTHORIZATION) String authToken,
            @PathVariable String clientId) throws TrackerException {
        return commentService.getClientComments(clientId, requestDetails);
    }
}
