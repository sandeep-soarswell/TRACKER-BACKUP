import api from '../api/api.services';
import type { Comment, CommentFormData } from '~/pages/comments/Commentstype';

type Listener = (comments: Comment[]) => void;
let listeners: Listener[] = [];
let currentComments: Comment[] = [];

const notifyListeners = () => {
  listeners.forEach((listener) => listener(currentComments));
};

export const getAllByCandidateId = async (candidateId: string): Promise<Comment[]> => {
  const response = await api.get(`/comment/${candidateId}`);
  const commentList: Comment[] = Array.isArray(response.data?.data) ? response.data.data : [];
  currentComments = commentList;
  notifyListeners();
  return currentComments;
};

export const addComment = async (
  candidateId: string,
  data: CommentFormData
): Promise<Comment> => {
  const response = await api.post(`/comment/${candidateId}`, {
    content: data.text,
  });
  await getAllByCandidateId(candidateId);
  return response.data?.data;
};

export const subscribe = (_channel: string, listener: Listener) => {
  listeners.push(listener);

  if (Array.isArray(currentComments)) {
    listener(currentComments);
  }

  return () => {
    listeners = listeners.filter((l) => l !== listener);
  };
};
