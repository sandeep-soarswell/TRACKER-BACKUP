package com.soarswell.tracker.exception;

import com.soarswell.tracker.common.ResponseObject;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.converter.HttpMessageNotReadableException;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResponseObject<Object>> handleValidationExceptions(MethodArgumentNotValidException ex,
            WebRequest request) {
        Map<String, String> errors = new HashMap<>();
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            errors.put(error.getField(), error.getDefaultMessage());
        }
        ResponseObject<Object> response = ResponseObject.builder()
                .path(request.getDescription(false))
                .message("Validation error")
                .error(errors)
                .build();
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<ResponseObject<Object>> handleEntityNotFound(EntityNotFoundException ex, WebRequest request) {
        Map<String, String> error = new HashMap<>();
        error.put("message", ex.getMessage());
        ResponseObject<Object> response = ResponseObject.builder()
                .path(request.getDescription(false))
                .message("Not Found")
                .error(error)
                .build();
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ResponseObject<Object>> handleDataIntegrityViolation(DataIntegrityViolationException ex,
            WebRequest request) {
        Map<String, String> error = new HashMap<>();
        error.put("message", "Resource already exists");
        ResponseObject<Object> response = ResponseObject.builder()
                .path(request.getDescription(false))
                .message("Conflict")
                .error(error)
                .build();
        return new ResponseEntity<>(response, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ResponseObject<Object>> handleAccessDenied(AccessDeniedException ex, WebRequest request) {
        Map<String, String> error = new HashMap<>();
        error.put("message", "Access denied");
        ResponseObject<Object> response = ResponseObject.builder()
                .path(request.getDescription(false))
                .message("Forbidden")
                .error(error)
                .build();
        return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ResponseObject<Object>> handleBadCredentials(BadCredentialsException ex, WebRequest request) {
        Map<String, String> error = new HashMap<>();
        error.put("message", "Invalid credentials");
        ResponseObject<Object> response = ResponseObject.builder()
                .path(request.getDescription(false))
                .message("Unauthorized")
                .error(error)
                .build();
        return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResponseObject<Object>> handleAllUncaughtException(Exception ex, WebRequest request) {
        Map<String, String> error = new HashMap<>();
        error.put("message", "An unexpected error occurred");
        ResponseObject<Object> response = ResponseObject.builder()
                .path(request.getDescription(false))
                .message("Internal Server Error")
                .error(error)
                .build();
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ResponseObject<Object>> handleResponseStatusException(ResponseStatusException ex,
            WebRequest request) {
        Map<String, String> error = new HashMap<>();
        error.put("message", ex.getReason() != null ? ex.getReason() : "Error occurred");
        ResponseObject<Object> response = ResponseObject.builder()
                .path(request.getDescription(false))
                .message(ex.getStatusCode().toString())
                .error(error)
                .build();
        return new ResponseEntity<>(response, ex.getStatusCode());
    }

    @ExceptionHandler(TrackerException.class)
    public ResponseEntity<ResponseObject<Object>> handleTrackerException(TrackerException ex, WebRequest request) {
        Map<String, String> error = new HashMap<>();
        error.put("message", ex.getMessage());
        ResponseObject<Object> response = ResponseObject.builder()
                .path(request.getDescription(false))
                .message(ex.getStatus() != null ? ex.getStatus().toString() : "Error")
                .error(error)
                .build();
        return new ResponseEntity<>(response,
                ex.getStatus() != null ? ex.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ResponseObject<Object>> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, WebRequest request) {
        Map<String, String> error = new HashMap<>();
        if (ex.getCause() instanceof com.fasterxml.jackson.databind.exc.InvalidFormatException formatEx) {
            String fieldName = "";
            if (!formatEx.getPath().isEmpty()) {
                fieldName = formatEx.getPath().get(0).getFieldName();
            }
            if (fieldName.equals("date")) {
                error.put("date", "Invalid date format. year must be 0-9999,month must be 0-12,day must be 1-31.");
            }
            if (fieldName.equals("startTime")) {
                error.put("startTime", "Invalid time format. Hour must be 0–23, minute must be 0–59.");
            }
            if (fieldName.equals("endTime")) {
                error.put("endTime", "Invalid time format. Hour must be 0–23, minute must be 0–59.");
            }
        }else {
            error.put("message", "Invalid JSON Request");
        }
        ResponseObject<Object> response = ResponseObject.builder()
                .path(request.getDescription(false))
                .message("Bad Request")
                .error(error)
                .build();
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
}

