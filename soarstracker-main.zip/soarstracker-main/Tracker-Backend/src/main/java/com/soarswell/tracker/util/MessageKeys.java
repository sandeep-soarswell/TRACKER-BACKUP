package com.soarswell.tracker.util;

public class MessageKeys {

    // Email subjects
    public static final String MAIL_SUBJECT_REGISTRATION = "mail.subject.registration";
    public static final String MAIL_SUBJECT_USER_UPDATED = "mail.subject.user.updated";
    public static final String MAIL_SUBJECT_OTP = "mail.subject.otp";
    public static final String MAIL_SUBJECT_RESET_OTP="mail.subject.reset.otp";
    public static final String MAIL_SUBJECT_PASSWORD_CHANGED = "mail.subject.password.changed";
    public static final String MAIL_SUBJECT_DEFAULT = "mail.subject.default";

    // Email templates
    public static final String MAIL_TEMPLATE_REGISTRATION = "mail.template.registration";
    public static final String MAIL_TEMPLATE_USER_UPDATED = "mail.template.user.updated";
    public static final String MAIL_TEMPLATE_OTP = "mail.template.otp";
    public static final String MAIL_TEMPLATE_COMPANY_CREATED = "mail.template.company.created";
    public static final String MAIL_TEMPLATE_PASSWORD_CHANGED = "mail.template.password.changed";

    // Error Messages
    public static final String ERROR_EMAIL_SEND_FAILED = "error.email.send.failed";

    // OPERATION TAG NAMES
    public static final String USER_REGISTRATION_TAG_NAME = "${user.registration.tag.name}";
    public static final String USER_REGISTRATION_DESCRIPTION = "${user.registration.description}";

    public static final String USER_GET_BY_ID_TAG_NAME = "${user.get.by.id.tag.name}";
    public static final String USER_GET_BY_ID_DESCRIPTION = "${user.get.by.id.description}";

    public static final String USER_GET_ALL_TAG_NAME = "${user.get.all.tag.name}";
    public static final String USER_GET_ALL_DESCRIPTION = "${user.get.all.description}";

    public static final String USER_DELETE_TAG_NAME = "${user.delete.tag.name}";
    public static final String USER_DELETE_DESCRIPTION = "${user.delete.description}";

    public static final String USER_UPDATE_TAG_NAME = "${user.update.tag.name}";
    public static final String USER_UPDATE_DESCRIPTION = "${user.update.description}";

    public static final String GET_FREE_USERS_TAG_NAME="${user.get.free.users.tag.name}";
    public static final String GET_FREE_USERS_DESCRIPTION="${user.get.free.users.description}";

    public static final String GET_USER_JOBS_TAG_NAME="${user.get.user.jobs.tag.name}";
    public static final String GET_USER_JOBS_DESCRIPTION="${user.get.user.jobs.description}";

    public static final String JOB_CREATION_TAG_NAME="${create.Job.tag.name}";
    public static final String JOB_DELETE_TAG_NAME="${Job.delete.tag.name}";
    public static final String JOB_UPDATE="${update.Job.tag.name}";
    public static final String JOB_UPDATE_DESC="${Update.an.existing.job's.details}";
    public static final String JOB_CREATION_DESCRIPTION="${create.Job.description}";
    public static final String JOB_DELETE_DESCRIPTION="${Job.delete.description}";

    public static final String JOB_GET_BY_ID="${get.job.id}";
    public static final String JOB_GET_BY_ID_DESCRIPTION="${get.job.id.description}";
    public static final String UPDATE_INACTIVE_USER_STATUS_TAG_NAME = "${update.inactive.user.status.tag.name}";
    public static final String UPDATE_INACTIVE_USER_STATUS_DESCRIPTION = "${update.inactive.user.status.description}";
    public static final String JOB_ASSIGN_USER_TAG="${assign.job.to.user}";
    public static final String JOB_ASSIGN_USER_DESCRIPTION="${assign.job.to.user.description}";
    public static final String JOB_UNASSIGN_CANDIDATE_TAG = "${api.unassign.job.from.candidate}";
    public static final String JOB_UNASSIGN_CANDIDATE_DESCRIPTION = "${api.unassign.job.from.candidate.description}";
    public static final String JOB_UNASSIGN_USER_TAG = "${api.unassignJobFromUser.tag}";
    public static final String JOB_UNASSIGN_USER_DESCRIPTION = "${api.unassignJobFromUser.description}";
    public static final String CANDIDATE_USER_UNASSIGN_TAG = "${api.candidateUnassignFromUser.tag}";
    public static final String CANDIDATE_USER_UNASSIGN_DESCRIPTION = "${api.candidateUnassignFromUser.description}";
    public static final String ASSIGN_JOB_CANDIDATE_TAG_NAME = "${api.job.candidate.assign.tag.name}";
    public static final String ASSIGN_JOB_CANDIDATE_DESCRIPTION = "${api.job.candidate.assign.description}";
    
    public static final String GET_USER_ASSIGNED_CANDIDATES_TAG_NAME = "${user.get.assigned.candidates.tag.name}";
    public static final String GET_USER_ASSIGNED_CANDIDATES_DESCRIPTION = "${user.get.assigned.candidates.description}";
    public static final String GET_USER_CREATED_CANDIDATES_TAG_NAME = "${user.get.created.candidates.tag.name}";
    public static final String GET_USER_CREATED_CANDIDATES_DESCRIPTION = "${user.get.created.candidates.description}";
    public static final String CANDIDATE_USER_REASSIGN_TAG = "${candidate.user.reassign.tag}";
    public static final String CANDIDATE_USER_REASSIGN_DESCRIPTION = "${candidate.user.reassign.description}";
    public static final String MAIL_SUBJECT_USER_ASSIGNED_TO_CANDIDATE = "mail.subject.user.assigned.to.candidate";
    public static final String MAIL_TEMPLATE_USER_ASSIGNED_TO_CANDIDATE = "mail.template.user.assigned.to.candidate";
    public static final String UPLOAD_BULK_JOBS = "Upload Jobs in Bulk";
    public static final String UPLOAD_BULK_JOBS_DESC = "Upload multiple jobs from CSV or Excel file";
    public static final String FILE_NAME_FORMATE = "CSV or Excel file";
    public static final String GET_SCORE = "Get recruiter score";
    public static final String GET_SCORE_DESC = "Returns total and average points for a recruiter";
    public static final String GET_SCORE_DETAILS = "Get detailed recruiter score";
    public static final String GET_SCORE_DETAILS_DESC = "Returns detailed scoring breakdown by candidate";
    public static final String CLEAR_SCORE = "Clear recruiter scores";
    public static final String CLEAR_SCORE_DESC = "Clears all scores for a specific recruiter";
}