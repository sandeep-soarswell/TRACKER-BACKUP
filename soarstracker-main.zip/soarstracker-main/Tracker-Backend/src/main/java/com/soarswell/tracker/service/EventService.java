package com.soarswell.tracker.service;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.ClientRequest;
import com.soarswell.tracker.model.payload.EventRequest;
import com.soarswell.tracker.model.payload.EventUpdateRequest;
import org.springframework.http.ResponseEntity;

import javax.sound.midi.Track;

public interface EventService {
    public ResponseEntity<?> registerEvent(EventRequest eventRequest, RequestDetails requestDetails,String candidateId,String jobId) throws TrackerException;
    public ResponseEntity<?> getEvents(RequestDetails requestDetails) throws TrackerException;
    public ResponseEntity<?> getEventById(String eventId, RequestDetails requestDetails) throws TrackerException;
    public ResponseEntity<?> updateEvent(String eventId, EventUpdateRequest eventUpdateRequest, RequestDetails requestDetails) throws TrackerException;
    public ResponseEntity<?> deleteEvent(String eventId,RequestDetails requestDetails) throws TrackerException;
    public ResponseEntity<?> getUpcomingEventsNotifications(RequestDetails requestDetails) throws TrackerException;
    public ResponseEntity<?> markNotificationAsRead(String eventId, RequestDetails requestDetails) throws TrackerException;
}
