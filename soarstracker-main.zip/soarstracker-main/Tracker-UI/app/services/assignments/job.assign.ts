import api from "../api/api.services";

const assignService = {

  assignJobToUser: async (userId: string, jobId: string) => {
    const params = {
      "userId": userId,
      "jobId": jobId
    }
    const response = await api.post(`/job/assign-user-job?${new URLSearchParams(params)}`);
    return response.data;
  },

  unassignJobToUser: async (jobId: string, userId: string) => {
    const params = {
      "jobId": jobId,
      "userId": userId
    }
    const response = await api.post(`/job/unassign-user-job?${new URLSearchParams(params)}`);
    return response.data;
  },

  assignJobToCandidate: async (jobId: string, candidateId: string) => {
    const params = {
      "jobId": jobId,
      "candidateId": candidateId
    }
    const response = await api.post(`/job/assign-candidate-job?${new URLSearchParams(params)}`);
    return response.data;
  },

  unassignJobToCandidate: async (jobId: string, candidateId: string) => {
    const params = {
      "jobId": jobId,
      "candidateId": candidateId
    }
    const response = await api.post(`/job/unassign-candidate-job?${new URLSearchParams(params)}`);
    return response.data;
  },

  assignedCandidate: async (userId: string, candidateId: string) => {
    const params = {
      "userId": userId,
      "candidateId": candidateId
    }
    const response = await api.post(`/candidate/assign-candidate-user?${new URLSearchParams(params)}`);
    return response.data;
  },
  unassignedCandidate: async (candidateId: string, userId: string) => {
    const params = {
      "candidateId": candidateId,
      "userId": userId
    }
    const response = await api.post(`/candidate/unassign-candidate-user?${new URLSearchParams(params)}`);
    return response.data;
  },

}

export default assignService;