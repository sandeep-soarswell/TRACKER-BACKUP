package com.soarswell.tracker.service;

import com.soarswell.tracker.model.Candidate;
import com.soarswell.tracker.model.Job;
import com.soarswell.tracker.model.payload.AISuitabilityResponse;
import com.soarswell.tracker.model.payload.FullAIResponse;
import java.util.List;

public interface AiService {

    public FullAIResponse processResume(String resumeContent);

    public List<AISuitabilityResponse> getSuitabilityScores(Job job, List<Candidate> candidates);

}