package com.soarswell.tracker.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="candidate_job_assignments")
@Getter
@Setter
public class CandidateJobAssign {
    @Id
    String id;

    private LocalDateTime assignedDate;

    private LocalDate rejectedDate;

    private String candidatureStatus;

    private String assignedBy;

    private String clientId;

    @ManyToOne
    private Job job;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "jobAssignment")
    @JsonIgnore
    private Set<Candidate> candidates=new HashSet<>();

}
