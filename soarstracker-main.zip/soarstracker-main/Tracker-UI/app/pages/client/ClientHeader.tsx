import React, { useState, useEffect } from 'react';
import { ChevronLeftIcon, EditIcon, VisibilityIcon } from '~/components/ui/Icons';
import type { Client } from './ClientType';
import { Link } from 'react-router';
import clientService from '~/services/client/client.services';
import ClientDetailsDrawer from './ClientDetail';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import { Tooltip } from '@mui/material';

interface ClientHeaderProps {
  Client: Client;
}

const ClientHeader: React.FC<ClientHeaderProps> = ({
  Client,
}) => {
  const [showDetailsDrawer, setShowDetailsDrawer] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');

  return (
    <div className="rounded-xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl">
      <div className="bg-[#0A2463] p-6 text-white">
        {/* Header Navigation */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Link 
              to="/dashboard/Clients" 
              className="text-white hover:text-blue-200 transition-colors mr-3 p-1 rounded-lg hover:bg-white/10"
              title="Back to Clients"
            >
              <ChevronLeftIcon sx={{ fontSize: 24 }} />
            </Link>
            <div>
              <h1 className="text-2xl font-bold mb-1">
                {Client.clientName}
              </h1>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Tooltip title="View Client Details" arrow>
              <button
                onClick={() => setShowDetailsDrawer(true)}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all duration-200 hover:shadow-md hover:scale-105 active:scale-95 cursor-pointer"
              >
                <VisibilityIcon sx={{ fontSize: 18 }} />
                <span className="font-medium">View Details</span>
              </button>
            </Tooltip>
          </div>
        </div>

        {/* Client Information Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="flex flex-col">
              <span className="text-white text-xs uppercase font-semibold tracking-wide mb-1">
                Contact Person
              </span>
              <span className="font-semibold text-lg">
                {Client.contactPersonName || 'Not specified'}
              </span>
            </div>

            <div className="flex flex-col">
              <span className="text-white text-xs uppercase font-semibold tracking-wide mb-1">
                Email Address
              </span>
              <span className="font-semibold text-lg break-all">
                {Client.email || 'Not provided'}
              </span>
              {Client.email && (
                <a 
                  href={`mailto:${Client.email}`}
                  className="text-blue-300 hover:text-blue-100 text-sm mt-1 underline transition-colors"
                >
                  Send Email
                </a>
              )}
            </div>

            <div className="flex flex-col">
              <span className="text-white text-xs uppercase font-semibold tracking-wide mb-1">
                Phone Number
              </span>
              <span className="font-semibold text-lg">
                {Client.contactPersonNumber || 'Not provided'}
              </span>
            </div>
        </div>
      </div>

      {/* Details Drawer */}
      {showDetailsDrawer && (
        <ClientDetailsDrawer
          client={Client}
          onClose={() => setShowDetailsDrawer(false)}
        />
      )}

      {/* Snackbar for notifications */}
      <CustomSnackbar
        open={snackbarOpen}
        message={snackbarMessage}
        severity="error"
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={4000}
      />
    </div>
  );
};

export default ClientHeader;