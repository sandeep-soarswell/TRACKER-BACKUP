package com.soarswell.tracker.model.payload;

import lombok.*;

import java.time.LocalDate;
import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class CommentResponse {
    private String content;
    private String candidateId;
    private String status;
    private String createdBy;
    private String createdByName;
    private String createdAt;
    private LocalDate createDate;
    private boolean systemComment;
}


