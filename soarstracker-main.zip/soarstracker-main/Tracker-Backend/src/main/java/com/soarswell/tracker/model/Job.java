package com.soarswell.tracker.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.soarswell.tracker.persistance.AbstractEntity;
import jakarta.persistence.*;
import lombok.*;

import java.util.Set;

@Entity
@Table(name = "job",indexes = {
        @Index(name = "idx_job_title", columnList = "title"),
        @Index(name = "idx_job_location", columnList = "location"),
        @Index(name = "idx_job_skills", columnList = "skills"),
        @Index(name = "idx_job_status", columnList = "status"),
        @Index(name= "idx_job_client_id_company_status", columnList = "clientId,companyId,status"),
        @Index(name = "idx_job_experience", columnList = "experience"),
        @Index(name="idx_job_company_status",columnList = "companyId,status"),
        @Index(name="idx_job_id_company_status", columnList = "id,companyId,status"),
        @Index(name="idx_job_company_client_id",columnList = "companyId,clientId")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Job extends AbstractEntity{


    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "description",columnDefinition = "varchar(1000)")
    private String description;

    @Column(name = "location")
    private String location;

    @Column(name = "skills")
    private String skills;

    @Column(name = "salary")
    private String salary;

    @Column(name = "openings")
    private Integer openings;

    @Column(name = "deadline")
    private java.time.LocalDate deadline;

    @Column(name= "clientId")
    private String clientId;

    @Column(name= "experience")
    private String experience;

    @Column(name = "status")
    @Builder.Default
    private String status = Status.OPEN.getLongLabel();

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "user_job_assignments",
            joinColumns = @JoinColumn(name = "job_id"),
            inverseJoinColumns = @JoinColumn(name = "user_id",nullable = false)
    )
    private Set<User> users;

    @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<CandidateJobAssign> candidateJobAssignments;

    private String companyId;

    private String jobId;

    private String contactPersonName;

    private String contactPersonEmail;

    private String contactPersonPhone;

    @Builder.Default
    private boolean isRead=false;

    @Builder.Default
    private boolean notificationSent = false;

    public boolean getIsRead() { return this.isRead;}
}