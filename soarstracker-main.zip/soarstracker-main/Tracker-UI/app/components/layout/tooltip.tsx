import React from "react";
import Tooltip, {type TooltipProps } from "@mui/material/Tooltip";
 
interface CustomTooltipProps extends TooltipProps {
  offsetY?: number;
}
 
const CustomTooltip: React.FC<CustomTooltipProps> = ({ children, offsetY = -25, ...props }) => {
  return (
    <Tooltip
      placement="top-start"
      slotProps={{
        popper: {
          modifiers: [
            {
              name: "offset",
              options: { offset: [0, offsetY] }, // control vertical spacing
            },
          ],
        },
      }}
      {...props}
    >
      {children}
    </Tooltip>
  );
};
 
export default CustomTooltip;