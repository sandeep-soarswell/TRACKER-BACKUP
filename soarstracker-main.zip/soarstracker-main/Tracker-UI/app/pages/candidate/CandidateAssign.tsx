import React, { useEffect, useState, useRef } from "react";
import {
  Autocomplete,
  TextField,
  IconButton,
  CircularProgress,
  InputAdornment,
  Snackbar, Tooltip
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import SearchIcon from "@mui/icons-material/Search";
import type { Candidate } from "~/pages/types/types";
import userService from "~/services/employee/employee.service";
import assignService from "~/services/assignments/job.assign";

interface CandidateAssignProps {
  candidate: Candidate;
  onAssigned: () => void;
  showSnackbar: (message: string, severity: 'success' | 'error') => void;
}

interface Employee {
  id: string;
  name: string;
}

const CandidateAssign: React.FC<CandidateAssignProps> = ({
  candidate,
  onAssigned,
  showSnackbar,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [assignedEmployeeId, setAssignedEmployeeId] = useState<string | null>(null);
  const [assignedEmployeeName, setAssignedEmployeeName] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [assigning, setAssigning] = useState(false);
  const [selected, setSelected] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [isAssigned, setIsAssigned] = useState(false);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsEditing(false);
      }
    };

    if (isEditing) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isEditing]);

  useEffect(() => {
    if (candidate.userId && candidate.userName) {
      const assigned: Employee = {
        id: candidate.userId,
        name: candidate.userName
      };
      setSelectedEmployee(assigned);
      setIsAssigned(true);
    } else {
      setIsAssigned(false);
    }
  }, [candidate]);

  const fetchEmployees = async () => {
    try {
      if (isAssigned && selectedEmployee) {
        setEmployees([selectedEmployee]);
      } else {
        const response = await userService.getAll(0,1000,"*","","*","createDate","desc");
        const list = response.data.records.map((u: any): Employee => ({
          id: u.id,
          name: `${u.firstName} ${u.middleName || ""} ${u.lastName}`.trim(),
        }));
        setEmployees(list);
      }
    } catch (err) {
      showSnackbar("Failed to load employee list", "error");
    }
  };

  const handleAssign = async () => {
    try {
      setLoading(true);
      const response = await assignService.assignedCandidate(selectedEmployee?.id || "", candidate.id);
      setSelected(true);
      showSnackbar(response.data || "Candidate assigned successfully!", "success");
      onAssigned?.();
      setIsEditing(false);
    } catch (error: any) {
      const errorMessage = error?.response.data.error?.message || "Failed to assign candidate.";
      showSnackbar(errorMessage, "error");
    } finally {
      setLoading(false);
    }
  };

  const handleUnassign = async () => {
    try {
      setLoading(true);
      const response = await assignService.unassignedCandidate(candidate.id, candidate.userId);
      setSelected(false);
      showSnackbar(response.data?.message || "Candidate unassigned successfully!", "success");
      onAssigned?.();
      setIsEditing(false);
    } catch (error: any) {
      const errorMessage = error?.response.data.error?.message || "Failed to unassign candidate.";
      showSnackbar(errorMessage, "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full min-w-[200px]" ref={dropdownRef}>
      {!isEditing ? (
        <div
          className="text-blue-600 cursor-pointer hover:underline truncate px-2"
          onClick={() => setIsEditing(true)}
        >
          {candidate.userName || "(empty)"}
        </div>
      ) : (
        <div className="flex items-center gap-1 border px-1 py-1 rounded bg-white min-w-[200px]">
          <Autocomplete
            fullWidth
            options={employees}
            getOptionLabel={(option) => option.name}
            loading={loading}
            value={selectedEmployee}
            onChange={(event, newValue) => setSelectedEmployee(newValue)}
            onOpen={fetchEmployees}
            disabled={isAssigned}
            openOnFocus
            popupIcon={null}
            disableCloseOnSelect={true}
            onInputChange={(event, newInputValue, reason) => {
              if (reason === 'input' || reason === 'reset') {
              }
            }}
            sx={{
              width: 120,
              height: 25,
              '& .MuiInputBase-root': {
                fontSize: '0.875rem',
              }
            }}
            componentsProps={{
              popper: {
                onClick: (e) => {
                  e.stopPropagation();
                },
              },
              paper: {
                onClick: (e) => {
                  e.stopPropagation();
                },
                onMouseDown: (e) => {
                  e.stopPropagation();
                },
              }
            }}
            renderInput={(params) => (
              <TextField
                {...params}
                placeholder="Search"
                variant="standard"
                sx={{
                  width: 120,
                  height: 25,
                  '& .MuiInputBase-input': {
                    fontSize: '0.875rem',
                    padding: '2px 0',
                  }
                }}
                InputProps={{
                  ...params.InputProps,
                  disableUnderline: true,
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon sx={{ fontSize: 14 }} className="text-gray-500" />
                    </InputAdornment>
                  ),
                }}
              />
            )}
          />
          <div className="flex items-center gap-0.5 flex-shrink-0">
            <Tooltip title="Assign" placement="top">
              <IconButton

                onClick={(e) => {
                  e.stopPropagation();
                  handleAssign();
                }}
                disabled={!selectedEmployee || assigning}
                size="small"
                sx={{
                  padding: '2px',
                  minWidth: 'auto',
                  '&:hover': {
                    backgroundColor: 'rgba(76, 175, 80, 0.1)'
                  }
                }}
              >
                <CheckCircleIcon
                  className={`text-green-600 ${!selectedEmployee ? "opacity-50 cursor-not-allowed" : ""}`}
                  sx={{ fontSize: 16 }}
                />
              </IconButton>
            </Tooltip>
            <Tooltip title="Unassign" placement="top">
              <IconButton
                onClick={(e) => {
                  e.stopPropagation();
                  handleUnassign();
                }}
                size="small"
                sx={{
                  padding: '2px',
                  minWidth: 'auto',
                  '&:hover': {
                    backgroundColor: 'rgba(244, 67, 54, 0.1)'
                  }
                }}
              >
                <CancelIcon
                  className="text-red-600"
                  sx={{ fontSize: 16 }}
                />
              </IconButton>
            </Tooltip>
          </div>
        </div>
      )}
    </div>
  );
};

export default CandidateAssign;