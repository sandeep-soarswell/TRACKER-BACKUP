package com.soarswell.tracker.model.role;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

@Getter
public enum RoleCategoryType {

    SYSTEM_DEFINED("System Defined"),
    USER_DEFINED("User Defined");

    private final String category;
    RoleCategoryType(String category) {
        this.category = category;
    }

    public static RoleCategoryType byCategory(final String category) {
        if(StringUtils.isNotBlank(category)) {
            for(RoleCategoryType rc : values()) {
                if(rc.name().equalsIgnoreCase(category)
                        || rc.getCategory().equalsIgnoreCase(category)) {
                    return rc;
                }
            }
        }
        return null;
    }
}

