package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.soarswell.tracker.util.RegExConstants;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;
import io.swagger.v3.oas.annotations.media.Schema;
import com.soarswell.tracker.util.Constants;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import io.swagger.v3.oas.annotations.media.Schema;
import com.soarswell.tracker.util.Constants;

import java.net.URL;
import java.time.LocalDate;
import java.util.Date;

@Getter
@Setter
public class CandidateRequest {

    @Schema(example = Constants.FIRST_NAME)
    @NotBlank(message = "{firstname.not.null}")
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message ="{candidate.firstname.size}" )
    @Size(min = 3, max = 20, message = Constants.FIRSTNAME_FORMAT)
    private String firstName;

    @Schema(example = Constants.MIDDLE_NAME)
    @Size(max = 20, message =  Constants.MIDDLE_NAME_FORMAT)
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = "{candidate.middleName.size}")
    private String middleName;

    @Schema(example = Constants.LAST_NAME)
    @NotBlank(message = "{lastname.not.null}")
    @Pattern(regexp = RegExConstants.NAME_PATTERN,message = "{candidate.lastname.size}")
    @Size(min = 3, max = 20, message = Constants.LASTNAME_FORMAT)
    private String lastName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Past(message="{data.in.past}")
    @NotNull(message = "{D.O.B.not.null}")
    private LocalDate dateOfBirth;

    @Schema(example = Constants.EMAIL)
    @NotNull(message = "{email.not.null}")
    @Email(message = "{invalid.email.format}")
    private String email;

    @Schema(example = Constants.PHONE)
    @NotNull(message = "{mobile.no.not.null}")
    @ValidPhoneNumber(message = "{invalid.mobile.number}")
    private String phoneNumber;

    @Schema(example = Constants.CONTACT_ADDRESS_EXAMPLE)
    @Size(max = 500, message = "{address.size}")
    private String address;

    @Schema(example =Constants.JOB_SKILLS)
    @Size(max = 500, message = "{skills.size}")
    private String skills;

    @Schema(example = "Software Engineer")
    @Pattern(regexp = RegExConstants.CANDIDATE_ROLE,message = "{invalid.candidate.role.format}")
    @Size(max = 500, message = "{candidate.role.size}")
    private String candidateRole;

    @Schema(example = Constants.EMAIL)
    @Email(message = "{invalid.alternate.email.format}")
    private String alternateEmail;

    @Schema(example = Constants.PHONE)
    @ValidPhoneNumber(message = "{invalid.alternate.mobile.number}")
    private String alternatePhoneNumber;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Future(message = "{availability.date.future}")
    @NotNull(message = "{availability.join.not.null}")
    private LocalDate availabilityOfJoining;

    @Schema(example = "4.5 Years")
    @Size(max = 100, message = "{experience.size}")
    private String experience;

    @Schema( example = "30 Days")
    @Size(max = 100, message = "{noticePeriod.size}")
    private String noticePeriod;

    @Schema(example = "9,00,000")
    private String currentSalary;

    @Schema(example = "12,00,000")
    private String expectedSalary;

    @Schema(example = "4.5")
    private double collegeRating;

    @Schema(example = "4.0")
    private double companyRating;

    @Schema(example = "4.2")
    private double experienceRating;

    @Schema(example = "4.8")
    private double skillsRating;

    @Schema(example = "AI-generated summary of the candidate")
    private String aiSummary;

    @Schema(example = "Male")
    @NotBlank(message = "{gender.not.null}")
    private String gender;

    @Schema(example = "1, 2, 3 or more")
    private String numberOfOffers;

}