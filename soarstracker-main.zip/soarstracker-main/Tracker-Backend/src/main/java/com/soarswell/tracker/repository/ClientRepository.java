package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.ClientEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Repository
public interface ClientRepository extends JpaRepository<ClientEntity, String> {
    public Page<ClientEntity> findByCompanyIdAndStatus(String companyId, String status, Pageable pageable);
    public Optional<ClientEntity>findById(String id);
    public Optional<ClientEntity> findByCompanyIdAndId(String companyId, String id);
    public boolean existsByCompanyIdAndEmail(String companyId,String email);
    public boolean existsByCompanyIdAndClientName(String companyId, String clientName);
    public boolean existsByCompanyIdAndContactPersonNumber(String companyId, String contactPersonName);
    @Query("SELECT c FROM ClientEntity c WHERE c.companyId = :companyId AND c.status = :status AND (" +
            "LOWER(c.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.clientName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.contactPersonName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.website) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.address) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.contactPersonNumber) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.country) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.state) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.zipCode) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(c.coolingPeriod AS string) LIKE CONCAT('%', :keyword, '%')" +
            ")")
    Page<ClientEntity> searchAllFieldsByCompanyIdAndStatus(@Param("companyId") String companyId,
                                                             @Param("status") String status,
                                                             @Param("keyword") String keyword,
                                                             Pageable pageable);

    public Optional<ClientEntity> findByCompanyIdAndIdAndStatus(String companyId, String id, String status);
}