export default function equalsIgnoreCase(str1: string, str2: string): boolean {
  if(str1===undefined ||typeof(str1)!=typeof("")|| str1==="" || str1===" " || str1===null) return false
  return String(str1.trim().toLowerCase()) === String(str2.trim().toLowerCase());
}

export const formatSalaryWithCommas = (value: string) => {
  const numeric = value.replace(/[^\d]/g, '');
  if (!numeric) return '';
  return Number(numeric).toLocaleString('en-IN'); 
};

export const formatSalaryRangeWithCommas = (value: string, curr: string) => {
  if (!value) return '';

  //Different locales for different currencies
  const currencyToLocale: Record<string, string> = {
    '₹': 'en-IN', // Indian Rupee
    '$': 'en-US', // US Dollar
    '€': 'de-DE', // Euro
    '£': 'en-GB', // British Pound
    '¥': 'ja-JP'  // Yen
  };

  const currencyMatch = curr.match(/[₹$€£¥]/);
  const currency = currencyMatch ? currencyMatch[0] : '';
  const locale = currencyToLocale[currency] || 'en-IN';
  const parts = value.split('-').sort((a,b)=>{
    const numA = parseFloat(a.replace(/[^\d]/g, ''));
    const numB = parseFloat(b.replace(/[^\d]/g, ''));
    return numA - numB;
  });

  const formatted = parts
    .filter(p => p.trim() !== '')
    .map(p => {
      const numeric = p.replace(/[^\d]/g, '');
      if (!numeric) return '';
      return (currency ? `${currency} ` : '') + Number(numeric).toLocaleString(locale);
    });
  return formatted.join(' - ');
};