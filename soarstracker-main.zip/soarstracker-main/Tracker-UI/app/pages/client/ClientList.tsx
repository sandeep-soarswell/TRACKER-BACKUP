import { AddIcon, SearchIcon, LinkIcon, VisibilityIcon, EditIcon, DeleteIcon, HomeIcon } from '~/components/ui/Icons';
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import TuneIcon from '@mui/icons-material/Tune';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import { DataGrid } from '@mui/x-data-grid';
import Card from "~/components/ui/Card";
import clientService from "~/services/client/client.services";
import type { Client } from '~/pages/types/types';
import ClientRegistrationPage from "./ClientRegistrationPage";
import ClientDetailsDrawer from "./ClientDetail";
import CustomSnackbar from '~/components/ui/Customsnackbar';
import CustomTooltip from '~/components/layout/tooltip';


const ClientsPage: React.FC = () => {
    const [clients, setClients] = useState<Client[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState<string>("");
    const [statusFilter, setStatusFilter] = useState<string>("Active");
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [viewMode, setViewMode] = useState<"view" | "edit" | "create" | null>(null);
    const [selectedClient, setSelectedClient] = useState<Client | null>(null);
    const [searchError, setSearchError] = useState<string | null>(null);
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");
    const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");
    const [currentPage, setCurrentPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [totalEntries, setTotalEntries] = useState(0);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [showStatusModal, setShowStatusModal] = useState(false);
    const [clientToUpdate, setClientToUpdate] = useState<Client | null>(null);
    const [showFilters, setShowFilters] = useState(false);
    const navigate = useNavigate();

    const fetchClients = async () => {
        setSearchError(null);
        setLoading(true);
        try {
            const response = await clientService.getAll(
                currentPage - 1,
                rowsPerPage,
                searchTerm,
                statusFilter,
                "createDate",
                "desc"
            );
            const clientsArray = response.content || [];
            if (Array.isArray(clientsArray)) {
                const validClients = clientsArray.filter((client: Client) => client && client.id);
                setClients(validClients);
                setTotalEntries(response.totalElements || 0);
            } else {
                setClients([]);
                setTotalEntries(0);
                showSnackbar("Unexpected data format from server.", "error");
            }
        } catch (error: any) {
            let errorMessage = "Failed to fetch clients.";
            if (error.response?.status === 401) {
                errorMessage = "Unauthorized: Please log in again.";
            } else if (
                error.response?.status === 404 &&
                error.response?.data?.error?.message === "No clients found under provided criteria"
            ) {
                setSearchError(error.response.data.error.message);
                setClients([]);
                setTotalEntries(0);
            } else if (error.code === "ERR_NETWORK") {
                errorMessage = "Network error: Check your connection or server status.";
                navigate("/");
            } else {
                errorMessage = error?.response?.data?.message || error?.response?.data?.error || "Failed to fetch clients.";
            }
            showSnackbar(errorMessage, "error");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchClients();
    }, [currentPage, rowsPerPage, searchTerm, statusFilter]);

    const showSnackbar = (message: string, severity: "success" | "error" = "success") => {
        setSnackbarMessage(message);
        setSnackbarSeverity(severity);
        setSnackbarOpen(true);
    };

    const handleViewDetails = (client: Client) => {
        setSelectedClient(client);
        setViewMode("view");
        setIsDrawerOpen(true);
    };

    const handleStatusClick = (client: Client) => {
        if (client.status?.toLowerCase() === 'inactive') {
            setClientToUpdate(client);
            setShowStatusModal(true);
        }
    };

    const confirmStatusChange = async () => {
        if (!clientToUpdate?.id) return;
        try {
            const payload = {
                contactPersonNumber: clientToUpdate.contactPersonNumber || '',
                contactPersonName: clientToUpdate.contactPersonName || '',
                address: clientToUpdate.address || '',
                website: clientToUpdate.website || '',
                country: clientToUpdate.country || '',
                state: clientToUpdate.state || '',
                zipCode: clientToUpdate.zipCode || '',
                status: 'active',
                coolingPeriod: clientToUpdate.coolingPeriod || 0,
            };
            await clientService.update(clientToUpdate.id, payload);
            showSnackbar("Client status updated to Active.", "success");
            setStatusFilter("Active");
            fetchClients();
        } catch (error) {
            showSnackbar("Failed to update client status.", "error");
        } finally {
            setShowStatusModal(false);
            setClientToUpdate(null);
        }
    };

    const handleEdit = (client: Client | null) => {
        setSelectedClient(client);
        setViewMode(client ? "edit" : "create");
        setIsDrawerOpen(true);
    };

    const handleDelete = (client: Client) => {
        setSelectedClient(client);
        setShowDeleteModal(true);
    };

    const confirmDelete = async () => {
        if (!selectedClient?.id) {
            showSnackbar("Invalid client ID.", "error");
            return;
        }
        try {
            await clientService.delete(selectedClient.id);
            showSnackbar("Client deleted successfully!", "success");
            fetchClients();
        } catch (error: any) {
            showSnackbar("Failed to delete client.", "error");
        } finally {
            setShowDeleteModal(false);
            setSelectedClient(null);
        }
    };

    const closeDrawer = () => {
        setIsDrawerOpen(false);
        setSelectedClient(null);
        setViewMode(null);
    };

    return (
        <div className="h-[calc(100vh-100px)]">
            <CustomSnackbar
                open={snackbarOpen}
                message={snackbarMessage}
                severity={snackbarSeverity}
                onClose={() => setSnackbarOpen(false)}
                autoHideDuration={3000}
            />
            <div className="flex items-center">
                <div className="flex items-center text-sm text-gray-600">
                    <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
                    <a
                        href="/dashboard"
                        className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                    >
                        Dashboard
                    </a>
                </div>
                <span className="mx-2 text-gray-400">/</span>
                <div className="text-sm text-gray-600">Clients</div>
            </div>
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-gray-900 flex items-center">
                    Client Management
                </h1>
                <button
                    onClick={() => handleEdit(null)}
                    className="flex items-center gap-2 font-bold rounded-lg mb-1 px-3.5 py-2 shadow transition"
                    style={{
                        backgroundColor: "#0A2463",
                        color: "white",
                        letterSpacing: "0.5px",
                        fontSize: "1rem",
                        cursor: "pointer",
                    }}
                >
                    <AddIcon sx={{ fontSize: 18 }} />
                    New Client
                </button>
            </div>
            <Card className="py-3 mb-4">
                {/* Search and filter UI updated to match Jobs page style */}
                <div className="flex flex-col md:flex-row gap-4">
                    <div className="relative w-full md:w-96">
                        <SearchIcon
                            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                            sx={{ fontSize: 18 }}
                        />
                        <input
                            type="text"
                            placeholder="Search by name, email, address, contact person, number, or website..."
                            className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                            value={searchTerm}
                            onChange={(e) => {
                                setSearchTerm(e.target.value);
                                setCurrentPage(1);
                            }}
                        />
                    </div>
                    <div className="ml-auto relative">
                        <button
                            onClick={() => setShowFilters((prev) => !prev)}
                            className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-gray-200 cursor-pointer"
                            title="Filter"
                        >
                            <TuneIcon />
                        </button>

                        {showFilters && (
                            <div className="absolute z-10 right-0 mt-2 w-[260px] bg-white border border-gray-200 rounded-lg shadow-lg p-4 space-y-3">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Status</label>
                                    <select
                                        value={statusFilter}
                                        onChange={(e) => {
                                            setStatusFilter(e.target.value);
                                            setCurrentPage(1);
                                        }}
                                        className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                    >
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </Card>

            {loading ? (
                <p className="text-center text-gray-500">Loading clients...</p>
            ) : (
                <Card className="h-[calc(100vh-245px)] w-full">
                    <DataGrid
                        rows={clients.map((client, index) => ({
                            ...client,
                            sno: (currentPage - 1) * rowsPerPage + index + 1,
                        }))}
                        columns={[
                            { field: 'sno', headerName: '#', flex: 0.3 },
                            {
                                field: 'clientName',
                                headerName: 'Name',
                                flex: 1.2,
                                renderCell: (params) => (
                                    <CustomTooltip title={'Jobs Page'} 
                                    >
                                    <div
                                        onClick={() => navigate('/dashboard/jobs', { state: { clientId: params.row.id } })}
                                        className="text-blue-600 hover:underline cursor-pointer font-medium w-full h-full flex items-center"
                                        role="button"
                                        tabIndex={0}
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter' || e.key === ' ') {
                                                navigate('/dashboard/jobs', { state: { clientId: params.row.id } });
                                            }
                                        }}
                                    >
                                        {params.value}
                                    </div>
                                    </CustomTooltip>
                                ),
                            },
                            { field: 'email', headerName: 'Email', flex: 1.5 },
                           
                            {
                                field: 'contactPersonName', headerName: 'Contact Person', flex: 1,
                                renderCell: (params) => (
                                     <CustomTooltip title={'Comments Page'}>
                                    <div
                                           
                                        onClick={() => navigate('/dashboard/clientcomments', { state: { clientId: params.row.id } })}

                                        className="text-blue-600 hover:underline cursor-pointer font-medium w-full h-full flex items-center"
                                        role="button"
                                        tabIndex={0}
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter' || e.key === ' ') {
                                                navigate('/dashboard/clientcomments', { state: { clientId: params.row.id } });
                                            }
                                        }}
                                    >
                                        {params.value}
                                    </div>
                                    </CustomTooltip>
                                ),
                            },
                            {
                                field: 'website',
                                headerName: 'Website',
                                flex: 1.2,
                                renderCell: (params) => params.value ? (
                                    <a
                                        href={params.value}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-blue-600 hover:underline flex items-center"
                                    >
                                        <LinkIcon sx={{ fontSize: 18, marginRight: 1 }} />
                                        {params.value}
                                    </a>
                                ) : (
                                    <span className="text-gray-400">No Website</span>
                                ),
                            },
                            {
                                field: 'actions',
                                headerName: 'Actions',
                                flex: 0.8,
                                sortable: false,
                                filterable: false,
                                renderCell: (params) => {
                                    const isInactive = params.row.status?.toLowerCase() === 'inactive';
                                    return (
                                        <div className="flex items-center gap-3">
                                            <CustomTooltip title="View Client" placement="top">
                                                <div
                                                    className="p-1 transition cursor-pointer"
                                                    onClick={e => { e.stopPropagation(); handleViewDetails(params.row); }}
                                                >
                                                    <VisibilityIcon className="text-blue-400 hover:scale-110 transition-transform" sx={{ fontSize: 18 }} />
                                                </div>
                                            </CustomTooltip>
                                            {isInactive && (
                                                <CustomTooltip title="Activate Client" placement="top">
                                                    <div
                                                        className="p-1 transition cursor-pointer"
                                                        onClick={e => { e.stopPropagation(); handleStatusClick(params.row); }}
                                                    >
                                                        <CheckCircleOutlineIcon className="text-green-600 hover:scale-110 transition-transform" sx={{ fontSize: 22 }} />
                                                    </div>
                                                </CustomTooltip>
                                            )}
                                            {!isInactive && (
                                                <>
                                                    <CustomTooltip title="Edit Client" placement="top">
                                                        <div
                                                            className="p-1 transition cursor-pointer"
                                                            onClick={e => { e.stopPropagation(); handleEdit(params.row); }}
                                                            tabIndex={0}
                                                        >
                                                            <EditIcon className="text-blue-400 hover:scale-110 transition-transform" sx={{ fontSize: 18 }} />
                                                        </div>
                                                    </CustomTooltip>
                                                    <CustomTooltip title="Delete Client" placement="top">
                                                        <div
                                                            className="p-1 transition cursor-pointer"
                                                            onClick={e => { e.stopPropagation(); handleDelete(params.row); }}
                                                            tabIndex={0}
                                                        >
                                                            <DeleteIcon className="text-red-600 hover:scale-110 transition-transform" sx={{ fontSize: 18 }} />
                                                        </div>
                                                    </CustomTooltip>
                                                </>
                                            )}
                                        </div>
                                    );
                                },
                            },
                        ]}
                        pagination
                        paginationMode="server"
                        rowCount={totalEntries}
                        pageSizeOptions={[5, 10, 20, 50]}
                        paginationModel={{ page: currentPage - 1, pageSize: rowsPerPage }}
                        onPaginationModelChange={({ page, pageSize }) => {
                            setCurrentPage(page + 1);
                            setRowsPerPage(pageSize);
                        }}
                        disableRowSelectionOnClick
                        sx={{
                            width: '100%',
                            '& .MuiDataGrid-columnHeaders': { backgroundColor: '#f1f5f9 !important' },
                            '& .MuiDataGrid-columnHeader': { backgroundColor: '#f1f1f1' },
                            '& .MuiDataGrid-columnHeaderTitle': { fontWeight: 'bold', textTransform: 'uppercase' },
                            '& .MuiDataGrid-row:hover': { backgroundColor: 'inherit' },
                            '& .MuiDataGrid-main': { padding: 0 },
                            '& .MuiDataGrid-footerContainer': { justifyContent: 'flex-end' },
                        }}
                    />
                </Card>
            )}

            {/* Modals and Drawers remain the same */}
            {isDrawerOpen && viewMode === "view" && selectedClient && (
                <ClientDetailsDrawer onClose={closeDrawer} client={selectedClient} />
            )}
            {isDrawerOpen && (viewMode === "edit" || viewMode === "create") && (
                <ClientRegistrationPage
                    client={selectedClient ?? undefined}
                    onClose={closeDrawer}
                    onSuccess={(message) => {
                        fetchClients();
                        closeDrawer();
                        showSnackbar(
                            message,
                            "success"
                        );
                    }}
                />
            )}
            {showDeleteModal && selectedClient && (
                <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
                    <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
                        <h2 className="text-lg font-semibold text-center text-black mb-4">Confirm Delete</h2>
                        <p className="text-center mb-4">
                            Are you sure you want to delete <strong>{selectedClient.clientName}</strong>?
                        </p>
                        <div className="flex justify-center gap-4">
                            <button
                                onClick={confirmDelete}
                                className="bg-red-600 text-white px-5 py-3 rounded hover:bg-red-700 cursor-pointer"
                            >
                                Yes, Delete
                            </button>
                            <button
                                onClick={() => setShowDeleteModal(false)}
                                className="bg-gray-300 text-gray-700 px-5 py-3 rounded hover:bg-gray-400 cursor-pointer"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            )}
            {showStatusModal && clientToUpdate && (
                <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
                    <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
                        <h2 className="text-lg font-semibold text-center text-black mb-4">Confirm Status Change</h2>
                        <p className="text-center mb-4">
                            Are you sure you want to change the status of <strong>{clientToUpdate.clientName}</strong> to Active?
                        </p>
                        <div className="flex justify-center gap-4">
                            <button
                                onClick={confirmStatusChange}
                                className="bg-green-600 text-white px-5 py-3 rounded hover:bg-green-700 cursor-pointer"
                            >
                                Yes, Activate
                            </button>
                            <button
                                onClick={() => {
                                    setShowStatusModal(false);
                                    setClientToUpdate(null);
                                }}
                                className="bg-gray-300 text-gray-700 px-5 py-3 rounded hover:bg-gray-400 cursor-pointer"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ClientsPage;