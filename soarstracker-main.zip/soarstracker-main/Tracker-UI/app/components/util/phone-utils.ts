import { parsePhoneNumberFromString,getCountries, getCountryCallingCode } from "libphonenumber-js";

export const getCountryForCallingCode=(callingCode: string): string=> {
  const code = callingCode.replace('+', '');
  getCountries().filter(
    (country) => {
      if(getCountryCallingCode(country) === code){
        return country;
      }
    }
  );
  return "in";
}
export const getCountryCallingCodeLength = (phoneNumber: string) => {
  if (!phoneNumber) return 3; // Default length for "+91" (INDIA)
  const parsedPhoneNumber=parsePhoneNumberFromString(phoneNumber);
  return parsedPhoneNumber?parsedPhoneNumber.countryCallingCode.length+1 :3;
}

