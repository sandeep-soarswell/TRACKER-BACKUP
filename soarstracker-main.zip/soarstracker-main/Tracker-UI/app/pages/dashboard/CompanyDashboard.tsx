import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'framer-motion';
import {
  People as UsersIcon,
  PersonAdd as UserCheckIcon,
  Work as BriefcaseIcon,
  Business as BuildingIcon,
  CalendarMonth as CalendarIcon,
} from '@mui/icons-material';
import numeral from 'numeral';
import userService from '~/services/employee/employee.service';
import candidateService from '~/services/candidate/candidate.service';
import jobService from '~/services/job/job.services';
import clientService from '~/services/client/client.services';
import eventService from '~/services/event/event.service';
import { StatCard } from './StatCard';
import CandidateDetailsDrawer from '../candidate/CandidateDetailsDrawer';
import type { Candidate } from '../types/types';
import Card from '~/components/ui/Card';

interface DonutHoverInfo {
  label: string;
  value: string;
}

const useClientRevenue = ({
  hiredCandidates,
  clients,
  openJobsList,
  closedJobsList,
}: {
  hiredCandidates: any[],
  clients: any[],
  openJobsList: any[],
  closedJobsList: any[],
}) => {
  return useMemo(() => {
    if (!hiredCandidates.length || !clients.length) return {};

    const revenueMap: { [client: string]: number } = {};
    const allJobs = [...openJobsList, ...closedJobsList];

    hiredCandidates.forEach((candidate: any) => {
      const jobId = candidate.jobId || candidate.job?.id;
      const job = allJobs.find((j: any) => j.id === jobId);

      let clientName = 'Unknown Client';
      if (job) {
        const client = clients.find((c: any) => c.id === job.clientId);
        clientName = client?.clientName || job.clientName || 'Unknown Client';
      } else {
        clientName = candidate.clientName || candidate.job?.clientName || 'Unknown Client';
      }

      let packageValue = 0;
      if (typeof candidate.acceptedPackage === 'string') {
        const match = candidate.acceptedPackage.replace(/,/g, '').match(/(\d+(\.\d+)?)/);
        if (match) packageValue = parseFloat(match[1]);
      } else if (typeof candidate.acceptedPackage === 'number') {
        packageValue = candidate.acceptedPackage;
      }

      revenueMap[clientName] = (revenueMap[clientName] || 0) + packageValue;
    });

    return revenueMap;
  }, [hiredCandidates, clients, openJobsList, closedJobsList]);
};

const CompanyDashboard: React.FC = () => {
  const [ChartComponent, setChartComponent] = useState<React.ComponentType<any> | null>(null);
  const [stats, setStats] = useState({
    users: { active: 0, total: 0 },
    candidates: { active: 0, total: 0 },
    jobs: { active: 0, total: 0 },
    clients: { active: 0, total: 0 },
  });
  const [candidateStatusCounts, setCandidateStatusCounts] = useState<{ [status: string]: number }>({});
  const [jobsByClient, setJobsByClient] = useState<{ [client: string]: { open: number; closed: number } }>({});
  const [openingsPerClient, setOpeningsPerClient] = useState<{ [client: string]: number }>({});
  const [hiredCandidates, setHiredCandidates] = useState<any[]>([]);
  const [upcomingEvents, setUpcomingEvents] = useState<any[]>([]);
  const [clientNameToIdMap, setClientNameToIdMap] = useState<{ [name: string]: string }>({});
  const [revenueDonutHoverInfo, setRevenueDonutHoverInfo] = useState<DonutHoverInfo | null>(null);
  const [candidateDonutHoverInfo, setCandidateDonutHoverInfo] = useState<{ label: string; value: string } | null>(null);
  const [jobsDonutHoverInfo, setJobsDonutHoverInfo] = useState<{ label: string; value: string } | null>(null);
  const [candidatesByUser, setCandidatesByUser] = useState<{ [userId: string]: number }>({});
  const [userNameToIdMap, setUserNameToIdMap] = useState<{ [name: string]: string }>({});
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedRecruiter, setSelectedRecruiter] = useState<string>('');
  const [userList, setUserList] = useState<{ id: string; name: string }[]>([]);
  const [recruiterCandidateStatuses, setRecruiterCandidateStatuses] = useState<{ [userId: string]: { [status: string]: number } }>({});
  const [uniqueStatuses, setUniqueStatuses] = useState<string[]>([]);
  const [openJobsList, setOpenJobsList] = useState<any[]>([]);
  const [closedJobsList, setClosedJobsList] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);

  const navigate = useNavigate();
  const customPalette = ["#8bbcebff", "#a8f050ff", "#eb98e8ff", "#f3c769ff", "#4472C4", '#66CDAA', "#9E480E"];

  useEffect(() => {
    import('react-apexcharts').then(module => {
      setChartComponent(() => module.default);
    }).catch();
  }, []);

  useEffect(() => {
    const fetchAllData = async () => {
      setIsLoading(true);
      try {
        const [userRes, candidateRes, clientRes, openJobsRes, closedJobsRes, hiredRes, eventsRes] = await Promise.all([
          userService.getAll(0, 1000, ''),
          candidateService.getAll(0, 1000, '', undefined, undefined),
          clientService.getAll(0, 1000, '', undefined),
          jobService.getAll({ page: 0, size: 1000, filter: 'OPEN' }),
          jobService.getAll({ page: 0, size: 1000, filter: 'CLOSED' }),
          candidateService.getAll(0, 5, '', undefined, 'Hired', 'updateDate', 'desc'),
          eventService.getAll()
        ]);
        const users = userRes.data?.records || [];
        setStats(prev => ({ ...prev, users: { active: users.length, total: users.length } }));
        const recruiterUsers = users.filter((u: any) => {
          if (u.role && typeof u.role === 'string' && u.role.toUpperCase() === 'RECRUITER') return true;
          if (u.roles) {
            if (Array.isArray(u.roles)) return u.roles.map((r: string) => r.toUpperCase()).includes('RECRUITER');
            if (typeof u.roles === 'string') return u.roles.toUpperCase() === 'RECRUITER';
          }
          return false;
        });
        const allCandidates = candidateRes.content || [];
        const activeCandidatesCount = allCandidates.filter((c: any) => (c.status || '').toLowerCase() === 'active').length;
        const statusCounts: { [status: string]: number } = {};
        allCandidates.forEach((c: any) => {
          const status = (c.candidatureStatus || 'Unknown').toLowerCase();
          statusCounts[status] = (statusCounts[status] || 0) + 1;
        });
        setStats(prev => ({ ...prev, candidates: { active: activeCandidatesCount, total: allCandidates.length } }));
        setCandidateStatusCounts(statusCounts);
        setHiredCandidates(hiredRes.content || []);
        const clientsArr = clientRes.content || [];
        setClients(clientsArr);
        const activeClientsCount = clientsArr.filter((c: any) => (c.status || '').toLowerCase() === 'active').length;
        const nameToId: { [name: string]: string } = {};
        clientsArr.forEach((c: any) => {
          const clientName = c.clientName || c.name;
          if (c.id && clientName) nameToId[clientName] = c.id;
        });
        setStats(prev => ({ ...prev, clients: { active: activeClientsCount, total: clientsArr.length } }));
        setClientNameToIdMap(nameToId);

        const openJobs = openJobsRes.data?.data || [];
        const closedJobs = closedJobsRes.data?.data || [];
        setOpenJobsList(openJobs);
        setClosedJobsList(closedJobs);
        const allJobs = [...openJobs, ...closedJobs];
        setStats(prev => ({ ...prev, jobs: { active: openJobs.length, total: allJobs.length } }));

        const clientJobs: { [name: string]: { open: number; closed: number } } = {};
        const clientOpenings: { [name: string]: number } = {};
        allJobs.forEach(job => {
          const client = clientsArr.find((c: any) => c.id === job.clientId);
          const clientName = client?.clientName || job.clientName || 'Unknown Client';
          if (!clientJobs[clientName]) clientJobs[clientName] = { open: 0, closed: 0 };
          if (job.status.toLowerCase() === 'open') {
            clientJobs[clientName].open++;
            clientOpenings[clientName] = (clientOpenings[clientName] || 0) + (job.openings || 0);
          } else {
            clientJobs[clientName].closed++;
          }
        });
        setJobsByClient(clientJobs);
        setOpeningsPerClient(clientOpenings);

        const userNameToId: { [name: string]: string } = {};
        const userDropdownList = users.map((user: any) => {
          const userName = [user.firstName, user.lastName].filter(Boolean).join(' ') || user.email || 'Unknown User';
          if (user.id && userName) userNameToId[userName] = user.id;
          return { id: user.id, name: userName };
        });
        setUserNameToIdMap(userNameToId);
        setUserList([{ id: '', name: 'All Users' }, ...userDropdownList]);

        const candidatesByUserCount: { [userId: string]: number } = {};
        const candidateCountPromises = users.map(async (user: { id: string; }) => {
          const res = await userService.getAssignedCandidatesByUserId(user.id, 0, 1, "ACTIVE", "*");
          const count = res.data?.totalRecords ?? res.totalRecords ?? 0;
          candidatesByUserCount[user.id] = count;
          return count;
        });
        const candidateAssignedCounts = await Promise.all(candidateCountPromises);
        const totalCandidateAssigned = candidateAssignedCounts.reduce((sum, c) => sum + c, 0);
        candidatesByUserCount['unassigned'] = allCandidates.length - totalCandidateAssigned;
        setCandidatesByUser(candidatesByUserCount);
        const recruiterData: { [userId: string]: { [status: string]: number } } = {};
        const statusSet = new Set<string>();
        const candidateAssignmentMap = new Map<string, string>();
        for (const user of recruiterUsers) {
          const res = await userService.getAssignedCandidatesByUserId(user.id, 0, 1000, "ACTIVE", "*");
          const candidates = res.data?.records || [];
          const counts: { [status: string]: number } = {};
          candidates.forEach((c: any) => {
            const status = (c.candidatureStatus || 'Unknown').toLowerCase();
            counts[status] = (counts[status] || 0) + 1;
            statusSet.add(status);
            if (c.id) candidateAssignmentMap.set(c.id, user.id);
          });
          recruiterData[user.id] = counts;
        }
        const unassignedCounts: { [status: string]: number } = {};
        allCandidates.forEach((c: any) => {
          if (!candidateAssignmentMap.has(c.id)) {
            const status = (c.candidatureStatus || 'Unknown').toLowerCase();
            unassignedCounts[status] = (unassignedCounts[status] || 0) + 1;
            statusSet.add(status);
          }
        });
        recruiterData['unassigned'] = unassignedCounts;
        setRecruiterCandidateStatuses(recruiterData);
        setUniqueStatuses(Array.from(statusSet).sort());

        const recruiterDropdownList = recruiterUsers.map((user: any) => {
          const userName = [user.firstName, user.lastName].filter(Boolean).join(' ') || user.email || 'Unknown Recruiter';
          return { id: user.id, name: userName };
        });
        setUserList([{ id: '', name: 'All Recruiters' }, ...recruiterDropdownList]);

        const now = new Date();
        const normalizedEvents = eventsRes.map((item: any) => {
          if (item.event) return item.event;
          return item;
        });
        const sortedEvents = normalizedEvents
          .map((event: any) => ({
            ...event,
            startDateTime: new Date(`${event.date}T${event.startTime}`),
          }))
          .filter((event: any) => event.startDateTime instanceof Date && !isNaN(event.startDateTime.getTime()) && event.startDateTime >= now)
          .sort((a: any, b: any) => a.startDateTime.getTime() - b.startDateTime.getTime())
          .slice(0, 5);
        setUpcomingEvents(sortedEvents);

      } catch (error) {
        console.error("Failed to fetch dashboard data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAllData();
  }, []);

  // Unified, reliable revenue calculation
  const clientRevenue = useClientRevenue({
    hiredCandidates,
    clients,
    openJobsList,
    closedJobsList,
  });

  const TOP_N = 6;
  const chartData = useMemo(() => {
    const clientNames = Object.keys(jobsByClient)
      .filter(name => jobsByClient[name].open > 0)
      .sort((a, b) => jobsByClient[b].open - jobsByClient[a].open);
    const topClientNames = clientNames.slice(0, TOP_N);
    const jobCounts = topClientNames.map(name => jobsByClient[name].open);
    const otherCount = clientNames.slice(TOP_N).reduce((sum, name) => sum + jobsByClient[name].open, 0);
    let labels = [...topClientNames];
    let series = [...jobCounts];
    if (otherCount > 0) {
      labels.push('Others');
      series.push(otherCount);
    }
    return { labels, series };
  }, [jobsByClient]);

  const revenueChartData = useMemo(() => {
    const clientNames = Object.keys(clientRevenue).filter(name => clientRevenue[name] > 0);
    const topClientNames = clientNames.slice(0, TOP_N);
    const revenueValues = topClientNames.map(name => clientRevenue[name]);
    const otherRevenue = clientNames.slice(TOP_N).reduce((sum, name) => sum + clientRevenue[name], 0);
    let labels = [...topClientNames];
    let series = [...revenueValues];
    if (otherRevenue > 0) {
      labels.push('Others');
      series.push(otherRevenue);
    }
    return { labels, series };
  }, [clientRevenue]);

  const donutChartOptions = useMemo(() => ({
    chart: {
      type: 'donut',
      events: {
        dataPointMouseEnter: (_: any, __: any, config: any) => {
          const clientName = chartData.labels[config.dataPointIndex];
          if (clientName) {
            const total = jobsByClient[clientName].open;
            setJobsDonutHoverInfo({ label: clientName, value: `${total}` });
          }
        },
        mouseLeave: () => setJobsDonutHoverInfo(null),
        dataPointSelection: (_: any, __: any, config: any) => {
          const clientName = chartData.labels[config.dataPointIndex];
          if (clientName) navigate('/dashboard/jobs', { state: { clientId: clientNameToIdMap[clientName] } });
        },
      },
    },
    plotOptions: {
      pie: {
        donut: {
          size: '65%',
          labels: {
            show: true,
            total: {
              show: true,
              showAlways: true,
              label: jobsDonutHoverInfo ? jobsDonutHoverInfo.label : 'Open Jobs',
              fontSize: jobsDonutHoverInfo ? '16px' : '22px',
              fontWeight: jobsDonutHoverInfo ? 400 : 600,
              color: '#374151',
              formatter: () => jobsDonutHoverInfo ? jobsDonutHoverInfo.value : `${stats.jobs.active}`,
            }
          }
        }
      }
    },
    tooltip: {
      custom: function ({ seriesIndex, w }: any) {
        const clientName = w.globals.labels[seriesIndex];
        const openJobs = jobsByClient[clientName].open;
        return `<div class="p-2 bg-gray-800 text-white rounded-lg shadow-xl border border-gray-700">
                    <div class="font-bold text-base mb-1">${clientName}</div>
                    <div class="flex items-center"><span class="w-2 h-2 rounded-full bg-green-400 mr-2"></span>Open: ${openJobs}</div>
                  </div>`;
      }
    },
    dataLabels: {
      enabled: true,
      formatter: (val: number) => `${val.toFixed(0)}%`,
      style: {
        colors: ['#fff'],
        fontWeight: 'bold',
      },
      dropShadow: {
        enabled: true,
        top: 1,
        left: 1,
        blur: 1,
        color: '#000',
        opacity: 0.45
      }
    },
    legend: {
      show: true,
      position: 'bottom',
      horizontalAlign: 'center',
      offsetY: 5,
      fontSize: '14px',
      fontWeight: 500,
      markers: {
        width: 12,
        height: 12,
        radius: 6
      },
      itemMargin: {
        horizontal: 8,
        vertical: 4
      }
    },
    colors: customPalette,
    labels: chartData.labels,
    responsive: [{
      breakpoint: 640,
      options: {
        chart: { height: 300 },
        plotOptions: { pie: { donut: { size: '75%' } } },
        legend: {
          fontSize: '12px',
          itemMargin: {
            horizontal: 6,
            vertical: 2
          },
          markers: {
            width: 10,
            height: 10,
            radius: 5
          }
        }
      },
    }],
  }), [chartData, jobsDonutHoverInfo, stats.jobs.active, jobsByClient, clientNameToIdMap, navigate]);

  const revenueChartOptions = useMemo(() => ({
    chart: {
      type: 'donut',
      events: {
        dataPointMouseEnter: (_: any, __: any, config: any) => {
          const clientName = revenueChartData.labels[config.dataPointIndex];
          if (clientName) {
            setRevenueDonutHoverInfo({ label: clientName, value: numeral(clientRevenue[clientName] || 0).format('0,0') });
          }
        },
        mouseLeave: () => setRevenueDonutHoverInfo(null),
        dataPointSelection: (_: any, __: any, config: any) => {
          const clientName = revenueChartData.labels[config.dataPointIndex];
          if (clientName && clientName !== 'Others') {
            navigate('/dashboard/candidates', {
              state: {
                candidatureStatus: 'Hired',
                clientId: clientNameToIdMap[clientName]
              }
            });
          }
        },
      },
    },
    plotOptions: {
      pie: {
        donut: {
          size: '65%',
          labels: {
            show: true,
            total: {
              show: true,
              showAlways: true,
              label: revenueDonutHoverInfo ? revenueDonutHoverInfo.label : 'Revenue',
              fontSize: revenueDonutHoverInfo ? '16px' : '22px',
              fontWeight: revenueDonutHoverInfo ? 400 : 600,
              color: '#374151',
              formatter: () => revenueDonutHoverInfo ? revenueDonutHoverInfo.value : numeral(Object.values(clientRevenue).reduce((a, b) => a + b, 0)).format('0,0'),
            }
          }
        }
      }
    },
    tooltip: {
      custom: function ({ seriesIndex, w }: any) {
        const clientName = w.globals.labels[seriesIndex];
        const revenue = clientRevenue[clientName] || 0;
        return `<div class="p-2 bg-gray-800 text-white rounded-lg shadow-xl border border-gray-700">
                    <div class="font-bold text-base mb-1">${clientName}</div>
                    <div class="flex items-center"><span class="w-2 h-2 rounded-full bg-blue-400 mr-2"></span>Revenue: ₹${numeral(revenue).format('0,0a')}</div>
                  </div>`;
      }
    },
    dataLabels: {
      enabled: true,
      formatter: (val: number, { seriesIndex, w }: any) => {
        const value = w.config.series[seriesIndex];
        return `${numeral(value).format('0.0a')}`;
      },
      style: {
        colors: ['#fff'],
        fontWeight: 'bold',
      },
      dropShadow: {
        enabled: true,
        top: 1,
        left: 1,
        blur: 1,
        color: '#000',
        opacity: 0.45
      }
    },
    legend: {
      show: true,
      position: 'bottom',
      horizontalAlign: 'center',
      offsetY: 5,
      fontSize: '14px',
      fontWeight: 500,
      markers: {
        width: 12,
        height: 12,
        radius: 6
      },
      itemMargin: {
        horizontal: 8,
        vertical: 4
      }
    },
    colors: customPalette,
    labels: revenueChartData.labels,
    responsive: [{
      breakpoint: 640,
      options: {
        chart: { height: 300 },
        plotOptions: { pie: { donut: { size: '75%' } } },
        legend: {
          fontSize: '12px',
          itemMargin: {
            horizontal: 6,
            vertical: 2
          },
          markers: {
            width: 10,
            height: 10,
            radius: 5
          }
        }
      },
    }],
  }), [revenueChartData, revenueDonutHoverInfo, clientRevenue, clientNameToIdMap, navigate]);

  const candidateStatusChartOptions = useMemo(() => ({
    chart: {
      type: 'donut',
      height: 350,
      events: {
        dataPointMouseEnter: (_: any, __: any, config: any) => {
          const status = Object.keys(candidateStatusCounts)[config.dataPointIndex];
          if (status) {
            const count = candidateStatusCounts[status];
            setCandidateDonutHoverInfo({ label: status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()), value: `${count}` });
          }
        },
        mouseLeave: () => setCandidateDonutHoverInfo(null),
        dataPointSelection: (_: any, __: any, config: any) =>
          handleCandidateStatusClick(Object.keys(candidateStatusCounts)[config.dataPointIndex])
      }
    },
    plotOptions: {
      pie: {
        donut: {
          size: '65%',
          labels: {
            show: false
          }
        }
      }
    },
    labels: Object.keys(candidateStatusCounts).map(s =>
      s.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
    ),
    colors: customPalette,
    legend: {
      show: true,
      position: 'bottom',
      horizontalAlign: 'center',
      offsetY: 5,
      fontSize: '14px',
      fontWeight: 500,
      markers: {
        width: 12,
        height: 12,
        radius: 6
      },
      itemMargin: {
        horizontal: 8,
        vertical: 4
      }
    },
    dataLabels: {
      enabled: true,
      formatter: (val: number) => `${val.toFixed(1)}%`,
      style: {
        fontSize: '12px',
        fontWeight: 'bold',
        colors: ['#fff']
      },
      dropShadow: {
        enabled: true,
        top: 1,
        left: 1,
        blur: 1,
        color: '#000',
        opacity: 0.45
      }
    },
    tooltip: {
      enabled: true,
      custom: function ({ seriesIndex, w }: any) {
        const status = Object.keys(candidateStatusCounts)[seriesIndex];
        const count = candidateStatusCounts[status];
        return `<div class="p-2 bg-gray-800 text-white rounded-lg shadow-xl border border-gray-700">
                    <div class="font-bold text-base mb-1">${status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</div>
                    <div class="flex items-center"><span class="w-2 h-2 rounded-full mr-2" style="background-color: ${customPalette[seriesIndex % customPalette.length]};"></span>Count: ${count}</div>
                  </div>`;
      }
    },
    responsive: [
      {
        breakpoint: 768,
        options: {
          chart: { height: 280 },
          legend: {
            fontSize: '12px',
            itemMargin: {
              horizontal: 6,
              vertical: 2
            },
            markers: {
              width: 10,
              height: 10,
              radius: 5
            }
          },
          dataLabels: {
            enabled: true,
            style: {
              fontSize: '10px',
              fontWeight: 'bold'
            }
          }
        }
      },
      {
        breakpoint: 480,
        options: {
          chart: { height: 250 },
          legend: {
            show: true,
            position: 'bottom',
            fontSize: '11px',
            itemMargin: {
              horizontal: 4,
              vertical: 2
            },
            markers: {
              width: 8,
              height: 8,
              radius: 4
            }
          },
          dataLabels: { enabled: false }
        }
      }
    ]
  }), [candidateStatusCounts, candidateDonutHoverInfo, stats.candidates.total]);

  const stackedBarChartData = useMemo(() => {
    if (Object.keys(recruiterCandidateStatuses).length === 0) return { userNames: [], userIds: [] };

    let recruiterUserIds = (userList.filter(u => u.id && u.id !== '' && recruiterCandidateStatuses[u.id]).map(u => u.id));
    recruiterUserIds = recruiterUserIds.sort((a, b) => (candidatesByUser[b] || 0) - (candidatesByUser[a] || 0));

    const userNames = recruiterUserIds.map(userId => {
      const user = userList.find(u => u.id === userId);
      return user ? user.name : 'Unknown Recruiter';
    });

    return { userNames, userIds: recruiterUserIds };
  }, [recruiterCandidateStatuses, userList, candidatesByUser]);

  const stackedBarOptions = useMemo(() => ({
    chart: {
      type: 'bar',
      height: 350,
      stacked: true,
      events: {
        dataPointSelection: function(event: any, chartContext: any, config: any) {
          const recruiterIndex = config.dataPointIndex;
          const recruiterId = stackedBarChartData.userIds[recruiterIndex];
          if (recruiterId) setSelectedRecruiter(recruiterId);
        }
      },
      toolbar: { show: false } // Disable download options
    },
    plotOptions: {
      bar: {
        horizontal: false,
      },
    },
    xaxis: {
      categories: stackedBarChartData.userNames,
      labels: {
        rotate: 0,
        offsetY: 10,
        trim: false,
        minHeight: 60,
        style: {
          fontSize: '12px',
          fontWeight: 600,
          whiteSpace: 'normal',
        },
      },
      scrollbar: {
        enabled: false,
        show: false,
        height: 20,
        color: '#ccc',
        track: {
          background: '#f1f1f1',
        },
        vertical: true,
        alwaysShow: true,
      },
    },
    yaxis: {
      title: {
        text: 'Number of Candidates'
      },
    },
    legend: {
      show: true,
      position: 'top',
      horizontalAlign: 'left',
    },
    fill: {
      opacity: 1
    },
    colors: customPalette,
    dataLabels: {
      enabled: false
    },
    tooltip: {
      y: {
        formatter: (val: number) => `${val} candidates`
      }
    },
    responsive: [{
      breakpoint: 480,
      options: {
        legend: {
          position: 'bottom',
          offsetX: -10,
          offsetY: 0
        }
      }
    }]
  }), [stackedBarChartData.userNames]);

  const stackedBarSeries = useMemo(() => uniqueStatuses.map(status => ({
    name: status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
    data: stackedBarChartData.userIds.map(id => recruiterCandidateStatuses[id]?.[status] || 0)
  })), [uniqueStatuses, stackedBarChartData.userIds, recruiterCandidateStatuses]);

  const recruiterBarOptions = useMemo(() => {
    if (!selectedRecruiter || !recruiterCandidateStatuses[selectedRecruiter]) return {};
    const statusKeys = Object.keys(recruiterCandidateStatuses[selectedRecruiter]);
    return {
      chart: {
        type: 'bar',
        height: 300,
        stacked: true,
        events: {
          dataPointSelection: (_: any, __: any, config: any) => {
            const status = statusKeys[config.dataPointIndex];
            if (status) {
              const formattedStatus = status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
              navigate('/dashboard/candidates', {
                state: { candidatureStatus: formattedStatus, recruiterId: selectedRecruiter }
              });
            }
          }
        },
        toolbar: { show: false } // Disable download options
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: '55%',
        },
      },
      xaxis: {
        categories: [Object.entries(userNameToIdMap).find(([_, id]) => id === selectedRecruiter)?.[0] || 'Recruiter'],
        labels: {
          style: {
            fontSize: '12px',
            fontWeight: 600,
          },
        },
      },
      yaxis: {
        title: {
          text: 'Number of Candidates',
        },
      },
      legend: {
        show: true,
        position: 'top',
        horizontalAlign: 'left',
        fontSize: '14px',
        fontWeight: 500,
        markers: {
          width: 12,
          height: 12,
          radius: 6,
        },
        itemMargin: {
          horizontal: 8,
          vertical: 4,
        },
      },
      fill: {
        opacity: 1,
      },
      colors: customPalette,
      dataLabels: {
        enabled: false,
      },
      tooltip: {
        enabled: true,
        custom: function ({ seriesIndex, dataPointIndex, w }: any) {
          const status = statusKeys[seriesIndex];
          const count = recruiterCandidateStatuses[selectedRecruiter][status];
          return `<div class="p-2 bg-gray-800 text-white rounded-lg shadow-xl border border-gray-700">
            <div class="font-bold text-base mb-1">${status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</div>
            <div class="flex items-center"><span class="w-2 h-2 rounded-full mr-2" style="background-color: ${customPalette[seriesIndex % customPalette.length]};"></span>Count: ${count}</div>
          </div>`;
        },
      },
      responsive: [
        {
          breakpoint: 768,
          options: {
            chart: { height: 220 },
            legend: {
              fontSize: '12px',
              itemMargin: { horizontal: 6, vertical: 2 },
              markers: { width: 10, height: 10, radius: 5 },
            },
          },
        },
        {
          breakpoint: 480,
          options: {
            chart: { height: 180 },
            legend: {
              position: 'bottom',
              fontSize: '11px',
              itemMargin: { horizontal: 4, vertical: 2 },
              markers: { width: 8, height: 8, radius: 4 },
            },
          },
        },
      ],
    };
  }, [selectedRecruiter, recruiterCandidateStatuses, customPalette, navigate]);

  const recruiterBarSeries = useMemo(() => {
    if (!selectedRecruiter || !recruiterCandidateStatuses[selectedRecruiter]) return [];
    const statusKeys = Object.keys(recruiterCandidateStatuses[selectedRecruiter]);
    return statusKeys.map(status => ({
      name: status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      data: [recruiterCandidateStatuses[selectedRecruiter][status] || 0],
    }));
  }, [selectedRecruiter, recruiterCandidateStatuses]);

  const handleCandidateStatusClick = (status?: string) => {
    if (!status) {
      navigate('/dashboard/candidates');
      return;
    }
    const formattedStatus = status
      .replace(/_/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase());
    navigate('/dashboard/candidates', {
      state: { candidatureStatus: formattedStatus }
    });
  };

  const handleUpcomingEventClick = (event: any) => {
    if (event.startDateTime) {
      navigate('/dashboard/calendar', {
        state: { targetDate: event.startDateTime.toISOString() }
      });
    }
  };

  const containerVariants = {
    hidden: { opacity: 1 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } }
  };

  return (
    <div className="space-y-6">
      <Card>
        <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-slate-700 to-slate-600 bg-clip-text text-transparent">
          Company Admin Dashboard
        </h1>
        <p className="text-slate-600">Manage your workforce, track hiring progress</p>
      </Card>
      <motion.div variants={containerVariants} initial="hidden" animate="visible" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Open Jobs" icon={BriefcaseIcon} color="blue" value={stats.jobs.active} onClick={() => navigate('/dashboard/jobs')} />
        <StatCard title="Total Clients" icon={BuildingIcon} color="blue" value={stats.clients.total} onClick={() => navigate('/dashboard/clients')} />
        <StatCard title="Total Employees" icon={UsersIcon} color="blue" value={stats.users.total} onClick={() => navigate('/dashboard/users')} />
        <StatCard title="Total Candidates" icon={UserCheckIcon} color="blue" value={stats.candidates.total} onClick={() => navigate('/dashboard/candidates')} />
      </motion.div>
      
      <motion.div variants={containerVariants} initial="hidden" animate="visible" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div variants={itemVariants}>
          <Card className="h-full">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Jobs by Client</h3>
            {ChartComponent && chartData.series.length > 0 ? (
              <ChartComponent options={donutChartOptions} series={chartData.series} type="donut" height={350} />
            ) : <div className="flex items-center justify-center h-64 text-gray-500">{isLoading ? "Loading Chart..." : "No job data."}</div>}
          </Card>
        </motion.div>
      
        <motion.div variants={itemVariants}>
          <Card className="h-full">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Candidate Status</h3>
            {ChartComponent && Object.keys(candidateStatusCounts).length > 0 ? (
              <ChartComponent
                options={candidateStatusChartOptions}
                series={Object.values(candidateStatusCounts)}
                type="pie"
                height={350}
              />
            ) : <div className="flex items-center justify-center h-64 text-gray-500">No candidate data.</div>}
          </Card>
        </motion.div>
        <motion.div variants={itemVariants}>
          <Card className="h-full">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Client Revenue (Accepted Packages)</h3>
            {ChartComponent && revenueChartData.series.length > 0 ? (
              <ChartComponent options={revenueChartOptions} series={revenueChartData.series} type="donut" height={350} />
            ) : <div className="flex items-center justify-center h-64 text-gray-500">{isLoading ? "Loading Chart..." : "No revenue data."}</div>}
          </Card>
        </motion.div>
      </motion.div>
      <motion.div variants={containerVariants} initial="hidden" animate="visible" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div variants={itemVariants} className="lg:col-span-1">
          <Card className="h-full flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Upcoming Events</h3>
              <button onClick={() => navigate('/dashboard/calendar')} className="text-blue-600 hover:text-blue-800 cursor-pointer text-sm font-medium">View All</button>
            </div>
            <div className="space-y-3 flex-1 overflow-y-auto pr-2">
              {upcomingEvents.length > 0 ? upcomingEvents.map(event => (
                <div
                  key={event.id}
                  className="flex items-center gap-4 p-2.5 hover:bg-gray-50 rounded-lg cursor-pointer"
                  onClick={() => handleUpcomingEventClick(event)}
                >
                  <div className="flex-shrink-0 bg-blue-100 text-blue-600 rounded-lg w-10 h-10 flex items-center justify-center">
                    <CalendarIcon fontSize="small" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-800 truncate">{event.title}</p>
                    <p className="text-xs text-gray-500">{new Date(event.startDateTime).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                </div>
              )) : <div className="flex items-center justify-center h-full text-gray-500">No upcoming events.</div>}
            </div>
          </Card>
        </motion.div>
        <motion.div variants={itemVariants} className="lg:col-span-1">
          <Card className="h-full flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Recently Hired</h3>
              <button onClick={() => handleCandidateStatusClick('hired')} className="text-blue-600 hover:text-blue-800 text-sm cursor-pointer font-medium">View All</button>
            </div>
            <div className="space-y-2 flex-1 overflow-y-auto pr-2">
              {hiredCandidates.length > 0 ? hiredCandidates.map(candidate => {
                const name = [candidate.firstName, candidate.lastName].filter(Boolean).join(' ') || 'N/A';
                return (
                  <div key={candidate.id} onClick={() => { setSelectedCandidate(candidate); setDrawerOpen(true); }} className="flex items-center gap-3 p-2.5 hover:bg-gray-50 rounded-lg cursor-pointer">
                    <div className="w-10 h-10 bg-green-100 text-green-700 rounded-full flex items-center justify-center font-bold flex-shrink-0">{name.charAt(0).toUpperCase()}</div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-gray-900 truncate">{name}</p>
                      <p className="text-xs text-gray-500 truncate">{candidate.email}</p>
                    </div>
                    <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-green-100 text-green-700 border border-green-200">
                      <svg className="w-3 h-3 mr-1 text-green-500" fill="currentColor" viewBox="0 0 20 20"><circle cx="10" cy="10" r="10" /></svg>
                      Hired
                    </span>
                  </div>
                );
              }) : <div className="flex items-center justify-center h-full text-gray-500">No recent hires.</div>}
            </div>
          </Card>
        </motion.div>
        <motion.div variants={itemVariants} className="lg:col-span-1">
          <Card className="h-full flex flex-col">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Openings by Client</h3>
            <div className="flex-1 min-h-0">
              {ChartComponent && Object.keys(openingsPerClient).length > 0 ? (
                <ChartComponent
                  options={{
                    chart: { type: 'line', height: '100%', toolbar: { show: false } },
                    stroke: { curve: 'smooth', width: 3, colors: [...customPalette] },
                    colors: [...customPalette],
                    xaxis: {
                      categories: Object.keys(openingsPerClient),
                      labels: { rotate: -20, style: { fontSize: '10px', fontWeight: 'bold' } }
                    },
                    yaxis: { title: { text: 'Number of Openings' } },
                    dataLabels: { enabled: false },
                    markers: { size: 5 },
                    tooltip: {
                      y: { formatter: (val: number) => `${val} openings` }
                    },
                    grid: { borderColor: '#e5e7eb', row: { colors: ['#f3f4f6', 'transparent'], opacity: 0.5 } },
                    responsive: [
                      {
                        breakpoint: 768,
                        options: {
                          chart: { height: 280 },
                          xaxis: { labels: { style: { fontSize: '9px' } } }
                        }
                      }
                    ]
                  }}
                  series={[{
                    name: 'Job Openings',
                    data: Object.values(openingsPerClient)
                  }]}
                  type="line"
                  height="100%"
                />
              ) : (
                <div className="flex items-center justify-center h-full text-gray-500">No openings data.</div>
              )}
            </div>
          </Card>
        </motion.div>
      </motion.div>
      <motion.div variants={containerVariants} initial="hidden" animate="visible" className="grid grid-cols-1 gap-6">
        <motion.div variants={itemVariants}>
          <Card className="h-[400px]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Recruiter Performance Overview</h3>
            </div>
            <div className="h-[300px]">
              {(ChartComponent && uniqueStatuses.length > 0 &&
                (selectedRecruiter && selectedRecruiter !== '' && recruiterCandidateStatuses[selectedRecruiter] && Object.keys(recruiterCandidateStatuses[selectedRecruiter]).length > 0)) ? (
                  <div className="w-full h-full">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-medium">Candidate Status for {Object.entries(userNameToIdMap).find(([_, id]) => id === selectedRecruiter)?.[0] || 'Recruiter'}</h3>
                      <button
                        onClick={() => setSelectedRecruiter('')}
                        className="px-4 py-2 bg-[#0A2463] text-white rounded hover:bg-[#0A2463]/80 transition-colors text-sm"
                      >
                        ← Back to All Recruiters
                      </button>
                    </div>
                    <div className="w-full h-full flex flex-col items-center">
                      <div className="w-full h-full max-w-3xl">
                        <ChartComponent
                          options={recruiterBarOptions}
                          series={recruiterBarSeries}
                          type="bar"
                          align="center"
                          width="50%"
                          height="100%"
                        />
                      </div>
                    </div>
                  </div>
                ) : (ChartComponent && uniqueStatuses.length > 0 && stackedBarChartData.userIds.length > 0) ? (
                  <div className="w-full" style={{ height: '330px' }}>
                    <div className="h-full overflow-x-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100">
                      <div
                        className="inline-block"
                        style={{ 
                          minWidth: `${Math.max(600, stackedBarChartData.userIds.length * 120)}px`,
                          height: '300px',
                          paddingBottom: '20px'
                        }}
                      >
                        <ChartComponent
                          options={stackedBarOptions}
                          series={stackedBarSeries}
                          type="bar"
                          height={300}
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-64 text-gray-500">{isLoading ? "Loading Chart..." : "No recruiter data."}</div>
                )}
            </div>
          </Card>
        </motion.div>
      </motion.div>
      <CandidateDetailsDrawer candidate={selectedCandidate} open={drawerOpen} onClose={() => setDrawerOpen(false)} />
    </div>
  );
};

export default CompanyDashboard;