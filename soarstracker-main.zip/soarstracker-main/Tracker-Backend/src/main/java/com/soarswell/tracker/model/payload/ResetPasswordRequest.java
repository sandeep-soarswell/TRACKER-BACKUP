package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.RegExConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(description = Constants.REQUEST_RESET)
public class ResetPasswordRequest {

    @NotBlank(message = "{email.required}")
    @Email(message = "{error.invalid.email}")
    @Pattern(regexp = RegExConstants.EMAIL_PATTERN, message = "{error.invalid.email}")
    @Schema(description = Constants.COMPANY_EMAIL_DESC, example = Constants.COMPANY_EMAIL_EXAMPLE, required = true)
    private String email;

    @NotBlank(message = "{password.new.required}")
    @Pattern(regexp = RegExConstants.PASSWORD_PATTERN, message = "{password.pattern.invalid}")
    @Schema(description = Constants.PASSWORD_DESC, example = Constants.PASSWORD_EXAMPLE, required = true)
    private String newPassword;
}