import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router';
import { VpnKey as VpnKeyIcon } from '@mui/icons-material';
import type { Comment, CommentFormData } from '~/pages/types/types';
import type { Candidate } from '~/pages/types/types';
import candidateService from '~/services/candidate/candidate.service';
import { addComment, getAllByCandidateId as getComments, subscribe } from '~/services/coments/comments.service';
import CandidateHeader from '../student/CandidateHeader';
import CommentList from '../comments/CommentList';
import CommentForm from '../comments/CommentForm';
import Card from '~/components/ui/Card';
import { useLayoutEffect, useRef } from 'react';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import { HomeIcon } from '~/components/ui/Icons';

const EachCandidate: React.FC = () => {
  const location = useLocation();
  const { id } = location.state || {};
  const [candidate, setCandidate] = useState<Candidate | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [newCommentIds, setNewCommentIds] = useState<Set<string>>(new Set());
  const scrollRef = useRef<HTMLDivElement>(null);
  const initialLoadRef = useRef(true);

  const clearNewCommentIds = (ids: string[]) => {
    setTimeout(() => {
      setNewCommentIds((prev) => {
        const updated = new Set(prev);
        ids.forEach((id) => updated.delete(id));
        return updated;
      });
    });
  };

  useLayoutEffect(() => {
    if (!loading && initialLoadRef.current && scrollRef.current && comments.length > 0) {
      requestAnimationFrame(() => {
        if (scrollRef.current) {
          scrollRef.current.scrollTop = 0;
          initialLoadRef.current = false;
        }
      });
    }
  }, [loading, comments]);

  const handleStatusUpdate = async (updatedCandidate: Candidate) => {
  setCandidate(updatedCandidate);
  try {
    const commentList = await getComments(id);
    const sorted = commentList.sort(
      (a, b) => new Date(b.createDate).getTime() - new Date(a.createDate).getTime()
    );
    setComments(sorted);
    const newCommentIds = commentList
      .filter((comment) => new Date(comment.createDate).getTime() > Date.now() - 10000)
      .map((c) => c.id);
    setNewCommentIds(new Set(newCommentIds));
    clearNewCommentIds(newCommentIds);
  } catch (err) {
    setSnackbar({
      message: 'Failed to fetch updated comments',
      severity: 'error',
      open: true,
    });
  }
};
  const [snackbar, setSnackbar] = useState<{
    message: string;
    severity: 'success' | 'error' | 'info' | 'warning';
    open: boolean;
  }>({ message: '', severity: 'error', open: false });

  const NotFound = VpnKeyIcon;

  useEffect(() => {
    if (!id) return;
    const fetchData = async () => {
      setLoading(true);
      try {
        const candidateData = await candidateService.getById(id);
        if (!candidateData) {
          setError('Candidate not found');
          return;
        }
        setCandidate(candidateData);
        const commentList = await getComments(id);
        const sorted = commentList.sort(
          (a, b) => new Date(b.createDate).getTime() - new Date(a.createDate).getTime()
        );
        setComments(sorted);
      } catch (err) {
        setError('Failed to load data');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
    const unsubscribe = subscribe(id, (updatedComments: unknown) => {
      if (!Array.isArray(updatedComments)) {
        return;
      }
      const sortedUpdates = updatedComments.sort(
        (a, b) => new Date(b.createDate).getTime() - new Date(a.createDate).getTime()
      );
      setComments((prev) => {
        const map = new Map<string, Comment>();
        [...sortedUpdates, ...prev].forEach((c) => map.set(c.id, c));
        return Array.from(map.values()).sort(
          (a, b) => new Date(b.createDate).getTime() - new Date(a.createDate).getTime()
        );
      });
      const newIds = updatedComments.map((c) => c.id);
      setNewCommentIds((prev) => {
        const updated = new Set(prev);
        newIds.forEach((id) => updated.add(id));
        return updated;
      });
      clearNewCommentIds(newIds);
    });
    return () => {
      unsubscribe();
    };
  }, [id]);

  const handleSubmitComment = async (data: CommentFormData) => {
    if (!candidate) return;

    setSubmitting(true);
    try {
      const newCommentFromServer = await addComment(candidate.id.toString(), data);
      const newComment: Comment = {
        ...newCommentFromServer,
        createDate: newCommentFromServer.createDate || new Date().toISOString(),
      };
      setSnackbar({
        message: 'Comment added successfully!',
        severity: 'success',
        open: true
      });

      setComments((prev) => {
        const exists = prev.some((c) => c.id === newComment.id);
        const updated = exists ? prev : [newComment, ...prev];
        return updated.sort(
          (a, b) => new Date(b.createDate).getTime() - new Date(a.createDate).getTime()
        );
      });

      setNewCommentIds((prev) => new Set(prev).add(newComment.id));
      clearNewCommentIds([newComment.id]);
    } catch (err: any) {
      const errorMsg = err?.response?.data?.error?.message || 'Failed to add comment';
      setSnackbar({
        message: errorMsg,
        severity: 'error',
        open: true
      });
    }
    finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto p-4">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-32 w-32 bg-blue-200 rounded-full mb-4" />
          <div className="h-6 w-40 bg-gray-200 rounded mb-2" />
          <div className="h-4 w-64 bg-gray-200 rounded" />
        </div>
      </div>
    );
  }
  if (error || !candidate) {
    return (
      <div className="max-w-7xl mx-auto p-4 text-center">
        <NotFound className="text-gray-400 mb-4 mx-auto" sx={{ fontSize: 64 }} />
        <h1 className="text-2xl font-bold text-gray-700 mb-2">Candidate Not Found</h1>
        <p className="text-gray-500 mb-6">
          {error || "We couldn't find the candidate you're looking for."}
        </p>
        <a
          href="/dashboard/candidates"
          className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
        >
          Go Back Home
        </a>
      </div>
    );
  }
  return (
    <div className="max-w-8xl mx-auto p-2 flex flex-col overflow-hidden h-[calc(100vh-105px)] w-full">
      <div className="flex items-center px-4 py-2">
        <div className="flex items-center text-sm text-gray-600">
          <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
          <a
            href="/dashboard"
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
          >
            Dashboard
          </a>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="flex items-center text-sm text-gray-600">
          <a
            href="/dashboard/candidates"
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
          >
            Candidates
          </a>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="text-sm text-gray-600">
          Candidate Comments
        </div>
      </div>
      <div className="sticky top-5 mb-4 h-45">
        <CandidateHeader candidate={candidate} onStatusUpdate={handleStatusUpdate} />
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto min-h-0">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            <Card>
              <CommentList
                comments={Array.isArray(comments) ? comments : []}
                newCommentIds={newCommentIds}
                isLoading={loading}
              />
            </Card>
          </div>
          <div className="md:col-span-1 space-y-4">
            <CommentForm
              onSubmit={handleSubmitComment}
              isSubmitting={submitting}
            />
          </div>
        </div>
      </div>
      <CustomSnackbar
        open={snackbar.open}
        message={snackbar.message}
        severity={snackbar.severity}
        onClose={() => setSnackbar((prev) => ({ ...prev, open: false }))}
      />

    </div>
  );
};

export default EachCandidate;
