import React, { useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router';
import { LockIcon, VisibilityIcon, VisibilityOffIcon } from '~/components/ui/Icons';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import SplitCardLayout from '~/components/layout/SplitCardLayout';
import AuthHeader from '~/components/layout/AuthHeader';
import authService from '~/services/login/login.services';

const ResetPassword: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const email = location.state?.email;

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [alertSeverity, setAlertSeverity] = useState<'success' | 'error'>('success');

  const passwordChecks = [
    { label: 'At least 1 uppercase letter', isValid: /[A-Z]/.test(newPassword) },
    { label: 'At least 1 number', isValid: /[0-9]/.test(newPassword) },
    { label: 'At least 1 special character', isValid: /[!@#$%^&*]/.test(newPassword) },
    { label: 'Minimum 8 characters', isValid: newPassword.length >= 8 },
  ];

  const isPasswordValid = passwordChecks.every(check => check.isValid);


  if (!email) {
    navigate('/forgot-password', { replace: true });
    return null;
  }

  const handleSnackbarClose = () => setOpenSnackbar(false);

  const showAlert = (message: string, severity: 'success' | 'error') => {
    setAlertMessage(message);
    setAlertSeverity(severity);
    setOpenSnackbar(true);
  };

  const validatePassword = (password: string) => {
    if (password.length < 8) return 'Password must be at least 8 characters long.';
    if (!/[A-Z]/.test(password)) return 'Password must contain at least one uppercase letter.';
    if (!/[0-9]/.test(password)) return 'Password must contain at least one number.';
    if (!/[!@#$%^&*]/.test(password)) return 'Password must contain at least one special character.';
    return '';
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newPassword || !confirmPassword) {
      showAlert('Please fill all fields.', 'error');
      return;
    }

    const passwordError = validatePassword(newPassword);
    if (passwordError) {
      showAlert(passwordError, 'error');
      return;
    }

    if (newPassword !== confirmPassword) {
      showAlert('Passwords do not match!', 'error');
      return;
    }

    setLoading(true);
    try {
      const token = localStorage.getItem('userToken');
      if (!token) {
        throw new Error('Session expired. Please request a new OTP.');
      }

      const response = await authService.changePassword(newPassword);
      if (response.message.toLowerCase() === 'success') {
        showAlert('Password reset successful! Redirecting...', 'success');
        localStorage.removeItem('userToken');
        setTimeout(() => navigate('/'), 3000);
      } else {
        throw new Error(response?.message || 'Password reset failed.');
      }
    } catch (error: any) {
      const backendMsg =
        error?.response?.data?.error?.newPassword ||
        error?.response?.data?.error?.message ||
        error?.response?.data?.message ||
        'Failed to reset password.';
      showAlert(backendMsg, 'error');
    } finally {
      setLoading(false);
    }
  };

  const [openSnackbar, setOpenSnackbar] = useState(false);

  return (
    <SplitCardLayout>
      <form
        onSubmit={handleResetPassword}
        className="bg-white p-10 rounded-xl shadow-lg w-full max-w-[400px] flex flex-col"
      >
        <AuthHeader subtext="Set new password" />

        <PasswordField
          label="New Password"
          value={newPassword}
          onChange={setNewPassword}
          visible={showNewPassword}
          toggleVisibility={() => setShowNewPassword(!showNewPassword)}
        />
        <PasswordField
          label="Confirm Password"
          value={confirmPassword}
          onChange={setConfirmPassword}
          visible={showConfirmPassword}
          toggleVisibility={() => setShowConfirmPassword(!showConfirmPassword)}
        />
        <ul className="text-xs text-left text-black mb-4 w-full pl-5 list-disc space-y-1">
          {passwordChecks
            .filter(({ isValid }) => !isValid)
            .map(({ label }) => (
              <li key={label}>{label}</li>
            ))}
        </ul>

        <button
          type="submit"
          disabled={!isPasswordValid}
          className={`w-full py-2 px-4 text-white border-none rounded-md font-medium text-sm shadow-md transition-all duration-300 ${!isPasswordValid ? 'bg-gray-400 cursor-not-allowed' : 'bg-[#0A2463] hover:bg-[#081c4e]'
            } focus:ring-2 focus:ring-[#3E92CC]`}
        >
          {loading ? 'Please wait...' : 'Reset Password'}
        </button>

        <div className="w-full flex justify-start mt-2">
          <Link
            to="/"
            className="text-blue-500 text-sm hover:underline font-bold cursor-pointer"
          >
            Back to Login
          </Link>
        </div>
      </form>

      <CustomSnackbar
        open={openSnackbar}
        message={alertMessage}
        onClose={handleSnackbarClose}
        severity={alertSeverity}
        autoHideDuration={3000}
      />
    </SplitCardLayout>
  );
};

const PasswordField: React.FC<{
  label: string;
  value: string;
  onChange: (val: string) => void;
  visible: boolean;
  toggleVisibility: () => void;
}> = ({ label, value, onChange, visible, toggleVisibility }) => (
  <div className="relative mb-5">
    <LockIcon
      className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"
      sx={{ fontSize: 18 }}
    />
    <input
      type={visible ? 'text' : 'password'}
      placeholder={label}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full pl-10 pr-10 py-2 rounded-lg border border-gray-300 bg-[#fafafa] text-[15px] focus:outline-none focus:ring-2 focus:ring-[#3E92CC]"
      required
    />
    {visible ? (
      <VisibilityOffIcon
        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 cursor-pointer"
        sx={{ fontSize: 18 }}
        onClick={toggleVisibility}
      />
    ) : (
      <VisibilityIcon
        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 cursor-pointer"
        sx={{ fontSize: 18 }}
        onClick={toggleVisibility}
      />
    )}
  </div>
);

export default ResetPassword;