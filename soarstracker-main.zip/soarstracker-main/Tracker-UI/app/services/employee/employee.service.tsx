import api from "../api/api.services";

const userService = {
  register: async (payload: any) => {
    const response = await api.post("/user", payload);
    return response.data;
  },
  update: async (userId: string, payload: any) => {
    const response = await api.patch(`/user/${userId}`, payload);
    return response.data;
  },
  getAll: async (
    page: number = 0,
    size: number = 10,
    role: string = "*",
    keyword: string = "",
    filter: string = "*",
    sortByField: string = "createDate",
    sortOrder: string = "desc"
  ) => {
    const params: any = {
      page,
      size,
      sortByField,
      "desc/asc": sortOrder,
      keyword,
      filter,
      role,
    };
    try {
      const response = await api.get("/user", { params });
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  delete: async (userId: string) => {
    const response = await api.delete(`/user/${userId}`);
    return response.data;
  },

  getById: async (userId: string) => {
    const response = await api.get(`/user/${userId}`);
    return response.data;
  },


  getFreeUsers: async (
    page?: number,
    size?: number,
    role?: string,
    jobId?: string
  ) => {
    const params: any = { jobId };
    if (page !== undefined) params.page = page;
    if (size !== undefined) params.size = size;
    if (role) params.role = role;

    const response = await api.get("/user/free-users", { params });
    return response.data;
  },
  updateStatus: async (userId: string, status: string) => {
    return api.patch(`/user/status/${userId}?status=${status}`);
  },

  getAssignedCandidatesByUserId: async ( 
    userId:string ,
    page: number=0,
    size: number=10, 
    filter: string="*", 
    statusFilter:string="*" ) => {

      const params = {userId,page, size, filter, statusFilter};
      const response = await api.get('user/assigned-candidates/',{params});
      return response.data;
  },

   getCreatedCandidatesByUserId: async ( 
    userId:string,
    page: number=0,
    size: number=10, 
    filter: string="*", 
    statusFilter:string="*" ) => {

      const params = {userId,page, size, filter, statusFilter};
      const response = await api.get('user/created-candidates/',{params});
      return response.data;
  },

  getJobsByUserId: async (userId: string, clientId: string)=>{
    const params={
      page:0,
      size:10,
      userId,
      clientId
    };
    const response = await api.get(`/user/jobs/`, { params })
    return response.data;
  },

  getRecruiterScore: async (userId: string) => {
    const response = await api.get(`/user/score?userId=${userId}`);
    return response.data.data;
  },

  getRecruiterScoreDetails: async (userId: string) => {
    const response = await api.get(`/user/score/details?userId=${userId}`);
    return response.data.data;
  },

  clearRecruiterScores: async (userId: string) => {
    const response = await api.delete(`/user/score/clear?userId=${userId}`);
    return response.data;
  },
};

export default userService;
