import React, { useState } from 'react';
import { useLocation } from 'react-router';
import Button from '~/components/ui/Button';
import { SendIcon } from '~/components/ui/Icons';
import { type CommentFormData } from '~/pages/types/types';
import { RequiredLabel } from '~/components/layout/blackFieldStyles';
import EventScheduleForm from '~/pages/event/EventScheduleForm';
import { jwtDecode } from 'jwt-decode';

interface CommentFormProps {
  onSubmit: (data: CommentFormData) => Promise<void>;
  isSubmitting: boolean;
}

const CommentForm: React.FC<CommentFormProps> = ({ onSubmit, isSubmitting }) => {
  const location = useLocation();
  const { id: candidateId, userId: candidateUserId } = location.state || {};

  const [formData, setFormData] = useState<CommentFormData>({
    text: ''
  });
  const [errors, setErrors] = useState<{ text?: string }>({});

  const userEmail = localStorage.getItem('userEmail');
  const token = localStorage.getItem('userToken');
  interface DecodedToken {
    userId: string;
    roles: string[];
  }
  const decoded = jwtDecode<DecodedToken>(token || '');
  const loggedInUserId = decoded.userId;
  const role = decoded.roles[0];
  console.log(role, candidateUserId, loggedInUserId);

  const validate = (): boolean => {
    const newErrors: { text?: string } = {};
    const trimmedText = formData.text.trim();
    if (!trimmedText) {
      newErrors.text = 'Comment is required';
    } else if (trimmedText.length < 3) {
      newErrors.text = 'Comment must be at least 3 characters.';
    } else if (trimmedText.length > 500) {
      newErrors.text = 'Comment must be less than 500 characters.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      await onSubmit(formData);
      setFormData({ text: '' });
    } catch (error) { }
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    if (errors[name as keyof typeof errors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  return (
    <>
      {((role === 'COMPANY_ADMIN' || role === 'MANAGER') || candidateUserId === loggedInUserId) && (
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <form onSubmit={handleSubmit}>
            <h3 className="text-lg font-medium text-gray-800 mb-4">Add Comment</h3>
            <div className="mb-2 text-sm text-gray-600">
              Commenting as: <span className="font-semibold">{userEmail || 'Unknown Recruiter'}</span>
            </div>
            <div className="mb-4">
              <label htmlFor="text" className="block text-sm font-medium text-gray-700 mb-1">
                <RequiredLabel label="Comment" />
              </label>
              <textarea
                id="text"
                name="text"
                value={formData.text}
                onChange={handleChange}
                rows={4}
                className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.text ? 'border-red-500' : 'border-gray-300'
                  }`}
                placeholder="Enter your comment"
              />
              {errors.text && <p className="mt-1 text-sm text-red-500">{errors.text}</p>}
            </div>
            <div className="flex justify-end gap-2">
              <Button
                type="submit"
                variant="primary"
                isLoading={isSubmitting}
                icon={<SendIcon sx={{ fontSize: 16 }} />}
              >
                Add Comment
              </Button>
            </div>
          </form>
        </div>
      )}


      {candidateId && loggedInUserId &&
        ((role === 'COMPANY_ADMIN' || role === 'MANAGER') || candidateUserId === loggedInUserId) && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Schedule Event</h3>
            <EventScheduleForm candidateId={candidateId} />
          </div>
        )}
    </>
  );
};

export default CommentForm;