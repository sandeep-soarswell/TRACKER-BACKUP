package com.soarswell.tracker.model;

import lombok.Getter;

@Getter
public enum Status {

    CREATED("created","CREATED"),
    ACTIVE("active","ACTIVE"),
    INACTIVE("inactive","INACTIVE"),
    ASSIGNED("Profile Submitted","Profile Submitted"),
    UNASSIGNED("unassigned","UNASSIGNED"),
    OPEN("open","OPEN"),
    CLOSE("close","CLOSE"),
    CLOSED("closed","CLOSED"),
    PENDING("pending", "PENDING"),
    INTERVIEW("interview", "INTERVIEW"),
    HIRED("hired", "HIRED"),
    REJECTED("rejected", "REJECTED");
    private final String shortLabel;
    private final String longLabel;

    Status(String shortLabel,String longLabel){
        this.shortLabel=shortLabel;
        this.longLabel=longLabel;
    }

}
