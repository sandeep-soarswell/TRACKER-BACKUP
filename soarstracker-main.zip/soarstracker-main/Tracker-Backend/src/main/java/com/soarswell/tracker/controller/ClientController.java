package com.soarswell.tracker.controller;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.ClientRequest;
import com.soarswell.tracker.service.ClientService;
import com.soarswell.tracker.springsecurity.Authorities;
import com.soarswell.tracker.util.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import com.soarswell.tracker.model.payload.ClientUpdateRequest;
import jakarta.validation.Valid;
import java.io.IOException;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/")
@Tag(name = Constants.CLIENT_TAG)
@ApiResponses({
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "400", description = "The request is malformed or invalid."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "403", description = "The user does not have the necessary privileges to perform the operation."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "500", description = "An internal server error occurred."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "401", description = "Access Denied."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "503", description = "A service is unreachable."),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ResponseObject.class)), responseCode = "504", description = "Gateway Timeout Error"),
        @ApiResponse(responseCode = "200"),
        @ApiResponse(responseCode = "202", content = @Content(schema = @Schema(implementation = ResponseObject.class)))
})
public class ClientController {
    @Autowired
    private ClientService clientService;

    @Autowired
    private RequestDetails requestDetails;

    @PostMapping(Constants.CLIENT)
    @PreAuthorize(Authorities.CLIENT_CREATE)
    @Operation(security = {@SecurityRequirement(name=Constants.AUTH_KEY)},summary = "${api.registerClient.tag}", description = "${api.registerClient.description}")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved clients")
    public ResponseEntity<?>registerClient(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(Constants.AUTH_KEY) String authToken,
            @RequestBody @Valid ClientRequest clientRequest){
        return clientService.registerClients(clientRequest,requestDetails);
    }

    @GetMapping(Constants.CLIENT)
    @PreAuthorize(Authorities.CLIENT_LIST)
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)},
            summary = "${api.getClients.tag}", description = "${api.getClients.description}")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved clients")
    public ResponseEntity<?> getClients(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(value = Constants.AUTH_KEY,required = false) String authToken,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createDate") String sortByField,
            @RequestParam(value="desc/asc",required = false) String order,
            @RequestParam(value = "keyword", required = false) String keyword,
            @RequestParam(defaultValue = "ACTIVE") String filter) throws TrackerException {
        return clientService.getClients(page, size, requestDetails, sortByField, order,keyword,filter);
    }
    @GetMapping(Constants.CLIENT_BY_ID)
    @PreAuthorize(Authorities.CLIENT_READ)
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)},
            summary = "${api.getClient.tag}", description = "${api.getClient.description}")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved clients")
    public ResponseEntity<?> getClientById(@Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
                                           @RequestHeader(Constants.AUTH_KEY) String authToken,
                                           @PathVariable String clientId) throws TrackerException {
        return clientService.getClientsById(clientId, requestDetails);
    }

    @DeleteMapping(Constants.CLIENT_BY_ID)
    @PreAuthorize(Authorities.CLIENT_DELETE)
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)},summary = "${api.deleteClient.tag}", description = "${api.deleteClient.description}")
    @ApiResponse(responseCode = "200", description = "OK")
    public ResponseEntity<?> deleteClientById(@Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
                                              @RequestHeader(Constants.AUTH_KEY) String authToken,
                                              @PathVariable String clientId
    ) throws TrackerException {
        return clientService.deleteClientById(clientId, requestDetails);
    }

    @RequestMapping(value=Constants.CLIENT_UPDATE,method = RequestMethod.PATCH,consumes = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize(Authorities.CLIENT_WRITE)
    @Operation(security = {@SecurityRequirement(name = Constants.AUTH_KEY)},
            summary = "${api.updateClient.tag}", description = "${api.updateClient.description}")
    @ApiResponse(responseCode="202",description ="Accepted")
    public ResponseEntity<?> updateClientById(@Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
                                              @RequestHeader(Constants.AUTH_KEY) String authToken,
                                              @PathVariable String clientId,
                                              @RequestBody @Valid ClientUpdateRequest clientUpdateRequest) throws TrackerException, IOException {
        return clientService.updateClientById(clientId, clientUpdateRequest,  requestDetails);

    }
}