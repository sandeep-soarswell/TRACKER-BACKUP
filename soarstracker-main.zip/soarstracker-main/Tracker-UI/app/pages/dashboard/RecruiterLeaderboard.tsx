import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from "react-router";
import Card from '~/components/ui/Card';
import userService from '~/services/employee/employee.service';
import { Search, Trophy, Users, Target, TrendingUp, ChevronUp, ChevronDown, Crown, Medal, Award, Star, Zap, Flame as Fire, X } from 'lucide-react';

interface RecruiterScoreData {
  userId: string;
  totalPoints: number;
  distinctCandidates: number;
  averagePoints: number;
  hiredCandidates: number;
  hiredPercentage: number;
}

interface RecruiterScoreDetail {
  id: string;
  candidateId: string;
  points: number;
  eventType: string;
  createDate: string;
}

interface CandidateDetails {
  firstName: string;
  lastName: string;
  middleName: string | null;
  fullName: string;
  email: string;
  scores: RecruiterScoreDetail[];
}

interface Recruiter {
  id: string;
  name: string;
  score: number;
  placements: number;
  successRate: number;
  department: string;
  avatar: string;
  trend: 'up' | 'down' | 'stable';
  badges: string[];
}

const RecruiterLeaderboard: React.FC = () => {
  const [recruiters, setRecruiters] = useState<Recruiter[]>([]);
  const [filteredRecruiters, setFilteredRecruiters] = useState<Recruiter[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('All');
  const [isLoading, setIsLoading] = useState(true);
  const [departments, setDepartments] = useState<string[]>(['All']);
  const [selectedRecruiter, setSelectedRecruiter] = useState<Recruiter | null>(null);
  const [scoreDetails, setScoreDetails] = useState<Record<string, CandidateDetails> | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState<string | null>(null);
  const [isDetailsLoading, setIsDetailsLoading] = useState(false);
  const [detailsError, setDetailsError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRecruitersAndScores = async () => {
      setIsLoading(true);
      try {
        const userRes = await userService.getAll(0, 1000, 'recruiter');
        const users = userRes.data?.records || [];
        const scorePromises = users.map(async (user: any) => {
          try {
            const scoreRes = await userService.getRecruiterScore(user.id);
            const scoreData: RecruiterScoreData = scoreRes;
            return {
              id: user.id,
              name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || 'Unknown',
              score: Math.round(scoreData.averagePoints || 0),
              placements: scoreData.hiredCandidates || 0,
              successRate: Math.round(scoreData.hiredPercentage || 0),
              department: user.role || 'Unknown',
              avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(user.firstName + ' ' + user.lastName)}&background=random&size=128`,
              trend: 'stable',
              badges: scoreData.hiredPercentage > 80 ? ['Top Performer'] : [],
            };
          } catch (err) {
            return null;
          }
        });

        const recruiterData = (await Promise.all(scorePromises)).filter(Boolean) as Recruiter[];
        recruiterData.sort((a, b) => b.score - a.score);

        setRecruiters(recruiterData);
        setFilteredRecruiters(recruiterData);

        const uniqueDepts = ['All', ...new Set(recruiterData.map(r => r.department))];
        setDepartments(uniqueDepts);
      } catch (error) {
        console.error('Error fetching recruiters:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRecruitersAndScores();
  }, []);

  useEffect(() => {
    let filtered = recruiters.filter(r =>
      r.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (filterDepartment !== 'All') {
      filtered = filtered.filter(r => r.department === filterDepartment);
    }

    setFilteredRecruiters(filtered);
  }, [searchTerm, filterDepartment, recruiters]);

  const fetchScoreDetails = async (userId: string) => {
    setIsDetailsLoading(true);
    setDetailsError(null);
    try {
      const response = await userService.getRecruiterScoreDetails(userId);
      console.log('Score details response:', response);

      // Handle the ResponseBuilder wrapper structure
      let candidates;
      if (response && response.data && response.data.candidates) {
        // ResponseBuilder wraps data in response.data
        candidates = response.data.candidates;
      } else if (response && response.candidates) {
        // Direct response without wrapper
        candidates = response.candidates;
      } else {
        throw new Error('Invalid response structure: Candidates data is missing');
      }

      setScoreDetails(candidates);
      setSelectedRecruiter(recruiters.find(r => r.id === userId) || null);
    } catch (error) {
      console.error('Error fetching score details:', error);
      setDetailsError('Failed to load score details. Please try again.');
      setScoreDetails(null);
      setSelectedRecruiter(null);
    } finally {
      setIsDetailsLoading(false);
    }
  };

  const clearScores = async (userId: string) => {
    try {
      await userService.clearRecruiterScores(userId);
      // Refresh recruiter data after clearing scores
      const scoreRes = await userService.getRecruiterScore(userId);
      const scoreData: RecruiterScoreData = scoreRes;
      setRecruiters(prev =>
        prev.map(r =>
          r.id === userId
            ? {
              ...r,
              score: Math.round(scoreData.averagePoints || 0),
              placements: scoreData.hiredCandidates || 0,
              successRate: Math.round(scoreData.hiredPercentage || 0),
              badges: scoreData.hiredPercentage > 80 ? ['Top Performer'] : [],
            }
            : r
        ).sort((a, b) => b.score - a.score)
      );
      setFilteredRecruiters(prev =>
        prev.map(r =>
          r.id === userId
            ? {
              ...r,
              score: Math.round(scoreData.averagePoints || 0),
              placements: scoreData.hiredCandidates || 0,
              successRate: Math.round(scoreData.hiredPercentage || 0),
              badges: scoreData.hiredPercentage > 80 ? ['Top Performer'] : [],
            }
            : r
        ).sort((a, b) => b.score - a.score)
      );
      setShowClearConfirm(null);
      setScoreDetails(null);
      setSelectedRecruiter(null);
    } catch (error) {
      console.error('Error clearing scores:', error);
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <ChevronUp className="h-4 w-4 text-green-500" />;
      case 'down':
        return <ChevronDown className="h-4 w-4 text-red-500" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 95) return 'text-green-600 bg-green-100';
    if (score >= 85) return 'text-blue-600 bg-blue-100';
    if (score >= 75) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getPodiumPosition = (index: number) => {
    const positions = [
      { height: 'h-32', bg: 'from-yellow-400 via-yellow-500 to-yellow-600', icon: Crown, glow: 'shadow-yellow-500/50' },
      { height: 'h-24', bg: 'from-gray-300 via-gray-400 to-gray-500', icon: Medal, glow: 'shadow-gray-400/50' },
      { height: 'h-20', bg: 'from-orange-400 via-orange-500 to-orange-600', icon: Award, glow: 'shadow-orange-500/50' }
    ];
    return positions[index] || positions[2];
  };

  const topThree = filteredRecruiters.slice(0, 3);

  if (isLoading) {
    return <div className="flex items-center justify-center h-64 text-gray-500">Loading Leaderboard...</div>;
  }

  return (
    <Card className="h-auto min-h-[600px] bg-white text-gray-900">
      <div className="bg-[#0A2463] backdrop-blur-sm border-b border-white/10 p-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white rounded-xl shadow-lg">
              <Trophy className="h-8 w-8 text-yellow-400" />
            </div>
            <div>
              <h1 className="text-3xl text-white font-bold">Recruiter Champions</h1>
              <p className="text-yellow-200 mt-1">Elite performance leaderboard</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search champions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent w-full sm:w-64 text-white placeholder-gray-300"
              />
            </div>
            <select
              value={filterDepartment}
              onChange={(e) => setFilterDepartment(e.target.value)}
              className="px-4 py-2 bg-white rounded-lg border border-white/20 focus:ring-2 focus:ring-purple-500 focus:border-transparent text-white"
            >
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="p-8">
        {/* Champions Podium */}
        <div className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold mb-2 flex items-center justify-center gap-3">
              Hall of Champions
            </h2>
            <p className="text-blue-500">This month's elite performers</p>
          </div>

          <div className="flex items-end justify-center gap-8 mb-8">
            {topThree[1] && (
              <div className="flex flex-col items-center group">
                <div className="relative mb-4">
                  <img
                    src={topThree[1].avatar}
                    alt={topThree[1].name}
                    className="w-20 h-20 rounded-full object-cover ring-4 ring-gray-400 shadow-2xl group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute -top-2 -right-2 bg-gradient-to-r from-gray-300 to-gray-500 rounded-full p-2 shadow-lg">
                    <Medal className="h-6 w-6 text-white" />
                  </div>
                </div>
                <div className={`${getPodiumPosition(1).height} w-24 bg-gradient-to-t ${getPodiumPosition(1).bg} rounded-t-xl shadow-2xl ${getPodiumPosition(1).glow} flex flex-col items-center justify-center relative overflow-hidden group-hover:scale-105 transition-transform duration-300`}>
                  <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <span className="text-white font-bold text-2xl mb-1">2</span>
                  <span className="text-white/80 text-xs font-medium">SILVER</span>
                </div>
                <div className="mt-4 text-center">
                  <h3 className="font-bold text-lg">{topThree[1].name}</h3>
                  <p className="text-gray-300 text-sm">{topThree[1].department}</p>
                  <div className="flex items-center justify-center gap-1 mt-2">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span className="font-semibold">{topThree[1].score}</span>
                  </div>
                </div>
              </div>
            )}

            {topThree[0] && (
              <div className="flex flex-col items-center group">
                <div className="relative mb-4">
                  <img
                    src={topThree[0].avatar}
                    alt={topThree[0].name}
                    className="w-28 h-28 rounded-full object-cover ring-4 ring-yellow-400 shadow-2xl group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute -top-3 -right-3 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full p-3 shadow-lg animate-pulse">
                    <Crown className="h-8 w-8 text-white" />
                  </div>
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-yellow-400/20 to-transparent animate-ping" />
                </div>
                <div className={`${getPodiumPosition(0).height} w-28 bg-gradient-to-t ${getPodiumPosition(0).bg} rounded-t-xl shadow-2xl ${getPodiumPosition(0).glow} flex flex-col items-center justify-center relative overflow-hidden group-hover:scale-105 transition-transform duration-300`}>
                  <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <span className="text-white font-bold text-3xl mb-1">1</span>
                  <span className="text-white/90 text-sm font-bold">GOLD</span>
                </div>
                <div className="mt-4 text-center">
                  <h3 className="font-bold text-xl">{topThree[0].name}</h3>
                  <p className="text-gray-300">{topThree[0].department}</p>
                  <div className="flex items-center justify-center gap-1 mt-2">
                    <Star className="h-5 w-5 text-yellow-400" />
                    <span className="font-bold text-lg">{topThree[0].score}</span>
                  </div>
                </div>
              </div>
            )}

            {topThree[2] && (
              <div className="flex flex-col items-center group">
                <div className="relative mb-4">
                  <img
                    src={topThree[2].avatar}
                    alt={topThree[2].name}
                    className="w-18 h-18 rounded-full object-cover ring-4 ring-orange-400 shadow-2xl group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute -top-2 -right-2 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full p-2 shadow-lg">
                    <Award className="h-5 w-5 text-white" />
                  </div>
                </div>
                <div
                  className={`${getPodiumPosition(2).height} w-20 rounded-t-xl shadow-2xl flex flex-col items-center justify-center relative overflow-hidden group-hover:scale-105 transition-transform duration-300`}
                  style={{ background: '#0A2463' }}
                >
                  <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <span className="text-white font-bold text-xl mb-1">3</span>
                  <span className="text-white/80 text-xs font-medium">BRONZE</span>
                </div>
                <div className="mt-4 text-center">
                  <h3 className="font-bold">{topThree[2].name}</h3>
                  <p className="text-gray-300 text-sm">{topThree[2].department}</p>
                  <div className="flex items-center justify-center gap-1 mt-2">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span className="font-semibold">{topThree[2].score}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Full Leaderboard */}
        <div className="bg-white rounded-2xl border border-[#0A2463] overflow-hidden">
          <div className="px-6 py-4 border-b border-white bg-[#0A2463]">
            <h2 className="text-2xl text-white font-bold flex items-center gap-2">
              <Trophy className="h-6 w-6 text-yellow-400" />
              Complete Rankings
            </h2>
          </div>

          <div className="p-6">
            <div className="space-y-4">
              {filteredRecruiters.map((recruiter, index) => (
                <div
                  key={recruiter.id}
                  className="flex items-center gap-4 p-4 rounded-xl bg-white backdrop-blur-sm border border-white/10 hover:bg-blue-100 transition-all duration-300 group cursor-pointer"
                >
                  {/* Rank */}
                  <div className="flex-shrink-0">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm bg-blue-500 text-white shadow-lg shadow-blue-500/50 animate-pulse`}>
                      {index + 1}
                    </div>
                  </div>

                  {/* Avatar */}
                  <div className="flex-shrink-0">
                    <img
                      src={recruiter.avatar}
                      alt={recruiter.name}
                      className="w-12 h-12 rounded-full object-cover ring-2 ring-white/20 shadow-lg group-hover:ring-purple-400/50 transition-all duration-300"
                    />
                  </div>

                  {/* Info */}
                  <div className="flex-grow">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold">{recruiter.name}</h3>
                      {getTrendIcon(recruiter.trend)}
                    </div>
                    <p className="text-black-200 text-sm">{recruiter.department}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {recruiter.badges.map(badge => (
                        <span
                          key={badge}
                          className="px-2 py-1 text-xs font-medium bg-purple-500/20 text-white-200 rounded-full border border-purple-400/30"
                        >
                          {badge}
                        </span>
                      ))}
                    </div>
                    <div className="mt-2">
                      <button
                        onClick={() => fetchScoreDetails(recruiter.id)}
                        className="text-sm text-blue-500 hover:text-blue-700"
                      >
                        View Score Details
                      </button>
                      <button
                        onClick={() => setShowClearConfirm(recruiter.id)}
                        className="text-sm text-red-500 hover:text-red-700 ml-4"
                      >
                        Clear Scores
                      </button>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="flex-shrink-0 text-right">
                    <div
                      className="inline-flex items-center px-3 py-1 rounded-full text-sm font-bold"
                      style={{ color: "#0A2463", backgroundColor: "#eaf0fa", border: "1px solid #0A2463" }}
                    >
                      <Star className="h-4 w-4 mr-1" style={{ color: "#0A2463" }} />
                      {recruiter.score}
                    </div>
                    <div className="text-xs text-gray-400 mt-1">
                      {recruiter.placements} placements • {recruiter.successRate}% success
                    </div>
                  </div>
                </div>
              ))}

              {filteredRecruiters.length === 0 && (
                <div className="text-center text-gray-400 py-8">No recruiters found matching your criteria.</div>
              )}
            </div>
          </div>
        </div>

        {/* Score Details Modal */}
        {selectedRecruiter && scoreDetails && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl p-6 w-full max-w-2xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">{selectedRecruiter.name}'s Score Details</h2>
                <button onClick={() => {
                  setSelectedRecruiter(null);
                  setScoreDetails(null);
                  setDetailsError(null);
                }} className="text-gray-500 hover:text-gray-700">
                  <X className="h-6 w-6" />
                </button>
              </div>
              <div className="max-h-96 overflow-y-auto">
                {isDetailsLoading && (
                  <div className="text-center text-gray-500 py-8">Loading score details...</div>
                )}

                {detailsError && (
                  <div className="text-center text-red-500 py-8">{detailsError}</div>
                )}

                {!isDetailsLoading && !detailsError && scoreDetails && Object.keys(scoreDetails).length > 0 && (
                  Object.entries(scoreDetails).map(([candidateId, candidateDetails]) => (
                    <div key={candidateId} className="mb-4 p-4 bg-gray-50 rounded-lg">
                      <h3 className="font-semibold text-lg">{candidateDetails.fullName}</h3>
                      <p className="text-sm text-gray-600 mb-3">Email: {candidateDetails.email}</p>
                      <ul className="mt-2 space-y-2">
                        {candidateDetails.scores && Array.isArray(candidateDetails.scores) && candidateDetails.scores.length > 0 ? (
                          candidateDetails.scores.map((score: RecruiterScoreDetail) => (
                            <li key={score.id} className="flex justify-between items-center p-2 bg-white rounded border" style={{ minWidth: '300px' }}>
                              <span className="font-medium w-1/3 text-left">{score.eventType}</span>
                              <span className="text-blue-600 font-semibold w-1/3 text-center">{score.points} points</span>
                              <span className="text-gray-500 text-sm w-1/3 text-right">
                                {new Date(score.createDate).toLocaleDateString()}
                              </span>
                            </li>
                          ))
                        ) : (
                          <li className="text-gray-500 italic">No scores available for this candidate</li>
                        )}
                      </ul>
                    </div>
                  ))
                )}

                {!isDetailsLoading && !detailsError && (!scoreDetails || Object.keys(scoreDetails).length === 0) && (
                  <div className="text-center text-gray-500 py-8">No score details available.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Clear Scores Confirmation Dialog */}
        {showClearConfirm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl p-6 w-full max-w-md">
              <h2 className="text-xl font-bold mb-4">Confirm Clear Scores</h2>
              <p className="mb-4">Are you sure you want to clear all scores for {recruiters.find(r => r.id === showClearConfirm)?.name}?</p>
              <div className="flex justify-end gap-4">
                <button
                  onClick={() => setShowClearConfirm(null)}
                  className="px-4 py-2 bg-gray-200 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={() => clearScores(showClearConfirm)}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg"
                >
                  Clear Scores
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default RecruiterLeaderboard;