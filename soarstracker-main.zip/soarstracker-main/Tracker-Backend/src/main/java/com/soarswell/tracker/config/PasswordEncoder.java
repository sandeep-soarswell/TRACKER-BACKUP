package com.soarswell.tracker.config;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class PasswordEncoder {

    private static final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

    public String encode(final String rawPassword) {
        if(StringUtils.isNotBlank(rawPassword)) {
            return encoder.encode(rawPassword);
        }
        return rawPassword;
    };

    public BCryptPasswordEncoder encoder(){
        return encoder;
    }
}

