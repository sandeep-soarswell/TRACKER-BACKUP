package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventRequest {
    @NotBlank(message = "{event.title.not.blank}")
    @Size(max = 255, message = "{event.title.size}")
    @Schema(example = "Interview with candidate")
    private String title;

    @Size(max = 500, message = "{event.description.size}")
    @Schema(example = "Discuss the candidate's qualifications and experience")
    private String description;

    @NotNull(message = "{event.date.not.null}")
    @Schema(example = "2023-10-01")
    @FutureOrPresent(message = "{event.date.future.or.present}")
    private LocalDate date;

    @NotNull(message = "{event.startTime.not.null}")
    @Schema(example = "10:00:00")
    private LocalTime startTime;

    @NotNull(message = "{event.endTime.not.null}")
    @Schema(example = "11:00:00")
    private LocalTime endTime;

    @AssertTrue(message = "{event.endTime.after.startTime}")
    @Schema(hidden = true)
    public boolean isEndTimeAfterStartTime() {
        return startTime != null && endTime != null && endTime.isAfter(startTime);
    }
}
