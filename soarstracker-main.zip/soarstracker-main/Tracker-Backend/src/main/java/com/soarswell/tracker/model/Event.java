package com.soarswell.tracker.model;
import com.soarswell.tracker.persistance.AbstractEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import java.time.LocalDate;
import java.time.LocalTime;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Entity
@Table(name = "Event")
public class Event extends AbstractEntity{
    private String title;
    @Column(columnDefinition = "varchar(500)")
    private String description;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private String candidateId;
    private String jobId;
    @Builder.Default
    private boolean notificationSent = false;
    @Builder.Default
    private boolean isRead=false;

    public boolean getIsRead() {
        return this.isRead;
    }

    private String companyId;
}