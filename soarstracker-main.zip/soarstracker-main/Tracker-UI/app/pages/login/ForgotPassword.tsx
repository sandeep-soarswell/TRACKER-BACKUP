import React, { useState, useEffect } from 'react';
import { MailIcon } from '~/components/ui/Icons';
import AuthHeader from '~/components/layout/AuthHeader';
import SplitCardLayout from '~/components/layout/SplitCardLayout';
import authService from '~/services/login/login.services';
import { useNavigate, Link } from 'react-router';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import CustomOtpInput from '~/components/layout/customotp';

const ForgotPassword: React.FC = () => {
  const [email, setEmail] = useState('');
  const [emailTouched, setEmailTouched] = useState(false);
  const [emailError, setEmailError] = useState('');
  const [loading, setLoading] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [alertSeverity, setAlertSeverity] = useState<'success' | 'error'>('success');
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');
  const [otpError, setOtpError] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const navigate = useNavigate();

  const handleSnackbarClose = () => setOpenSnackbar(false);

  const showAlert = (message: string, severity: 'success' | 'error') => {
    setAlertMessage(message);
    setAlertSeverity(severity);
    setOpenSnackbar(true);
  };

  const validateEmail = (value: string) => {
    if (!value.trim()) return 'Please enter a valid email address.';
    if (!/\S+@\S+\.\S+/.test(value)) return 'Please enter a valid email address.';
    return '';
  };

  useEffect(() => {
    if (emailTouched) {
      const error = validateEmail(email);
      setEmailError(error);
    }
  }, [email, emailTouched]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendCooldown > 0) {
      timer = setInterval(() => {
        setResendCooldown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [resendCooldown]);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const error = validateEmail(email);
    setEmailError(error);
    if (error) {
      return;
    }
    setLoading(true);
    try {
      const response = await authService.forgotPassword(email);
      const { data } = response;
      if (response.message.toLowerCase() === 'success') {
        setOtpSent(true);
        setResendCooldown(30);
        showAlert('OTP sent to your email.', 'success');
      } else {
        const backendMsg = response?.error?.message || data?.message || 'Failed to send OTP.';
        throw new Error(backendMsg);
      }
    } catch (error: any) {
      const backendMsg =
        error?.response?.data?.error?.message || error?.response?.data?.message || error?.message;
      showAlert(backendMsg || 'Server error while sending OTP.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp.trim()) {
      setOtpError('Please enter the OTP.');
      return;
    }
    setLoading(true);
    try {
      const response = await authService.validateOtp(email, otp);
      localStorage.setItem('userToken', response.data.token);
      if (response.message.toLowerCase() === 'success') {
        navigate('/reset-password', { state: { email } });
      } else {
        const backendMsg = response?.error?.message || response?.data?.message || 'Invalid OTP.';
        throw new Error(backendMsg);
      }
    } catch (error: any) {
      const backendMsg =
        error?.response?.data?.error?.message || error?.response?.data?.message || error?.message;
      showAlert(backendMsg || 'Failed to verify OTP.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    if (resendCooldown > 0) {
      showAlert(`Please wait ${resendCooldown} seconds before resending OTP.`, 'error');
      return;
    }
    setLoading(true);
    try {
      const response = await authService.resendOtp(email);
      const { data } = response;
      if (response.message.toLowerCase() === 'success') {
        setOtp('');
        setOtpError('');
        setResendCooldown(30);
        showAlert('OTP resent to your email.', 'success');
      } else {
        const backendMsg = response?.error?.message || data?.message || 'Failed to resend OTP.';
        throw new Error(backendMsg);
      }
    } catch (error: any) {
      const backendMsg =
        error?.response?.data?.error?.message || error?.response?.data?.message || error?.message;
      showAlert(backendMsg || 'Failed to resend OTP.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const isEmailValid = !validateEmail(email);

  return (
    <SplitCardLayout>
      <form
        onSubmit={otpSent ? handleVerifyOtp : handleSendOtp}
        className="bg-white p-10 rounded-xl shadow-lg w-full max-w-[400px] flex flex-col"
        noValidate
      >
        <AuthHeader subtext="Reset your password below" />
        {!otpSent && (
          <div className="relative mb-2">
            <label htmlFor="email" className="block mb-1 text-sm text-gray-700">
              Email address
            </label>
            <MailIcon
              className="absolute left-3 top-11 transform -translate-y-1/2 text-gray-500"
              sx={{ fontSize: 18 }}
            />
            <input
              id="email"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value.trim())}
              onBlur={() => setEmailTouched(true)}
              disabled={otpSent}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 bg-[#fafafa] text-[16px] focus:outline-none focus:ring-2 focus:ring-[#3E92CC]"
            />
            {emailError && <p className="text-red-600 text-xs mt-1">{emailError}</p>}
          </div>
        )}
        {otpSent && (
          <div className="mb-5 mt-4 w-full">
            <p className="block mb-2 text-sm text-gray-700">Enter the OTP sent to {email}</p>
            <CustomOtpInput
              value={otp}
              onChange={(val: string) => {
                setOtp(val);
                if (otpError && val.trim()) setOtpError('');
              }}
              length={6}
              autoFocus
            />

            {otpError && <p className="text-red-600 text-xs mt-1">{otpError}</p>}
          </div>
        )}
        <button
          type="submit"
          disabled={loading}
          className={`w-full mt-4 py-2 px-4 text-white rounded-md cursor-pointer font-medium text-sm shadow-md transition-all duration-300 bg-[#0A2463] hover:bg-[#081c4e] focus:ring-2 focus:ring-[#3E92CC] ${loading ? 'opacity-60' : ''}`}
        >
          {loading ? 'Please wait...' : otpSent ? 'Validate OTP' : 'Send OTP'}
        </button>
        <div className="w-full flex justify-between mt-2 gap-3 items-center">
          <Link
            to="/"
            className="text-blue-500 text-sm hover:underline font-bold cursor-pointer"
          >
            Back to Login
          </Link>
          {otpSent && (
            <div className="flex flex-col items-end">
              <button
                type="button"
                onClick={handleResendOtp}
                disabled={loading || resendCooldown > 0}
                className={`text-sm font-bold py-2 cursor-pointer ${loading || resendCooldown > 0
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-blue-500 hover:underline'
                  }`}
              >
                {resendCooldown > 0 ? `Resend OTP in ${resendCooldown}s` : 'Resend OTP'}
              </button>
            </div>
          )}
        </div>
      </form>
      <CustomSnackbar
        open={openSnackbar}
        message={alertMessage}
        severity={alertSeverity}
        onClose={handleSnackbarClose}
      />
    </SplitCardLayout>
  );
};

export default ForgotPassword;