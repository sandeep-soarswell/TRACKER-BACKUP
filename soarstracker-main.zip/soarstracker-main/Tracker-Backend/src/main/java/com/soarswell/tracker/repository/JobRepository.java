package com.soarswell.tracker.repository;

import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.Job;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;
import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<Job, String> {
    public Optional<Job> findByIdAndCompanyIdAndStatus(String Id,String companyId,String status) throws TrackerException;
    public Page<Job> findByCompanyIdAndStatus(String companyId, String status, Pageable pageable) throws TrackerException;
    @Query("SELECT j FROM Job j WHERE j.companyId = :companyId AND j.status = :status AND (" +
            "LOWER(j.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.description) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.location) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.skills) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(j.salary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "CAST(j.openings AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "CAST(j.deadline AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(j.clientId) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.experience) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.jobId) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.contactPersonName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.contactPersonEmail) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.contactPersonPhone) LIKE LOWER(CONCAT('%',:keyword,'%'))" +
            ")")
    public Page<Job> searchAllFieldsByCompanyIdAndStatus(@Param("companyId") String companyId,
                                                         @Param("status") String status,
                                                         @Param("keyword") String keyword,
                                                         Pageable pageable) throws TrackerException;

    @Query("SELECT j FROM Job j WHERE j.companyId = :companyId AND j.clientId = :clientId AND j.status = :status AND (" +
            "LOWER(j.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.description) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.location) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.skills) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "CAST(j.salary AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "CAST(j.openings AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "CAST(j.deadline AS string) LIKE CONCAT('%', :keyword, '%') OR " +
            "LOWER(j.experience) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.jobId) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.contactPersonName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.contactPersonEmail) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(j.contactPersonPhone) LIKE LOWER(CONCAT('%', :keyword, '%'))" +
            ")")
    public Page<Job> searchAllFieldsByCompanyIdAndClientIdAndStatus(@Param("companyId") String companyId,
                                                             @Param("clientId") String clientId,
                                                             @Param("status") String status,
                                                             @Param("keyword") String keyword,
                                                             Pageable pageable) throws TrackerException;

    @Modifying
    @Transactional
    @Query("UPDATE Job j SET j.status = :status WHERE j.companyId = :companyId AND j.clientId = :clientId AND j IN :jobs")
    public void updateJobStatusForJobs(@Param("companyId") String companyId,
                                @Param("clientId") String clientId,
                                @Param("status") String status,
                                @Param("jobs") List<Job> jobs) throws TrackerException;

    public Page<Job> findByCompanyIdAndClientIdAndStatus(String companyId, String clientId, String status, Pageable pageable) throws TrackerException;
    public List<Job> findByCompanyIdAndClientIdAndStatus(String companyId, String clientId, String status) throws TrackerException;
    public List<Job> findByCompanyIdAndStatus(String companyId, String status) throws TrackerException;
    public boolean existsByCompanyIdAndClientIdAndJobId(String companyId, String clientId, String jobId) throws TrackerException;
    public List<Job> findByDeadline(LocalDate date) throws TrackerException;
    public boolean existsByJobId(String jobId) throws TrackerException;
}