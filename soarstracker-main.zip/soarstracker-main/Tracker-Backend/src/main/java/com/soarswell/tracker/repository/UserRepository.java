package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, String> {

    public Optional<User> findByIdAndCompanyIdAndStatusIn(String id, String companyId,List<String> statuses);

    public Optional<User> findByIdAndCompanyId(String id, String companyId);

    public boolean existsByEmail(String email);

    public boolean existsByPhoneNumber(String phoneNumber);


    public Optional<User> findByIdAndStatusIn(String id,List<String> statuses);

    public Page<User> findByCompanyIdAndStatusIn(String companyId, List<String> statuses, Pageable pageable);

    public Optional<User> findByEmail(String email);

    public Page<User> findByCompanyIdAndRoleAndStatusIn(String companyId, String role, List<String> statuses, Pageable pageable);

    @Query("SELECT u FROM User u WHERE u.companyId = :companyId " +
            "AND u.status IN :statuses " +
            "AND (" +
            "LOWER(TRIM(REPLACE(CONCAT(u.firstName, ' ', COALESCE(u.middleName, ''), ' ', u.lastName), '  ', ' '))) LIKE LOWER(CONCAT('%', REPLACE(:keyword, '  ', ' '), '%'))" +
            "OR LOWER(u.email) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
            "OR LOWER(u.phoneNumber) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
            "OR LOWER(u.companyName) LIKE LOWER(CONCAT('%', :keyword, '%')))")

    public Page<User> searchAllFieldsByCompanyIdAndStatusIn(
            @Param("companyId") String companyId,
            @Param("statuses") List<String> statuses,
            @Param("keyword") String keyword,
            Pageable pageable
    );

    @Query("SELECT u FROM User u WHERE u.companyId = :companyId AND u.role = :role AND u.status IN :statuses AND (" +
            "LOWER(TRIM(REPLACE(CONCAT(u.firstName, ' ', COALESCE(u.middleName, ''), ' ', u.lastName), '  ', ' '))) LIKE LOWER(CONCAT('%', REPLACE(:keyword, '  ', ' '), '%')) OR " +
            "LOWER(u.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(u.phoneNumber) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(u.companyName) LIKE LOWER(CONCAT('%', :keyword, '%'))" +
            ")")
    public Page<User> searchAllFieldsByCompanyIdAndRoleAndStatusIn(
            @Param("companyId") String companyId,
            @Param("role") String role,
            @Param("statuses") List<String> statuses,
            @Param("keyword") String keyword,
            Pageable pageable
    );

    public Page<User> findByStatusAndCompanyId(String status, String companyId, Pageable pageable);

    public Page<User> findByRoleAndStatusAndCompanyId(String role, String status, String companyId, Pageable pageable);
}
