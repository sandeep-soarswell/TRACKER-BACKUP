import React from "react";

interface DrawerLayoutProps {
  title: string;
  onClose: () => void;
  children?: React.ReactNode;
  footer?: React.ReactNode;
}
const DrawerLayout: React.FC<DrawerLayoutProps> = ({
  title,
  onClose,
  children,
  footer,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 ">
      <div className="bg-white rounded-lg shadow-xl w-full mx-4 sm:mx-6 md:mx-8 lg:mx-auto 
                        max-w-full sm:max-w-xl md:max-w-2xl lg:max-w-3xl 
                        max-h-[90vh] flex flex-col overflow-hidden">
        <div
          className="relative w-full"
          style={{
            backgroundColor: "#0A2463",
            borderTopLeftRadius: "0.5rem",
            borderTopRightRadius: "0.5rem",
          }}
        >
          <h2 className="text-xl md:text-2xl font-bold text-white text-center py-4">
            {title}
          </h2>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white hover:text-gray-200 text-2xl font-bold focus:outline-none cursor-pointer"
            aria-label="Close"
            style={{ right: 20, top: 16 }}
          >
            ×
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-4">{children}</div>
        {footer && (
          <div className="flex justify-end px-8 pb-8">{footer}</div>
        )}
      </div>
    </div>
  );
};
export default DrawerLayout;
