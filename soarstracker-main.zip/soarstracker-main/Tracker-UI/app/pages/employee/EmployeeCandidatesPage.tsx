import React, { useEffect, useState, useMemo } from "react";
import { DataGrid } from '@mui/x-data-grid';
import { HomeIcon } from "~/components/ui/Icons";
import Card from "~/components/ui/Card";
import { Typography } from '@mui/material';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import jobService from '~/services/job/job.services';
import type { Candidate } from '~/pages/types/types';
import { useLocation, useNavigate } from 'react-router';

interface TableRow {
  id: string;
  sno: number;
  fullName: string;
  experience: string;
  skills: string;
  candidateStatus: string;
  email: string;
}

const InfoBox: React.FC<{ label: string; value?: string }> = ({ label, value }) => (
  <div className="rounded-md w-full">
    <Typography variant="subtitle2" className="text-blue-100 text-sm mb-1">
      {label}
    </Typography>
    <Typography variant="body1" className="text-white font-medium">
      {value || 'N/A'}
    </Typography>
  </div>
);

const CandidateHeader: React.FC<{ clientName: string; jobTitle: string; candidates: Candidate[] }> = ({
  clientName,
  jobTitle,
  candidates,
}) => {
  const candidateCount = candidates.length;
  return (
    <div className="rounded-lg overflow-hidden transition-all duration-300">
      <div className="bg-gradient-to-r from-[#0A2463] to-[#0A2463] p-6 text-white">
        <div className="grid grid-cols-1 sm:grid-cols-3">
          <InfoBox label="Client Name" value={clientName} />
          <InfoBox label="Job Title" value={jobTitle} />
          <InfoBox label="Number of Candidates" value={candidateCount.toString()} />
        </div>
      </div>
    </div>
  );
};

const EmployeeCandidatesPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { clientName = 'N/A', jobTitle = 'N/A', jobId = '', userId = '' } = location.state || {};
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [displayClientName, setDisplayClientName] = useState(clientName);
  const [displayJobTitle, setDisplayJobTitle] = useState(jobTitle);
  const [loading, setLoading] = useState(true);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");
  const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 10 });

  const showSnackbar = (message: string, severity: "success" | "error" = "success") => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  };

  const fetchCandidates = async () => {
    if (!jobId) {
      showSnackbar("No job ID provided.", "error");
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const candidatesData = await jobService.getAssignedCandidates(jobId);
      const candidatesList = Array.isArray(candidatesData?.data) ? candidatesData.data : [];
      const matchedCandidates = userId
        ? candidatesList.filter((candidate: Candidate) => candidate.userId === userId)
        : candidatesList;
      setCandidates(matchedCandidates);
      setDisplayClientName(matchedCandidates.length > 0 ? matchedCandidates[0].clientName || clientName : clientName);
      setDisplayJobTitle(matchedCandidates.length > 0 ? matchedCandidates[0].jobTitle || jobTitle : jobTitle);
    } catch (err: any) {
      const errorMsg = err?.response?.data?.error?.message || 'Failed to load candidates';
      setCandidates([]);
      setDisplayClientName(clientName);
      setDisplayJobTitle(jobTitle);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCandidates();
  }, [jobId, userId]);

  const rows: TableRow[] = useMemo(() => {
    return candidates.map((candidate, index) => ({
      id: candidate.id,
      sno: index + 1,
      fullName: `${candidate.firstName || ''} ${candidate.middleName || ''} ${candidate.lastName || ''}`.trim(),
      experience: candidate.experience || 'N/A',
      skills: Array.isArray(candidate.skills) ? candidate.skills.join(', ') : candidate.skills || 'N/A',
      candidateStatus: candidate.candidatureStatus || 'N/A',
      email: candidate.email || 'N/A',
    }));
  }, [candidates]);

  if (loading) {
    return (
      <div className="h-[calc(100vh-100px)]">
        <div className="max-w-7xl mx-auto p-4">
          <div className="rounded-lg overflow-hidden bg-[#0A2463] p-6">
            <div className="animate-pulse">
              <div className="h-8 w-48 bg-blue-200 rounded mb-4" />
              <div className="h-5 w-32 bg-blue-200 rounded mb-2" />
              <div className="h-5 w-48 bg-blue-200 rounded" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-100px)]">
      <CustomSnackbar
        open={snackbarOpen}
        message={snackbarMessage}
        severity={snackbarSeverity}
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={3000}
      />
      <div className="flex items-center">
        <div className="flex items-center text-sm text-gray-600">
          <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
          <span
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors cursor-pointer"
            onClick={() => navigate('/dashboard')}
          >
            Dashboard
          </span>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="flex items-center text-sm text-gray-600">
          <span
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors cursor-pointer"
            onClick={() => navigate('/dashboard/users')}
          >
            Employees
          </span>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="flex items-center text-sm text-gray-600">
          <span
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors cursor-pointer"
            onClick={() => navigate('/dashboard/employee/assignes', { state: { id: userId } })}
          >
            Employee Assignees
          </span>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="text-sm text-gray-600">Employee Candidates</div>
      </div>
      <div className="flex justify-between items-center mt-2 mb-4">
        <h1 className="text-2xl font-bold text-gray-900">
          Job Candidates
        </h1>
      </div>
      <CandidateHeader clientName={displayClientName} jobTitle={displayJobTitle} candidates={candidates} />
      <div className="mt-4">
        {rows.length > 0 ? (
          <Card className="h-[calc(100vh-290px)] w-full">
            <DataGrid
              rows={rows}
              columns={[
                { field: 'sno', headerName: '#', flex: 0.3 },
                { field: 'fullName', headerName: 'Full Name', flex: 1.5 },
                { field: 'experience', headerName: 'Experience', flex: 1 },
                { field: 'skills', headerName: 'Skills', flex: 1.5 },
                { field: 'candidateStatus', headerName: 'Status', flex: 1 },
                { field: 'email', headerName: 'Email', flex: 1.5 },
              ]}
              pagination
              paginationMode="client"
              pageSizeOptions={[5, 10, 20, 50]}
              paginationModel={paginationModel}
              onPaginationModelChange={setPaginationModel}
              rowCount={rows.length}
              disableRowSelectionOnClick
              sx={{
                width: '100%',
                '& .MuiDataGrid-columnHeaders': { backgroundColor: '#f1f5f9 !important' },
                '& .MuiDataGrid-columnHeader': { backgroundColor: '#f1f1f1' },
                '& .MuiDataGrid-columnHeaderTitle': { fontWeight: 'bold', textTransform: 'uppercase' },
                '& .MuiDataGrid-row:hover': { backgroundColor: 'inherit' },
                '& .MuiDataGrid-main': { padding: 0 },
                '& .MuiDataGrid-footerContainer': { justifyContent: 'flex-end' },
              }}
            />
          </Card>
        ) : (
          <Card className="h-[calc(100vh-290px)] w-full flex items-center justify-center">
            <Typography variant="h6" color="textSecondary">
              There are no common candidates available for this job and employee
            </Typography>
          </Card>
        )}
      </div>
    </div>
  );
};

export default EmployeeCandidatesPage;