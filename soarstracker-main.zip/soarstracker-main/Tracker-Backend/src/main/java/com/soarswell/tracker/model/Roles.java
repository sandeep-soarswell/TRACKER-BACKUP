package com.soarswell.tracker.model;

import lombok.Getter;

@Getter
public enum Roles {

    SUPER_ADMIN("sys_admin","SYS_ADMIN"),
    COMPANY_ADMIN("company_admin","COMPANY_ADMIN"),
    MANAGER("manager","MANAGER"),
    RECRUITER("recruiter","RECRUITER");

    private final String shortLabel;
    private final String longLabel;

    private Roles(String shortLabel,String longLabel){
        this.shortLabel=shortLabel;
        this.longLabel=longLabel;
    }
}