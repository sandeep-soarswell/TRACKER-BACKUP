import React, { useEffect, useState, useCallback, useRef } from "react";
import { useLocation, useNavigate } from "react-router";
import Card from "~/components/ui/Card";
import TuneIcon from '@mui/icons-material/Tune';
import type { Job } from "~/pages/types/types";
import JobForm from "./Jobform";
import {
    AddIcon,
    DeleteIcon,
    VisibilityIcon,
    EditIcon,
    AssignmentIcon,
    SearchOutlinedIcon,
    HomeIcon,AssistantIcon,
    ArrowDropDownIcon,
} from '~/components/ui/Icons';
import { Snackbar, Alert, CircularProgress} from "@mui/material";
import { DataGrid } from '@mui/x-data-grid';
import jobService from "~/services/job/job.services";
import JobDetailsDrawer from "./Jobdetails";
import clientService from '~/services/client/client.services';
import userService from "~/services/employee/employee.service";
import CustomSnackbar from "~/components/ui/Customsnackbar";
import UploadJobModal from "./BulkJobs";
import CustomTooltip from '~/components/layout/tooltip';
import Modal from '~/components/ui/Modal';
import { type Candidate } from '~/pages/types/types';

interface Client {
    id: string;
    name: string;
}

const JobPage: React.FC = () => {
    const location = useLocation();
    const nav = useNavigate();
    const clientIdFromNav = location.state?.clientId || '';
    const clientNameFromNav = location.state?.clientName || '';
    const jobTitleFromNav = location.state?.jobTitle || '';
    const fromEmployeeAssignes = location.state?.fromEmployeeAssignes || false;
    const userId = location.state?.userId || '';
    const [jobs, setJobs] = useState<Job[]>([]);
    const [clients, setClients] = useState<Client[]>([]);
    const [selectedClientId, setSelectedClientId] = useState<string>(clientIdFromNav);
    const [loading, setLoading] = useState(false);
    const [clientsFetched, setClientsFetched] = useState(false);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [showUploadModal, setShowUploadModal] = useState(false);
    const [selectedJob, setSelectedJob] = useState<Job | null>(null);
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [viewMode, setViewMode] = useState<"view" | "edit" | "create" | null>(null);
    const [snackbarMessage, setSnackbarMessage] = useState("");
    const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");
    const [searchTerm, setSearchTerm] = useState<string>(jobTitleFromNav);
    const [debouncedSearchTerm, setDebouncedSearchTerm] = useState(searchTerm);
    const [currentPage, setCurrentPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [totalEntries, setTotalEntries] = useState(0);
    const [statusFilter, setStatusFilter] = useState("OPEN");
    const [showOptions, setShowOptions] = useState(false);
    const [showFilters, setShowFilters] = useState(!!clientNameFromNav);
    const dropdownOptionsRef = useRef<HTMLDivElement>(null);
    const dropdownFiltersRef = useRef<HTMLDivElement>(null);
    const token = localStorage.getItem("userToken");
    const decoded = token ? JSON.parse(atob(token.split('.')[1])) : null;
    const userIdFromToken = decoded?.userId || '';
    const role = decoded?.roles?.[0] || '';
    const username = decoded?.sub || '';
    const [matchingCandidates, setMatchingCandidates] = useState<Candidate[]>([]);
    const [showMatchingCandidatesModal, setShowMatchingCandidatesModal] = useState(false);


    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (
                (dropdownOptionsRef.current && !dropdownOptionsRef.current.contains(event.target as Node)) &&
                (dropdownFiltersRef.current && !dropdownFiltersRef.current.contains(event.target as Node))
            ) {
                setShowOptions(false);
            }
            if (dropdownFiltersRef.current && !dropdownFiltersRef.current.contains(event.target as Node)) {
                setShowFilters(false);
            }
        };


        if (showOptions || showFilters) {
            document.addEventListener('mousedown', handleClickOutside);
        } else {
            document.removeEventListener('mousedown', handleClickOutside);
        }

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [showOptions, showFilters]);

    const toggleOptions = () => setShowOptions((prev) => !prev);

    const fetchClients = async () => {
        try {
            const { content } = await clientService.getAll(0, 1000, "", "ACTIVE", "createDate", "desc");
            const clientList = content.map((client: any) => ({
                id: client.id,
                name: client.clientName,
            }));
            setClients(clientList);
            if (clientIdFromNav) {
                const match = clientList.find((client: Client) => client.id === clientIdFromNav);
                if (match) {
                    setSelectedClientId(clientIdFromNav);
                } else {
                    setSnackbarMessage(`Client with ID ${clientIdFromNav} not found`);
                    setSnackbarSeverity("error");
                    setSnackbarOpen(true);
                }
            } else if (clientNameFromNav) {
                const match = clientList.find((c: Client) => c.name === clientNameFromNav);
                if (match) {
                    setSelectedClientId(match.id);
                } else {
                    setSnackbarMessage(`Client ${clientNameFromNav} not found`);
                    setSnackbarSeverity("error");
                    setSnackbarOpen(true);
                }
            }
            setClientsFetched(true);
        } catch (err) {
            setClients([]);
            setSnackbarMessage("Failed to fetch clients");
            setSnackbarSeverity("error");
            setSnackbarOpen(true);
            setClientsFetched(true);
        }
    };

    const fetchJobs = useCallback(async () => {
        if (loading || !clientsFetched) return;
        setLoading(true);
        try {
            let combinedJobs: Job[] = [];
            let response;
            if (role === 'RECRUITER') {
                let assignedJobs: Job[] = [];
                try {
                    const recruiterJobResponse = await userService.getJobsByUserId(userIdFromToken, selectedClientId || '');
                    assignedJobs = recruiterJobResponse?.data?.records || [];
                } catch (error: any) {
                    showSnackbar(error?.response?.data?.error?.message || "Failed to fetch assigned jobs", "error");
                }
                const jobMap = new Map<string, Job>();
                assignedJobs.forEach((j) => {
                    if (j?.id) jobMap.set(String(j.id), j);
                });
                combinedJobs = Array.from(jobMap.values());
                setTotalEntries(combinedJobs.length);
            } else {
                response = await jobService.getAll({
                    page: currentPage,
                    size: rowsPerPage,
                    clientId: selectedClientId || '',
                    keyword: searchTerm,
                    filter: statusFilter,
                });
                combinedJobs = (response?.data?.data || []).filter((j: Job) => j && j.id);
                setTotalEntries(response?.data?.totalEntries || 0);
            }
            setJobs(combinedJobs);
        } catch (error: any) {
            let errorMessage = "Failed to fetch jobs.";
            if (error.response?.status === 401) {
                errorMessage = "Unauthorized: Please log in again.";
            } else if (
                error.response?.status === 404 &&
                (error.response?.data?.error?.message === "No jobs found" || error.response?.data?.message)
            ) {
                setJobs([]);
                setTotalEntries(0);
            } else if (error.code === "ERR_NETWORK") {
                errorMessage = "Network error: Check your connection or server.";
                nav("/");
            } else {
                errorMessage = error?.response?.data?.message || error?.response?.data?.error?.message || "Failed to fetch jobs.";
            }
            showSnackbar(errorMessage, "error");
        } finally {
            setLoading(false);
        }
    }, [currentPage, rowsPerPage, searchTerm, selectedClientId, statusFilter, role, userIdFromToken, nav, clientsFetched]);

    useEffect(() => {
        const loadData = async () => {
            await fetchClients();
            await fetchJobs();
        };
        loadData();
    }, [clientIdFromNav, clientNameFromNav, jobTitleFromNav, fetchJobs]);

    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedSearchTerm(searchTerm);
        }, 500);
        return () => {
            clearTimeout(handler);
        };
    }, [searchTerm]);

    useEffect(() => {
        fetchJobs();
    }, [fetchJobs, selectedClientId, debouncedSearchTerm]);

    const showSnackbar = (message: string, severity: "success" | "error" = "success") => {
        setSnackbarMessage(message);
        setSnackbarSeverity(severity);
        setSnackbarOpen(true);
    };

    const handleView = (job: Job) => {
        setSelectedJob(job);
        setViewMode("view");
        setIsDrawerOpen(true);
    };

    const handleEdit = (job: Job | null) => {
        setSelectedJob(job);
        setViewMode(job ? "edit" : "create");
        setIsDrawerOpen(true);
    };

    const closeDrawer = () => {
        setIsDrawerOpen(false);
        setSelectedJob(null);
        setViewMode(null);
    };

    const handleDelete = async () => {
        if (!selectedJob?.id) {
            showSnackbar("Invalid job ID.", "error");
            return;
        }
        try {
            const response = await jobService.delete(String(selectedJob.id));
            showSnackbar(response.message || "Job deleted successfully!", "success");
            fetchJobs();
            setShowModal(false);
            setSelectedJob(null);
        } catch (error) {
            showSnackbar("Failed to delete job.", "error");
        }
    };

    const handleAssignStatus = async (jobId: string) => {
        nav("/dashboard/jobs/assign-status", {
            state: { jobId },
        });
    };

    const handleUploadCSV = () => {
        setShowUploadModal(true);
        setShowOptions(false);
    };

    const handleJobMatching = async (jobId: string) => {
        try {
            setLoading(true);
            const response = await jobService.findMatchingCandidates(jobId);
            const candidatesWithScores = response.data.map((match: any) => ({
                ...match.candidate,
                suitabilityScore: match.suitabilityScore
            }));
            setMatchingCandidates(candidatesWithScores || []);
            setShowMatchingCandidatesModal(true);
        } catch (error) {
            showSnackbar("Failed to find matching candidates.", "error");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-[calc(100vh-100px)]">
            <CustomSnackbar
                open={snackbarOpen}
                message={snackbarMessage}
                severity={snackbarSeverity}
                onClose={() => setSnackbarOpen(false)}
            />
            <div className="flex items-center">
                <div className="flex items-center text-sm text-gray-600">
                    <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
                    <a href="/dashboard" className="text-blue-600 hover:text-blue-800 hover:underline transition-colors">
                        Dashboard
                    </a>
                </div>
                 <div className="flex items-center text-sm text-gray-600">
                    <span className="mx-2 text-gray-400">/</span>
                    <a href="/dashboard/clients" className="text-blue-600 hover:text-blue-800 hover:underline transition-colors">Clients</a>
                </div>
                <span className="mx-2 text-gray-400">/</span>
                {fromEmployeeAssignes && (
                    <>
                        <div className="flex items-center text-sm text-gray-600">
                            <span
                                className="text-blue-600 hover:text-blue-800 hover:underline transition-colors cursor-pointer"
                                onClick={() => nav('/dashboard/employee/assignes', { state: { id: userId } })}
                            >
                                Employee Assignees
                            </span>
                        </div>
                        <span className="mx-2 text-gray-400">/</span>
                    </>
                )}
                <div className="text-sm text-gray-600">Jobs</div>
            </div>
            <Snackbar
                open={snackbarOpen}
                autoHideDuration={5000}
                onClose={() => setSnackbarOpen(false)}
                anchorOrigin={{ vertical: "top", horizontal: "right" }}
            >
                <Alert onClose={() => setSnackbarOpen(false)} severity={snackbarSeverity} sx={{ width: "100%" }} variant="filled">
                    {snackbarMessage}
                </Alert>
            </Snackbar>
            <div className="flex justify-between items-center px-1 py-1">
                <h1 className="text-2xl font-bold text-gray-900">Job Management</h1>
                <div className="relative inline-block text-left" ref={dropdownOptionsRef}>
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            toggleOptions();
                        }}
                        className="flex items-center gap-2 font-bold rounded-lg mb-1 px-3.5 py-2 shadow transition cursor-pointer"
                        style={{
                            backgroundColor: "#0A2463",
                            color: "white",
                            letterSpacing: "0.5px",
                            fontSize: "1rem",
                        }}
                    >
                        Job Register
                        <ArrowDropDownIcon sx={{ fontSize: 18 }} />
                    </button>
                    {showOptions && (
                        <div className="absolute right-0 z-20 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg">
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    handleEdit(null);
                                }}
                                className="block w-full px-4 py-2 text-gray-800 font-semibold hover:bg-gray-100"
                            >
                                New Job
                            </button>
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    handleUploadCSV();
                                }}
                                className="block w-full px-4 py-2 text-gray-800 font-semibold hover:bg-gray-100 rounded-b-lg"
                            >
                                Upload CSV
                            </button>
                        </div>
                    )}
                </div>
            </div>
            <Card className="py-3 mb-4">
                <div className="flex flex-col md:flex-row gap-4">
                    <div className="relative w-full md:w-96">
                        <SearchOutlinedIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <input
                            type="text"
                            placeholder="Search by title, location, or skills..."
                            className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                            value={searchTerm}
                            onChange={(e) => {
                                setSearchTerm(e.target.value);
                                setCurrentPage(0);
                            }}
                        />
                    </div>
                    <div className="ml-auto relative" ref={dropdownFiltersRef}>
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                setShowFilters((prev) => !prev);
                            }}
                            className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-gray-200 cursor-pointer"
                            title="Filter"
                        >
                            <TuneIcon />
                        </button>
                        {showFilters && (
                            <div className="absolute z-10 right-0 mt-2 w-[260px] bg-white border border-gray-200 rounded-lg shadow-lg p-4 space-y-3">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Client</label>
                                    <select
                                        value={selectedClientId}
                                        onChange={(e) => {
                                            const newClientId = e.target.value;
                                            setSelectedClientId(newClientId);
                                            setCurrentPage(0);
                                        }}
                                        className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                    >
                                        <option value="">All Clients</option>
                                        {clients.map((client) => (
                                            <option key={client.id} value={client.id}>
                                                {client.name ?? 'Unknown'}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Status</label>
                                    <select
                                        value={statusFilter}
                                        onChange={(e) => {
                                            setStatusFilter(e.target.value);
                                            setCurrentPage(0);
                                        }}
                                        className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                    >
                                        <option value="OPEN">OPEN</option>
                                        <option value="CLOSED">CLOSED</option>
                                    </select>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </Card>
            {loading ? (
                <div className="flex justify-center items-center h-[300px]">
                    <CircularProgress color="primary" />
                </div>
            ) : (
                    <Card className="h-[calc(100vh-245px)] w-full">
                        <DataGrid
                            rows={jobs.map((job, index) => ({
                                id: job.id,
                                sno: (currentPage) * rowsPerPage + index + 1,
                                jobId: job.jobId,
                                title: job.title,
                                clientName: job.clientName,
                                experience: job.experience,
                                location: job.location,
                                salary: job.salary,
                                skills: job.skills,
                                job,
                            }))}
                            columns={[
                                { field: 'sno', headerName: '#', flex: 0.3 },
                                { field: 'jobId', headerName: 'Job ID', flex: 1 },
                                { field: 'title', headerName: 'Title', flex: 1.2 },
                                { field: 'clientName', headerName: 'Client', flex: 1 },
                                { field: 'experience', headerName: 'Experience', flex: 0.8 },
                                { field: 'location', headerName: 'Location', flex: 1 },
                                { field: 'salary', headerName: 'Salary', flex: 1, type: 'number', headerAlign: 'left', align: 'left' },
                                { field: 'skills', headerName: 'Skills Required', flex: 1.2 },
                                {
                                    field: 'actions',
                                    headerName: 'Actions',
                                    flex: 1.5,
                                    sortable: false,
                                    filterable: false,
                                    headerAlign: 'left',
                                    align: 'center',
                                    renderCell: (params) => (
                                        <div className="flex items-center gap-2">
                                            <CustomTooltip title="Job Matching">
                                                <button onClick={(e) => { e.stopPropagation(); handleJobMatching(String(params.row.id)) }}
                                                    className="p-1 rounded-full hover:bg-blue-100 transition cursor-pointer">
                                                    <AssistantIcon fontSize="small" className="text-blue-400 transition hover:scale-110" />
                                                </button>
                                            </CustomTooltip>
                                            <CustomTooltip title={statusFilter === 'CLOSED' ? 'Cannot be assigned because the job is closed' : 'Assign Status'}>
                                                <span>
                                                    <button
                                                        onClick={e => { e.stopPropagation(); handleAssignStatus(String(params.row.id)); }}
                                                        className={`p-1 rounded-full transition 
                                                            ${statusFilter === 'CLOSED'
                                                                ? 'text-gray-400 cursor-not-allowed'
                                                                : 'text-blue-500 hover:bg-blue-50 cursor-pointer'
                                                            }`}
                                                        disabled={statusFilter === 'CLOSED'}
                                                    >
                                                        <AssignmentIcon
                                                            fontSize="small"
                                                            className={`transition hover:scale-110 
                                                                ${statusFilter === 'CLOSED' ? 'text-gray-400' : 'text-blue-400'}`}
                                                        />
                                                    </button>
                                                </span>
                                            </CustomTooltip>
                                            <CustomTooltip title="View">
                                                <button
                                                    onClick={e => { e.stopPropagation(); handleView(params.row.job); }}
                                                    className="p-1 rounded-full hover:bg-blue-100 transition cursor-pointer"
                                                >
                                                    <VisibilityIcon fontSize="small" className="text-blue-400 transition hover:scale-110" />
                                                </button>
                                            </CustomTooltip>
                                            <CustomTooltip title={statusFilter === 'CLOSED' ? 'Cannot edit closed jobs' : 'Edit'}>
                                                <span>
                                                    <button
                                                        onClick={e => { e.stopPropagation(); handleEdit(params.row.job); }}
                                                        className={`p-1 rounded-full ${statusFilter === 'CLOSED' ? 'text-gray-400 cursor-not-allowed' : 'text-blue-500 hover:bg-blue-50 cursor-pointer'} transition`}
                                                        disabled={statusFilter === 'CLOSED'}
                                                    >
                                                        <EditIcon fontSize="small" className="text-blue-400 transition hover:scale-110" />
                                                    </button>
                                                </span>
                                            </CustomTooltip>
                                            <CustomTooltip title={statusFilter === 'CLOSED' ? 'Cannot delete closed jobs' : 'Delete'}>
                                                <span>
                                                    <button
                                                        onClick={e => {
                                                            e.stopPropagation();
                                                            setSelectedJob(params.row.job);
                                                            setShowModal(true);
                                                        }}
                                                        className={`p-1 rounded-full ${statusFilter === 'CLOSED' ? 'text-gray-400 cursor-not-allowed' : 'text-red-500 hover:bg-red-50 cursor-pointer'} transition`}
                                                        disabled={statusFilter === 'CLOSED'}
                                                    >
                                                        <DeleteIcon className="text-red-600 transition hover:scale-110" sx={{ fontSize: 18 }} />
                                                    </button>
                                                </span>
                                            </CustomTooltip>
                                        </div>
                                    ),
                                },
                            ]}
                            pagination
                            paginationMode="server"
                            rowCount={totalEntries}
                            pageSizeOptions={[5, 10, 15, 20, 50]}
                            paginationModel={{ page: currentPage, pageSize: rowsPerPage }}
                            onPaginationModelChange={({ page, pageSize }) => {
                                setCurrentPage(page);
                                setRowsPerPage(pageSize);
                            }}
                            disableRowSelectionOnClick
                            sx={{
                                height: '100%',
                                '& .MuiDataGrid-columnHeaders': { backgroundColor: '#f1f5f9 !important' },
                                '& .MuiDataGrid-columnHeader': { backgroundColor: '#f1f1f1' },
                                '& .MuiDataGrid-columnHeaderTitle': { fontWeight: 'bold', textTransform: 'uppercase' },
                                '& .MuiDataGrid-row:hover': { backgroundColor: 'inherit' },
                                '& .MuiDataGrid-main': { padding: 0 },
                                '& .MuiDataGrid-footerContainer': { justifyContent: 'flex-end' },
                            }}
                        />
                    </Card>
            )}
            {isDrawerOpen && viewMode === "view" && (
                <div className="z-[100]">
                    <JobDetailsDrawer
                        open={isDrawerOpen && viewMode === "view"}
                        onClose={closeDrawer}
                        job={selectedJob}
                    />
                </div>
            )}
            {isDrawerOpen && (viewMode === "edit" || viewMode === "create") && (
                <div className="z-[100]">
                    <JobForm
                        job={selectedJob ?? undefined}
                        onClose={closeDrawer}
                        onSuccess={() => {
                            fetchJobs();
                            closeDrawer();
                            showSnackbar(
                                viewMode === "edit" ? "Job updated successfully!" : "Job registered successfully!",
                                "success"
                            );
                        }}
                        clientId={selectedClientId || clientIdFromNav}
                    />
                </div>
            )}
            {showModal && selectedJob?.id && (
                <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
                    <div className="bg-white p-10 rounded-lg max-w-sm shadow-lg">
                        <h2 className="text-lg font-semibold text-center text-black mb-4">Confirm Delete</h2>
                        <p className="text-center mb-4">
                            Are you sure you want to delete <strong>{selectedJob.title}</strong>?
                        </p>
                        <div className="flex justify-center gap-4">
                            <button
                                onClick={handleDelete}
                                className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 cursor-pointer"
                            >
                                Yes, Delete
                            </button>
                            <button
                                onClick={() => {
                                    setShowModal(false);
                                    setSelectedJob(null);
                                }}
                                className="bg-gray-300 text-gray-700 px-4 py-2 rounded hover:bg-gray-400 cursor-pointer"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            )}
            {showUploadModal && (
                <div className="z-[100]">
                    <UploadJobModal
                        open={showUploadModal}
                        onClose={() => setShowUploadModal(false)}
                        onUploadSuccess={() => {
                            fetchJobs();
                            showSnackbar("Jobs uploaded successfully!", "success");
                        }}
                    />
                </div>
            )}
            <Modal
                open={showMatchingCandidatesModal}
                onClose={() => setShowMatchingCandidatesModal(false)}
                title="Matching Candidates"
            >
                <div className="p-4" style={{ minWidth: '400px', maxHeight: '500px', overflowY: 'auto' }}>
                    {loading ? (
                        <div className="flex justify-center items-center">
                            <CircularProgress />
                        </div>
                    ) : matchingCandidates.length > 0 ? (
                        <ul className="space-y-3">
                            {matchingCandidates.map((candidate: any) => (
                                <li key={candidate.id} className="p-3 border rounded-lg shadow-sm">
                                    <div className="flex justify-between items-center mb-1">
                                        <p className="font-bold text-lg text-gray-800">
                                            {candidate.firstName} {candidate.lastName}
                                        </p>
                                        <span className="text-sm font-semibold bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                                            {candidate.suitabilityScore}% Match
                                        </span>
                                    </div>
                                    <p className="text-sm text-gray-600">
                                        <span className="font-semibold">Email:</span> {candidate.email}
                                    </p>
                                    <p className="text-sm text-gray-600 break-words">
                                        <span className="font-semibold">Skills:</span> {candidate.skills}
                                    </p>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-center text-gray-500">No matching candidates found.</p>
                    )}
                </div>
            </Modal>
        </div>
    );
};

export default JobPage;