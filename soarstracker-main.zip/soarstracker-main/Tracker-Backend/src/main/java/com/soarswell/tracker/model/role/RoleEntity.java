package com.soarswell.tracker.model.role;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.soarswell.tracker.persistance.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * Entity for the Role
 */
@Getter
@Setter
@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleEntity extends AbstractEntity {

    @JsonIgnore public static final String NAME_PROPERTY            = "name";
    @JsonIgnore public static final String DESC_PROPERTY            = "desc";
    @JsonIgnore public static final String USAGE_PROPERTY           = "usage";
    @JsonIgnore public static final String CATEGORY_TYPE_PROPERTY   = "categoryType";
    @JsonIgnore public static final String PERMISSIONS_PROPERTY     = "permissions";
    @JsonIgnore public static final String STATUS_PROPERTY          = "status";

    @JsonProperty(NAME_PROPERTY)
    private String name;

    @JsonProperty(DESC_PROPERTY)
    private String desc;

    @JsonProperty(USAGE_PROPERTY)
    private String usage;

    @JsonProperty(CATEGORY_TYPE_PROPERTY)
    private String categoryType;

    @JsonProperty(PERMISSIONS_PROPERTY)
    private Collection<String> permissions;

    @JsonProperty(STATUS_PROPERTY)
    private String status;

    public void addPermission(final String permissionId) {
        if(permissions == null) {
            permissions = new ArrayList<>();
        }
        permissions.add(permissionId);
    }

}