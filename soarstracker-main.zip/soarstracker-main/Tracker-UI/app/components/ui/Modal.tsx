
import React from 'react';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
  className?: string;
}

const Modal: React.FC<ModalProps> = ({ open, onClose, children, title, className }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
      <div className={`bg-white rounded-lg shadow-xl max-w-lg w-full p-0 relative ${className || ''}`}>
        {title && (
          <div className="flex items-center justify-center bg-[#0A2463] rounded-t-lg px-6 py-4 mb-6 relative" style={{ minHeight: '56px' }}>
            <h2 className="text-white font-semibold text-xl m-0 w-full text-center">{title}</h2>
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 text-2xl cursor-pointer font-bold focus:outline-none absolute right-6 top-1/2 transform -translate-y-1/2"
              aria-label="Close"
              style={{ lineHeight: 1 }}
            >
              &times;
            </button>
          </div>
        )}
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
};

export default Modal;
