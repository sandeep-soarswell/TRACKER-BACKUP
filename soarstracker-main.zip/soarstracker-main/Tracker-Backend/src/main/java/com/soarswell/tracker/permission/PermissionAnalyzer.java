package com.soarswell.tracker.permission;

public class PermissionAnalyzer {
}
