package com.soarswell.tracker.controller;

import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.CompanyImageUpdate;
import com.soarswell.tracker.model.payload.CompanyRequest;
import com.soarswell.tracker.model.payload.CompanyResponse;
import com.soarswell.tracker.model.payload.CompanyUpdateRequest;
import com.soarswell.tracker.service.CompanyService;
import com.soarswell.tracker.springsecurity.Authorities;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.util.AuthTokenUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/company")
@Tag(name = "${api.company.tag}")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
@ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = Constants.API_RESPONSE_OK),
        @ApiResponse(responseCode = "400", description = Constants.API_RESPONSE_BAD_REQUEST,
                content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "401", description = Constants.API_RESPONSE_UNAUTHORIZED,
                content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "404", description = Constants.API_RESPONSE_NOT_FOUND,
                content = @Content(schema = @Schema(implementation = ResponseObject.class))),
        @ApiResponse(responseCode = "500", description = Constants.API_RESPONSE_ERROR,
                content = @Content(schema = @Schema(implementation = ResponseObject.class)))
})
public class CompanyController {
    @Autowired
    private CompanyService companyService;

    @Autowired
    private RequestDetails requestDetails;

    @Operation(
            summary = "${api.company.create.summary}",
            description = "${api.company.create.description}",
            security = {@SecurityRequirement(name = Constants.TRACKER_SECURITY_SCHEME)}
    )
    @PostMapping(consumes = Constants.MEDIA_TYPE_JSON)
    @PreAuthorize(Authorities.COMPANY_CREATE)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> createCompany(
            @Valid @RequestBody CompanyRequest request) {
        return companyService.createCompany(request,requestDetails);
    }

    @Operation(
            summary = "${api.company.getAll.summary}",
            description = "${api.company.getAll.description}",
            security = {@SecurityRequirement(name = Constants.TRACKER_SECURITY_SCHEME)}
    )
    @PreAuthorize(Authorities.COMPANY_LIST)
    @GetMapping
    @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
    public ResponseEntity<?> getAllCompanies(
            @Parameter(hidden = true, required = true, description = "${apiAuthToken.description}", example = "Bearer abcdef12-1234-1234-1234-abcdefabcdef")
            @RequestHeader(value = Constants.AUTH_KEY,required = false) String authToken  ,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createDate") String sortByField,
            @RequestParam(value="desc/asc",required = false) String order,
            @RequestParam(required = false) String keyword ) throws TrackerException {
        return companyService.getAllCompanies(page, size, requestDetails, sortByField, order,keyword);
    }

    @Operation(
            summary = "${api.company.getById.summary}",
            description = "${api.company.getById.description}",
            security = {@SecurityRequirement(name = Constants.TRACKER_SECURITY_SCHEME)}
    )
    @GetMapping("/{companyId}")
    @PreAuthorize(Authorities.COMPANY_READ)
    public ResponseEntity<ResponseObject<CompanyResponse>> getCompanyById(
            @Parameter(description = "${api.company.companyId.description}", required = true)
            @PathVariable String companyId) {
        return companyService.getCompanyById(companyId, requestDetails);
    }

    @Operation(
            summary = "${api.company.update.summary}",
            description = "${api.company.update.description}",
            security = {@SecurityRequirement(name = Constants.TRACKER_SECURITY_SCHEME)}
    )
    @PatchMapping(value = "/{companyId}", consumes = Constants.MEDIA_TYPE_JSON)
    @PreAuthorize(Authorities.COMPANY_WRITE)
    public ResponseEntity<ResponseObject<String>> updateCompany(
            @Parameter(description = "${api.company.companyId.description}", required = true)
            @PathVariable String companyId,
            @Valid @RequestBody CompanyUpdateRequest request) {
        return companyService.updateCompany(companyId, request, requestDetails);
    }

    @Operation(
            summary = "${api.company.updateImage.summary}",
            description = "${api.company.updateImage.description}",
            security = {@SecurityRequirement(name = Constants.TRACKER_SECURITY_SCHEME)}
    )
    @PatchMapping(value = "/{companyId}/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize(Authorities.COMPANY_WRITE)
    public ResponseEntity<ResponseObject<String>> updateCompanyImage(
            @Parameter(description = "${api.company.companyId.description}", required = true)
            @PathVariable String companyId,
            @ModelAttribute @Valid CompanyImageUpdate companyImageUpdate,
            @RequestPart(Constants.FILE) MultipartFile file) throws TrackerException, IOException {
        return companyService.updateCompanyImage(companyId, companyImageUpdate, file, requestDetails);
    }

    @Operation(
            summary = "${api.company.getCompanyImage.summary}",
            description = "${api.company.getCompanyImage.description}",
            security = {@SecurityRequirement(name = Constants.TRACKER_SECURITY_SCHEME)}
    )
    @GetMapping("/{companyId}/image")
    @PreAuthorize(Authorities.COMPANY_WRITE)
    public ResponseEntity<?> getCompanyImage(@Parameter(description = "${api.company.companyId.description}", required = true) @PathVariable String companyId,
                                             HttpServletRequest request) throws TrackerException {
        return companyService.getCompanyImage(companyId, request, requestDetails);
    }
}

