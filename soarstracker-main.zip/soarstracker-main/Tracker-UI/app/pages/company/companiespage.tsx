import React, { useEffect, useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { useNavigate } from "react-router";
import { AddIcon, SearchIcon, VisibilityIcon, EditIcon, UploadFileIcon, HomeIcon } from '~/components/ui/Icons';
import Card from '~/components/ui/Card';
import companyService from '~/services/company/company.service';
import type { CompanyType } from '~/pages/types/types';
import CompanyRegistrationPage from './CompanyRegistrationPage';
import CompanyDetailsDrawer from './CompanyDetail';
import DrawerLayout from '~/components/layout/DrawerLayout';
import * as XLSX from 'xlsx';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import CustomTooltip from '~/components/layout/tooltip';


const CompaniesPage: React.FC = () => {
  const [companies, setCompanies] = useState<CompanyType[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSeverity, setAlertSeverity] = useState<'success' | 'error'>('success');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<CompanyType | null>(null);
  const [isUploadDrawerOpen, setIsUploadDrawerOpen] = useState(false);
  const [selectedCompanyForUpload, setSelectedCompanyForUpload] = useState<CompanyType | null>(null);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [existingImageUrl, setExistingImageUrl] = useState<string | null>(null);
  const [totalEntries, setTotalEntries] = useState(0);
  const [isViewDrawerOpen, setIsViewDrawerOpen] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const navigate = useNavigate(); 

  const fetchCompanies = async () => {
    setSearchError(null);
    setLoading(true);
    try {
      const response = await companyService.getAll(
        currentPage - 1,
        rowsPerPage,
        searchTerm,
        'createDate',
        'desc'
      );
      const companiesArray: CompanyType[] = response.content || [];
      const total: number = response.totalElements || 0;
      const validCompanies = companiesArray.filter(
        (company): company is CompanyType =>
          company &&
          typeof company === 'object' &&
          'id' in company &&
          'companyName' in company
      );
      setCompanies(validCompanies);
      setTotalEntries(total);
    } catch (error: any) {
      let errorMessage = 'Failed to fetch companies.';
      if (error.response?.status === 401) {
        errorMessage = 'Unauthorized: Please log in again.';
      } else if (
        error.response?.status === 404 &&
        error.response?.data?.error?.message === 'No companies found under provided criteria'
      ) {
        setSearchError(error.response.data.error.message);
        setCompanies([]);
        setTotalEntries(0);
      } else if (error.code === 'ERR_NETWORK') {
        errorMessage = 'Network error: Check your connection or server status.';
        navigate("/");
      } else {
        errorMessage =
          error?.response?.data?.message ||
          error?.response?.data?.error ||
          'Failed to fetch companies.';
      }
      showSnackbar(errorMessage, 'error');
      setCompanies([]);
      setTotalEntries(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCompanies();
  }, [currentPage, rowsPerPage, searchTerm, statusFilter]);

  const showSnackbar = (message: string, severity: 'success' | 'error' = 'success') => {
    setAlertMessage(message);
    setAlertSeverity(severity);
    setOpenSnackbar(true);
  };

  const handleEdit = (company: CompanyType | null) => {
    setSelectedCompany(company);
    setIsEditMode(!!company);
    setIsDrawerOpen(true);
  };

  const handleViewDetails = (company: CompanyType) => {
    setSelectedCompany(company);
    setIsViewDrawerOpen(true);
  };

  const closeViewDrawer = () => {
    setIsViewDrawerOpen(false);
    setSelectedCompany(null);
  };

  const handleUpload = async (company: CompanyType) => {
    setSelectedCompanyForUpload(company);
    setIsUploadDrawerOpen(true);
    const hasImage = company.imageFile && company.id;
    if (hasImage) {
      try {
        const token = localStorage.getItem('userToken');
        if (token) {
          const imageUrl = await companyService.getCompanyImage(company.id, token);
          setExistingImageUrl(imageUrl);
        }
      } catch (error) {
        setExistingImageUrl(null);
      }
    } else {
      setExistingImageUrl(null);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleImageUpload = async () => {
    if (!selectedFile || !selectedCompanyForUpload?.id) return;
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    if (!allowedTypes.includes(selectedFile.type)) {
      showSnackbar('Please upload a valid image file (JPEG, PNG)', 'error');
      return;
    }
    const maxSize = 2 * 1024 * 1024; // 2MB
    if (selectedFile.size > maxSize) {
      showSnackbar('Image size should be less than 2MB', 'error');
      return;
    }
    const formData = new FormData();
    formData.append('file', selectedFile);
    try {
      setUploadLoading(true);
      let res = await companyService.uploadImage(selectedCompanyForUpload.id, formData);
      console.log('Upload response:', res);
      showSnackbar(res, 'success');
      fetchCompanies();
      setIsUploadDrawerOpen(false);
      setSelectedFile(null);
      setPreviewUrl(null);
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message ||
        error?.response?.data?.error ||
        'Failed to upload image. Please try again.';
      showSnackbar(errorMessage, 'error');
    } finally {
      setUploadLoading(false);
    }
  };

  const handleCloseUploadDrawer = () => {
    setIsUploadDrawerOpen(false);
    setSelectedFile(null);
    setPreviewUrl(null);
  };

  const handleFormSuccess = () => {
    fetchCompanies();
    setTimeout(() => {
      setIsDrawerOpen(false);
      setIsEditMode(false);
      setSelectedCompany(null);
    }, 500);
  };

  const handleDownloadCompanies = async () => {
    try {
      const response = await companyService.getAll(0, 10000, '', 'createDate', 'desc');
      let companies = response.content;
      companies = companies.map((company: { imageFile?: any;[key: string]: any }) => {
        const { imageFile, ...rest } = company;
        return rest;
      });
      const worksheet = XLSX.utils.json_to_sheet(companies);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Companies');
      XLSX.writeFile(workbook, 'companies.xlsx');
    } catch (error) {
      alert('Failed to download company data.');
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-100px)]">
        <CustomSnackbar
                open={openSnackbar}
                message={alertMessage}
                severity={alertSeverity}
                onClose={() => setOpenSnackbar(false)}
                autoHideDuration={3000}
            />

      <div className="flex items-center">
        <div className="flex items-center text-sm text-gray-600">
          <HomeIcon fontSize="small" className="mr-1 text-gray-600" />
          <a
            href="/dashboard"
            className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
          >
            Dashboard
          </a>
        </div>
        <span className="mx-2 text-gray-400">/</span>
        <div className="text-sm text-gray-600">
          Companies
        </div>
      </div>

      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center">
          Company Management
        </h1>
        <button
          onClick={() => handleEdit(null)}
          className="flex items-center gap-2 font-bold rounded-lg px-3.5 py-2 shadow transition mb-1"
          style={{
            backgroundColor: '#0A2463',
            color: 'white',
            letterSpacing: '0.5px',
            fontSize: '1rem',
            cursor: 'pointer',
          }}
        >
          <AddIcon sx={{ fontSize: 18 }} />
          New Company
        </button>
      </div>

      <Card className='mb-3'>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="relative w-full md:w-96">
            <SearchIcon
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
              sx={{ fontSize: 18 }}
            />
            <input
              type="text"
              placeholder="Search by name, email, phone..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 hover:border-blue-400 text-sm"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
            />
          </div>

          <CustomTooltip title="Download Companies" placement="top">
          <a href='#' onClick={handleDownloadCompanies} className="text-sm font-medium text-gray-700 hover:underline hover:text-blue-600" style={
            { float: 'right' }
          }>
            <CloudDownloadIcon className="mr-2" sx={{ fontSize: 30 }} /></a>
        </CustomTooltip>
        </div>
      </Card>

      {loading ? (
        <p className="text-center text-gray-500">Loading companies...</p>
      ) : (
        <div className="flex flex-col flex-grow overflow-hidden">
          <Card className="overflow-hidden flex-grow">
            <div className="h-full">
              <DataGrid
                rows={companies.map((company, index) => ({
                  id: company.id || `company-${index}`,
                  sno: (currentPage - 1) * rowsPerPage + index + 1,
                  companyName: company.companyName || 'N/A',
                  emailId: company.emailId || 'N/A',
                  mobileNo: company.mobileNo || 'N/A',
                  companyRegNo: company.companyRegNo || 'N/A',
                  status: company.status,
                  company,
                }))}
                columns={[
                  { field: 'sno', headerName: '#', flex: 0.3, headerAlign: 'center', align: 'center' },
                  { field: 'companyName', headerName: 'Company Name', flex: 1.2 },
                  { field: 'emailId', headerName: 'Email', flex: 1 },
                  { field: 'mobileNo', headerName: 'Mobile', flex: 1 },
                  { field: 'companyRegNo', headerName: 'Reg. No', flex: 0.8 },
                  {
                    field: 'actions',
                    headerName: 'Actions',
                    flex: 1,
                    sortable: false,
                    filterable: false,
                    align: 'left',
                    headerAlign: 'left',
                    renderCell: (params) => (
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', width: '100%', gap: 12 }}>
                        <CustomTooltip title="View Company" placement="top">
                          <div
                            className="p-1 transition cursor-pointer"
                            onClick={() => handleViewDetails(params.row.company)}
                          >
                            <VisibilityIcon
                              className="text-blue-400 hover:scale-110 transition-transform"
                              sx={{ fontSize: 18 }}
                            />
                          </div>
                        </CustomTooltip>
                        <CustomTooltip title="Edit Company" placement="top">
                          <div
                            className="p-1 transition cursor-pointer"
                            onClick={() => handleEdit(params.row.company)}
                          >
                            <EditIcon
                              className="text-blue-400 hover:scale-110 transition-transform"
                              sx={{ fontSize: 18 }}
                            />
                          </div>
                        </CustomTooltip>
                        <CustomTooltip title="Upload Image" placement="top">
                          <div
                            className="p-1 transition cursor-pointer"
                            onClick={() => handleUpload(params.row.company)}
                          >
                            <UploadFileIcon
                              className="text-green-400 hover:scale-110 transition-transform"
                              sx={{ fontSize: 18 }}
                            />
                          </div>
                        </CustomTooltip>
                      </div>
                    ),
                  },
                ]}
                pagination
                paginationMode="server"
                rowCount={totalEntries}
                pageSizeOptions={[5, 10, 20, 50]}
                paginationModel={{ page: currentPage - 1, pageSize: rowsPerPage }}
                onPaginationModelChange={({ page, pageSize }) => {
                  setCurrentPage(page + 1);
                  setRowsPerPage(pageSize);
                }}
                disableRowSelectionOnClick
                sx={{
                  width: '100%',
                  '& .MuiDataGrid-columnHeaders': {
                    backgroundColor: '#f1f5f9 !important',
                  },
                  '& .MuiDataGrid-columnHeader': {
                    backgroundColor: '#f1f1f1',
                  },
                  '& .MuiDataGrid-columnHeaderTitle': {
                    fontWeight: 'bold',
                    textTransform: 'uppercase',
                  },
                  '& .MuiDataGrid-row:hover': {
                    backgroundColor: 'inherit',
                  },
                }}
                localeText={{
                  noRowsLabel: searchError || 'No companies found.',
                }}
              />
            </div>
          </Card>
        </div>
      )}

      {isDrawerOpen && (
        <CompanyRegistrationPage
          company={selectedCompany || undefined}
          onClose={() => {
            setIsDrawerOpen(false);
            setIsEditMode(false);
            setSelectedCompany(null);
          }}
          onSuccess={(message) => {
                        fetchCompanies();
                        setIsDrawerOpen(false);
                        showSnackbar(
                            message,
                            "success"
                        );
                    }}
        />
      )}

      {isUploadDrawerOpen && (
        <DrawerLayout
          title="Upload Company Image"
          onClose={handleCloseUploadDrawer}
          footer={
            <div className="flex justify-end gap-4">
              <button
                onClick={handleCloseUploadDrawer}
                className="bg-gray-300 text-gray-700 px-5 py-3 rounded hover:bg-gray-400"
                disabled={uploadLoading}
              >
                Cancel
              </button>
              <button
                onClick={handleImageUpload}
                className="bg-[#0A2463] text-white px-5 py-3 rounded hover:bg-blue-800 flex items-center"
                disabled={!selectedFile || uploadLoading}
              >
                {uploadLoading ? 'Uploading...' : (
                  <>
                    <UploadFileIcon sx={{ fontSize: 18, marginRight: 1 }} />
                    Upload Image
                  </>
                )}
              </button>
            </div>
          }
        >
          <div className="space-y-4 px-2 py-4">
            <p className="text-gray-600">
              {existingImageUrl ? 'Update image for' : 'Upload an image for'} {selectedCompanyForUpload?.companyName}
            </p>
            {existingImageUrl && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">Current Image:</p>
                <div className="relative w-full h-48 border border-gray-300 rounded-lg overflow-hidden">
                  <img
                    src={existingImageUrl}
                    alt="Current company"
                    className="w-full h-full object-contain bg-gray-50"
                  />
                </div>
              </div>
            )}

            <div className="flex flex-col items-center justify-center w-full">
              <label
                htmlFor="image-upload"
                className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
              >
                {previewUrl ? (
                  <div className="relative w-full h-full">
                    <img
                      src={previewUrl}
                      alt="Preview"
                      className="w-full h-full object-contain"
                    />
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        setSelectedFile(null);
                        setPreviewUrl(null);
                      }}
                      className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
                    >
                      ×
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <UploadFileIcon className="w-8 h-8 mb-4 text-gray-500" />
                    <p className="mb-2 text-sm text-gray-500">
                      <span className="font-semibold">Click to upload</span> or drag and drop
                    </p>
                    <p className="text-xs text-gray-500">PNG, JPG or JPEG (MAX. 2MB)</p>
                  </div>
                )}
                <input
                  id="image-upload"
                  type="file"
                  className="hidden"
                  accept="image/*"
                  onChange={handleFileSelect}
                  disabled={uploadLoading}
                />
              </label>
            </div>
          </div>
        </DrawerLayout>
      )}

      {isViewDrawerOpen && selectedCompany && (
        <CompanyDetailsDrawer
          open={isViewDrawerOpen}
          onClose={closeViewDrawer}
          company={selectedCompany}
        />
      )}
    </div>
  );
};

export default CompaniesPage;