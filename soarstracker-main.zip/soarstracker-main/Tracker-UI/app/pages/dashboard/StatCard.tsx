import React from 'react';

interface StatCardProps {
  title: string;
  value?: string|number;
  subtitle?: React.ReactNode;
  change?: string;
  trend?: 'up' | 'down';
  icon: React.ElementType;
  color: 'blue' | 'green' | 'purple' | 'orange';
  onClick?: () => void;
  active?: number;
  total?: number;
  percentBar?: number;
  percentLabel?: string;
}

const colorVariants = {
  blue: 'from-blue-500 to-cyan-500',
  green: 'from-green-500 to-emerald-500',
  purple: 'from-purple-500 to-pink-500',
  orange: 'from-orange-500 to-red-500',
};

export const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon, color, onClick, subtitle, active, total, percentBar, percentLabel }) => {
  return (
    <div
      className={`bg-white/80 backdrop-blur-xl rounded-xl p-6 border border-gray-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1${onClick ? ' cursor-pointer' : ''}`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between h-full">
        <div>
          <p className="text-sm font-semibold text-gray-500 mb-1">{title}</p>
          {subtitle && <p className="text-xs text-gray-400 mb-1">{subtitle}</p>}
         { active!==undefined &&  <div className="flex items-baseline gap-1">
            <span className="text-4xl font-bold text-gray-900">{(active ?? 0).toLocaleString()}</span>
          </div>}
          <div className='flex items-baseline gap-1'>
          <span className="text-4xl font-bold text-gray-900">{value}</span>
          </div>
          {percentBar !== undefined && (
            <div className="mt-2">
              {percentLabel && <div className="text-xs text-gray-600 mt-1 text-center">{percentLabel}</div>}
            </div>
          )}
        </div>
        <div className="flex items-center gap-2">
          <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${colorVariants[color]} flex items-center justify-center`}>
            <Icon className="w-8 h-8 text-white" />
          </div>
        </div>
      </div>
    </div>
  );
};