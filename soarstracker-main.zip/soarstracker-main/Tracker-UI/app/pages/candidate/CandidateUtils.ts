    import  candidateService  from '~/services/candidate/candidate.service';

    export const normalizeStatus = (status: string): string => {
      return status.trim()
        .toLowerCase()
        .split(' ')
        .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
    };

    export const isDefaultStatus = (status: string): boolean => {
      const normalizedInput = normalizeStatus(status);
      return DEFAULT_CANDIDATE_STATUSES.some(defaultStatus => 
        normalizeStatus(defaultStatus) === normalizedInput
      );
    };

    export const getCanonicalStatus = (status: string): string => {
      const normalizedInput = normalizeStatus(status);
      const defaultStatus = DEFAULT_CANDIDATE_STATUSES.find(defaultStatus => 
        normalizeStatus(defaultStatus) === normalizedInput
      );
      return defaultStatus || normalizedInput;
    };

    export const DEFAULT_CANDIDATE_STATUSES = [
      'Profile Submitted',
      'Created', 
      'Pending',
      'Rejected',
      'Interviewing', 
      'Hired',
      'Candidate Declined',
      'Job Assigned'
    ];

    export const fetchCandidatureStatuses = async () => {
      try {
        const statuses = await candidateService.getUniqueCandidatureStatuses();
       return statuses;
      } catch (error) {
        console.error('Failed to fetch candidature statuses:', error);
        return DEFAULT_CANDIDATE_STATUSES;
      }
    };