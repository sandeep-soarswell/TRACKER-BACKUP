package com.soarswell.tracker.model;

import com.soarswell.tracker.persistance.AbstractEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Table(name="comment",indexes = {
        @Index(name="idx_candidate_id", columnList = "candidateId"),
})

public class CommentEntity extends AbstractEntity {

    private String candidateId;
    @Column(columnDefinition = "TEXT")
    private String content;

}
