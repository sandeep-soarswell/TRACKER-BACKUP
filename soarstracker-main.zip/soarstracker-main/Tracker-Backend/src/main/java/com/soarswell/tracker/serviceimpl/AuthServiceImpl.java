package com.soarswell.tracker.serviceimpl;

import com.soarswell.tracker.auth.JWTService;
import com.soarswell.tracker.common.ResponseBuilder;
import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.Otp;
import com.soarswell.tracker.model.Session;
import com.soarswell.tracker.model.Status;
import com.soarswell.tracker.model.payload.*;
import com.soarswell.tracker.repository.OtpRepository;
import com.soarswell.tracker.repository.SessionRepository;
import com.soarswell.tracker.service.AuthService;
import com.soarswell.tracker.service.EmailService;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.MessageKeys;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.context.SecurityContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.context.MessageSource;
import com.soarswell.tracker.repository.UserRepository;
import com.soarswell.tracker.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;

@Slf4j
@Service
public class AuthServiceImpl implements AuthService {

    private final OtpRepository otpRepository;
    private final EmailService emailService;
    private final JWTService jwtService;
    private final UserRepository userRepository;
    private final SessionRepository sessionRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${otp.fixed}")
    private String fixedOtp;

    private final ConcurrentHashMap<String, String> otpPurposeMap = new ConcurrentHashMap<>();

    @Autowired
    public AuthServiceImpl(
            OtpRepository otpRepository,
            EmailService emailService,
            JWTService jwtService,
            SessionRepository sessionRepository,
            UserRepository userRepository,
            PasswordEncoder passwordEncoder) {
        this.otpRepository = otpRepository;
        this.emailService = emailService;
        this.jwtService = jwtService;
        this.sessionRepository = sessionRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    private ResponseEntity<?> sendOtp(String email){
        log.debug(Constants.LOG_AUTH_SEND_OTP_ATTEMPT, email);
        String otp = fixedOtp;
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(Constants.OTP_EXPIRY_MINUTES);
        Otp token = new Otp(email, otp, expiry);
        otpRepository.save(token);
        otpPurposeMap.put(email, Constants.OTP_PURPOSE_LOGIN);

        emailService.sendOtpEmail(
                email,
                otp,
                String.valueOf(Constants.OTP_EXPIRY_MINUTES),
                MessageKeys.MAIL_SUBJECT_OTP
        );
        log.info(Constants.LOG_AUTH_OTP_SENT, email);

        Map<String, String> response = new HashMap<>();
        response.put(Constants.MESSAGE, Constants.OTP_SENT_SUCCESS);
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(response));
    }

    @Override
    public ResponseEntity<?> authenticate(LoginRequest request) {
        log.debug(Constants.LOG_AUTH_LOGIN_ATTEMPT, request.getUsername());
        User user = userRepository.findByEmail(request.getUsername())
                .orElseThrow(() -> {
                    log.warn(Constants.LOG_AUTH_LOGIN_INVALID, request.getUsername());
                    throw new TrackerException(
                            ErrorMessageHandler.getMessage(Constants.INVALID__CREDENTIALS),
                            Constants.INVALID_CREDENTIALS,
                            HttpStatus.UNAUTHORIZED);
                });
        if (Constants.INACTIVE.equalsIgnoreCase(user.getStatus())) {
            log.warn("User is inactive: {}", request.getUsername());
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(Constants.USER_INACTIVE),
                    Constants.USER_INACTIVE,
                    HttpStatus.UNAUTHORIZED);
        }
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            log.warn(Constants.LOG_AUTH_LOGIN_INVALID, request.getUsername());
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(Constants.INVALID__CREDENTIALS),
                    Constants.INVALID_CREDENTIALS,
                    HttpStatus.UNAUTHORIZED);
        }
        return sendOtp(user.getEmail());
    }

    @Override
    @Transactional
    public ResponseEntity<?> reSendOtp(String email) {
        Otp recentOtp=otpRepository.findByEmail(email)
                .orElseThrow(()->new TrackerException(ErrorMessageHandler.getMessage(
                        ErrorMessageKey.USER_NOT_AUTHENTICATED.getStatusCode()),HttpStatus.UNAUTHORIZED
                ));

        if(recentOtp.getExpiryDate().plusMinutes(30).isBefore(LocalDateTime.now())){
            throw new TrackerException(ErrorMessageHandler.getMessage(
                    ErrorMessageKey.USER_NOT_AUTHENTICATED.getStatusCode()),HttpStatus.UNAUTHORIZED);
        }

        return sendOtp(email);

    }

    @Scheduled(cron="0 0 0 * * *")
    public void flushExpired(){
        LocalDateTime now=LocalDateTime.now().minusMinutes(30);
        List<Otp> expiredOtps;
        do{
            expiredOtps=otpRepository.findTop100ByExpiryDateBefore(now);
            if(!expiredOtps.isEmpty()){
                otpRepository.deleteAll(expiredOtps);
            }
        }while(!expiredOtps.isEmpty());
    }

    @Override
    @Transactional
    public ResponseEntity<?> changePassword(String username, ChangePasswordRequest request) {
        String newPassword = request.getNewPassword();
        log.debug(Constants.LOG_AUTH_CHANGE_PASSWORD_ATTEMPT, username);

        User user = userRepository.findByEmail(username)
                .orElseThrow(() -> {
                    log.warn(Constants.LOG_AUTH_USER_NOT_FOUND, username);
                    throw new TrackerException(
                            ErrorMessageHandler.getMessage(Constants.USER__NOT_FOUND),
                            Constants.USER_NOT_FOUND,
                            HttpStatus.NOT_FOUND);
                });

        // Check if new password is same as previous password in DB
        if (passwordEncoder.matches(newPassword, user.getPassword())) {
            log.warn("New password cannot be same as previous password for user: {}", username);
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(Constants.SAME_AS_OLD_PASSWORD),
                    Constants.SAME_AS_OLD_PASSWORD,
                    HttpStatus.BAD_REQUEST);
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        if (Constants.CREATED.equalsIgnoreCase(user.getStatus().toString())) {
            user.setStatus(Status.ACTIVE.getLongLabel());
        }

        userRepository.save(user);
        log.info(Constants.LOG_AUTH_CHANGE_PASSWORD_SUCCESS, username);

        // Destroy all tokens/sessions for this user after password change
        sessionRepository.deleteAllByUsername(username);
        log.info("All sessions/tokens destroyed for user after password change: {}", username);

        Map<String, String> response = new HashMap<>();
        response.put(Constants.MESSAGE, Constants.PASSWORD_CHANGE_SUCCESS);
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(response));
    }

    @Override
    public ResponseEntity<?> forgotPassword(ForgotPasswordRequest request) {
        log.debug(Constants.LOG_AUTH_FORGOT_PASSWORD_ATTEMPT, request.getEmail());

        userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    log.warn(Constants.LOG_AUTH_FORGOT_PASSWORD_USER_NOT_FOUND, request.getEmail());
                    throw new TrackerException(
                            ErrorMessageHandler.getMessage(ErrorMessageKey.USER_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND);
                });

        String otp = fixedOtp;
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(Constants.OTP_EXPIRY_MINUTES);

        Otp token = new Otp(request.getEmail(), otp, expiry);
        otpRepository.save(token);
        otpPurposeMap.put(request.getEmail(), Constants.OTP_PURPOSE_RESET);

        emailService.sendOtpEmail(
                request.getEmail(),
                otp,
                String.valueOf(Constants.OTP_EXPIRY_MINUTES),
                MessageKeys.MAIL_SUBJECT_RESET_OTP
        );
        log.info(Constants.LOG_AUTH_OTP_SENT, request.getEmail());

        Map<String, String> response = new HashMap<>();
        response.put(Constants.MESSAGE, Constants.OTP_SENT_SUCCESS);
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(response));
    }

    @Override
    @Transactional
    public ResponseEntity<?> validateOtp(ValidateOtpRequest request) {
        log.debug(Constants.LOG_AUTH_OTP_VALIDATION_ATTEMPT, request.getEmail());

        Otp token = otpRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    log.warn(Constants.LOG_AUTH_OTP_NOT_FOUND, request.getEmail());
                    return new TrackerException(
                            ErrorMessageHandler.getMessage(Constants.OTP_ERROR),
                            Constants.OTP_ERROR,
                            HttpStatus.NOT_FOUND);
                });

        if (!token.getOtp().equals(request.getOtp())) {
            log.warn(Constants.LOG_AUTH_OTP_INVALID, request.getEmail());
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(Constants.INVALID_OTP),
                    Constants.INVALID_OTP,
                    HttpStatus.BAD_REQUEST);
        }

        if (token.getExpiryDate().isBefore(LocalDateTime.now())) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.OTP_EXPIRED.getStatusCode()),HttpStatus.BAD_REQUEST);
        }
        // Determine purpose for JWT token
        String otpPurpose = otpPurposeMap.getOrDefault(request.getEmail(), "");
        otpPurposeMap.remove(request.getEmail());
        otpRepository.deleteByEmail(request.getEmail());
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new TrackerException(
                        ErrorMessageHandler.getMessage(Constants.USER__NOT_FOUND),
                        Constants.EMPLOYEE_NOT_FOUND,
                        HttpStatus.NOT_FOUND));

        String roles = user.getRole().toString();
        String purpose;
        if (Constants.OTP_PURPOSE_RESET.equals(otpPurpose)) {
            purpose = Constants.RESET_PASSWORD;
        } else if (Constants.CREATED.equalsIgnoreCase(user.getStatus().toString())) {
            purpose = Constants.FIRST_TIME;
        } else {
            purpose = Constants.GENERAL;
        }
        String tokenJwt = jwtService.generateToken(user.getEmail(), List.of(roles.toString()), user.getCompanyId(), purpose, user.getId());
        sessionRepository.save(Session.builder()
                .token(tokenJwt)
                .username(user.getEmail())
                .build());

        Map<String, String> response = new HashMap<>();
        response.put(Constants.TOKEN, tokenJwt);
        response.put(Constants.MESSAGE,
                Constants.CREATED.equalsIgnoreCase(user.getStatus().toString())
                        ? ErrorMessageHandler.getMessage(Constants.FIRST_TIME_LOGIN)
                        : ErrorMessageHandler.getMessage(Constants.VALIDATE_OTP)
        );
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(response));
    }

    @Override
    @Transactional
    public ResponseEntity<?> resetPassword(ResetPasswordRequest request) {
        log.debug(Constants.LOG_AUTH_RESET_PASSWORD_ATTEMPT, request.getEmail());

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    log.warn(Constants.LOG_AUTH_USER_NOT_FOUND, request.getEmail());
                    throw new TrackerException(
                            ErrorMessageHandler.getMessage(Constants.USER__NOT_FOUND),
                            Constants.USER_NOT_FOUND,
                            HttpStatus.NOT_FOUND);
                });

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        otpRepository.deleteByEmail(request.getEmail());
        log.info(Constants.LOG_AUTH_RESET_PASSWORD_SUCCESS, request.getEmail());

        Map<String, String> response = new HashMap<>();
        response.put(Constants.MESSAGE, Constants.PASSWORD_RESET_SUCCESS);
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(response));
    }

    @Override
    @Transactional
    public ResponseEntity<?> logout(String username) {
        var authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || authentication.getPrincipal() == null
                || Constants.ANONYMOUSUSER.equals(authentication.getPrincipal())) {
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(Constants.INVALID__OR_EXPIRED_TOKEN),
                    Constants.INVALID_OR_EXPIRED_TOKEN,
                    HttpStatus.UNAUTHORIZED);
        }
        sessionRepository.deleteAllByUsername(username);
        Map<String, String> response = new HashMap<>();
        response.put(Constants.MESSAGE, Constants.LOGOUT_SUCCESS);
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(response));
    }

    @Override
    public ResponseEntity<?> validateToken(String token) {
        try {
            if (token == null || token.isBlank()) {
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(Constants.INVALID_TOKEN),
                        Constants.INVALID_TOKEN,
                        HttpStatus.UNAUTHORIZED);
            }
            // Check if token exists in sessionRepository (DB)
            boolean sessionValid = sessionRepository.findByToken(token).isPresent();
            if (!sessionValid) {
                throw new TrackerException(
                        ErrorMessageHandler.getMessage(Constants.INVALID_TOKEN),
                        Constants.INVALID_OR_EXPIRED_TOKEN,
                        HttpStatus.UNAUTHORIZED);
            }
            var usernameOpt = jwtService.extractUsername(token);
            if (usernameOpt.isPresent() && jwtService.validateToken(token, usernameOpt.get())) {
                if (jwtService.isTokenExpired(token)) {
                    // Remove expired token from DB
                    sessionRepository.deleteByToken(token);
                    throw new TrackerException(
                            ErrorMessageHandler.getMessage(Constants.OTP_EXPIRED),
                            Constants.OTP_EXPIRED,
                            HttpStatus.UNAUTHORIZED);
                }
                Map<String, String> response = new HashMap<>();
                response.put(Constants.MESSAGE, Constants.TOKEN_VALIDATED_SUCCESS);
                return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(response));
            }
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(Constants.INVALID_TOKEN),
                    Constants.INVALID_OR_EXPIRED_TOKEN,
                    HttpStatus.UNAUTHORIZED);
        } catch (TrackerException e) {
            throw e;
        } catch (Exception e) {
            log.error("Token validation failed: {}", e.getMessage());
            throw new TrackerException(
                    Constants.INVALID_OR_EXPIRED_TOKEN,
                    HttpStatus.UNAUTHORIZED);
        }
    }
}
