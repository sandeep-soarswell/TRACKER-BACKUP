package com.soarswell.tracker.database;

import com.soarswell.tracker.repository.OtpRepository;
import com.soarswell.tracker.repository.SessionRepository;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CleanUpServices {

    @Autowired
    private SessionRepository sessionRepository;

    @Autowired
    private OtpRepository otpRepository;

    Logger logger = LoggerFactory.getLogger(CleanUpServices.class);

    @PostConstruct
    public void clearAllSessions() {
        sessionRepository.deleteAll();
        otpRepository.deleteAll();
        logger.info("All previous sessions and stored otp's cleared.");

    }
}