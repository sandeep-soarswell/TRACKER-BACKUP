package com.soarswell.tracker.auth;

import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.util.Constants;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.MacAlgorithm;
import io.jsonwebtoken.security.SignatureException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import javax.crypto.SecretKey;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Component
public class JWTService {

    private static final MacAlgorithm alg = Jwts.SIG.HS256;
    private static final SecretKey key = alg.key().build();

    public String generateToken(String username, List<String> roles, String companyId, String purpose, String  userId) {
        Date now = new Date();
        long expiryMillis = 3600000; // 1 hour default
        String claimPurpose = Constants.GENERAL;
        if (Constants.RESET_PASSWORD.equalsIgnoreCase(purpose)) {
            expiryMillis = 600000;
            claimPurpose = Constants.RESET_PASSWORD;
        } else if (Constants.FIRST_TIME.equalsIgnoreCase(purpose)) {
            expiryMillis = 600000;
            claimPurpose = Constants.FIRST_TIME;
        } else if (purpose != null && !purpose.isBlank()) {
            claimPurpose = purpose;
        }
        Date expiryDate = new Date(now.getTime() + expiryMillis);
        try {
            List<String> processedRoles = roles.stream()
                    .map(role -> role.startsWith(Constants.ROLE_) ? role.substring(5) : role)
                    .toList();

            return Jwts.builder()
                    .subject(username)
                    .claim(Constants.JWT_ROLES_CLAIM, processedRoles)
                    .claim(Constants.COMPANY_ID, companyId)
                    .claim("userId", userId)
                    .claim(Constants.PURPOSE, claimPurpose)
                    .issuedAt(now)
                    .expiration(expiryDate)
                    .signWith(key, alg)
                    .compact();
        } catch (Exception e) {
            log.error(ErrorMessageHandler.getMessage(Constants.ERROR_JWT_GENERATION_FAILED) + ": {}", e.getMessage());
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(Constants.ERROR_JWT_GENERATION_FAILED),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public Optional<String> extractUsername(String token) {
        try {
            return Optional.ofNullable(extractAllClaims(token))
                    .map(Claims::getSubject);
        } catch (ExpiredJwtException e) {
            log.warn(ErrorMessageHandler.getMessage(Constants.ERROR_JWT_EXPIRED) + ": {}", e.getMessage());
        } catch (SignatureException e) {
            log.error(ErrorMessageHandler.getMessage(Constants.ERROR_JWT_SIGNATURE) + ": {}", e.getMessage());
        } catch (Exception e) {
            log.error(ErrorMessageHandler.getMessage(Constants.ERROR_JWT_EXTRACTION) + ": {}", e.getMessage());
        }
        return Optional.empty();
    }

    public Optional<List<String>> extractRoles(String token) {
        try {
            return Optional.ofNullable(extractAllClaims(token))
                    .map(claims -> claims.get(Constants.JWT_ROLES_CLAIM, List.class));
        } catch (Exception e) {
            log.error(ErrorMessageHandler.getMessage(Constants.ERROR_JWT_ROLES_EXTRACTION) + ": {}", e.getMessage());
            return Optional.empty();
        }
    }

    public Claims extractAllClaims(String token) {
        if (token == null) {
            throw new IllegalArgumentException(ErrorMessageHandler.getMessage(Constants.ERROR_TOKEN_NULL));
        }

        String processedToken = token.startsWith(Constants.BEARER)
                ? token.substring(7)
                : token;

        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(processedToken)
                .getPayload();
    }

    public boolean validateToken(String token, String username) {
        if (token == null || username == null) {
            return false;
        }

        try {
            Optional<String> tokenUsername = extractUsername(token);
            return tokenUsername.isPresent()
                    && tokenUsername.get().equals(username)
                    && !isTokenExpired(token);
        } catch (Exception e) {
            log.error(ErrorMessageHandler.getMessage(Constants.ERROR_JWT_VALIDATION) + ": {}", e.getMessage());
            return false;
        }
    }

    public static Claims validateToken(String token) throws TrackerException {
        try {
            return Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (JwtException e) {
            log.error("Invalid JWT token");
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_TOKEN.name()),
                    HttpStatus.UNAUTHORIZED);
        }
    }

    public boolean isTokenExpired(String token) {
        try {
            Date expiration = extractAllClaims(token).getExpiration();
            return expiration.before(new Date());
        } catch (Exception e) {
            log.error(ErrorMessageHandler.getMessage(Constants.ERROR_JWT_EXPIRATION) + ": {}", e.getMessage());
            return true;
        }
    }

    public boolean isTokenExpiringSoon(String token, long thresholdMillis) {
        try {
            Date expiration = extractAllClaims(token).getExpiration();
            long timeLeft = expiration.getTime() - System.currentTimeMillis();
            return timeLeft < thresholdMillis; // less than 1 minute
        } catch (Exception e) {
            return false;
        }
    }

    public String refreshToken(String token) {
        try {
            Claims claims = extractAllClaims(token);
            String username = claims.getSubject();
            List<?> rawRoles = claims.get(Constants.JWT_ROLES_CLAIM, List.class);

            List<String> roles = rawRoles.stream()
                    .map(Object::toString)
                    .collect(Collectors.toList());

            String companyId = claims.get(Constants.COMPANY_ID, String.class);

            String purpose = claims.get(Constants.PURPOSE, String.class);

            String userId=claims.get("UserId", String.class);

            if (purpose.equalsIgnoreCase(Constants.GENERAL)) {
                return generateToken(username, roles, companyId, purpose, userId);
            }

        } catch (Exception e) {
            log.error(ErrorMessageHandler.getMessage("{}: {}", ErrorMessageKey.ERROR_JWT_REFRESH_FAILED.getStatusCode()), e.getMessage());
            throw new TrackerException(
                    ErrorMessageHandler.getMessage(ErrorMessageKey.ERROR_JWT_REFRESH_FAILED.getStatusCode()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return token;
    }

}