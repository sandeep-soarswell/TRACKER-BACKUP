package com.soarswell.tracker.serviceimpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseBuilder;
import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.Event;
import com.soarswell.tracker.model.Job;
import com.soarswell.tracker.model.Status;
import com.soarswell.tracker.model.User;
import com.soarswell.tracker.model.payload.EventRequest;
import com.soarswell.tracker.model.payload.EventNotificationResponse;
import com.soarswell.tracker.model.payload.EventUpdateRequest;
import com.soarswell.tracker.repository.*;
import com.soarswell.tracker.service.CompanyService;
import com.soarswell.tracker.service.EmailService;
import com.soarswell.tracker.service.EventService;
import com.soarswell.tracker.service.JobService;
import com.soarswell.tracker.util.AuthTokenUtils;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.PatchHelper;
import com.soarswell.tracker.util.ResourceIdUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.sound.midi.Track;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class EventServiceImpl implements EventService {

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private CompanyService companyService;

    @Autowired
    private JobService jobService;

    @Override
    public ResponseEntity<?> registerEvent(EventRequest eventRequest, RequestDetails requestDetails,String candidateId, String jobId) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId,requestDetails);
        if (eventRequest == null) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INTERNAL_SERVER_ERROR.getStatusCode()),HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if(eventRequest.getDate().isEqual(LocalDate.now()) && eventRequest.getStartTime().isBefore(LocalTime.now())) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_EVENT_TIME.getStatusCode()),HttpStatus.BAD_REQUEST);
        }
        Event event = objectMapper.convertValue(eventRequest, Event.class);
        event.setCompanyId(companyId);
        event.setId(ResourceIdUtils.generateEventResourceId(companyId,LocalTime.now()));
        if (candidateId != null && !candidateId.isBlank()) {
            if (candidateRepository.findByCompanyIdAndIdAndStatus(companyId,candidateId,Status.ACTIVE.getLongLabel()).isEmpty()) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.CANDIDATE_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND);
            }
            event.setCandidateId(candidateId);
        }
        if (jobId != null && !jobId.isBlank()) {
            Job job = jobRepository.findByIdAndCompanyIdAndStatus(jobId,companyId,Status.OPEN.getLongLabel())
                    .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.JOB_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));

            User existingUser = userRepository.findByEmail(requestDetails.getUserId())
                    .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_USERS_FOUND_WITH_PROVIDED_COMPANY_ID.getStatusCode()),HttpStatus.NOT_FOUND));
            boolean userHasJob = existingUser.getJobs().contains(job);
            if (!userHasJob) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_JOBS_FOUND_FOR_USER.getStatusCode()), HttpStatus.NOT_FOUND);
            }
            event.setJobId(jobId);
        }
        event.setCreatedBy(requestDetails.getUserId());
        event.setCreateDate(new Date(Instant.now().toEpochMilli()));
        eventRepository.save(event);
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.EVENT_CREATION), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> getEvents(RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        String username = requestDetails.getUserId();
        List<Event> events = eventRepository.findAllByCreatedBy(username);
        events.sort(Comparator.comparing(Event::getDate).reversed()
                .thenComparing(Event::getStartTime, Comparator.nullsLast(Comparator.naturalOrder())));

        List<Object> eventResponses = new ArrayList<>();
        for (Event event : events) {
            if (event.getCandidateId() != null && !event.getCandidateId().isBlank()) {
                candidateRepository.findByCompanyIdAndId(companyId,event.getCandidateId()).ifPresent(candidate -> {
                    Map<String, Object> eventWithCandidate = new HashMap<>();
                    eventWithCandidate.put(Constants.EVENT, event);
                    StringBuilder candidateName = new StringBuilder();
                    if (candidate.getFirstName() != null) candidateName.append(candidate.getFirstName()).append(" ");
                    if (candidate.getMiddleName() != null) candidateName.append(candidate.getMiddleName()).append(" ");
                    if (candidate.getLastName() != null) candidateName.append(candidate.getLastName());
                    String name = candidateName.toString().trim().replaceAll(" +", " ");
                    Map<String, Object> candidateInfo = new HashMap<>();
                    candidateInfo.put(Constants.name, name);
                    candidateInfo.put(Constants.phoneNumber, candidate.getPhoneNumber());
                    candidateInfo.put(Constants.email, candidate.getEmail());
                    if (candidate.getJobAssignment() != null && candidate.getJobAssignment().getJob() != null) {
                        Job job = candidate.getJobAssignment().getJob();
                        candidateInfo.put(Constants.jobTitle, job.getTitle());
                        if (job.getClientId() != null) {
                            clientRepository.findByCompanyIdAndId(companyId,job.getClientId()).ifPresent(client ->
                                    candidateInfo.put(Constants.clientName, client.getClientName())
                            );
                        }
                    }
                    eventWithCandidate.put(Constants.candidate, candidateInfo);
                    eventResponses.add(eventWithCandidate);
                });
            } else {
                eventResponses.add(event);
            }
        }
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(eventResponses), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> getEventById(String eventId, RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.EVENT_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));
        if (!event.getCreatedBy().equals(requestDetails.getUserId())) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()), HttpStatus.UNAUTHORIZED);
        }
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(event), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> updateEvent(String eventId, EventUpdateRequest eventUpdateRequest, RequestDetails requestDetails){
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        Event existingEvent = eventRepository.findById(eventId)
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.EVENT_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));
        if (!existingEvent.getCreatedBy().equals(requestDetails.getUserId())) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()), HttpStatus.UNAUTHORIZED);
        }
        if (eventUpdateRequest.getDate() != null && eventUpdateRequest.getStartTime() != null && eventUpdateRequest.getEndTime() != null) {
            if(LocalDate.now().isAfter(eventUpdateRequest.getDate())){
                throw  new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_EVENT_DATE.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            if (!eventUpdateRequest.getEndTime().isAfter(eventUpdateRequest.getStartTime())) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_EVENT_TIME.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
            if (LocalDate.now().isEqual(eventUpdateRequest.getDate()) && LocalTime.now().isAfter(eventUpdateRequest.getStartTime())) {
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_EVENT_TIME.getStatusCode()), HttpStatus.BAD_REQUEST);
            }
        }
        boolean flag = false;
        try {
            flag = PatchHelper.updateValue(existingEvent, eventUpdateRequest);
        } catch (Exception e) {
            log.error("PatchHelper failed to update event: {}", e.toString());
            throw new TrackerException("Failed to update event fields", e);
        }
        if(flag){
            existingEvent.setNotificationSent(false);
            eventRepository.save(existingEvent);
        }
        String responseMessage = flag ? Constants.EVENT_UPDATE : Constants.NO_CHANGES_DETECTED;
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(responseMessage), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> deleteEvent(String eventId,RequestDetails requestDetails){
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.EVENT_NOT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));
        if (!event.getCreatedBy().equals(requestDetails.getUserId())) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.ACCESS_DENIED.getStatusCode()), HttpStatus.UNAUTHORIZED);
        }
        eventRepository.delete(event);
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.EVENT_DELETE), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> getUpcomingEventsNotifications(RequestDetails requestDetails) {
        String username = requestDetails.getUserId();
        List<EventNotificationResponse> notifications = getNotificationsForUser(username);
        // Return the list directly to avoid serialization issues
        return ResponseEntity.ok(notifications);
    }

    @Scheduled(cron = "0 * * * * *")
    public void scheduledNotifications() {
        sendEventReminders();
    }

    private void sendEventReminders() {
        LocalTime now = LocalTime.now();
        LocalTime thirtyMinutesFromNow = now.plusMinutes(30);
        List<Event> upcomingEvents = eventRepository.findByDateAndStartTimeBetweenAndNotificationSentFalse(
                LocalDate.now(),
                now,
                thirtyMinutesFromNow
        );
        if (upcomingEvents.isEmpty()) {
            return;
        }
        log.info("Scheduler: Found {} upcoming events to notify via email.", upcomingEvents.size());
        for (Event event : upcomingEvents) {
            String userEmail = event.getCreatedBy();
            if (userEmail == null || userEmail.isBlank()) {
                continue;
            }
            log.info("Processing event reminder for event ID {} ('{}') for user {}", event.getId(), event.getTitle(), userEmail);
            String eventDate = event.getDate().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy"));
            String eventTime = event.getStartTime().format(DateTimeFormatter.ofPattern("hh:mm a"));
            emailService.sendEventReminderEmail(
                    userEmail,
                    event.getTitle(),
                    eventDate,
                    eventTime,
                    event.getDescription()
            );
            event.setNotificationSent(true);
            eventRepository.save(event);
            log.info("Event reminder email queued for event ID {} and notification flag set to true.", event.getId());
        }
    }

    private List<EventNotificationResponse> getNotificationsForUser(String username) {
        LocalTime now = LocalTime.now();
        LocalTime thirtyMinutesFromNow = now.plusMinutes(30);
        List<Event> upcomingEvents = eventRepository.findByDateAndStartTimeBetween(
                LocalDate.now(),
                now,
                thirtyMinutesFromNow
        );
        return upcomingEvents.stream()
                .filter(event -> username.equals(event.getCreatedBy()))
                .sorted(Comparator.comparing(Event::getCreateDate).reversed())
                .map(event -> new EventNotificationResponse(
                        event.getId(),
                        event.getTitle(),
                        event.getStartTime().format(DateTimeFormatter.ofPattern("hh:mm a")),
                        event.getIsRead()
                ))
                .collect(Collectors.toList());
    }

    @Override
    public ResponseEntity<?> markNotificationAsRead(String eventId, RequestDetails requestDetails) throws TrackerException{
        Event event=eventRepository.findById(eventId)
                .orElseThrow();
        event.setRead(true);
        eventRepository.save(event);
        return ResponseEntity.ok(ResponseBuilder.builder().build().createSuccessResponse(Constants.EVENT_READ));
    }
}