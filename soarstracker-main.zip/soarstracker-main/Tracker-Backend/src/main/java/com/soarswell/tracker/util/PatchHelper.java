package com.soarswell.tracker.util;

import com.soarswell.tracker.exception.TrackerException;

import java.lang.reflect.Field;
import java.net.URL;
import java.time.LocalDate;

public class PatchHelper {

    public static boolean updateValue(Object target, Object source) throws TrackerException {
        boolean changed = false;
        Field[] sourceFields = source.getClass().getDeclaredFields();
        Class<?> targetClass = target.getClass();

        for (Field sourceField : sourceFields) {
            try {
                sourceField.setAccessible(true);
                Object newValue = sourceField.get(source);
                if (newValue != null) {
                    try {
                        Field targetField = targetClass.getDeclaredField(sourceField.getName());
                        targetField.setAccessible(true);
                        Object oldValue = targetField.get(target);
                        if (!valuesAreEqual(oldValue,newValue)) {
                            targetField.set(target, newValue);
                            changed = true;
                        }
                    } catch (NoSuchFieldException ignore) {
                        // If the field does not exist in the target, we ignore it.
                        // This allows for flexibility in the source object structure.
                    }
                }
            } catch (IllegalAccessException e) {
                throw new TrackerException("Failed to access field: " + sourceField.getName(), e);
            }
        }
        return changed;
    }

    private static boolean valuesAreEqual(Object oldValue, Object newValue) {
        if (oldValue == null || newValue == null) return false;

        if (oldValue instanceof LocalDate && newValue instanceof LocalDate) {
            return ((LocalDate) oldValue).equals((LocalDate) newValue);
        }

        if (oldValue instanceof URL && newValue instanceof URL) {
            return oldValue.toString().equals(newValue.toString());
        }

        return oldValue.equals(newValue);
    }

}
