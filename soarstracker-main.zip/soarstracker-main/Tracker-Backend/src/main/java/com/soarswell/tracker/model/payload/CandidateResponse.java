package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.soarswell.tracker.persistance.AbstractEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.net.URL;
import java.time.LocalDate;

@Getter
@Setter
public class CandidateResponse extends AbstractEntity {


    private String firstName;

    private String middleName;

    private String lastName;

    private LocalDate dateOfBirth;

    private String email;

    private String phoneNumber;

    private String address;

    private String skills;

    private String candidateRole;

    private String alternateEmail;

    private String alternatePhoneNumber;

    private LocalDate availabilityOfJoining;

    private String experience;

    private String noticePeriod;

    private String currentSalary;

    private String  expectedSalary;

    private URL resume;

    private String clientName;

    private String JobTitle;

    private String status;

    private String jobId;

    private String candidatureStatus;

    private String userName;

    private String userId;

    private String createdBy;

    private String acceptedPackage;

    private String numberOfOffers;

    private String gender;
    private String aiSummary;
    private String companyRating;
    private String collegeRating;
    private String experienceRating;
    private String skillsRating;
}

