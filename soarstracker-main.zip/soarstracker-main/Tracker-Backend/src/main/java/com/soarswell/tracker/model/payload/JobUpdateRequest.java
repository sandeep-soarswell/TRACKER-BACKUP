package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.RegExConstants;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class JobUpdateRequest {

    @Size(min = 2, max = 100, message = "{job.title.size}")
    @Schema(description = "Job title", example = Constants.SOFTWARE_ENGINEER, required = true)
    private String title;

    @Size(max = 1000, message = "{job.description.size}")
    @Schema(description = "Job description", example = Constants.JOB_DESCRIPTION)
    private String description;

    @Size(max = 100, message = "{location.size}")
    @Pattern(regexp = RegExConstants.LOCATION, message = "{invalid.location.format}")
    @Schema(description = "Job location", example = Constants.JOB_LOCATION)
    private String location;

    @Size(max = 500, message = "{skills.size}")
    @Schema(description = "Required skills", example = Constants.JOB_SKILLS)
    private String skills;

    @Schema(description = "Experience", example = Constants.JOB_EXPERIENCE)
    private String experience;


    @Schema(description = "Salary offered", example = Constants.JOB_SALARY)
    private String salary;

    @Min(value = 1, message = "{minimum.openings}")
    @Max(value = 1000, message = "{maximum.openings}")
    @Schema(description = "Number of openings", example = Constants.JOB_OPENINGS)
    private Integer openings;

    @FutureOrPresent(message = "{event.date.future.or.present}")
    @Schema(description = "Application deadline", example = Constants.JOB_DEADLINE)
    private LocalDate deadline;

    @Schema(example = "JD123")
    @Pattern(regexp = RegExConstants.JOB_ID_PATTERN, message = "{job.id.pattern}")
    private String jobId;

    @Schema(example = Constants.name)
    @Size(min = 3, max = 25, message = "{contactPersonName.size.message}")
    @Pattern(regexp = RegExConstants.NAME_PATTERN, message = "{contactPersonName.pattern.message}")
    private String contactPersonName;

    @Schema(example = Constants.EMAIL)
    @Email(message = "{invalid.email.format}")
    private String contactPersonEmail;

    @Schema(example = Constants.PHONE)
    @ValidPhoneNumber(message = "{invalid.mobile.number}")
    private String contactPersonPhone;
}
