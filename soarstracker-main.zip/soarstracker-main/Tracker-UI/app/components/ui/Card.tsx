import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hoverable?: boolean;
  onClick?: React.MouseEventHandler<HTMLDivElement>;
}

const Card: React.FC<CardProps> = ({ children, className = '', hoverable = false, onClick }) => {
  return (
    <div
      className={`bg-white rounded-xl shadow-sm p-4 ${hoverable ? 'transition-all duration-300 hover:shadow-md hover:-translate-y-1' : ''
        } ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  );
};

export default Card;