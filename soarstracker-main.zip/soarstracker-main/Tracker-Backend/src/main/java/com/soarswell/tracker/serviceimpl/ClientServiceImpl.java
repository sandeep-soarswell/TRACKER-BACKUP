package com.soarswell.tracker.serviceimpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.common.ResponseBuilder;
import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.*;
import com.soarswell.tracker.model.payload.ClientRequest;
import com.soarswell.tracker.model.payload.ClientUpdateRequest;
import com.soarswell.tracker.repository.ClientCommentRepository;
import com.soarswell.tracker.repository.ClientRepository;
import com.soarswell.tracker.repository.JobRepository;
import com.soarswell.tracker.service.ClientService;
import com.soarswell.tracker.service.CommentService;
import com.soarswell.tracker.service.CompanyService;
import com.soarswell.tracker.util.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.soarswell.tracker.util.TrackerUtils.isValidFieldInClass;

@Slf4j
@Service
public class ClientServiceImpl implements ClientService {

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private CompanyService companyService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private CommentService commentService;

    @Override
    @Transactional
    public ResponseEntity<?> registerClients(ClientRequest clientRequest, RequestDetails requestDetails) {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        Map<String,String> exceptions = new HashMap<>();
        companyService.getCompanyById(companyId, requestDetails);
        if (clientRequest == null || !StringUtils.hasText(clientRequest.getEmail())) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INTERNAL_SERVER_ERROR.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if (clientRepository.existsByCompanyIdAndEmail(companyId, clientRequest.getEmail())) {
            exceptions.put(Constants.ERROR_EMAIL,ApiResponses.EMAIL_EXISTS);
        }
        if (clientRepository.existsByCompanyIdAndClientName(companyId, clientRequest.getClientName())) {
            exceptions.put(Constants.ERROR_CLIENT_NAME,ApiResponses.CLIENT_NAME_EXISTS);
        }
        if (clientRepository.existsByCompanyIdAndContactPersonNumber(companyId, clientRequest.getContactPersonNumber())) {
            exceptions.put(Constants.ERROR_PHONE,ApiResponses.CONTACT_PERSON_NUMBER);
        }
        if (!exceptions.isEmpty()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResponseBuilder.builder().build().createErrorResponse(exceptions));
        }
        try {
            ClientEntity client = objectMapper.convertValue(clientRequest, ClientEntity.class);
            client.setId(ResourceIdUtils.generateClientResourceId(companyId, client.getEmail()));
            client.setStatus(Status.ACTIVE.getLongLabel());
            client.setCreatedBy(requestDetails.getUserId());
            client.setCreateDate(new Date(Instant.now().toEpochMilli()));
            client.setCompanyId(companyId);
            client.setCoolingPeriod(clientRequest.getCoolingPeriod());
            clientRepository.save(client);
            log.info("Client details saved successfully: {}", client.getClientName());
            String content = client.getClientName()+" Registered Successfully by "+ requestDetails.getUserId();
            commentService.clientComments(client.getId(),content, requestDetails);
            log.info("Client comment saved successfully for client: {}", client.getClientName());
        } catch (Exception e) {
            log.error("Unable to save client details: {}", clientRequest.getClientName(), e);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_SAVE_CLIENT_DETAILS.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.CLIENT_REGISTER), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> getClients(int page, int size, RequestDetails requestDetails, String sortByField, String order, String keyword, String filter) throws TrackerException {
        if (page < 0 || size <= 0) {
            log.error("Invalid pagination parameters: page={}, size={}", page, size);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_PAGINATION_PARAMS.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        if (!isValidFieldInClass(sortByField,ClientEntity.class)) {
            log.error("Invalid sort field: {}", sortByField);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_SORTBYFIELD.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        Sort.Direction sortDirection = Constants.ASC.equalsIgnoreCase(order) ? Sort.Direction.ASC : Sort.Direction.DESC;
        PageRequest pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortByField));
        String status;
        Page<ClientEntity> clientPage = null;
        if (filter != null && !filter.trim().isEmpty()) {
            if (!Constants.FILTER_ACTIVE.equalsIgnoreCase(filter) && !Constants.FILTER_INACTIVE.equalsIgnoreCase(filter)) {
                log.error("Invalid filter value: {}", filter);
                throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_FILTER_VALUE.name()), HttpStatus.BAD_REQUEST
                );
            }
            if (Constants.FILTER_INACTIVE.equalsIgnoreCase(filter)) {
                status = Status.INACTIVE.getLongLabel();
            } else {
                status = Status.ACTIVE.getLongLabel();
            }
            if (keyword != null && !keyword.trim().isEmpty()) {
                clientPage = clientRepository.searchAllFieldsByCompanyIdAndStatus(companyId, status, keyword.trim(), pageable);
            } else {
                clientPage = clientRepository.findByCompanyIdAndStatus(companyId, status, pageable);
            }
        }
        List<ClientEntity> responses = clientPage.getContent().stream()
                .map(client -> objectMapper.convertValue(client, ClientEntity.class))
                .toList();
        long totalEntries = clientPage.getTotalElements();
        Map<String, Object> res = new HashMap<>();
        res.put("data", responses);
        res.put("totalEntries", totalEntries);
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(res), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> deleteClientById(String clientId, RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        if (clientId == null || clientId.trim().isEmpty()) {
            log.error("Client ID is null or empty");
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.CLIENT_ID_NULL_OR_EMPTY.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        try {
            ClientEntity existingClient = clientRepository.findByCompanyIdAndIdAndStatus(companyId, clientId, Status.ACTIVE.getLongLabel())
                    .orElseThrow(()-> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_CLIENT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND));
            existingClient.setStatus(Status.INACTIVE.getLongLabel());
            clientRepository.save(existingClient);
            List<Job> existingJobs = jobRepository.findByCompanyIdAndClientIdAndStatus(companyId,clientId,Status.OPEN.getLongLabel());
            jobRepository.updateJobStatusForJobs(companyId,clientId, Status.CLOSED.getLongLabel(), existingJobs);
            String content =  existingClient.getClientName()+" Deleted Successfully by "+ requestDetails.getUserId();
            commentService.clientComments(clientId,content, requestDetails);
        }catch (TrackerException e){
            throw  e;
        }
        catch (Exception ex) {
            log.error("Failed to delete client: {}", clientId, ex);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_DELETE_CLIENT_DETAILS.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(Constants.CLIENT_DELETED), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> getClientsById(String clientId, RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        if (clientId == null || clientId.trim().isEmpty()) {
            log.error("Client ID is null or empty");
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.CLIENT_ID_NULL_OR_EMPTY.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        ClientEntity existingClient;
        try {
            existingClient = clientRepository.findByCompanyIdAndIdAndStatus(companyId, clientId, Status.ACTIVE.getLongLabel())
                    .orElseThrow(()-> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_CLIENT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND));
        } catch (TrackerException exception) {
            log.error("TrackerException occurred while fetching client by ID: {}", clientId, exception);
            throw exception;
        } catch (Exception exception) {
            log.error("Exception occurred while fetching client by ID: {}", clientId, exception);
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.UNABLE_GET_CLIENT_DETAILS.getStatusCode()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(existingClient), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> updateClientById(String clientId, ClientUpdateRequest clientUpdateRequest, RequestDetails requestDetails) throws TrackerException {
        String companyId = AuthTokenUtils.extractCompanyId(requestDetails);
        companyService.getCompanyById(companyId, requestDetails);
        if (clientId == null || clientId.trim().isEmpty()) {
            log.error("Client ID is null or empty");
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.CLIENT_ID_NULL_OR_EMPTY.getStatusCode()), HttpStatus.BAD_REQUEST);
        }
        ClientEntity existingClient = clientRepository.findByCompanyIdAndId(companyId, clientId)
                .orElseThrow(() -> new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_CLIENT_FOUND.getStatusCode()), HttpStatus.NOT_FOUND));
        if(existingClient.getStatus().equals(Status.INACTIVE.getLongLabel()) && clientUpdateRequest.getStatus()==null) {
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.NO_CLIENT_FOUND.getStatusCode()),HttpStatus.NOT_FOUND);
        }
        if (!existingClient.getContactPersonNumber().equals(clientUpdateRequest.getContactPersonNumber())) {
            if (clientRepository.existsByCompanyIdAndContactPersonNumber(companyId, clientUpdateRequest.getContactPersonNumber())) {
                log.info("Contact Person Number already exists");
                throw new TrackerException(ApiResponses.CONTACT_PERSON_NUMBER, HttpStatus.CONFLICT);
            }
        }
        boolean flag = false;
        try {
            flag = PatchHelper.updateValue(existingClient, clientUpdateRequest);
        } catch (Exception e) {
            log.error("PatchHelper failed to update client: {}", clientId, e);
            throw new TrackerException("Failed to update client fields", e);
        }
        if (flag) {
            clientRepository.save(existingClient);
            String content = existingClient.getClientName()+ " Details Updated Successfully by " +requestDetails.getUserId();
            commentService.clientComments(clientId, content, requestDetails);
        }
        String responseMessage = flag ? Constants.CLIENT_UPDATED : Constants.NO_CHANGES_DETECTED;
        return new ResponseEntity<>(ResponseBuilder.builder().build().createSuccessResponse(responseMessage), HttpStatus.OK);
    }
}
