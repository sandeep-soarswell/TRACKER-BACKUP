package com.soarswell.tracker.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.soarswell.tracker.auth.JWTService;
import com.soarswell.tracker.common.ResponseBuilder;
import com.soarswell.tracker.common.ResponseErrorObject;
import com.soarswell.tracker.common.ResponseObject;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.Session;
import com.soarswell.tracker.repository.SessionRepository;
import com.soarswell.tracker.util.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Component("jwtFilter")
@RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {

    private final JWTService jwtService;
    private final SessionRepository sessionRepository;
    private final ObjectMapper objectMapper;


    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        try {
            log.error("JwtFilter is running for URI: {}", request.getRequestURI());
            log.debug("Request headers: {}", Collections.list(request.getHeaderNames()));
            log.debug("Authorization header: {}", request.getHeader(Constants.AUTH));

            String requestUri = request.getRequestURI();
            String method = request.getMethod();
            log.debug("Processing {} request to {}", method, requestUri);

            Optional<String> token = extractToken(request);
            if (token.isPresent()) {
                // --- Restrict reset password token usage ---
                String purpose = null;
                try {
                    purpose = jwtService.extractAllClaims(token.get()).get(Constants.PURPOSE, String.class);
                } catch (Exception ignored) {}
                if (Constants.PURPOSE_RESET_PASSWORD.equals(purpose) && Constants.RESET_PASSWORD_ALLOWED_ENDPOINTS.stream().noneMatch(requestUri::endsWith)) {
                    setInvalidOtpResponse(response, Constants.INVALID_TOKEN_ENDPOINT);
                    return;
                }
                // --- Restrict FIRST_TIME token usage ---
                if (Constants.FIRST_TIME.equalsIgnoreCase(purpose)) {
                    if (!(requestUri.endsWith("/change-password") || requestUri.endsWith("/validate-otp"))) {
                        setInvalidOtpResponse(response, "Access denied.");
                        return;
                    }
                }
                // --- End restriction ---
                log.debug("Found JWT token, processing authentication for {} {}", method, requestUri);
                boolean valid = processToken(token.get(), request, response);
                if (!valid) {
                    // Token/session invalid, response already set, stop filter chain
                    throw new TrackerException(
                            Constants.INVALID_TOKEN,
                            HttpStatus.UNAUTHORIZED);
                }
                boolean flag= jwtService.isTokenExpiringSoon(token.get(),5*60*1000);
                if(flag){
                    String newToken = jwtService.refreshToken(token.get());
                    if (newToken != null) {
                        response.setHeader(Constants.AUTH, "Bearer " + newToken);
                    } else {
                        log.error("Failed to refresh token for {} {}", method, requestUri);
                    }
                } else {
                    log.debug("Token is not expiring soon for {} {}", method, requestUri);
                }

            } else {
                log.debug("No JWT token found for {} {}. Headers: {}",
                        method, requestUri,
                        Collections.list(request.getHeaderNames()));
            }
        } catch (Exception e) {
            log.error("Error processing JWT token: {}", e.getMessage(), e);
        }
        filterChain.doFilter(request, response);
    }

    private Optional<String> extractToken(HttpServletRequest request) {
        try {
            String authHeader = request.getHeader(Constants.AUTH);
            log.debug("Authorization header: {}", authHeader);

            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring("Bearer ".length()).trim();
                if (token.isEmpty()) {
                    log.warn("Empty token found in Authorization header");
                    return Optional.empty();
                }
                log.debug("Extracted token: {}", maskToken(token));
                return Optional.of(token);
            }
        } catch (Exception e) {
            log.error("Error extracting token: {}", e.getMessage());
        }
        return Optional.empty();
    }

    private String maskToken(String token) {
        if (token == null || token.length() < 10) {
            return Constants.INVALID_TOKEN;
        }
        return token.substring(0, 10) + "...";
    }

    private boolean processToken(String token, HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        try {
            // Check session repository for token
            Optional<Session> sessionOpt = sessionRepository.findByToken(token);
            if (sessionOpt.isEmpty()) {
                log.warn("Session not found for token: {}", maskToken(token));
                setInvalidOtpResponse(response, Constants.INVALID_TOKEN);
                return false;
            }
            if (jwtService.isTokenExpired(token)) {
                log.warn("JWT token expired: {}", maskToken(token));
                try {
                    sessionRepository.deleteByToken(token);
                } catch (Exception e) {
                    log.warn("Failed to delete expired token: {}", e.getMessage());
                }
                setInvalidOtpResponse(response, Constants.INVALID_TOKEN);
                return false;
            }

            Optional<String> username = jwtService.extractUsername(token);
            log.debug("Extracted username from token: {}", username.orElse("none"));

            if (username.isPresent() && SecurityContextHolder.getContext().getAuthentication() == null) {
                if (jwtService.validateToken(token, username.get())) {
                    List<SimpleGrantedAuthority> authorities = extractAuthorities(token);
                    log.debug("Token validation successful. Extracted authorities: {}", authorities);
                    createAndSetAuthentication(username.get(), authorities, request);
                } else {
                    log.debug("Token validation failed for user: {}", username.get());
                    setInvalidOtpResponse(response, Constants.INVALID_TOKEN);
                    return false;
                }
            } else {
                log.debug("No username in token or authentication already exists in SecurityContext");
            }
            return true;
        } catch (Exception e) {
            log.error("Error processing token: {}", e.getMessage(), e);
            setInvalidOtpResponse(response, Constants.INVALID_TOKEN);
            return false;
        }
    }

    private void setInvalidOtpResponse(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(Constants.JSON_FORMAT);
        ResponseErrorObject error = ResponseErrorObject.builder().error(message).build();
        ResponseObject<Object> responseObject = new ResponseBuilder().createFailureResponse(error);
        String json = objectMapper.writeValueAsString(responseObject);
        response.getWriter().write(json);
        response.getWriter().flush();
    }

    private List<SimpleGrantedAuthority> extractAuthorities(String token) {
        try {
            Optional<List<String>> roles = jwtService.extractRoles(token);
            log.debug("Raw roles from token: {}", roles.orElse(Collections.emptyList()));
            return roles.map(roleList -> roleList.stream()
                            .map(role -> new SimpleGrantedAuthority(Constants.ROLE_PREFIX + role.toUpperCase()))
                            .collect(Collectors.toList()))
                    .orElse(Collections.emptyList());
        } catch (Exception e) {
            log.error("Error extracting authorities: {}", e.getMessage(), e);
            return Collections.emptyList();
        }
    }

    private void createAndSetAuthentication(String username,
                                            List<SimpleGrantedAuthority> authorities,
                                            HttpServletRequest request) {
        try {
            if (authorities.isEmpty()) {
                log.warn("No authorities found for user: {}", username);
                return;
            }

            log.debug("Creating authentication for user: {} with authorities: {}", username, authorities);
            UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(username, null,
                    authorities);
            authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
            SecurityContextHolder.getContext().setAuthentication(authToken);
            log.debug("Successfully set authentication in SecurityContext for user: {}", username);
        } catch (Exception e) {
            log.error("Error setting authentication: {}", e.getMessage());
            SecurityContextHolder.clearContext();
        }
    }
}

