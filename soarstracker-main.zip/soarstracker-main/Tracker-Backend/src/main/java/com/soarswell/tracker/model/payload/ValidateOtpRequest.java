package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.soarswell.tracker.util.RegExConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.soarswell.tracker.util.Constants;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(description = Constants.REQUEST_OTP)
public class ValidateOtpRequest {

    @NotBlank(message = "{email.required}")
    @Email(message = "{error.invalid.email}")
    @Pattern(regexp = RegExConstants.EMAIL_PATTERN, message = "{error.invalid.email}")
    @Schema(description = Constants.COMPANY_EMAIL_DESC, example = Constants.COMPANY_EMAIL_EXAMPLE, required = true)
    private String email;

    @Schema(description = Constants.OTP_DESC, example = Constants.OTP_EXAMPLE, required = true)
    @NotBlank(message = "{otp.required}")
    @Pattern(regexp = Constants.OTP_PATTERN, message = "{otp.invalid}")
    private String otp;
}