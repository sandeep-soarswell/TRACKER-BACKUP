package com.soarswell.tracker.persistance;

public interface IDEntity extends HasId, Entity {

}
