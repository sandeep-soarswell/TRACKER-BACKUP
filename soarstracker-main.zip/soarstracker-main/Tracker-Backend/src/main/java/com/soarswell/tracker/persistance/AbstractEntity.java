package com.soarswell.tracker.persistance;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
@MappedSuperclass
public abstract class AbstractEntity{

    @JsonIgnore public static final String ID_PROPERTY = "id";
    @JsonIgnore public static final String CREATE_DATE_PROPERTY = "createDate";
    @JsonIgnore public static final String CREATED_BY_PROPERTY = "createdBy";
    @JsonIgnore public static final String UPDATE_DATE_PROPERTY = "updateDate";
    @JsonIgnore public static final String UPDATED_BY_PROPERTY = "updatedBy";

    @JsonProperty(ID_PROPERTY)
    @Id
    private String id;

    @JsonProperty(CREATE_DATE_PROPERTY)
    private Date createDate;

    @JsonProperty(CREATED_BY_PROPERTY)
    private String createdBy;

    @JsonProperty(UPDATE_DATE_PROPERTY)
    private Date updateDate;

    @JsonProperty(UPDATED_BY_PROPERTY)
    private String updatedBy;

}
