package com.soarswell.tracker.persistance;

public interface HasId {

    public void setId(String id);

    public String getId();
}
