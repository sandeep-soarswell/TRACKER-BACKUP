package com.soarswell.tracker.model.payload;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EventNotificationResponse {
    private String id;
    private String title;
    private String startTime;
    private boolean read;
}