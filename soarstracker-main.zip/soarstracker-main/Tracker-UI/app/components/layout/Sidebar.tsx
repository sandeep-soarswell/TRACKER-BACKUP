import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router';
import { useNavigate } from "react-router";
import { DescriptionIcon, ChevronLeftIcon, ChevronRightIcon } from '~/components/ui/Icons';

import { getSidebarItems } from '~/auth/rbac';


const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [navItems, setNavItems] = useState<ReturnType<typeof getSidebarItems>>([]);
  const navigate = useNavigate();
  const location = useLocation();
  useEffect(() => {
    const items = getSidebarItems();
    setNavItems(items);
  }, []);

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };
  return (
    <aside
      className={`bg-[#0A2463] text-white transition-all duration-300 ease-in-out ${collapsed ? 'w-20' : 'w-64'
        } h-screen flex flex-col`}
    >
      <div className="flex items-center justify-between p-4 border-b border-blue-800">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <Link to="/dashboard" className="flex items-center space-x-2 pl-6">
              <span className="font-bold text-xl cursor-pointer">TRACKER</span>
            </Link>
          </div>
        )}
        {collapsed && (
          <DescriptionIcon className="text-white mx-auto" sx={{ fontSize: 24 }} />
        )}
        <button
          onClick={toggleSidebar}
          className="p-1 rounded-full hover:bg-blue-800 transition-colors duration-200"
        >
          {collapsed ? (
            <ChevronRightIcon sx={{ fontSize: 18 }} className="cursor-pointer" />
          ) : (
            <ChevronLeftIcon sx={{ fontSize: 18 }} className="cursor-pointer" />
          )}
        </button>
      </div>

      <nav className="flex-1 py-4">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.name}>
              <Link
                to={item.path}
                className={`flex items-center py-3 px-4 ${location.pathname === item.path
                    ? 'bg-blue-800 text-white'
                    : 'text-blue-100 hover:bg-blue-900'
                  } transition-colors duration-200 cursor-pointer ${collapsed ? 'justify-center' : 'justify-start'
                  }`}
              >
                <span className="inline-block">{item.icon}</span>
                {!collapsed && <span className="ml-3">{item.name}</span>}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};
export default Sidebar;
