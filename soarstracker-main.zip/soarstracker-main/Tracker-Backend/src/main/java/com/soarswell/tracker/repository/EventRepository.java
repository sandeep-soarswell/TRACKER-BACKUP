package com.soarswell.tracker.repository;

import com.soarswell.tracker.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Repository
public interface EventRepository extends JpaRepository<Event, String> {

    List<Event> findAllByCreatedBy(String createdBy);

    // This method is used by the scheduled emailer
    List<Event> findByDateAndStartTimeBetweenAndNotificationSentFalse(LocalDate date, LocalTime startTime, LocalTime endTime);

    // Add this new method for the API endpoint
    List<Event> findByDateAndStartTimeBetween(LocalDate date, LocalTime startTime, LocalTime endTime);
}