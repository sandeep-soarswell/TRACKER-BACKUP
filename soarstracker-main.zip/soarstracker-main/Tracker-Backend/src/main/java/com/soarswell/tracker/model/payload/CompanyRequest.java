package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;
import com.soarswell.tracker.util.RegExConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Request object for creating or updating a company")
public class CompanyRequest {

    @NotBlank(message = Constants.VALIDATION_COMPANY_NAME_REQUIRED)
    @Pattern(regexp = RegExConstants.COMPANY_NAME_PATTERN, message = Constants.COMPANY_NAME_VALIDATION)
    @Schema(description = Constants.COMPANY_NAME_DESC, example = Constants.COMPANY_NAME_EXAMPLE, required = true)
    private String companyName;

    @NotBlank(message = Constants.VALIDATION_COMPANY_EMAIL_REQUIRED)
    @Email(message = Constants.VALIDATION_COMPANY_EMAIL_INVALID)
    @Schema(description = Constants.COMPANY_EMAIL_DESC, example = Constants.COMPANY_EMAIL_EXAMPLE, required = true)
    private String emailId;

    @Schema(description = Constants.COMPANY_ADDRESS_DESC, example = Constants.COMPANY_ADDRESS_EXAMPLE)
    private String companyAddress;

    @Pattern(regexp = RegExConstants.R_NO, message = Constants.VALIDATION_REGISTRATION_NUMBER)
    @Schema(description = Constants.COMPANY_REG_NO_DESC, example = Constants.COMPANY_REG_NO_EXAMPLE)
    private String companyRegNo;

    @NotBlank(message = Constants.VALIDATION_COMPANY_MOBILE_REQUIRED)
    @ValidPhoneNumber(message = "{invalid.mobile.number}")
    @Schema(description = Constants.COMPANY_MOBILE_DESC, example = Constants.COMPANY_MOBILE_EXAMPLE, required = true)
    private String mobileNo;

    @Schema(description = Constants.COMPANY_ALT_MOBILE_DESC, example = Constants.COMPANY_ALT_MOBILE_EXAMPLE)
    @ValidPhoneNumber(message = "{invalid.alternate.mobile.number}")
    private String alternateNo;

    @NotBlank(message = Constants.VALIDATION_CONTACT_EMAIL_REQUIRED)
    @Email(message = Constants.VALIDATION_CONTACT_EMAIL_INVALID)
    @Schema(description = Constants.CONTACT_EMAIL_DESC, example = Constants.CONTACT_EMAIL_EXAMPLE, required = true)
    private String personalMailId;

}

