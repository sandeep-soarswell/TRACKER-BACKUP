package com.soarswell.tracker.database;
import com.soarswell.tracker.config.PasswordEncoder;
import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.Roles;
import com.soarswell.tracker.model.User;
import com.soarswell.tracker.model.role.RoleCategoryType;
import com.soarswell.tracker.model.role.RoleEntity;
import com.soarswell.tracker.model.role.RoleUsageType;
import com.soarswell.tracker.model.role.SystemRoles;
import com.soarswell.tracker.repository.UserRepository;
import com.soarswell.tracker.util.Constants;
import com.soarswell.tracker.util.ResourceIdUtils;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.*;

@Component
public class ApplicationDataInitializer {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationDataInitializer.class);
    @Autowired
    private Environment environment;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostConstruct
    public void initialize() throws TrackerException {
        createRolesAndUsers();
    }

    private void createRolesAndUsers() {
        Collection<RoleEntity> roles = createAndGetRoles();
        Optional<RoleEntity> roleEntity = roles.stream().filter(r ->
                (r.getUsage().equalsIgnoreCase(RoleUsageType.INTERNAL.name())
                        && (r.getName().equalsIgnoreCase(SystemRoles.SYSTEM_ADMIN.roleName())))).findFirst();
        if (roleEntity.isEmpty()) {
            logger.error("System role not available.");
            throw new TrackerException(ErrorMessageHandler.getMessage(ErrorMessageKey.SYSTEM_ROLE_NOT_AVAILABLE.name()),HttpStatus.BAD_REQUEST);
        }
        createAdminUser(roleEntity.get());
    }

    private Collection<RoleEntity> createAndGetRoles() {
        logger.info("Creating roles");
        return Arrays.stream(SystemRoles.values())
                .filter(r -> r != SystemRoles.UNDEFINED)
                .map(this::createRole)
                .toList();
    }

    private RoleEntity createRole(SystemRoles systemRoles) {
        logger.info("Creating role with name : {}", systemRoles.roleName());

        return RoleEntity.builder()
                .id(systemRoles.id())
                .name(systemRoles.roleName())
                .desc("")
                .usage(systemRoles.usageType().name())
                .categoryType(RoleCategoryType.SYSTEM_DEFINED.getCategory())
                .permissions(systemRoles.permissionsLabel())
                .build();
    }

    private void createAdminUser(RoleEntity roleEntity) {
        logger.info("Creating Tracker admin user");
        String firstName = environment.getProperty(Constants.SYS_ADMIN_FIRSTNAME);
        String lastName = environment.getProperty(Constants.SYS_ADMIN_LASTNAME);
        String userName = environment.getProperty(Constants.SYS_ADMIN_USERNAME);
        String password = environment.getProperty(Constants.SYS_ADMIN_PASSWORD);
        String createdBy=environment.getProperty(Constants.SYSTEM);
        if (userRepository.existsByEmail(userName)) {
            logger.info("Admin user already exists with email: {}", userName);
        } else if(password!=null) {
            User user = User.builder()
                    .id(ResourceIdUtils.generateSuperAdminResourceId(Constants.SUPER_ADMIN_MAIL))
                    .createDate(new Date(Instant.now().toEpochMilli()))
                    .email(userName)
                    .companyId("-1")
                    .firstName(firstName)
                    .lastName(lastName)
                    .phoneNumber(Constants.PHONE)
                    .createdBy(createdBy)
                    .companyName(createdBy)
                    .password(passwordEncoder.encode( new String(Base64.getDecoder().decode(password.getBytes()))))
                    .role(Roles.SUPER_ADMIN.getLongLabel())
                    .build();
            logger.info("role===> {}",user.getRole());
            userRepository.save(user);
        }
    }
}