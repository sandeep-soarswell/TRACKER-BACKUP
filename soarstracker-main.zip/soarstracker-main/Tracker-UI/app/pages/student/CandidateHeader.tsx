import React, { useState, useEffect } from 'react';
import { ChevronLeftIcon, EditIcon, VisibilityIcon } from '~/components/ui/Icons';
import { type Candidate, type CandidateStatus } from '~/pages/types/types';
import StatusBadge from './StatusBadge';
import Button from '~/components/ui/Button';
import { Link } from 'react-router';
import candidateService from '~/services/candidate/candidate.service';
import CandidateDetailsDrawer from '../candidate/CandidateDetailsDrawer';
import CustomSnackbar from '~/components/ui/Customsnackbar';
import { Autocomplete, TextField, Tooltip } from '@mui/material';
import { fetchCandidatureStatuses, getCanonicalStatus } from '../candidate/CandidateUtils';
import { jwtDecode } from 'jwt-decode';

interface CandidateHeaderProps {
  candidate: Candidate;
  onStatusUpdate: (updatedCandidate: Candidate) => void;
}

const CandidateHeader: React.FC<CandidateHeaderProps> = ({
  candidate,
  onStatusUpdate
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [newStatus, setNewStatus] = useState<CandidateStatus>(candidate.candidatureStatus);
  const [isUpdating, setIsUpdating] = useState(false);
  const [showDetailsDrawer, setShowDetailsDrawer] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'error'>('success');
  const [availableStatuses, setAvailableStatuses] = useState<string[]>([]);
  const [acceptedPackage, setAcceptedPackage] = useState<string>(candidate.acceptedPackage || '');

  useEffect(() => {
    fetchCandidatureStatuses().then(statuses => {
      setAvailableStatuses(statuses);
    });
  }, []);

  const handleStatusChange = async () => {
    if (newStatus === candidate.candidatureStatus && acceptedPackage === candidate.acceptedPackage) {
      setIsEditing(false);
      return;
    }
    setIsUpdating(true);
    try {
      const payload: any = { candidatureStatus: newStatus };
      if ((newStatus || '').toLowerCase() === 'hired' && acceptedPackage) {
        if (!acceptedPackage.toLowerCase().includes('lpa')) {
          payload.acceptedPackage = acceptedPackage.concat(' LPA');
        } else {
          payload.acceptedPackage = acceptedPackage.replace(/ lpa$/i, ' LPA');
        }
      }

      const res = await candidateService.updateStatus(candidate.id, payload);

      const updatedCandidate = { ...candidate, ...payload };
      onStatusUpdate(updatedCandidate);
      setIsEditing(false);
      console.log('Status updated successfully:', res);
      setSnackbarMessage(res || 'Status updated successfully.');
      setSnackbarSeverity('success');
      setSnackbarOpen(true);
    } catch (error: any) {
      const backendMessage = error?.response?.data?.error?.message || 'Failed to update candidate.';
      setSnackbarMessage(backendMessage);
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    } finally {
      setIsUpdating(false);
    }
  };

  const isHired = (newStatus || '').toLowerCase() === 'hired';
  const token = localStorage.getItem('userToken');
  const decodedToken = jwtDecode<any>(token || '');
  const loggeduserId = decodedToken.userId;
  const role = decodedToken.roles[0];

  console.log(loggeduserId, candidate.userId);

  return (
    <div className="rounded-xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl">
      <div className="bg-[#0A2463] p-6 text-white">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Link 
              to="/dashboard/candidates" 
              className="text-white hover:text-blue-200 transition-colors mr-3 p-1 rounded-lg hover:bg-white/10"
              title="Back to Candidates"
            >
              <ChevronLeftIcon sx={{ fontSize: 24 }} />
            </Link>
            <div>
              <h1 className="text-2xl font-bold mb-1">
                {`${candidate.firstName} ${candidate.middleName || ''} ${candidate.lastName}`}
              </h1>
            </div>
          </div>
          
          <div className="flex gap-2">
            {((role === 'COMPANY_ADMIN' || role === 'MANAGER') || (candidate.userId === loggeduserId && candidate.candidatureStatus.toLowerCase() !== 'hired')) &&  (
            <Tooltip title="Edit Status" arrow>
              <button
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-2 bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-lg transition-all duration-200 hover:shadow-md hover:scale-105 active:scale-95 cursor-pointer"
              >
                <EditIcon sx={{ fontSize: 18 }} />
                <span className="font-medium">Edit Status</span>
              </button>
            </Tooltip>
            )}
            <Tooltip title="View Candidate Details" arrow>
              <button
                onClick={() => setShowDetailsDrawer(true)}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all duration-200 hover:shadow-md hover:scale-105 active:scale-95 cursor-pointer"
              >
                <VisibilityIcon sx={{ fontSize: 18 }} />
                <span className="font-medium">View Details</span>
              </button>
            </Tooltip>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="flex flex-col">
            <span className="text-white text-xs uppercase font-semibold tracking-wide mb-1">
              Job Title
            </span>
            <span className="font-semibold text-lg">
              {candidate.jobTitle}
            </span>
            <span className="text-white text-sm mt-0.5">
              {candidate.jobId}
            </span>
          </div>

          <div className="flex flex-col">
            <span className="text-white text-xs uppercase font-semibold tracking-wide mb-1">
              Client Name
            </span>
            <span className="font-semibold text-lg">
              {candidate.clientName}
            </span>
          </div>

          <div className="flex flex-col">
            <span className="text-white text-xs uppercase font-semibold tracking-wide mb-1">
              Status
            </span>
            {isEditing ? (
              <div className="flex flex-col gap-2">
                <Autocomplete
                  freeSolo
                  options={availableStatuses}
                  value={newStatus}
                  className='w-32 h-8 mb-2'
                  onChange={(event, newValue) => {
                    setNewStatus(getCanonicalStatus(newValue as string) as CandidateStatus);
                  }}
                  onInputChange={(event, newInputValue) => {
                    setNewStatus(getCanonicalStatus(newInputValue) as CandidateStatus);
                  }}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      size="small"
                      placeholder="Enter or select status"
                      sx={{ backgroundColor: 'white', borderRadius: 1, minWidth: 200 }}
                    />
                  )}
                />

                {(isHired || candidate.candidatureStatus.toLowerCase() === 'hired') && (
                  <TextField
                    value={acceptedPackage}
                    onChange={(e) => setAcceptedPackage(e.target.value)}
                    placeholder="Enter package in LPA"
                    size="small"
                    sx={{
                      backgroundColor: 'white',
                      borderRadius: 1,
                      minWidth: 200,
                      minHeight: 40
                    }}
                    className='w-32 h-8'
                  />
                )}

                <div className="flex gap-2">
                  <Button
                    variant="success"
                    size="sm"
                    onClick={handleStatusChange}
                    isLoading={isUpdating}
                    disabled={!newStatus.trim() || (isHired && !acceptedPackage.trim())}
                  >
                    Save
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setNewStatus(candidate.candidatureStatus);
                      setAcceptedPackage(candidate.acceptedPackage || '');
                      setIsEditing(false);
                    }}
                    className="!bg-white/20 !text-white !border-white/30 hover:!bg-white/30"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <StatusBadge
                  CandidateStatus={candidate.candidatureStatus}
                  className="bg-white/10 px-2 py-1 rounded text-white"
                  animate
                />
                {candidate.candidatureStatus.toLowerCase() === 'hired' && (
                  <span className="text-white text-sm font-medium">
                    Package: {candidate.acceptedPackage || 'Not set'}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      {showDetailsDrawer && (
        <CandidateDetailsDrawer
          candidate={candidate}
          open={showDetailsDrawer}
          onClose={() => setShowDetailsDrawer(false)}
        />
      )}
      <CustomSnackbar
        open={snackbarOpen}
        message={snackbarMessage}
        severity={snackbarSeverity}
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={4000}
      />
    </div>
  );
};
export default CandidateHeader;