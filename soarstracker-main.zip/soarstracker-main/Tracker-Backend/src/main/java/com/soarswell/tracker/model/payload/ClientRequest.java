package com.soarswell.tracker.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.soarswell.tracker.util.RegExConstants;
import com.soarswell.tracker.util.TrackerUtils.ValidPhoneNumber;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientRequest {

    @Schema(example = "Soarswell Technologies")
    @NotBlank(message = "{client.name.notnull.message}")
    @Size(min = 3, max = 50, message = "{client.name.size.message}")
    @Pattern(
            regexp = RegExConstants.COMPANY_NAME_PATTERN,
            message = "{client.name.pattern.message}"
    )
    private String clientName;

    @Schema(example = "123, Tech Park Road, Hyderabad, India")
    @NotBlank(message = "{client.address.notnull.message}")
    @Size(min = 5, max = 100, message = "{client.address.size.message}")
    private String address;

    @Schema(example = "John Smith")
    @NotBlank(message = "{client.contactPersonName.notnull.message}")
    @Size(min = 3, max = 25, message = "{client.contactPersonName.size.message}")
    @Pattern(
            regexp = RegExConstants.NAME_PATTERN,
            message = "{client.contactPersonName.pattern.message}"
    )
    private String contactPersonName;

    @Schema(example = "9876543210")
    @NotBlank(message = "{client.contactNumber.notnull.message}")
    @ValidPhoneNumber(message = "{invalid.mobile.number}")
    private String contactPersonNumber;

    @Schema(example = "john@example.com")
    @NotBlank(message = "{client.email.notnull.message}")
    @Email(message = "{client.email.pattern.message}")
    private String email;

    @Schema(example = "https://soarswell.com")
    @NotBlank(message = "{client.website.notnull.message}")
    @Pattern(
            regexp = RegExConstants.WEBSITE,
            message = "{client.website.pattern.message}"
    )
    private String website;

    @Schema(example = "India")
    @NotBlank(message = "{country.notnull}")
    @Pattern(regexp = RegExConstants.COUNTRY_PATTERN,
            message = "{invalid.country.pattern}"
    )
    @Size(min = 2, max = 50, message = "{country.size.message}")
    private String country;

    @Schema(example = "Telangana")
    @Pattern(regexp = RegExConstants.STATE_PATTERN, message = "{invalid.state.pattern}")
    private String state;

    @Schema(example = "500081")
    @Pattern(regexp = RegExConstants.ZIPCODE_PATTERN,message = "{invalid.zipCode.pattern}")
    private String zipCode;

    @Schema(example = "30")
    @Min(value = 0, message = "{cooling.period.min.message}")
    private Integer coolingPeriod;

}