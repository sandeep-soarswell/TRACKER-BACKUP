import equalsIgnoreCase from  './util.services'

const getChangedFields=(
  original: Record<string, any>,
  updated: Record<string, any>
): Record<string, any> =>{
  const changes: Record<string, any> = {};

  for (const key in updated) {
    if (!Object.prototype.hasOwnProperty.call(updated, key)) continue;

    const originalValue = original?.[key];
    const updatedValue = updated?.[key]; 
    const flag=typeof updatedValue=== typeof null

    if(originalValue==="" && updatedValue===null)continue
    if(flag){changes[key]=""; continue}

    if (updatedValue==undefined || updatedValue === "" || updatedValue===" ") continue;

    if (!equalsIgnoreCase(String(originalValue),String(updatedValue))) {
      changes[key] = updatedValue;
    }
  }

  return changes;
}

export default getChangedFields;