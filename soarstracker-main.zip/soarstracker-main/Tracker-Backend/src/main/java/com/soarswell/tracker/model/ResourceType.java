package com.soarswell.tracker.model;

import com.soarswell.tracker.exception.ErrorMessageHandler;
import com.soarswell.tracker.exception.ErrorMessageKey;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.util.Constants;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;

@AllArgsConstructor
@Getter
public enum ResourceType {

    ADMIN("admin", Constants.ADMIN),
    TRACKER_ADMIN("tracker_admin", Constants.TRACKER_ADMIN),
    COMPANY("Company", Constants.COMPANY),
    COMPANY_ADMIN("cadmin",Constants.COMPANY_ADMIN),
    MANAGER("manager", Constants.MANAGER),
    RECRUITER("recruiter",Constants.RECRUITER),
    CANDIDATE("Candidate",Constants.CANDIDATE),
    JOB("Job",Constants.JOB),
    CLIENT("Client",Constants.CLIENT_TAG),
    UNDEFINED("", ""),
    COMMENT("COMMENT",Constants.COMMENT ),
    EVENT("EVENT",Constants.EVENT ),
    CANDIDATE_JOB("candidate-job",Constants.CANDIDATE_JOB),
    CANDIDATE_USER("candidate-user",Constants.CANDIDATE_USER),
    CILENT_COMMENT("Client-Comment", Constants.CLIENT_COMMENT);

    private final String value;
    private final String persistValue;

    public String value() {
        return this.value;
    }

    public String persistValue() {
        return this.persistValue;
    }

    public static ResourceType fromValue(final String value) throws TrackerException {
        ResourceType type = byValue(value);
        if (type != UNDEFINED)
            return type;
        throw new TrackerException(
                String.format(ErrorMessageHandler.getMessage(ErrorMessageKey.INVALID_RESOURCE_TYPE.name()), value),
                HttpStatus.BAD_REQUEST);
    }

    public static ResourceType byValue(final String value) {
        if (StringUtils.isNotEmpty(value)) {
            for (ResourceType type : values()) {
                if (value.equalsIgnoreCase(type.name())
                        || value.equalsIgnoreCase(type.value())
                        || value.equalsIgnoreCase(type.persistValue())) {
                    return type;
                }
            }
        }
        return UNDEFINED;
    }
}