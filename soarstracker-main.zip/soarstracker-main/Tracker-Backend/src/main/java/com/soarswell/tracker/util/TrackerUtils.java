package com.soarswell.tracker.util;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;
import java.util.Arrays;

public class TrackerUtils {

    @Documented
    @Constraint(validatedBy = PhoneNumberValidator.class)
    @Target({ElementType.FIELD})
    @Retention(RetentionPolicy.RUNTIME)
    public @interface ValidPhoneNumber {
        String message() default "Invalid phone number";
        Class<?>[] groups() default {};
        Class<? extends Payload>[] payload() default {};
    }

    public static boolean isValidFieldInClass(String fieldName,Class<?> currentClass) {
        while (currentClass != null) {
            boolean isValid = Arrays.stream(currentClass.getDeclaredFields())
                    .anyMatch(field -> field.getName().equalsIgnoreCase(fieldName));
            if (isValid) {
                return true;
            }
            currentClass = currentClass.getSuperclass();
        }
        return false;
    }
}