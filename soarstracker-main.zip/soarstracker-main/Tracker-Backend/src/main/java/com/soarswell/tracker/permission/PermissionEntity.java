package com.soarswell.tracker.permission;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.soarswell.tracker.persistance.IDEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

/**
 * Entity for the Permission
 */
@Getter
@Setter
@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PermissionEntity implements IDEntity {

    @JsonIgnore public static final String ID_PROPERTY              = "id";
    @JsonIgnore public static final String NAME_PROPERTY            = "name";
    @JsonIgnore public static final String TYPE_PROPERTY            = "type";
    @JsonIgnore public static final String SHORT_LABEL_PROPERTY     = "shortLabel";
    @JsonIgnore public static final String STATUS_PROPERTY          = "status";

    @JsonProperty(ID_PROPERTY)
    private String id;

    @JsonProperty(NAME_PROPERTY)
    private String name;

    @JsonProperty(TYPE_PROPERTY)
    private String type;

    @JsonProperty(SHORT_LABEL_PROPERTY)
    private String shortLabel;

    @JsonProperty(STATUS_PROPERTY)
    private String status;

}
