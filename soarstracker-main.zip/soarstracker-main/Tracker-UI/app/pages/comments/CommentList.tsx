import React, { useEffect, useRef } from 'react';
import type { Comment } from '~/pages/types/types';
import CommentItem from './CommentItem';

interface CommentListProps {
  comments: Comment[];
  newCommentIds: Set<string>;
  isLoading?: boolean;
}

const CommentList: React.FC<CommentListProps> = ({
  comments,
  newCommentIds,
  isLoading = false,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (newCommentIds.size > 0 && scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = 0;
    }
  }, [newCommentIds]);

  if (isLoading) {
    return <div className="py-8 text-center">Loading comments...</div>;
  }

  const filteredComments = comments.filter(
    (comment) => comment.id && comment.content?.trim() !== ''
  );

  if (filteredComments.length === 0) {
    return (
      <div className="py-8 text-center">
        <p className="text-gray-500">No comments yet. Be the first to add one!</p>
      </div>
    );
  }

  const sortedComments = [...filteredComments].sort((a, b) => {
    const aTime = new Date(a.createDate).getTime();
    const bTime = new Date(b.createDate).getTime();
    return bTime - aTime;
  });

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-medium text-gray-800 mb-4">
        Comments ({filteredComments.length})
      </h2>

      <div
        ref={scrollContainerRef}
        className="space-y-4 h-[calc(100vh-132px)] overflow-y-auto pr-2"
      >
        {sortedComments.map((comment) => (
          <div key={comment.id}>
            <CommentItem comment={comment} isNew={newCommentIds.has(comment.id)} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommentList;