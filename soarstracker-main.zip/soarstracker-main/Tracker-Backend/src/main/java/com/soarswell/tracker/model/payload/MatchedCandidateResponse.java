package com.soarswell.tracker.model.payload;

import com.soarswell.tracker.model.Candidate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MatchedCandidateResponse {

    private int suitabilityScore;
    private Candidate candidate; // Contains all original candidate details

    public MatchedCandidateResponse(Candidate candidate, int suitabilityScore) {
        this.candidate = candidate;
        this.suitabilityScore = suitabilityScore;
    }
}