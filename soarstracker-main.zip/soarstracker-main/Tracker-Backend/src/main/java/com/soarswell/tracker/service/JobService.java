package com.soarswell.tracker.service;

import com.soarswell.tracker.common.RequestDetails;
import com.soarswell.tracker.model.payload.JobRequest;
import com.soarswell.tracker.exception.TrackerException;
import com.soarswell.tracker.model.payload.JobUpdateRequest;
import com.soarswell.tracker.model.payload.MatchedCandidateResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


public interface JobService {

    public ResponseEntity<?> createJob(JobRequest jobRequest, String clientId,RequestDetails requestDetails) throws TrackerException;

    public ResponseEntity<?> getJobsByClientId(String clientId,int page,int size,String sortByField,String order,String keyword,String filter) throws TrackerException;

    public ResponseEntity<?> getJob(String id) throws TrackerException;

    public ResponseEntity<?> deleteJob(String id);

    public ResponseEntity<?> getUsersByJobId(String jobId) throws TrackerException;

    public ResponseEntity<?> updateJob(String jobId, JobUpdateRequest jobUpdateRequest, RequestDetails requestDetails) throws TrackerException;

    public ResponseEntity<?> getCandidatesByJobId(String jobId) throws TrackerException;

    public ResponseEntity<?> getCandidatesByJobIdWithSkills(String id,RequestDetails requestDetails);

    public ResponseEntity<?> JobAssignToCandidate(String candidateId,String userId,RequestDetails requestDetails) throws TrackerException;

    public ResponseEntity<?> JobAssignToUser(String recruiterId,String jobId) throws TrackerException;

    public ResponseEntity<?> JobUnassignFromCandidate(String candidateId, String jobId) throws TrackerException;

    public ResponseEntity<?> JobUnassignFromUser(String userId, String jobId) throws TrackerException;

    public ResponseEntity<?> getUpcomingJobDeadlineNotifications(RequestDetails requestDetails) throws TrackerException;

    public ResponseEntity<?> markNotificationAsRead(String jobId, RequestDetails requestDetails) throws TrackerException;

    public ResponseEntity<?> uploadjobs(MultipartFile file,  RequestDetails requestDetails, String clientId);
    public List<MatchedCandidateResponse> findMatchingCandidates(String jobId);

}