import { GroupIcon, DashboardIcon, GroupsIcon, Groups2Icon, LocationCityIcon, FormatListNumberedIcon, AccountCircleIcon, BusinessCenterIcon, SettingsIcon, CalendarMonthIcon } from '~/components/ui/Icons';
import { jwtDecode } from "jwt-decode";
import type { JSX } from "react";

export type ProtectedRoute = {
  name: string;
  icon: JSX.Element;
  path: string;
  roles: string[];
};

const matchPath = (pattern: string, path: string): boolean => {
  if (pattern === path) return true;
  if (pattern.endsWith('/*') && path.startsWith(pattern.slice(0, -2))) {
    return true;
  }
  const patternParts = pattern.split('/').filter(p => p);
  const pathParts = path.split('/').filter(p => p);

  if (patternParts.length !== pathParts.length) {
    return false;
  }
  for (let i = 0; i < patternParts.length; i++) {
    const patternPart = patternParts[i];
    const pathPart = pathParts[i];
    if (patternPart.startsWith(':')) {
      continue;
    }
    if (patternPart !== pathPart) {
      return false;
    }
  }
  return true;
};

export const protectedRoutes: ProtectedRoute[] = [
  {
    name: "Dashboard",
    icon: <DashboardIcon fontSize="small" />,
    path: "/dashboard",
    roles: ["company_admin", "manager", "recruiter", "employee", "sys_admin"],
  },
   {
    name: "Companies",
    icon: <LocationCityIcon fontSize="small" />,
    path: "/dashboard/companies",
    roles: ["SYS_ADMIN"],
  },
  {
    name: "Clients",
    icon: <GroupsIcon fontSize="small" />,
    path: "/dashboard/clients",
    roles: ["COMPANY_ADMIN", "RECRUITER", "MANAGER"],
  },
   {
    name: "Jobs",
    icon: <BusinessCenterIcon fontSize="small" />,
    path: "/dashboard/jobs",
    roles: ["COMPANY_ADMIN", "RECRUITER", "MANAGER"],
  },
  {
    name: "Assign Job Status",
    icon: <></>,
    path: "/dashboard/jobs/assign-status",
    roles: ["COMPANY_ADMIN", "RECRUITER", "MANAGER"],
  },
  {
    name: "Client comments",
    icon: <></>,
    path: "/dashboard/clientcomments",
    roles: ["COMPANY_ADMIN", "RECRUITER", "MANAGER"],
  },
  {
    name: "Employee Assignments",
    icon: <></>,
    path: "/dashboard/employee/assignes",
    roles: ["COMPANY_ADMIN", "RECRUITER", "MANAGER"],
  },
  {
    name: "Employee Candidates",
    icon: <></>,
    path: "/dashboard/employee/candidates",
    roles: ["COMPANY_ADMIN", "RECRUITER", "MANAGER"],
  },
  {
    name: "Employees",
    icon: <GroupIcon fontSize="small" />,
    path: "/dashboard/users",
    roles: ["COMPANY_ADMIN", "MANAGER"],
  },
 
  {
    name: "Candidates",
    icon: <Groups2Icon fontSize="small" />,
    path: "/dashboard/candidates",
    roles: ["COMPANY_ADMIN", "RECRUITER", "MANAGER"],
  },
  {
    name: "Candidate Details",
    icon: <></>,
    path: "/dashboard/comments",
    roles: ["COMPANY_ADMIN", "RECRUITER", "MANAGER"],
  },
  
   {
    name: "Calendar",
    icon: <CalendarMonthIcon fontSize="small" />,
    path: "/dashboard/calendar",
    roles: ["COMPANY_ADMIN", "RECRUITER", "MANAGER"],
  },
 
  {
    name: "My Profile",
    icon: <AccountCircleIcon fontSize="small" />,
    path: "/dashboard/profile",
    roles: ["COMPANY_ADMIN", "SYS_ADMIN", "RECRUITER", "MANAGER"],
  },
  {
    name: "Settings",
    icon: <SettingsIcon fontSize="small" />,
    path: "/dashboard/settings",
    roles: ["COMPANY_ADMIN", "SYS_ADMIN", "RECRUITER", "MANAGER"],
  },
  {
    name: "Recruiter Leaderboard",
    icon: <FormatListNumberedIcon fontSize="small" />,
    path: "/dashboard/recruiter-leaderboard",
    roles: ["COMPANY_ADMIN", "MANAGER"],
  }
];

export const getUserRolesFromToken = (): string[] => {
  if (typeof window === "undefined") {
    return [];
  }
  const token = localStorage.getItem("userToken");
  if (!token) return [];
  try {
    const decoded: any = jwtDecode(token);
    return Array.isArray(decoded?.roles)
      ? decoded.roles.map((role: string) => role.toLowerCase())
      : [];
  } catch (err) {
    return [];
  }
};

export const getSidebarItems = (): ProtectedRoute[] => {
  const userRoles = getUserRolesFromToken();
  return protectedRoutes
    .filter((route) =>
      route.roles.some((role) => userRoles.includes(role.toLowerCase()))
    )
    .filter((route) => ![
      "My Profile",
      "Settings",
      "Candidate Details",
      "Assign Job Status",
      "Client comments",
      "Employee Assignments",
      "Employee Candidates"
    ].includes(route.name));
};

export const isRouteAccessible = (path: string): boolean => {
  const userRoles = getUserRolesFromToken();
  const route = protectedRoutes.find((r) => matchPath(r.path, path));
  if (!route) {
    return false;
  }
  return route.roles.some((role) => userRoles.includes(role.toLowerCase()));
};